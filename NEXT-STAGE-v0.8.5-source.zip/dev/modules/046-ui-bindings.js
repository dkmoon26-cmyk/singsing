/* FILE src/ui-bindings.js */
'use strict';
// Final screen ownership. Feature helpers have unique names; no global overwrites.
const UI_IMPLEMENTATIONS = Object.freeze({
  home: home_evolution,
  artistModal: artistModal_evolution,
  inbox: inbox_campaign,
  charts: charts_season,
  scheduleEvents: scheduleEvents_season,
  projects: projects_season,
  reportDetail: reportDetail_season,
  finance: finance_campaign,
  projectModal: projectModal_evolution,
  budgetPreview: budgetPreview_season,
  settings: settings_evolution,
  unitModal: unitModal_evolution,
  mutate: mutate_evolution,
  talentModal: talentModal_operations,
  staffScreen: staffScreen_evolution,
  training: training_operations,
  teams: teams_evolution,
  company: company_market,
  industry: industry_progression,
  goals: goals_evolution,
  managementClick: dispatchManagementAction,
  schedule: schedule_operations,
  applyRestore: applyRestore_dayfeedback,
  todayTasks: todayTasks_season,
  releaseModal: releaseModal_season,
  showAdvanceNotice: showAdvanceNotice_evolution,
  staffDetail: staffDetail_campaign,
  traineeDetail: traineeDetail_evolution
});
function home(... args) {
  return UI_IMPLEMENTATIONS.home(... args);
}
function artistModal(... args) {
  return UI_IMPLEMENTATIONS.artistModal(... args);
}
function reportDetail(... args) {
  return UI_IMPLEMENTATIONS.reportDetail(... args);
}
function finance(... args) {
  return UI_IMPLEMENTATIONS.finance(... args);
}
function projectModal(... args) {
  return UI_IMPLEMENTATIONS.projectModal(... args);
}
function budgetPreview(... args) {
  return UI_IMPLEMENTATIONS.budgetPreview(... args);
}
function settings(... args) {
  return UI_IMPLEMENTATIONS.settings(... args);
}
function unitModal(... args) {
  return UI_IMPLEMENTATIONS.unitModal(... args);
}
function mutate(... args) {
  return UI_IMPLEMENTATIONS.mutate(... args);
}
function talentModal(... args) {
  return UI_IMPLEMENTATIONS.talentModal(... args);
}
function staffScreen(... args) {
  return UI_IMPLEMENTATIONS.staffScreen(... args);
}
function training(... args) {
  return UI_IMPLEMENTATIONS.training(... args);
}
function teams(... args) {
  return UI_IMPLEMENTATIONS.teams(... args);
}
function company(... args) {
  return UI_IMPLEMENTATIONS.company(... args);
}
function industry(... args) {
  return UI_IMPLEMENTATIONS.industry(... args);
}
function goals(... args) {
  return UI_IMPLEMENTATIONS.goals(... args);
}
function managementClick(... args) {
  return UI_IMPLEMENTATIONS.managementClick(... args);
}
function schedule(... args) {
  return UI_IMPLEMENTATIONS.schedule(... args);
}
function applyRestore(... args) {
  return UI_IMPLEMENTATIONS.applyRestore(... args);
}
function todayTasks(... args) {
  return UI_IMPLEMENTATIONS.todayTasks(... args);
}
function releaseModal(... args) {
  return UI_IMPLEMENTATIONS.releaseModal(... args);
}
function showAdvanceNotice(... args) {
  return UI_IMPLEMENTATIONS.showAdvanceNotice(... args);
}
function staffDetail(... args) {
  return UI_IMPLEMENTATIONS.staffDetail(... args);
}
function traineeDetail(... args) {
  return UI_IMPLEMENTATIONS.traineeDetail(... args);
}
function inbox(... args) {
  return UI_IMPLEMENTATIONS.inbox(... args);
}
function projects(... args) {
  return UI_IMPLEMENTATIONS.projects(... args);
}
function charts(... args) {
  return UI_IMPLEMENTATIONS.charts(... args);
}
function scheduleEvents(... args) {
  return UI_IMPLEMENTATIONS.scheduleEvents(... args);
}


;
