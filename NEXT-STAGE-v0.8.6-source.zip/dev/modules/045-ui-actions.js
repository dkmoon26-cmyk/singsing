/* FILE src/ui-actions.js */
'use strict';
// Unique action IDs. Add new actions here; feature handlers never chain by script order.
const UI_ACTIONS = Object.freeze({
  "m-festival": managementClick_season,
  "m-chart-scope": managementClick_season,
  "m-chart-more": managementClick_season,
  "m-awards": managementClick_season,
  "m-award-year": managementClick_season,
  "m-inbox-filter": managementClick_campaign,
  "m-inbox-category": managementClick_campaign,
  "m-report-unread": managementClick_campaign,
  "m-renew": managementClick_management,
  "m-debut": managementClick_management,
  "m-release-trainee": managementClick_management,
  "m-leave-confirm": managementClick_management,
  "m-trainee-release": managementClick_management,
  "m-leave": managementClick_management,
  "m-team-confirm": managementClick_management,
  "m-team-apply": managementClick_management,
  "m-team": managementClick_management,
  "m-transfer": managementClick_management,
  "m-transfer-confirm": managementClick_management,
  "m-transfer-apply": managementClick_management,
  "m-saves": managementClick_progression,
  "m-slot-save-confirm": managementClick_progression,
  "m-slot-save": managementClick_progression,
  "m-slot-load": managementClick_progression,
  "m-point-load": managementClick_progression,
  "m-restore-apply": managementClick_progression,
  "m-incident-open": managementClick_progression,
  "m-incident-respond": managementClick_progression,
  "m-slot-delete-confirm": managementClick_market,
  "m-slot-delete": managementClick_market,
  "m-points-clear-confirm": managementClick_market,
  "m-points-clear": managementClick_market,
  "m-release": managementClick_market,
  "m-release-scope": managementClick_market,
  "m-chart": managementClick_market,
  "m-compare-select": managementClick_market,
  "m-compare": managementClick_market,
  "m-reprint": managementClick_market,
  "m-reprint-apply": managementClick_market,
  "m-trainee-filter": managementClick_market,
  "m-personal": managementClick_personality,
  "m-staff-detail": managementClick_operations,
  "m-recruit-filter": managementClick_operations,
  "m-trainee-detail": managementClick_operations,
  "m-growth-range": managementClick_operations,
  "m-calendar-month": managementClick_operations,
  "m-calendar-today": managementClick_operations,
  "m-calendar-day": managementClick_operations,
  "m-calendar-event": managementClick_operations,
  "m-goal-filter": managementClick_evolution,
  "m-skip-moments": managementClick_evolution,
  "m-memory": managementClick_evolution,
  "m-story": managementClick_evolution,
  "m-story-choice": managementClick_evolution,
  "m-moment": managementClick_evolution,
  "m-next-moment": managementClick_evolution,
  "m-moments": managementClick_evolution,
  "m-offer": managementClick_evolution,
  "m-offer-accept": managementClick_evolution,
  "m-all-tasks": managementClick_evolution,
  "m-sound": managementClick_evolution
});
function dispatchManagementAction(action, data) {
  const handler = UI_ACTIONS[action];
  if (!handler) throw Error('지원하지 않는 동작입니다: ' + action);
  return handler(action, data);
}


;
