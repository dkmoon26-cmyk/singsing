import functools,http.server,threading,json,os,tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(os.environ.get('WEB_ROOT',Path(__file__).resolve().parents[1]));temporary=tempfile.TemporaryDirectory(prefix='next-stage-ui-');out=Path(os.environ.get('UI_SCREENSHOT_DIR',temporary.name));out.mkdir(parents=True,exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root)));threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':1440,'height':1050});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle');page.screenshot(path=str(out/'title-desktop.png'),full_page=True)
  page.evaluate('''()=>{game.newGame('루미에르 뮤직','서정훈');game.startCasting('audition','idol','any','career');for(let i=0;i<10;i++)game.nextDay();for(const c of [...game.s.candidates].slice(0,2))game.sign(c.id,'balanced');game.startCasting('audition','idol','any','trainee');for(let i=0;i<10;i++)game.nextDay();game.sign(game.s.candidates.find(c=>DATA.roster[c.id].trainee).id,'balanced');game.startProject(String(game.s.artists[0].id),'cover','첫 번째 봄',200,'balanced');game.s.guideHidden=true;save();navigate('home');}''')
  for width in [1440,1024,768,390,360]:
   page.set_viewport_size({'width':width,'height':1000 if width>600 else 844})
   for menu in ['home','artists','training','casting','projects','finance','schedule','inbox','company','charts','goals','staff']:
    page.evaluate('(p)=>navigate(p)',menu)
    overflow=page.evaluate('document.documentElement.scrollWidth>innerWidth')
    assert not overflow,(width,menu,page.evaluate('document.documentElement.scrollWidth'))
   page.evaluate("navigate('home')");page.wait_for_timeout(200)
   if width in [1440,390]:page.screenshot(path=str(out/f'home-{width}.png'),full_page=True)
  page.set_viewport_size({'width':1440,'height':1000});page.locator('.studio-person').first.click();assert page.locator('[role=dialog]').is_visible();page.screenshot(path=str(out/'artist-desktop.png'));page.keyboard.press('Escape')
  # The new roster must delegate both artist and trainee buttons to real modals.
  page.locator('.studio-person[data-action=m-trainee-detail]').click();assert page.locator('[role=dialog]').is_visible();page.keyboard.press('Escape')
  page.locator('.studio-agenda [data-action=nav]').first.click();assert page.evaluate("page==='schedule'")
  page.evaluate("navigate('home')");page.locator('.studio-archive summary').click();page.locator('#spotlight-select').select_option(page.evaluate('game.entities[1].key'));assert page.locator('.studio-archive').get_attribute('open') is not None
  assert page.locator('button[aria-current=page]').count()>0
  assert not errors,errors
  assert page.evaluate('validState(game.s) && saveOK')
  print('PASS responsive layout: 12 screens at 360, 390, 768, 1024, 1440px; roster modals; schedule action')
  browser.close()
finally:server.shutdown();server.server_close();temporary.cleanup()
