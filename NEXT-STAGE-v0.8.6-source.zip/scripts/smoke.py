#!/usr/bin/env python3
"""Browser regression checks; requires playwright and Chromium."""
import functools
import http.server
import json
import os
from pathlib import Path
import tempfile
import threading
from playwright.sync_api import sync_playwright

ROOT = Path(os.environ.get('WEB_ROOT', Path(__file__).resolve().parents[1])).resolve()

class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *_args):
        pass

server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(QuietHandler, directory=str(ROOT)))
threading.Thread(target=server.serve_forever, daemon=True).start()
try:
    with sync_playwright() as p, tempfile.TemporaryDirectory() as tmp:
        options = {'args': ['--disable-dev-shm-usage']}
        if os.environ.get('CHROMIUM_PATH'):
            options['executable_path'] = os.environ['CHROMIUM_PATH']
        browser = p.chromium.launch(**options)
        context = browser.new_context(accept_downloads=True)
        page = context.new_page()
        page.set_default_timeout(15000)
        errors, failed_responses = [], []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.on('response', lambda response: failed_responses.append(response.url) if response.status >= 400 else None)
        address = f'http://127.0.0.1:{server.server_port}/'
        legacy_bundle = os.environ.get('LEGACY_BUNDLE')
        if legacy_bundle:
            legacy_source = Path(legacy_bundle).read_text()
            page.route('**/src/game-bundle.js*', lambda route: route.fulfill(body=legacy_source, content_type='application/javascript'))
            page.goto(address, wait_until='networkidle')
            page.evaluate('''() => {
              game.newGame('기존 저장', '대표');
              for (let i=0;i<40;i++) game.nextDay();
              if (!save()) throw Error('Legacy save failed');
            }''')
            legacy_version = page.evaluate('DATA.rules.version')
            page.unroute('**/src/game-bundle.js*')
            page.reload(wait_until='networkidle')
            page.locator('[data-action=continue]').click()
            page.wait_for_function('game.s && document.querySelector(".main")')
            assert page.evaluate('game.s.company === "기존 저장" && game.s.day === 40 && validState(game.s)')
            print(f'PASS v{legacy_version} automatic save loaded in v0.8.6')
            page.evaluate('localStorage.clear()')
        page.goto(address, wait_until='networkidle')
        assert page.evaluate('DATA.rules.version') == '0.8.6'
        # Decode every extracted image, not only the portraits visible on the title.
        images = [str(path.relative_to(ROOT)) for path in (ROOT / 'assets/portraits').rglob('*.webp')]
        assert len(images) == 72
        assert set(page.evaluate('DATA.roster.map(person => person.image)')).issubset(set(images))
        page.evaluate('''async paths => {
          await Promise.all(paths.map(async path => {
            const img = new Image(); img.src = path; await img.decode();
            if (!img.naturalWidth) throw Error('Empty image: ' + path);
          }));
        }''', images)
        for width in (1440, 768, 390):
            page.set_viewport_size({'width': width, 'height': 900})
            page.evaluate('''async () => {
              const bg = getComputedStyle(document.querySelector('.title-art')).backgroundImage;
              const img = new Image(); img.src = bg.slice(bg.indexOf('url(') + 4, -1).replaceAll('"', '');
              await img.decode(); if (!img.naturalWidth) throw Error('Background missing');
            }''')
        print('PASS all 72 portraits and responsive background')
        page.locator('[data-action=new]').click()
        page.locator('[name=company]').fill('회귀 테스트')
        page.locator('[name=boss]').fill('대표')
        page.locator('#new-form button.primary').click()
        page.evaluate('close()')
        assert page.evaluate('validState(game.s) && saveOK')
        assert page.locator('.backup-reminder').count() == 0
        for menu in ('home', 'inbox', 'artists', 'casting', 'projects', 'staff', 'finance', 'training', 'teams', 'industry', 'company', 'goals', 'schedule', 'music', 'charts'):
            page.evaluate('(menu) => navigate(menu)', menu)
        print('PASS new game and 15 menus')
        result = page.evaluate('''() => {
          const g = new Game(); g.newGame('활동 테스트', '대표');
          g.startCasting('audition', 'idol', 'any', 'career');
          for (let i=0; i<10; i++) g.nextDay();
          const candidate = g.s.candidates.find(c => !DATA.roster[c.id].trainee);
          if (!candidate) throw Error('No career candidate');
          g.sign(candidate.id, 'balanced');
          g.startProject(String(candidate.id), 'cover', '첫 커버', 200, 'balanced');
          for (let i=0; i<30; i++) g.nextDay();
          if (!validState(g.s) || !g.s.performance.some(x => x.kind === 'cover')) throw Error('Activity did not complete');
          for (let i=40; i<400; i++) g.nextDay();
          if (!validState(g.s)) throw Error('Invalid 400-day state');
          return {day:g.s.day, performances:g.s.performance.length};
        }''')
        print('PASS casting, signing, cover completion, 400-day progression', result)
        assert page.evaluate('''() => {
          saveStore.saveSlot(1,game.s);
          return JSON.stringify(saveStore.loadSlot(1)) === JSON.stringify(game.s);
        }''')
        page.reload(wait_until='networkidle')
        page.locator('[data-action=continue]').click()
        page.wait_for_function('game.s && document.querySelector(".main")')
        assert page.evaluate('validState(game.s) && game.s.company === "회귀 테스트"')
        page.evaluate('''() => {for(let i=0;i<30;i++)game.nextDay();save();navigate('home');}''')
        assert page.locator('.backup-reminder').count() == 1
        page.evaluate('settings()')
        with page.expect_download() as download:
            page.locator('[data-action=export]').click()
        backup_path = Path(tmp) / 'backup.json'
        download.value.save_as(backup_path)
        state = json.loads(backup_path.read_text())
        assert state['day'] == 30
        assert '마지막 백업 내보내기 요청:' in page.locator('#modal-root').inner_text()
        assert page.locator('.backup-reminder').count() == 0
        assert page.evaluate('''() => {
          const state = game.s, now = Date.now();
          const write = (at,day) => localStorage.setItem(BACKUP_META_KEY,JSON.stringify({company:state.company,boss:state.boss,day,at}));
          write(now-7*86400000-1000,state.day); if(!backupDue(state)) return false;
          write(now,0); if(!backupDue(state)) return false;
          write(now,state.day); return !backupDue(state);
        }''')
        # A downloaded JSON must pass the actual import UI.
        page.locator('#import-save').set_input_files(backup_path)
        page.locator('[data-action=confirm-import]').click()
        assert page.evaluate('game.s.day === 30 && validState(game.s) && saveOK')
        print('PASS slots, reload, backup timing, JSON export and import')
        page.evaluate("navigate('home')")
        page.set_viewport_size({'width': 390, 'height': 844})
        assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
        page.goto(f'http://127.0.0.1:{server.server_port}/character-gallery.html', wait_until='networkidle')
        assert page.locator('.card').count() == 72
        page.locator('#type').select_option('band')
        assert page.locator('.card:visible').count() > 0
        page.locator('#type').select_option('')
        page.locator('#search').fill('서윤')
        assert page.locator('.card:visible').count() == 1
        page.locator('.card:visible').click()
        assert page.locator('dialog').is_visible()
        assert page.locator('dialog h2').inner_text() == '서윤'
        page.keyboard.press('Escape')
        assert not page.locator('dialog').is_visible()
        assert page.evaluate('document.activeElement.classList.contains("card")')
        assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
        print('PASS 72-character gallery, search, filters, details and keyboard close')
        assert not errors, errors
        assert not failed_responses, failed_responses
        print('PASS mobile width; no HTTP or JavaScript errors')
        browser.close()
finally:
    server.shutdown()
    server.server_close()
