/* FILE src/concept-ui.js */
'use strict';
let developmentId = null, developmentTab = 'training';
const developmentLabels = {balanced:'균형',vocal:'보컬',performance:'무대',creative:'창작',rest:'휴식'};
function openDevelopment(id) {
  game.ownedTalent(id); developmentId=Number(id);developmentTab='training';navigate('development');
}
function artistModal_concept(id,candidate=false) { return candidate?talentModal(id):openDevelopment(id); }
function traineeDetail_concept(id) { openDevelopment(id); }
function countdownHTML(a) {
  const mark=game.developmentCountdown(a);
  if(!mark)return `<span class="countdown-label">목표 일정을 지정해 보세요</span>`;
  const label={debut:'데뷔',live:'공연',single:'발매'}[mark.kind],left=mark.day-game.s.day;
  return `<span class="countdown-label">${label}${mark.completedDay!==null?' 완료':mark.confirmed?' · 확정 일정':' · 목표일'}</span><strong>${mark.completedDay!==null?'달성':left>0?left+'일':left===0?'오늘':Math.abs(left)+'일 지남'}</strong><small>${date(mark.completedDay??mark.day)}${!mark.confirmed&&mark.completedDay===null?' · 일정 예약 아님':''}</small>`;
}
function forecastModal() {
  const f=game.monthlyOperatingForecast();
  modal('월 예상 영업손익',`<p>${date(f.from)} ~ ${date(f.to)} · 향후 30일</p><div class="forecast-breakdown"><p>예상 영업 수입 <strong>${money(f.revenue)}</strong></p><p>예상 영업 지출 <strong>${money(f.expense)}</strong></p><p>예상 영업손익 <strong class="${f.profit<0?'negative':'positive'}">${f.profit>0?'+':''}${money(f.profit)}</strong></p><p>참고 · 예상 현금 증감 <strong>${money(f.cashChange)}</strong></p></div><p>현재 소속 인물·훈련 계획·확정 활동을 유지한 별도 30일 시뮬레이션입니다. 실제 진행과 난수 상태는 바꾸지 않습니다.</p><p>대출 실행·원금 상환·이자·회생 지원은 영업손익에서 제외합니다. 게임 거래 기준으로 이미 지출한 제작비는 재차 차감하지 않습니다. 신규 계약·신규 활동·앞으로의 선택은 반영하지 않으므로 실제 결과와 달라질 수 있습니다.</p>`,true);
}
function home_concept() {
  const s=game.s,tasks=todayTasks(),people=[...s.artists,...s.trainees];
  const events=scheduleEvents().filter(e=>e.end>=s.day&&e.start<=s.day+7).sort((a,b)=>Math.max(a.start,s.day)-Math.max(b.start,s.day));
  const forecast=running&&game._developmentForecast?game._developmentForecast.value:game.monthlyOperatingForecast();
  return `<div class="concept-home"><div class="concept-page-title"><h1>기획사 경영</h1><p>좋은 오늘이, 더 멋진 내일의 무대를 만듭니다.</p></div>
  <section class="concept-agency-scene" aria-label="기획사 사무실"><img src="assets/agency-manager-v1.webp" alt="따뜻한 기획사 사무실에서 태블릿을 들고 있는 운영 매니저"><div><small>${date(s.day,true)}</small><h2>오늘도, 다음 무대를 향해.</h2><p>좋은 음악, 좋은 사람이 모여<br>특별한 이야기가 시작되는 곳.</p><span>${esc(s.company)} · ${esc(DATA.stageNames[game.stage])}</span></div></section>
  <section class="concept-summary" aria-label="핵심 경영 지표">
  ${btn(`${ico('wallet')}<span><small>보유 자금</small><strong>${money(s.cash)}</strong></span>${ico('arrow')}`,'nav','data-page="finance"','concept-summary-card')}
  ${btn(`${ico('chart')}<span><small>월 예상 영업손익 · ${running?'진행 후 갱신':'향후 30일'}</small><strong class="${forecast.profit<0?'negative':'positive'}">${forecast.profit>0?'+':''}${money(forecast.profit)}</strong></span>${ico('arrow')}`,'m-month-forecast','','concept-summary-card')}
  ${btn(`${ico('people')}<span><small>소속 아티스트</small><strong>${s.artists.length}명 <em>· 연습생 ${s.trainees.length}명</em></strong></span>${ico('arrow')}`,'nav','data-page="artists"','concept-summary-card')}
  </section><div class="concept-desk">
  <section class="panel concept-task-panel"><div class="concept-section-heading"><h2>오늘의 주요 업무</h2><small>${tasks.length}건 확인 필요</small></div><div>${tasks.slice(0,5).map(t=>btn(`<span class="concept-check">${t.priority===0?'!':'↗'}</span><strong>${esc(t.label)}</strong><span class="concept-status ${t.priority===0?'urgent':''}">${t.priority===0?'우선 확인':'확인'}</span>`,t.action,t.args,'concept-task')).join('')||'<div class="concept-calm">급한 업무를 모두 확인했어요.<br>다음 무대를 준비해 보세요.</div>'}</div>${tasks.length>5?btn('전체 업무 보기','m-all-tasks','','link small'):''}</section>
  <section class="panel concept-agenda"><div class="concept-section-heading"><h2>다가오는 일정</h2>${btn('전체 일정','nav','data-page="schedule"','link small')}</div>${events.slice(0,5).map(e=>btn(`<time>${e.start<=s.day?'진행 중':'D-'+(e.start-s.day)}</time><strong>${esc(e.title)}</strong><small>${date(Math.max(s.day,e.start))}</small>`,'nav',`data-page="${e.page}"`,'concept-event')).join('')||'<div class="concept-calm">등록된 주요 일정이 없습니다.<br>날짜별 일정은 전체 일정에서 확인하세요.</div>'}</section>
  </div><section class="panel concept-roster"><div class="concept-section-heading"><h2>소속 아티스트</h2>${btn('전체 보기','nav',`data-page="${s.artists.length?'artists':'training'}"`,'link small')}</div><div class="concept-roster-bottom"><div class="concept-roster-cards">${people.slice(0,3).map(a=>{const d=DATA.roster[a.id],trainee=s.trainees.includes(a);return btn(`<div class="concept-thumb"><img src="${d.image}" alt="" loading="lazy"></div><span><strong>${esc(d.name)}</strong><small>${trainee?'연습생':DATA.labels[d.type]} · ${d.position}</small><span class="concept-energy ${a.energy<40?'low':''}">컨디션 ${a.energy<40?'회복 필요':a.energy<70?'보통':'좋음'}</span><span class="bar"><span style="width:${Math.max(0,Math.min(100,a.energy))}%"></span></span></span>`,'m-development',`data-id="${a.id}"`,'concept-person');}).join('')||`<div class="concept-calm">우리의 첫 인재를 기다리고 있어요.${btn('인재 모집 시작','casting-modal','','soft')}</div>`}</div></div></section>
  <details class="concept-more studio-archive" ${studioArchiveOpen?'open':''}><summary>가이드·경영 계획·함께한 기록</summary>${!s.guideHidden?guideCard():''}<div class="row wrap section">${btn('캐스팅','nav','data-page="casting"','soft')}${btn('활동 준비','project-modal','','soft',!s.artists.length)}${btn('개인 육성','nav','data-page="development"','soft',!people.length)}${btn('영업손익 산출 기준','m-month-forecast','','soft')}</div>${spotlight()}${recentWeekHTML()}${panel('우리의 최근 순간',s.moments.slice(-3).reverse().map(m=>`<p>${esc(m.title)} ${btn('다시 보기','m-moment',`data-id="${m.id}"`,'link small')}</p>`).join('')||'<p>첫 계약부터 우리의 기록이 쌓입니다.</p>')}${panel('최근 발매',s.catalog.slice(-3).reverse().map(c=>releaseRow({release:c,company:s.company,own:true})).join('')||'<p>첫 음악을 기다리고 있습니다.</p>')}</details></div>`;
}
function developmentScreen() {
  const people=[...game.s.artists,...game.s.trainees];
  const a=people.find(p=>p.id===developmentId)||people[0];
  if(!a)return heading('아티스트 육성','함께 성장할 인재를 먼저 만나보세요.',btn('인재 모집','casting-modal','','primary'))+'<div class="empty">영입한 아티스트와 연습생을 이곳에서 육성할 수 있습니다.</div>';
  developmentId=a.id;
  const d=DATA.roster[a.id],trainee=game.s.trainees.includes(a),target=a.growthTarget;
  const selected=a.weeklyPlan||Array(7).fill(trainee?a.trainingPlan:{balanced:'balanced',creative:'creative',stage:'performance',rest:'rest'}[a.focus]);
  const weekStart=game.s.day-DevelopmentWeekday(game.s.day),current=DevelopmentWeekday(game.s.day);
  const weekDate=day=>new Date(Date.UTC(2027,0,1+day));
  const dateInput=day=>weekDate(day).toISOString().slice(0,10);
  const defaultMark=a.milestone||{kind:trainee?'debut':'live',day:Math.max(game.s.day+14,trainee?a.signed+90:0)};
  return `<div class="development-page"><div class="concept-page-title"><h1>아티스트 육성</h1><p>지금의 노력이, 언젠가 가장 빛나는 무대가 됩니다.</p>${btn('아티스트 목록으로','nav',`data-page="${trainee?'training':'artists'}"`,'link small')}</div>
  <div class="development-picker"><label for="development-person">다른 아티스트 보기</label><select id="development-person">${people.map(p=>`<option value="${p.id}" ${p.id===a.id?'selected':''}>${esc(DATA.roster[p.id].name)} · ${game.s.trainees.includes(p)?'연습생':'아티스트'}</option>`).join('')}</select></div>
  <section class="development-overview"><div class="development-portrait"><img src="${d.image}" alt="${esc(d.name)}의 전체 초상화"></div><div class="development-info"><h2>${esc(d.name)} <small>· ${trainee?'데뷔를 준비하는 '+d.position:d.position+' 아티스트'}</small></h2><p class="development-quote">“${esc(game.trainingReaction(a.id))}”</p><nav class="development-tabs" aria-label="아티스트 정보">${[['profile','프로필'],['training','육성'],['story','스토리']].map(([key,label])=>btn(label,'m-development-tab',`data-tab="${key}"`,developmentTab===key?'active':'')).join('')}</nav>
  ${developmentTab==='story'?`<div class="panel development-story">${personalityCard(a.id)}${memoriesHTML(a.id)}</div>`:`<div class="panel development-stats"><div class="concept-section-heading"><h3>성장 능력치</h3><small>현재 실력</small></div>${statsHTML(a.stats)}<div class="development-state"><div><span>컨디션</span><strong>${a.energy<40?'회복 필요':a.energy<70?'보통':'좋음'}</strong><small>체력 ${Math.round(a.energy)} · 스트레스 ${Math.round(a.stress)}</small></div><div><span>회사 신뢰</span><strong>${Math.round(a.trust)}</strong><small>함께 쌓아가는 관계</small></div></div></div>`}
  ${developmentTab==='profile'?`<div class="development-profile"><p>${esc(d.story)}</p><p>${d.age}세 · ${esc(d.traits)} · ${DATA.labels[d.type]}</p><p>계약 만료 ${date(a.contract,true)}</p>${btn(trainee?'데뷔 계약 검토':'활동 준비',trainee?'m-debut':'project-modal',trainee?`data-id="${a.id}"`:`data-entity="${game.entities.find(e=>e.members.some(p=>p.id===a.id))?.key||a.id}"`,'primary')}</div>`:''}
  </div></section>
  ${developmentTab==='training'?`<div class="development-training"><section class="panel weekly-training"><div class="concept-section-heading"><h2>주간 훈련 계획</h2><span>${date(weekStart)} ~ ${date(weekStart+6)}</span></div><p class="development-note">월~일 반복 계획 · 오늘은 ${['월','화','수','목','금','토','일'][current]}요일입니다. 적용 후 다음 날짜 진행부터 반영됩니다.</p><form id="weekly-plan-form" data-person="${a.id}"><div class="weekly-scroll"><table class="weekly-grid"><thead><tr><th scope="col">훈련</th>${['월','화','수','목','금','토','일'].map((day,i)=>`<th scope="col" class="${i===current?'today':''}">${day}<small>${date(weekStart+i)}</small></th>`).join('')}</tr></thead><tbody>${Object.entries(developmentLabels).map(([key,label])=>`<tr><th scope="row">${label}</th>${selected.map((value,i)=>`<td class="${i===current?'today':''}"><label class="weekly-choice"><input type="radio" name="plan-${i}" value="${key}" ${value===key?'checked':''} aria-label="${['월','화','수','목','금','토','일'][i]}요일 ${label}" required><span aria-hidden="true">✓</span></label></td>`).join('')}</tr>`).join('')}</tbody></table></div><p class="weekly-scroll-hint">표를 좌우로 움직여 월~일 계획을 확인하세요.</p><div class="weekly-actions"><span>${a.weeklyPlan?'주간 계획 적용 중':'기존 훈련 방식으로 진행 중'}</span>${btn('반복 계획 해제','m-weekly-clear',`data-id="${a.id}"`,'link small',!a.weeklyPlan)}<button type="submit" class="primary">훈련 계획 적용 ${ico('arrow')}</button></div></form><details class="training-explainer"><summary>훈련별 효과와 비용</summary>${Object.entries(Game.trainingPlans).map(([key,plan])=>`<p><strong>${developmentLabels[key]}</strong> · ${plan.indexes.length?plan.indexes.map(i=>DATA.specs[i]).join('·'):'컨디션 회복'} · ${trainee?'훈련일 ' + money(plan.cost*(game.coach(key).staff ? 0.8 : 1)):key==='rest'?'훈련비 없음':'훈련일 ' + money(game.has('trainer')?7:10)}</p>`).join('')}<p>연습생은 지정 능력을 훈련하며, 아티스트는 해당 능력 중 하나가 성장합니다. 휴식일에도 월 지원비·고정비는 유지됩니다.</p></details><p class="development-note">체력 부족·과도한 스트레스·훈련비 부족 시 기존 보호 규칙이 우선합니다. 아티스트는 확정 활동을 유지하며, 휴식일에도 이미 확정한 활동이 취소되지는 않습니다.</p></section>
  <aside class="development-goals"><section class="panel personal-goal"><h3>개인 육성 목표</h3>${target?`<strong>${DATA.specs[target.metric]} ${target.target} ${target.achievedDay!==null?'달성':'목표'}</strong><p>현재 ${a.stats[target.metric].toFixed(1)}${target.achievedDay!==null?' · '+date(target.achievedDay)+' 달성':''}</p><div class="bar"><span style="width:${Math.min(100,a.stats[target.metric]/target.target*100)}%"></span></div>`:'<p>이번 성장 목표를 정해 보세요.</p>'}<details class="target-editor"><summary>목표 설정·변경</summary><form id="personal-goal-form" data-person="${a.id}"><label for="goal-metric">목표 능력</label><select id="goal-metric" name="metric">${DATA.specs.map((name,i)=>`<option value="${i}" ${target?.metric===i?'selected':''}>${name}</option>`).join('')}</select><label for="goal-target">목표값</label><input id="goal-target" name="target" type="number" min="1" max="99" value="${target?.target||Math.min(99,Math.ceil(a.stats[0])+5)}" required><button type="submit" class="soft">목표 저장</button></form></details><small>훈련 계획은 별도로 적용하세요. 목표 도달 시 달성일·보고를 남기며 추가 보상은 없습니다.</small></section>
  <section class="panel personal-countdown">${countdownHTML(a)}<details class="target-editor"><summary>목표일 설정·변경</summary><form id="milestone-form" data-person="${a.id}"><label for="milestone-kind">목표 일정</label><select id="milestone-kind" name="kind">${(trainee?[['debut','데뷔']]:[['live','공연'],['single','발매']]).map(([key,label])=>`<option value="${key}" ${defaultMark.kind===key?'selected':''}>${label}</option>`).join('')}</select><label for="milestone-date">목표 날짜</label><input id="milestone-date" name="date" type="date" min="${dateInput(trainee?Math.max(game.s.day,a.signed+90):game.s.day)}" max="${dateInput(game.s.day+365)}" value="${dateInput(Math.max(defaultMark.day,game.s.day))}" required><button type="submit" class="soft">목표일 저장</button></form></details><small>목표일은 활동을 자동 예약하지 않습니다. 확정한 제작·공연 일정이 있으면 그 완료일을 우선 표시합니다.${trainee?' 데뷔는 입소 90일과 평균 능력 55 등 기존 조건을 충족해야 합니다.':''}</small></section></aside></div>
  <details class="development-legacy"><summary>기존 훈련 방식과 상세 성장 기록</summary>${trainee?`<label for="training-mode-${a.id}">기존 관리 방식 · 변경 시 주간 계획 해제</label><select id="training-mode-${a.id}" data-control-id="${a.id}"><option value="auto" ${a.trainingMode==='auto'?'selected':''}>직원 자동 관리</option><option value="manual" ${a.trainingMode==='manual'?'selected':''}>직접 훈련</option></select><label for="training-${a.id}">기본 훈련 계획</label><select id="training-${a.id}" data-training-id="${a.id}">${Object.entries(Game.trainingPlans).map(([key,p])=>`<option value="${key}" ${a.trainingPlan===key?'selected':''}>${p.name}</option>`).join('')}</select>${growthGraph(a)}${btn('데뷔 계약 검토','m-debut',`data-id="${a.id}"`,'primary')}`:`<label for="focus">기존 육성 방향 · 변경 시 주간 계획 해제</label><select id="focus" data-focus="${a.id}">${Object.entries(focusLabel).map(([key,label])=>`<option value="${key}" ${a.focus===key?'selected':''}>${label}</option>`).join('')}</select>${btn('다음 활동 준비','project-modal',`data-entity="${game.entities.find(e=>e.members.some(p=>p.id===a.id))?.key||a.id}"`,'primary')}`}</details>`:''}</div>`;
}
function managementClick_concept(action,data) {
  if(action==='m-development')return openDevelopment(data.id);
  if(action==='m-development-tab'){developmentTab=['profile','training','story'].includes(data.tab)?data.tab:'training';return render();}
  if(action==='m-month-forecast')return forecastModal();
  if(action==='m-weekly-clear'){checkSaveSession();game.transaction(()=>game.clearWeeklyPlan(data.id));const saved=save();render();toast(saved?'주간 계획을 해제하고 이전 훈련 방식으로 돌아갑니다.':'저장에 실패했습니다. 설정에서 JSON 백업을 내보내 주세요.');return;}
}
UIEvents.onChange('development',event=>{if(event.target.id==='development-person')openDevelopment(event.target.value);});
document.addEventListener('submit',event=>{
  const form=event.target;
  if(!['weekly-plan-form','personal-goal-form','milestone-form'].includes(form.id))return;
  event.preventDefault();const data=new FormData(form),id=Number(form.dataset.person);
  try{
    checkSaveSession();
    if(form.id==='weekly-plan-form')game.setWeeklyPlan(id,Array.from({length:7},(_,i)=>data.get('plan-'+i)));
    if(form.id==='personal-goal-form')game.setGrowthTarget(id,data.get('metric'),data.get('target'));
    if(form.id==='milestone-form'){const day=(Date.parse(data.get('date')+'T00:00:00Z')-Date.UTC(2027,0,1))/86400000;game.setMilestone(id,data.get('kind'),day);}
    const saved=save();render();toast(saved?'변경 내용을 저장했습니다.':'저장에 실패했습니다. 설정에서 JSON 백업을 내보내 주세요.');
  }catch(error){toast(error.message);}
});

;
