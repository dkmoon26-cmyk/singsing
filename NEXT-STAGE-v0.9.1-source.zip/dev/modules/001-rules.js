/* FILE src/rules.js */
(function(root) {
  'use strict';
  const activity = Object.freeze({ single: Object.freeze({
    label: '싱글',
    days: 21,
    min: 1000,
    max: 7000,
    defaultBudget: 4000,
    budgets:[[1000, '신인 제작'], [2000, '소규모'], [4000, '기본 제작'], [7000, '집중 투자']]
  }), live: Object.freeze({
    label: '공연',
    days: 7,
    min: 300,
    max: 1500,
    defaultBudget: 300,
    budgets:[[300, '소규모 클럽'], [800, '기본 공연'], [1500, '확대 공연']]
  }), cover: Object.freeze({
    label: '커버',
    days: 5,
    min: 100,
    max: 600,
    defaultBudget: 100,
    budgets:[[100, '라이브 촬영'], [300, '기본 제작'], [600, '집중 제작']]
  }) });
  const rules = Object.freeze({
    version: '0.9.1',
    advertisement: { days: 5, balanceDays: 14 },
    activity,
    traineeFee: 100,
    physicalQuantities:[1000, 3000, 10000],
    unitCost: .6,
    voucherRate: .05,
    voucherCap: 200,
    jobCost(job) {
      return Math.round(((job.actualProductionCost ?? job.budget ?? 0) +(job.manufacturing || 0) +(job.promotionCost || 0)) * 100) / 100;
    },
    quote(budget, kind, options = {}, perks = {}) {
      const base = Number(budget),
      single = kind === 'single',
      manufacturing = single && options.format === 'physical' ? Number(options.quantity) * .6: 0,
      promo = single ? Number(options.promotionCost || 0): 0,
      discount = single && perks.productionVoucher > 0 ? Math.min(200, Math.round(base * .05 * 100) / 100): 0;
      return {
        base,
        discount,
        production: base - discount,
        manufacturing,
        promo,
        total: Math.round((base - discount + manufacturing + promo) * 100) / 100
      };
    }
  });
  if (typeof module !== 'undefined') module.exports = rules;
  else root.GameRules = rules;
})(typeof window !== 'undefined' ? window: globalThis);


;
