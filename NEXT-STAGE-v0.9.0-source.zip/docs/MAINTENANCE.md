# 개발 및 유지보수

## 소스와 빌드

- `dev/modules/`: 편집용 JS 모듈. 파일 내부의 원래 `FILE` 주석은 기능의 출처를 표시합니다.
- `dev/manifest.json`: 브라우저에서 실행할 순서. 전역 선언과 확장 클래스의 순서를 보존해야 합니다.
- `src/game-bundle.js`: 배포 산출물. 직접 수정하지 말고 원본을 편집한 뒤 빌드합니다.
- `src/style.css`: 스타일 원본. 이미지 URL은 CSS 파일을 기준으로 해석됩니다.
- `assets/portraits/`: 개별 제작된 72명의 스튜디오풍 기본 초상화. 기존 얼굴 이미지는 교체 후 삭제합니다.
- `vendor/`: 포함된 pako 및 라이선스. 저장 압축에 사용됩니다.

이 모듈들은 원본 배포본의 경계를 복원한 것으로, 독립적인 Node 모듈 진입점은 아닙니다.
런타임은 기존과 같이 하나의 브라우저 스크립트입니다. 빌드에는 Python 3만 필요합니다.

```sh
python3 scripts/build.py
python3 scripts/build.py --check
node --check src/game-bundle.js
```

새 코드 파일을 추가하면 manifest의 올바른 위치에 등록하세요. 게임 저장 형식의
`version`과 화면 버전은 서로 다릅니다. 이번 0.8.5 이미지 패치는 저장 형식을 변경하지 않습니다.

## 실행과 검증

```sh
python3 -m http.server 8000 --bind 127.0.0.1
```

선택적 브라우저 회귀 검증에는 Python Playwright와 Chromium이 필요합니다.
설치된 Chromium이 있으면 `CHROMIUM_PATH`를 지정하고, 없으면 Playwright의 Chromium을 설치합니다.
TLS·체크섬 검증과 실행 환경의 프록시 설정을 유지하세요.

```sh
python3 -m pip install playwright
python3 -m playwright install chromium
python3 scripts/smoke.py
# 시스템 Chromium 사용 시:
CHROMIUM_PATH=/usr/bin/chromium python3 scripts/smoke.py
```

테스트는 임시 브라우저 프로필과 비어 있는 로컬 저장소를 사용합니다. 사용자 저장을 수정하지 않습니다.
새 회사, 메뉴 표시, 계약과 활동 완료, 400일 진행, 저장 왕복·이어하기,
JSON 백업 내보내기·불러오기, 백업 알림 시점과 이미지 로딩을 검증합니다.
전체 게임 밸런스와 모든 계약·이벤트 조합을 보장하는 테스트는 아닙니다.

## 백업 안내

설정에서 마지막 내보내기 요청 시각과 게임 날짜를 확인할 수 있습니다.
백업 없이 30일을 진행했거나 마지막 내보내기 이후 게임 30일 또는 실제 7일이 지나면
화면에 백업 안내가 표시됩니다. 자동으로 파일을 다운로드하거나 진행을 막지 않습니다.
브라우저는 다운로드 파일의 최종 보관 여부를 알려 주지 않으므로, UI는 ‘요청’으로 표시합니다.
메타데이터 저장이 제한되어도 파일 내보내기와 게임 진행은 계속할 수 있습니다.
백업 기록은 저장 JSON에 추가하지 않고 별도 로컬 키에 보관합니다.

## 배포

```sh
python3 scripts/build.py --check --zip /tmp/NEXT-STAGE-v0.8.5-web.zip
```

ZIP에는 정적 실행 파일과 라이선스만 포함합니다. 현재 인물 이미지로 사용하지 않는 옛 인물 이미지와 중복 버전은 저장소와 배포에서 삭제합니다.
현재 게임 캐릭터 72명과 공통 배경·로고만 보관해 100개 미만을 유지합니다. 편집 소스·문서·검증 스크립트는
저장소에 보관하세요. ZIP의 `index.html`이 배포 루트에 있어야 합니다.
HTML이 참조하는 JS/CSS 쿼리 버전을 갱신해 이전 캐시를 구분하세요.
이미지를 바꿀 때는 파일명도 변경해 기존 이미지 캐시와 구분하세요.


## 캐릭터 아트

`dev/characters.json`은 게임 ID 0~71의 이름·역할·헤어·얼굴·포즈·의상·고유 특징을 기록합니다.
파일의 게임 ID와 실제 인물 데이터의 연결을 유지하세요. 이름이 비슷한 인물도 ID로 구별합니다.
`character-gallery.html`에서 72명을 이름·분야·경력으로 검색하고 이미지를 크게 확인할 수 있습니다.
갤러리는 같은 폴더 구조로 배포하며 정적 파일로도 열 수 있습니다.
각 초상화는 이미지 생성 도구로 개별 제작했습니다. 런타임 WebP는 생성 PNG를 자르거나 합성하지 않고
원래 해상도로 형식 변환·압축한 파일입니다. 대표 초상화를 기준으로 추가 의상·표정을 제작하세요.
새 초상화 경로는 기존 캐시와 구분되는 `artist-ID-studio-v3.webp`입니다.
이름·능력치·계약·저장 키는 이미지 교체로 변경하지 않습니다.


## UI 개발

공통 테마는 `src/theme.css`, 경영 홈은 `dev/modules/045-studio-ui.js`에서 관리합니다.
테마는 기본 CSS 뒤에 로드됩니다. 홈은 기존 게임 메서드의 데이터를 표시하고 기존 액션 핸들러로 연결합니다.
`현금 수지`는 monthIn - monthOut이며 대출 등 자금 이동도 포함하므로 영업이익으로 이름 붙이지 마세요.

```sh
CHROMIUM_PATH=/usr/bin/chromium python3 scripts/ui_smoke.py
```

스크린샷이 필요하면 `UI_SCREENSHOT_DIR=/tmp/next-stage-ui`를 추가합니다.
검증은 별도의 브라우저 프로필에서 실행하며 사용자 저장에 접근하지 않습니다.


## 주간 육성 및 월 예상 영업손익 (0.9.0)

- 모델: `dev/modules/019-development.js`, 저장 검증: `022-development-state.js`.
- 화면과 액션: `045-concept-ui.js`. 홈과 개인 육성의 바인딩은 `046-ui-bindings.js`에서 명시합니다.
- 저장 `developmentVersion: 1`. 인물별 `weeklyPlan`, `weeklyBase`, `growthTarget`, `milestone`는 기존 저장에서 null로 초기화합니다.
- 실제 게임 날짜(2027-01-01 시작)의 월~일을 계산합니다. 저장한 주간 계획은 다음 날짜 진행부터 적용되고 반복됩니다.
- 훈련 효율·회복·비용·능력군은 기존 Game.trainingPlans를 사용합니다. 아티스트의 기존 일일 성장 규칙을 유지하며 지정 능력군에서 하나를 훈련합니다.
- 목표 설정은 훈련 방향을 자동 변경하지 않습니다. 목표일은 자동 예약이 아닙니다. 확정된 제작·공연·행사 일정이 있으면 그 완료일을 우선 표시합니다.
- 월 예상 영업손익은 상태 복제본을 30일 전진시키며 operating 거래만 집계합니다. 금융 거래·이자와 비영업 지원금 제외. 이미 지급한 비용은 다시 공제하지 않습니다.
- 예측은 현재 계획을 유지하는 경우의 게임 거래 기준 추정치이며 신규 결정은 반영하지 않습니다. 실제 상태와 RNG는 변경하지 않습니다. 원본 상태별 결과를 캐시하고 자동 진행 중에는 마지막 결과를 유지한 뒤 종료 후 갱신합니다.

```sh
CHROMIUM_PATH=/usr/bin/chromium python3 scripts/smoke.py
CHROMIUM_PATH=/usr/bin/chromium python3 scripts/development_smoke.py
```

`ui_smoke.py`도 현재 `development_smoke.py`를 실행합니다. `WEB_ROOT`로 ZIP을 푼 경로를 지정할 수 있습니다.
