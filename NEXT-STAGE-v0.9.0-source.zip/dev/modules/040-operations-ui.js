/* FILE src/operations-ui.js */
'use strict';
let recruitFilter = 'all', calendarMonth = null, calendarDay = null, traineeGraphDays = 30, traineeGraphMetric = - 1;
function staffCard(p, hired = false) {
  return `<article class="panel staff-card"><span class="pill">${DATA.staffKinds[p.kind]}</span><h2>${esc(p.name)}</h2><p>${esc(p.specialty==='general'?p.spec:Game.trainingPlans[p.specialty].name+' 전문')} · 지도/직무 ${p.coaching} · 전문 ${p.expertise} · 관리 ${p.care}</p><strong>월급 ${money(p.salary)}</strong><p>${hired?'재직 중':'채용비 '+money(p.fee)}</p>${btn('상세정보','m-staff-detail',`data-id="${p.id}"`,'soft')}</article>`;
}
function staffScreen_operations() {
  const people = game.s.staff.map(id => DATA.staff.find(p => p.id === id));
  return heading('직원 관리', '고용한 직원 전원을 한 화면에서 확인하세요.', btn('직원 고용', 'nav', 'data-page="recruit"', 'primary')) + panel('전체 직원 ' + people.length + '명', `<h2>월급 합계 ${money(people.reduce((n,p)=>n+p.salary,0))}</h2><p>육성 직원은 인원 제한 없이 전체 연습생을 관리합니다. 분야별 가장 적합한 직원의 효과가 적용됩니다.</p><label for="policy">활동 운영 방침</label><select id="policy"><option value="balanced" ${game.s.policy==='balanced'?'selected':''}>균형</option><option value="growth" ${game.s.policy==='growth'?'selected':''}>집중 성장</option></select>`) + `<div class="three-col section">${people.map(p=>staffCard(p,true)).join('')||'<p class="panel">고용한 직원이 없습니다.</p>'}</div>`;
};
function recruitScreen() {
  const candidates = game.staffCandidates().filter(p => recruitFilter === 'all' || p.kind === recruitFilter);
  return heading('직원 고용', '미고용 후보 30명 중 매일 최대5명이 지원합니다. 고용한 후보는 목록에서 빠지며 당일 추가 충원은 없습니다.', btn('직원 관리', 'nav', 'data-page="staff"', 'soft')) + `<p>${date(game.s.day,true)} · 내일 지원자 갱신 · 같은 날 불러와도 유지</p><div class="tabs">${[['all','전체'],...Object.entries(DATA.staffKinds)].map(([key,label])=>btn(label,'m-recruit-filter',`data-filter="${key}"`,recruitFilter===key?'active':'')).join('')}</div><div class="three-col section">${candidates.map(p=>staffCard(p)).join('')||'<p class="panel">현재 조건에 맞는 지원자가 없습니다. 다른 직무를 확인하거나 다음 날 다시 찾아주세요.</p>'}</div>`;
}
function staffDetail_operations(id) {
  const p = DATA.staff.find(p => p.id === id);
  if (!p) throw Error('직원을 찾을 수 없습니다.');
  const hired = game.s.staff.includes(id),
  bonus = Math.min(.6, p.coaching * .004 + p.expertise * .002);
  modal(p.name + ' · ' + p.role, `<p>${esc(p.spec)}</p><div class="detail-state"><div>지도·직무 <b>${p.coaching}</b></div><div>전문성 <b>${p.expertise}</b></div><div>컨디션 관리 <b>${p.care}</b></div></div><p>월급 ${money(p.salary)} · 채용비 ${money(p.fee)}</p>${p.kind==='trainer'?`<p>기본 성장량 +${(p.coaching*.4).toFixed(1)}% · 전문 분야 ${Game.trainingPlans[p.specialty].name} +${(bonus*100).toFixed(1)}% (총 보너스 최대60%)</p><p>담당 인원 제한 없음. 분야마다 성장 효과가 가장 높은 직원이 지도하며, 보너스는 합산하지 않습니다. 훈련비20% 절감·피로 최대25%/스트레스 최대50% 완화는 해당 직원의 관리 능력에 비례합니다.</p>`:`<p>직무 능력에 따라 ${esc(p.spec)} 효과가 달라집니다. 같은 직무는 가장 능숙한 직원 효과를 적용합니다.</p>`}<div class="modal-actions">${hired?btn('퇴직 협의','staff-confirm',`data-id="${id}"`,'danger'):btn('채용 승인','hire',`data-id="${id}"`,'primary',!game.staffCandidates().some(x=>x.id===id))}</div>`);
}
function growthSummary(a, days = 30) {
  const points = a.growthHistory.filter(x => x.day >= game.s.day - days),
  first = points[0],
  last = points.at(- 1);
  return first && last ? { days: last.day - first.day, gain:(last.stats.reduce((n, v) => n + v, 0) - first.stats.reduce((n, v) => n + v, 0)) / 8 }: { days: 0, gain: 0 };
}
function training_operations() {
  const list = game.s.trainees.filter(a => traineeView === 'ready' ? game.s.day - a.signed >= 90 && game.readiness(a) >= 55: traineeView === 'rest' ? a.energy < 30 || a.stress > 80: true);
  return heading('연습생 관리', '연습생을 누르면 개인 성장 리포트와 훈련·계약 정보를 확인할 수 있습니다.', btn('인재 모집', 'casting-modal', '', 'primary')) + `<div class="tabs">${[['all','전체'],['ready','데뷔 가능'],['rest','회복 필요']].map(([key,label])=>btn(label,'m-trainee-filter',`data-filter="${key}"`,traineeView===key?'active':'')).join('')}</div><div class="two-col section">${list.map(a=>{const d=DATA.roster[a.id],growth=growthSummary(a),ready=game.s.day-a.signed>=90&&game.readiness(a)>=55;return `<button type="button" class="panel trainee-summary" data-action="m-trainee-detail" data-id="${a.id}"><img class="talent-thumb" src="${d.image}" alt="${d.name}" loading="lazy"><div><h2>${d.name}</h2><p>${game.has('trainer')&&a.trainingMode==='auto'?'직원 자동 관리':'직접 훈련'} · ${Game.trainingPlans[a.trainingPlan].name}</p><p>체력 ${Math.round(a.energy)} · 스트레스 ${Math.round(a.stress)} · ${ready?'데뷔 조건 충족':'데뷔 준비 중'}</p><small>${growth.days}일 기록 · 평균 ${growth.gain>=0?'+':''}${growth.gain.toFixed(2)} · ${DATA.specs[game.trainingAdvice(a).weak]} 보완</small></div></button>`;}).join('')||'<p class="panel">해당하는 연습생이 없습니다.</p>'}</div>`;
};
function growthGraph(a) {
  const points = a.growthHistory.filter(x => x.day >= game.s.day - traineeGraphDays),
  metric = traineeGraphMetric,
  label = metric < 0 ? '평균 능력': DATA.specs[metric];
  if (points.length < 2) return '<p>성장 기록을 쌓고 있습니다. 날짜를 진행하면 그래프가 표시됩니다. 과거 기록은 소급 생성하지 않습니다.</p>';
  const value = p => metric < 0 ? p.stats.reduce((n, v) => n + v, 0) / 8: p.stats[metric],
  first = points[0],
  last = points.at(- 1),
  span = Math.max(1, last.day - first.day),
  coords = points.map(p => `${40+(p.day-first.day)/span*460},${155-value(p)/100*125}`).join(' ');
  return `<svg class="growth-graph" viewBox="0 0 540 190" role="img" aria-label="${label} 성장 추이"><title>${label} · ${value(first).toFixed(2)} → ${value(last).toFixed(2)}</title>${[0,25,50,75,100].map(v=>`<line x1="40" x2="500" y1="${155-v*1.25}" y2="${155-v*1.25}" stroke="#dce4ef"/><text x="5" y="${159-v*1.25}" font-size="11" fill="#667085">${v}</text>`).join('')}<polyline fill="none" stroke="#2563eb" stroke-width="3" points="${coords}"/><text x="40" y="178" font-size="12">${date(first.day)}</text><text x="455" y="178" font-size="12">${date(last.day)}</text></svg><p>${points.length}개 실제 기록 · ${label} ${value(first).toFixed(2)} → ${value(last).toFixed(2)}</p>`;
}
function traineeDetail_operations(id) {
  const a = game.s.trainees.find(a => a.id === Number(id));
  if (!a) throw Error('소속 연습생이 아닙니다.');
  const d = DATA.roster[a.id],
  advice = game.trainingAdvice(a),
  profile = game.profile(a.id),
  coach = game.coach(a.trainingPlan);
  modal(d.name + ' · 개인 육성', `<div class="detail-grid"><img class="detail-photo" src="${d.image}" alt="${d.name}"><div><p>${d.age}세 · ${d.position}</p><p>${d.story}</p><p>평균 ${game.readiness(a).toFixed(1)} · 체력 ${Math.round(a.energy)} · 스트레스 ${Math.round(a.stress)}</p><p>입소 ${game.s.day-a.signed}일 / 최소90일 · 데뷔 기준 평균55</p></div></div><h3>육성 목표</h3><label for="training-mode-${id}">관리 방식</label><select id="training-mode-${id}" data-control-id="${id}">${[['auto','직원 자동 관리'],['manual','직접 계획 지정']].map(([key,label])=>`<option value="${key}" ${a.trainingMode===key?'selected':''}>${label}</option>`).join('')}</select><label for="training-goal-${id}">목표</label><select id="training-goal-${id}" data-goal-id="${id}">${[['balanced','균형 성장'],['debut','빠른 데뷔 · 부족한 분야 보완'],['longterm','장기 성장 · 회복 우선'],['vocal','보컬 강화'],['performance','무대 강화'],['creative','창작 강화']].map(([key,label])=>`<option value="${key}" ${a.trainingGoal===key?'selected':''}>${label}</option>`).join('')}</select><p>${coach.staff?coach.staff.name+' 지도 · 성장 +'+(coach.bonus*100).toFixed(1)+'%':'육성 직원 없음 · 기본 훈련 유지'}${a.trainingMode==='auto'&&!game.has('trainer')?' · 채용 후 자동 조율 시작':''}</p><label for="training-${id}">직접 훈련 계획 · 변경 시 수동 관리</label><select id="training-${id}" data-training-id="${id}">${Object.entries(Game.trainingPlans).map(([key,p])=>`<option value="${key}" ${a.trainingPlan===key?'selected':''}>${p.name} · 일 ${p.cost}만 원${coach.staff?' (직원20% 절감)':''}</option>`).join('')}</select><h3>성장 리포트</h3><div class="row wrap">${btn('최근30일','m-growth-range',`data-id="${id}" data-days="30"`,traineeGraphDays===30?'primary small':'small')}${btn('최근90일','m-growth-range',`data-id="${id}" data-days="90"`,traineeGraphDays===90?'primary small':'small')}</div><label for="growth-metric-${id}">표시 능력</label><select id="growth-metric-${id}" data-growth-id="${id}">${['평균',...DATA.specs].map((label,i)=>`<option value="${i-1}" ${traineeGraphMetric===i-1?'selected':''}>${label}</option>`).join('')}</select>${growthGraph(a)}<p><strong>${DATA.specs[advice.strong]} 강점 / ${DATA.specs[advice.weak]} 보완 권장</strong></p><p>장르·포지션 기준 추천: ${Game.trainingPlans[advice.plan].name}. 최근 상태: ${esc(a.lastTrainingReason||'기록 시작')}.</p><details><summary>능력·계약·성격 상세</summary>${statsHTML(a.stats)}<p>성장 한계 ${profile.potential} · 학습 계수 ${profile.learning.toFixed(2)} · 실제 훈련 ${a.trainedDays}일</p><p>계약 만료 ${date(a.contract,true)} · 월 지원비60만 원 + 실제 훈련비</p>${personalityCard(a.id)}</details><p>최소 데뷔 조건과 무대 준비 수준은 다릅니다. 부족한 분야를 보완하면 활동 완성도에 도움이 됩니다.</p><div class="modal-actions">${btn('데뷔 계약 검토','m-debut',`data-id="${id}"`,'primary')}${btn('합의 종료 검토','m-release-trainee',`data-id="${id}"`,'link')}</div>`, true);
}
function scheduleEvents_operations() {
  const s = game.s,
  events = [];
  for (const j of s.jobs) events.push({
    id: 'job-' + j.id,
    start: j.start,
    end: j.due,
    title: kindLabel[j.kind] +(j.kind === 'single' && game.productionState(j).paused ?(game.productionState(j).reason === '광고 촬영' ? ' (광고로 중단)': ' (행사로 중단)'): '') + ' · ' + j.name,
    kind: j.kind,
    body: `${j.snapshot?.name||'인재 모집'} · ${date(j.start)}~${date(j.due)} · 예산 ${money(DATA.rules.jobCost(j))}${j.kind==='single'?` · ${game.productionState(j).paused?game.productionState(j).reason+' 중 / '+date(game.productionState(j).resume)+' 재개':'제작 중'} · 제작 잔여 ${game.productionState(j).remaining}일 · 연장 ${game.productionState(j).delay}일`:''}`,
    page: 'projects'
  });
  for (const a of[... s.artists, ... s.trainees]) {
    events.push({
      id: 'contract-' + a.id,
      start: a.contract,
      end: a.contract,
      title: DATA.roster[a.id].name + ' 계약 만료',
      kind: 'contract',
      body: termsText(a),
      page: s.trainees.includes(a) ? 'training': 'teams'
    });
    if (a.recoveryUntil > s.day) events.push({
      id: 'rest-' + a.id,
      start: s.day,
      end: a.recoveryUntil - 1,
      title: DATA.roster[a.id].name + ' 회복',
      kind: 'rest',
      body: date(a.recoveryUntil) + '부터 새 활동 가능',
      page: 'artists'
    });
    if (s.trainees.includes(a) && a.signed + 90 >= s.day) events.push({
      id: 'debut-' + a.id,
      start: a.signed + 90,
      end: a.signed + 90,
      title: DATA.roster[a.id].name + ' 데뷔 평가 가능일',
      kind: 'debut',
      body: '입소90일과 평균 능력55를 모두 충족해야 데뷔 가능합니다.',
      page: 'training'
    });
  }
  for (const c of s.catalog) events.push({
    id: 'release-' + c.id,
    start: c.market.startDay,
    end: c.market.startDay,
    title: '발매 · ' + c.name,
    kind: 'single',
    body: c.market.artistName + ' · 완성도 ' + Math.round(c.quality) + ' · 음악 제작·홍보비 ' + money(c.market.production),
    page: 'music'
  });
  for (const[index, p] of s.performance.entries()) if (p.kind !== 'single') events.push({
    id: 'performance-' + index,
    start: p.day,
    end: p.day,
    title: kindLabel[p.kind] + ' 완료 · ' + p.ids.map(id => DATA.roster[id].name).join(' · '),
    kind: p.kind,
    body: '완성도 ' + Math.round(p.quality) + ' · 당시 활동 기록',
    page: 'projects'
  });
  const stamp = calendarBase(),
  first = Math.round((Date.UTC(Math.floor(stamp / 12), stamp % 12, 1) - Date.UTC(2027, 0, 1)) / 86400000),
  last = Math.round((Date.UTC(Math.floor(stamp / 12), stamp % 12 + 1, 0) - Date.UTC(2027, 0, 1)) / 86400000);
  for (let day = Math.max(30, Math.ceil(first / 30) * 30); day <= last; day += 30) if (!game.cashForecast().some(x => x.day === day && x.label === '월 고정비·연습생 지원비')) events.push({
    id: 'monthly-' + day,
    start: day,
    end: day,
    title: '정기 월 정산',
    kind: 'finance',
    body: '30일 주기의 급여·고정비 및 운영 정산. 구체적인 지출은 당시 인원·계약에 따라 달라집니다.',
    page: 'finance'
  });
  for (const[index, x] of game.cashForecast().entries()) events.push({
    id: 'cash-' + index,
    start: x.day,
    end: x.day,
    title: x.label,
    kind: 'finance',
    body: x.type + ' · ' + money(x.amount),
    page: 'finance'
  });
  return events;
}
function calendarBase() {
  const now = new Date(Date.UTC(2027, 0, 1 + game.s.day));
  return calendarMonth ?? now.getUTCFullYear() * 12 + now.getUTCMonth();
}
function schedule_operations() {
  const month = calendarBase(),
  year = Math.floor(month / 12),
  m = month % 12,
  start = Date.UTC(year, m, 1),
  startDay = Math.round((start - Date.UTC(2027, 0, 1)) / 86400000),
  weekday = new Date(start).getUTCDay(),
  days = new Date(Date.UTC(year, m + 1, 0)).getUTCDate(),
  count = Math.ceil((weekday + days) / 7) * 7,
  events = scheduleEvents(),
  selected = calendarDay ?? game.s.day,
  chosen = events.filter(x => x.start <= selected && x.end >= selected);
  return heading('통합 일정', '날짜를 선택하고 일정 항목을 누르면 상세정보가 열립니다.') + `<div class="row between wrap calendar-controls"><h2>${year}년 ${m+1}월</h2><div class="row">${btn('이전 달','m-calendar-month','data-shift="-1"')}${btn('오늘','m-calendar-today')}${btn('다음 달','m-calendar-month','data-shift="1"')}</div></div><div class="month-calendar">${['일','월','화','수','목','금','토'].map(x=>`<div class="weekday">${x}</div>`).join('')}${Array.from({length:count},(_,i)=>{const day=startDay-weekday+i,inside=i>=weekday&&i<weekday+days,items=events.filter(x=>x.start<=day&&x.end>=day),label=new Date(Date.UTC(2027,0,1+day)).getUTCDate();return `<button type="button" class="month-day ${inside?'':'outside'} ${day===game.s.day?'today':''} ${day===selected?'selected':''}" data-action="m-calendar-day" data-day="${day}" aria-label="${date(day,true)} 일정 ${items.length}건" aria-pressed="${day===selected}"><strong>${label}</strong>${items.slice(0,2).map(x=>`<span class="calendar-event event-${x.kind}">${esc(x.title)}</span>`).join('')}${items.length>2?`<small>+${items.length-2}건</small>`:''}</button>`;}).join('')}</div><section class="panel section"><h2>${date(selected,true)} · ${chosen.length}건</h2>${chosen.map(x=>btn(`<span class="pill event-${x.kind}">${kindLabel[x.kind]||{contract:'계약',rest:'회복',debut:'데뷔',finance:'정산'}[x.kind]}</span> ${esc(x.title)} · 상세 보기`,'m-calendar-event',`data-event="${x.id}"`,'calendar-detail')).join('')||'<p>등록된 주요 일정이 없습니다. 훈련과 음원 집계는 매일 자동 진행됩니다.</p>'}</section>`;
};
const operationsFinance = finance_progression;
function finance_operations() {
  return operationsFinance() + panel('예정 입금·지출', `<p>공연은 종료7일 후, 광고 잔금은 촬영14일 후 입금됩니다. 음원은 주간 정산입니다. 입금은 약정 배분 후 회사 몫이며 음원 추정은 현재 누적분만 포함합니다.</p>${game.cashForecast().map(x=>`<div class="contract-row"><strong>${date(x.day)} · ${esc(x.label)}</strong><p>${x.type} · ${money(x.amount)}</p></div>`).join('')}<small>미래 일 훈련비, 신규 제작·계약, 판매량 증가분은 포함하지 않습니다.</small>`);
};
const operationsProjectModal = projectModal_market, operationsTalentModal = talentModal_management;
function projectModal_operations(key) {
  operationsProjectModal(key);
  $('#release-options').insertAdjacentHTML('beforeend', `<label for="promotion">사전 홍보</label><select id="promotion" name="promotion">${Object.entries(DATA.promotionPlans).map(([key,p])=>`<option value="${key}">${p.name} · ${money(p.cost)} · 준비 +${p.days}일</option>`).join('')}</select><small>초기 관심을 높이지만 흥행을 보장하지 않습니다.</small>`);
  budgetPreview();
};
;
function talentModal_operations(id) {
  const d = DATA.roster[id];
  if (!d.career) return operationsTalentModal(id);
  modal(d.name + ' · 경력 아티스트', `<div class="detail-grid"><img class="detail-photo" src="${d.image}" alt="${d.name}"><div><span class="pill">${d.career} · ${d.position}</span><p>${d.age}세 · ${d.story}</p><p>현재 충성 팬 ${d.priorFans}명 · 인지도 ${d.priorFame}</p>${statsHTML(d.stats,true)}</div></div>${personalityCard(id)}<p>육성 대기 없이 계약 후 바로 활동 가능. 음반 제작 기간과 회복 일정은 필요합니다. 과거 작품 권리와 매출은 이전 소속사에 남습니다.</p><form id="m-contract"><input type="hidden" name="id" value="${id}"><label for="offer">계약 제안</label><select name="offer" id="offer">${Object.entries(DATA.terms).filter(([key])=>key!=='company').map(([key,t])=>`<option value="${key}">${t.name} · 계약금 ${money(t.fee+250+d.priorFame*12)} · 회사 ${Math.round(t.share*100)}% · ${t.days}일</option>`).join('')}</select><button class="primary section">전속계약 승인</button></form>`, true);
};
const operationsManagementClick = managementClick_personality;
function managementClick_operations(action, d) {
  switch (action) {
    case 'm-staff-detail': return staffDetail(d.id);
    case 'm-recruit-filter': recruitFilter = d.filter;
    render();
    return;
    case 'm-trainee-detail': traineeGraphDays = 30;
    traineeGraphMetric = - 1;
    return traineeDetail(d.id);
    case 'm-growth-range': traineeGraphDays = Number(d.days) === 90 ? 90: 30;
    return traineeDetail(d.id);
    case 'm-calendar-month': calendarMonth = calendarBase() +(Number(d.shift) < 0 ? - 1: 1);
    calendarDay = Math.round((Date.UTC(Math.floor(calendarMonth / 12), calendarMonth % 12, 1) - Date.UTC(2027, 0, 1)) / 86400000);
    render();
    return;
    case 'm-calendar-today': calendarMonth = null;
    calendarDay = game.s.day;
    render();
    return;
    case 'm-calendar-day': calendarDay = Number(d.day);
    render();
    return;
    case 'm-calendar-event': {
      const item = scheduleEvents().find(x => x.id === d.event);
      if (!item) throw Error('일정이 변경되었습니다. 달력을 다시 확인하세요.');
      return modal('일정 상세', `<h3>${esc(item.title)}</h3><p>${esc(item.body)}</p><p>${date(item.start,true)} → ${date(item.end,true)} · ${Math.max(0,item.end-game.s.day)}일 남음</p>${btn('관련 관리 화면','nav',`data-page="${item.page}"`,'primary')}`);
    }
    default: throw Error("처리할 수 없는 동작입니다.");
  }
};
UIEvents.onChange('operations', ev => {
  const target = ev.target;
  try {
    if (target.dataset.controlId !== undefined) {
      const a = game.talent(Number(target.dataset.controlId));
      game.setTrainingControl(a.id, target.value, a.trainingGoal);
      save();
      traineeDetail(a.id);
    } else if (target.dataset.goalId !== undefined) {
      const a = game.talent(Number(target.dataset.goalId));
      game.setTrainingControl(a.id, a.trainingMode, target.value);
      save();
      traineeDetail(a.id);
    } else if (target.dataset.growthId !== undefined) {
      traineeGraphMetric = Number(target.value);
      traineeDetail(target.dataset.growthId);
    } else if (target.dataset.trainingId !== undefined) {
      game.transaction(() => game.setTraining(Number(target.dataset.trainingId), target.value));
      save();
      render();
      traineeDetail(target.dataset.trainingId);
      toast('훈련 계획을 변경했습니다.');
    };
    if (target.id === 'promotion') budgetPreview();
  } catch (e) {
    toast(e.message);
  }
});


;
