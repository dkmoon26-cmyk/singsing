/* FILE src/evolution.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const clamp =(v, a, b) => Math.max(a, Math.min(b, v)),
    round = v => Math.round(v * 100) / 100;
    class EvolutionGame extends Base {
      upgrade() {
        super.upgrade();
        const s = this.s;
        this.upgradeReliability();
        if (!s || s.evolutionVersion === 1) return;
        s.evolutionVersion = 1;
        s.evolutionSince = s.day;
        s.rewardPaid = [];
        s.perks = { debutPromo: 0, productionVoucher: 0, livePromo: 0 };
        s.moments = [];
        s.outcomes = [];
        s.stories = [];
        s.specialOffers = [];
        s.monthProfits = [];
        s.staffImpact = {
          since: s.day,
          saved: 0,
          trainingDays: 0,
          recoveryDays: 0
        };
        s.milestoneKeys = [];
        s.pinnedEntity = null;
        s.soundEnabled = false;
        s.goalEvidence = {
          live: s.settlements.some(x => x.kind === 'live' && x.attendance > 0) ? 1: 0,
          liveprofit: s.settlements.some(x => x.kind === 'live' && x.net > 0) ? 1: 0,
          team: s.performance.some(p => p.key.startsWith('u')) ? 1: 0,
          comeback: s.performance.some(p => p.ids.some(id => D.roster[id].career)) ? 1: 0
        };
        for (const a of[... s.artists, ... s.trainees, ... s.departed]) {
          a.memories = [{ day: s.day, kind: 'start', text: ' 함께한 기록 시작 · 이전 사건과 대화는 소급 생성하지 않습니다.' }];
          a.storyKeys = [];
          a.coverAttention = 0;
          a.coverAttentionDay = s.day;
        }
        for (const u of s.units) {
          u.cohesion = 0;
          u.completedActivities = 0;
        }
        // Previously recorded achievements receive the new rewards exactly once.
        this.grantGoalRewards(true);
      }
      upgradeReliability() {
        const s = this.s;
        if (!s || s.reliabilityVersion === 1) return;
        s.reliabilityVersion = 1;
        for (const r of s.reports) if (r.kind === 'contract' && r.talentId === undefined) {
          const a = s.artists.find(a => r.body.startsWith(D.roster[a.id].name + '의 계약이 '));
          if (a) {
            r.talentId = a.id;
            const remaining = r.body.match(/계약이 (\d+)일 뒤 만료/);
            if (remaining) r.contractDue = r.day + Number(remaining[1]);
          }
        }
        // One-time conversion of old untyped records. New transactions never depend on captions.
        for (const item of s.receivables ||[]) if (!item.kind) item.kind = item.label.startsWith('공연 정산') ? 'concert_settlement': 'ad_balance';
      }
      remember(ids, kind, text) {
        for (const id of ids) {
          const a = this.talent(id) || this.s.departed.find(x => x.id === id);
          if (!a) continue;
          if (!a.memories) a.memories = [];
          a.memories.push({ day: this.s.day, kind, text });
          a.memories = a.memories.slice(- 60);
        }
      }
      moment(key, title, body, ids = []) {
        if (this.s.milestoneKeys.includes(key)) return;
        this.s.milestoneKeys.push(key);
        this.s.milestoneKeys = this.s.milestoneKeys.slice(- 1000);
        this.s.moments.push({
          id: this.id(),
          day: this.s.day,
          title,
          body,
          ids:[... ids],
          seen: false
        });
        this.s.moments = this.s.moments.slice(- 80);
      }
      goalList() {
        const s = this.s,
        rows = super.goalList(),
        e = s.goalEvidence || {};
        const paid = s.catalog.reduce((n, c) => n +(c.market ? Math.max(0, c.market.paidStream - c.market.payoutStream): 0), 0);
        rows.find(g => g.id === 'catalog').value = paid > 0 ? 1: 0;
        rows.find(g => g.id === 'catalog').target = 1;
        const full = s.monthProfits ||[],
        streak = full.slice(- 3).length === 3 && full.slice(- 3).every(x => x.profit > 0) ? 3: full.slice().reverse().findIndex(x => x.profit <= 0);
        const stable = full.length ? streak === - 1 ? Math.min(3, full.length): streak: 0;
        for (const[id, title, value, target] of[['live', '첫 공연 완료', e.live || 0, 1], ['liveprofit', '첫 공연 흑자', e.liveprofit || 0, 1], ['team', '우리 팀의 첫 활동', e.team || 0, 1], ['physical', '첫 실물 판매', s.catalog.reduce((n, c) => n +(c.market?.sales || 0), 0) > 0 ? 1: 0, 1], ['comeback', '경력자의 새 출발', e.comeback || 0, 1], ['stable', '안정적인 운영', stable, 3]]) rows.push({
          id,
          title,
          value,
          target,
          done: s.goals.includes(id)
        });
        return rows.map(g =>({ ... g, reward: D.goalRewards[g.id], paid:(s.rewardPaid ||[]).includes(g.id) }));
      }
      grantGoalRewards(migration = false) {
        const s = this.s;
        if (!s.rewardPaid) return;
        const fresh = [];
        for (const id of s.goals) {
          if (s.rewardPaid.includes(id)) continue;
          const r = D.goalRewards[id];
          if (!r) continue;
          s.rewardPaid.push(id);
          if (r.cash) this.change(r.cash, '목표 달성 지원금: ' + id, false, { kind: 'goal_grant' });
          if (r.perk) s.perks[r.perk]++;
          if (r.offer) {
            const o = D.specialOffers[r.offer];
            s.specialOffers.push({
              id: this.id(),
              kind: r.offer,
              day: s.day,
              expires: s.day + o.days,
              used: false
            });
          }
          fresh.push(id);
          if (['star', 'rival', 'large', 'comeback'].includes(id)) this.news(this.goalStory(id));
          const ids = id === 'star' ? this.starTargetIds(): id === 'debut' ? s.artists.slice(- 1).map(a => a.id): id === 'renew' ?[]: s.artists.slice(0, 5).map(a => a.id);
          this.moment('goal-' + id, this.goalList().find(g => g.id === id)?.title || id, r.text +(migration ? '\n이전에 달성한 목표의 새 보상을 지급했습니다.': '\n' + this.goalStory(id)), ids);
        }
        if (fresh.length) this.report('목표 보상 지급 · ' + fresh.length + '건', fresh.map(id =>(this.goalList().find(g => g.id === id)?.title || id) + ' · ' + D.goalRewards[id].text).join('\n'), 'info', false, { goalRewardIds: fresh });
      }
      goalStory(id) {
        const s = this.s,
        team = s.units.find(u => u.completedActivities > 0) || s.units[0],
        career = s.outcomes.slice().reverse().flatMap(o => o.ids).find(id => D.roster[id].career),
        name = career === undefined ? '경력 아티스트': D.roster[career].name;
        const lines = {
          sign: '“처음의 마음을 잊지 않고, 좋은 음악을 함께 만들고 싶어요.”',
          trainee: '“아직 부족하지만 첫 무대까지 꾸준히 준비할게요.”',
          debut: '“연습실에서 상상하던 무대를 이제 만나러 가요.” 다음 싱글에 홍보 지원이 적용됩니다.',
          release: '첫 작품이 세상에 나왔습니다. 다음 작품도 우리다운 음악으로 이어 가세요.',
          catalog: '첫 음원 정산이 실제 입금됐습니다. 작은 시작이지만 음악이 회사의 자산으로 쌓이기 시작했습니다.',
          profit: '제작·훈련·급여·배분을 감당하고 영업흑자를 기록했습니다. 다음 활동도 현금 흐름을 지켜 주세요.',
          staff: '“실무는 제가 돕겠습니다. 대표님은 다음 무대를 그려 주세요.” 직원 관리에서 실제 기여를 확인하세요.',
          fans: '팬의 편지 · “다음 무대도 기다리고 있어요. 우리 오래 만나요.” 소규모 팬 공연 제안이 도착했습니다.',
          renew: '“함께 보낸 시간을 믿어요. 다음 음악도 여기서 만들고 싶습니다.”',
          star: '업계 기사 · ' + s.company + '의 아티스트가 스타로 자리 잡았습니다. 꾸준한 실제 흥행과 팬들의 지지가 새로운 기회를 만들었습니다.',
          rival: '업계 기사 · ' + s.company + '가 라이벌 한 곳의 영업이익을 넘어섰습니다. 외부 세션과의 협업 제안이 도착했습니다.',
          large: '작은 회사에서 대형 엔터테인먼트사까지. 현재 소속 아티스트 ' + s.artists.length + '명 · 발매 ' + s.releases + '회. 첫 만남과 수많은 선택이 오늘의 회사를 만들었습니다.',
          live: '첫 무대의 기억 · “객석에서 우리 음악을 듣는 얼굴들을 봤어요. 이 순간을 기억하고 싶어요.”',
          liveprofit: '관객을 만나고 제작비·현장비·배분을 감당한 공연을 마쳤습니다. 다음 공연에 홍보 지원이 적용됩니다.',
          team:(team ? team.name: '우리 팀') + '의 첫 활동. “각자의 목소리가 하나의 무대가 됐어요.” 팀·계약 화면에서 단체 프로필을 확인하세요.',
          physical: '첫 구매자의 메시지 · “음악을 손에 간직하고 싶어서 샀어요. 다음 작품도 기대할게요.”',
          comeback: name + '의 새로운 시작 · “지난 경험을 딛고, 제 속도로 오래 음악을 하고 싶어요.”',
          stable: '완전한30일 정산3회 연속 영업흑자를 기록했습니다. 목표 지원금과 대출금은 영업실적에서 제외한 결과입니다.'
        };
        return lines[id] || '함께 만든 첫걸음을 회사의 기록에 남깁니다.';
      }
      starTargetIds() {
        let u = this.s.units.find(u => u.bestStar >= 3);
        return u ?[... u.ids]: this.s.artists.filter(a => a.bestStar >= 3).slice(0, 5).map(a => a.id);
      }
      sign(id, offer) {
        super.sign(id, offer);
        const a = this.talent(Number(id));
        if (!a.memories) a.memories = [];
        if (!a.storyKeys) a.storyKeys = [];
        a.coverAttention = a.coverAttention || 0;
        a.coverAttentionDay = this.s.day;
        this.remember([a.id], 'contract', D.roster[a.id].trainee ? '연습생으로 함께하기 시작했습니다.': '전속계약 · 새로운 음악을 함께 준비합니다.');
        if (D.roster[a.id].career) this.openStory(a.id, 'comeback');
      }
      debut(id, offer) {
        super.debut(id, offer);
        this.remember([Number(id)], 'debut', '첫 데뷔 · 기다려 온 시작을 함께했습니다.');
        this.moment('debut-' + id, D.roster[id].name + '의 데뷔', '“연습실에서 상상하던 무대를 이제 만나러 가요.”\n첫 작품과 공연을 준비할 수 있습니다.', [Number(id)]);
      }
      renew(id, offer) {
        super.renew(id, offer);
        const a = this.artist(id),
        last = a.memories?.filter(m => m.kind === 'choice').at(- 1);
        this.remember([a.id], 'renew', '재계약 · 다음 무대도 함께하기로 했습니다.');
        this.report('다음 무대도 함께 · ' + D.roster[id].name, '“' +(last ? '그때 제 이야기를 들어주신 걸 기억해요. ': '') + '다음 음악도 함께 만들고 싶어요.”', 'info', false, { talentId: a.id });
      }
      formUnit(name, ids) {
        super.formUnit(name, ids);
        const u = this.s.units.at(- 1);
        u.cohesion = 0;
        u.completedActivities = 0;
        this.remember(u.ids, 'team', u.name + ' 결성 · 서로의 호흡을 알아갑니다.');
      }
      teamProfile(e) {
        const u = this.s.units.find(u => u.key === e.key),
        needed = e.type === 'band' ?[0, 3, 4, 7]: e.type === 'rap' ?[1, 4, 5]:[0, 2, 5];
        const strength = [... needed].sort((a, b) => Math.max(... e.members.map(x => x.stats[b])) - Math.max(... e.members.map(x => x.stats[a])))[0],
        weak = [... needed].sort((a, b) => Math.max(... e.members.map(x => x.stats[a])) - Math.max(... e.members.map(x => x.stats[b])))[0];
        return {
          strength,
          weak,
          cohesion: u?.cohesion || 0,
          roles: new Set(e.members.map(a => D.roster[a.id].position)).size
        };
      }
      mean(e, index) {
        const avg = super.mean(e, index);
        if (e.members.length < 2) return avg;
        const p = this.teamProfile(e);
        return Math.min(99, avg +(Math.max(... e.members.map(a => a.stats[index])) - avg) * .30 + p.cohesion * .035);
      }
      teamAction(key, action, id) {
        super.teamAction(key, action, id);
        const u = this.s.units.find(u => u.key === key);
        if (u && action === 'add') u.cohesion = round((u.cohesion || 0) * .8);
      }
      leaveTeam(id) {
        const u = this.s.units.find(u => u.ids.includes(Number(id)));
        super.leaveTeam(id);
        if (u) u.cohesion = round((u.cohesion || 0) * .8);
      }
      get entities() {
        return [... this.s.units.filter(u => u.status === 'active' && u.ids.length >= 2).map(u => this.entity(u.key)), ... this.s.artists.map(a => this.entity(String(a.id)))];
      }
      projectQuote(key, kind, budget, options = {}) {
        return D.rules.quote(budget, kind, { ... options, promotionCost: D.promotionPlans[options.promotion || 'none']?.cost || 0 }, this.s.perks);
      }
      spend(n, label, meta = {}) {
        if (this._projectCharge && meta.kind === 'production') return super.spend(round(n - this._projectCharge.discount), label, meta);
        return super.spend(n, label, meta);
      }
      startProject(key, kind, title, budget, concept, options = {}) {
        const q = this.projectQuote(key, kind, budget, options);
        if (this.s.cash < q.total) throw Error('할인 적용 후 제작·제조·홍보비를 합친 자금이 부족합니다.');
        // Lower layers validate combined nominal costs. Quote-aware spend charges only actual cost.
        this._projectCharge = q;
        this._affordabilityDiscount = q.discount;
        try {
          super.startProject(key, kind, title, budget, concept, options);
        } finally {
          this._projectCharge = null;
          this._affordabilityDiscount = 0;
        }
        const j = this.s.jobs.at(- 1);
        j.productionDiscount = q.discount;
        j.actualProductionCost = q.production;
        if (q.discount) this.s.perks.productionVoucher--;
        if (kind === 'single' && this.s.perks.debutPromo > 0) {
          j.freePromotion = true;
          this.s.perks.debutPromo--;
        }
        if (kind === 'live' && this.s.perks.livePromo > 0) {
          j.freeLivePromotion = true;
          this.s.perks.livePromo--;
        }
        if (kind === 'single') {
          const e = this.entity(key);
          j.coverBoost = Math.min(.16, e.members.reduce((n, a) => n + this.coverAttention(a), 0) / e.members.length);
          e.members.forEach(a => {
            a.coverAttention = 0;
          });
        }
        if (kind === 'live') {
          const e = this.entity(key);
          for (const a of e.members) if (!a.storyKeys?.includes('firststage')) {
            this.openStory(a.id, 'firststage');
            break;
          }
        }
      }
      coverAttention(a) {
        return Math.max(0, (a.coverAttention || 0) *(1 - Math.max(0, this.s.day -(a.coverAttentionDay || 0)) / 60));
      }
      concert(e, j, quality) {
        let base = super.concert(e, j, quality),
        unitCost = j.budget <= 300 ? .8: j.budget <= 800 ? 1.2: 1.8,
        u = this.s.units.find(u => u.key === e.key),
        fan = e.members.reduce((n, a) => n + a.fans, 0),
        recent = this.s.performance.filter(p => p.kind === 'live' && p.day > this.s.day - 30 && p.ids.some(id => e.members.some(a => a.id === id))).length;
        if (e.members.length > 1) {
          const size = j.budget <= 300 ? {
            name: '팀 클럽 무대',
            capacity: 500,
            ticket: 10,
            variable: 1
          }
          : j.budget <= 800 ? {
            name: '팀 중형 공연장',
            capacity: 1400,
            ticket: 11,
            variable: 1.4
          }
          : {
            name: '팀 대형 공연장',
            capacity: 3200,
            ticket: 13,
            variable: 2
          };
          const demand =(quality * 2.4 + fan * .25 +(u?.fans || 0) * .30) *(10 / size.ticket) * this.imageFactor() *(1 + this.staffPower('live') * .2) *(1 +(u?.cohesion || 0) * .0015) /(1 + recent * .2);
          unitCost = size.variable;
          base = { ... size, attendance: clamp(Math.floor(demand), 0, size.capacity), recent };
        }
        const lastRelease = this.s.catalog.filter(c => c.market.ids.some(id => e.members.some(a => a.id === id))).at(- 1),
        newMusic = lastRelease && this.s.day - lastRelease.market.startDay <= 45 ? 1.08: 1,
        repeat =(1 + recent * .2) /(1 + recent * .32),
        promo = j.freeLivePromotion ? 1.08: 1;
        base.attendance = clamp(Math.floor(base.attendance * repeat * newMusic * promo), 0, base.capacity);
        base.gross = base.attendance * base.ticket;
        base.variable = round(base.attendance * unitCost);
        j.factors = j.factors ||[];
        if (base.recent > 0) j.factors.unshift('최근30일 공연 ' + base.recent + '회 · 반복 수요 조정 적용');
        if (newMusic > 1) j.factors.unshift('최근45일 신곡 · 공연 관심 +8%');
        if (promo > 1) j.factors.unshift('공연 홍보 지원 · 관객 수요 +8%');
        j.concert = base;
        return base;
      }
      newFans(e, j, quality, fan) {
        const gain = super.newFans(e, j, quality, fan);
        if (e.members.length < 2) return gain;
        this._fanGain = Math.floor(gain * 1.18);
        return this._fanGain;
      }
      finishEvolution(j) {
        const count = this.s.catalog.length,
        e = j.kind === 'casting' ? null: this.projectEntity(j),
        priorFans = e?.members.reduce((n, a) => n + a.fans, 0) || 0,
        priorSettlements = this.s.settlements[0];
        this.finishOperations(j);
        if (!e) return;
        const u = this.s.units.find(u => u.key === j.entity);
        if (j.entity?.startsWith('u') && j.snapshot?.ids.length >= 2 &&['single', 'live', 'cover'].includes(j.kind)) this.s.goalEvidence.team = 1;
        if (['single', 'live', 'cover'].includes(j.kind)) {
          if (u) {
            u.completedActivities =(u.completedActivities || 0) + 1;
            u.cohesion = clamp((u.cohesion || 0) + 3, 0, 100);
            this.s.goalEvidence.team = 1;
          }
          if (e.members.some(a => D.roster[a.id].career)) this.s.goalEvidence.comeback = 1;
          const ids = e.members.map(a => a.id);
          this.remember(ids, 'activity', j.name + ' · ' +({ single: '싱글 발매', live: '공연 완료', cover: '커버 공개' }[j.kind]));
          if (j.kind === 'cover') {
            const repeats = this.s.performance.filter(p => p.kind === 'cover' && p.day > this.s.day - 60 && p.ids.some(id => ids.includes(id))).length;
            for (const a of e.members) {
              a.coverAttention = Math.min(.16, this.coverAttention(a) + .08 / Math.max(1, repeats));
              a.coverAttentionDay = this.s.day;
            }
          }
          if (j.kind === 'single') {
            const c = this.s.catalog[count];
            c.market.production = round(c.market.production -(j.productionDiscount || 0));
            c.market.appeal = clamp(c.market.appeal *(1 +(j.coverBoost || 0) +(j.freePromotion ? .08: 0)), .3, 1.5);
            if (e.members.length > 1) {
              c.market.fanBase = Math.round(priorFans * .85 +(u?.fans || 0) * .60);
              c.market.appeal = clamp(c.market.appeal *(1 + Math.min(.20, e.members.length * .025 +(u?.cohesion || 0) * .001)), .3, 1.5);
            }
            this.resurface(ids, '새 싱글 발매', c.id);
          }
          if (j.kind === 'live') {
            this.s.goalEvidence.live = Math.max(this.s.goalEvidence.live, j.concert.attendance > 0 ? 1: 0);
            let entry = this.s.settlements[0];
            if (entry !== priorSettlements) {
              entry.budget = j.actualProductionCost ?? j.budget;
              entry.net = round(entry.gross - entry.payout - entry.variable - entry.budget);
              if (entry.net > 0) this.s.goalEvidence.liveprofit = 1;
            }
            if (j.concert.attendance > 0) this.resurface(ids, '공연 이후 다시 듣기');
          }
          for (const id of ids.filter(id => D.roster[id].career)) this.moment('comeback-' + id, D.roster[id].name + '의 새로운 출발', '“이번에는 제 속도로 오래 음악을 하고 싶어요.”\n우리 회사에서 첫 활동을 마쳤습니다.', [id]);
        }
        const entry = this.s.settlements[0],
        net = j.kind === 'live' && entry !== priorSettlements ? entry.net: null,
        outcome = {
          id: this.id(),
          day: this.s.day,
          kind: j.kind,
          title: j.name,
          entity: j.entity,
          ids: e.members.map(a => a.id),
          quality: round(this._lastQuality || 0),
          fans: e.members.reduce((n, a) => n + a.fans, 0) - priorFans,
          attendance: j.concert?.attendance || 0,
          capacity: j.concert?.capacity || 0,
          net,
          production: j.actualProductionCost ?? j.budget ?? 0,
          factors:(j.factors ||[]).slice(0, 3)
        };
        this.s.outcomes.push(outcome);
        this.s.outcomes = this.s.outcomes.slice(- 60);
        const r = this.s.reports.find(r => r.kind === 'result' && r.day === this.s.day && !r.outcomeId);
        if (r) r.outcomeId = outcome.id;
      }
      resurface(ids, reason, exclude = null) {
        for (const c of this.s.catalog) {
          if (c.id === exclude || this.s.day - c.market.startDay < 30 || !c.market.ids.some(id => ids.includes(id))) continue;
          if (c.market.resurfacedDay !== undefined && this.s.day - c.market.resurfacedDay < 45) continue;
          c.market.resurfacedDay = this.s.day;
          c.market.resurfaceUntil = this.s.day + 14;
          c.market.resurfaceReason = reason;
          this.log(c.name + ' · ' + reason + '로 이전 작품에 다시 관심이 모입니다.');
        }
      }
      releaseDay(c, owner) {
        const m = c.market,
        oldAppeal = m.appeal;
        if (owner === 'player' && m.resurfaceUntil > this.s.day) m.appeal = clamp(oldAppeal * 1.25, .3, 1.5);
        let result;
        try {
          result = super.releaseDay(c, owner);
        } finally {
          m.appeal = oldAppeal;
        }
        return result;
      }
      tickCatalog() {
        const hits = new Set(this.s.catalog.filter(c => c.market.hit).map(c => c.id));
        super.tickCatalog();
        for (const c of this.s.catalog) if (c.market.hit && !hits.has(c.id)) {
          this.remember(c.market.ids, 'hit', c.name + ' · 실제 흥행 기준을 달성했습니다.');
          this.moment('hit-' + c.entity, c.market.artistName + '의 첫 흥행', '「' + c.name + '」을 기다리는 사람들이 늘었습니다.\n“우리 음악이 누군가에게 닿았네요.”', c.market.ids);
          this.resurface(c.market.ids, '신곡 흥행', c.id);
        }
      }
      openStory(id, kind) {
        const a = this.talent(id);
        if (!a || !D.personalStories[kind] || a.storyKeys?.includes(kind) || this.s.stories.some(x => x.status === 'open')) return;
        const story = {
          id: this.id(),
          talentId: id,
          kind,
          day: this.s.day,
          expires: this.s.day + 14,
          status: 'open',
          choice: null
        };
        this.s.stories.push(story);
        this.s.stories = this.s.stories.slice(- 120);
        a.storyKeys.push(kind);
        const d = D.personalStories[kind];
        this.report(D.roster[id].name + ' · ' + d.title, d.body + '\n14일 안에 이야기할 수 있습니다. 기한이 지나도 별도 능력·신뢰 페널티는 없습니다.', 'info', true, { storyId: story.id, talentId: id });
      }
      resolveStory(id, choice) {
        const s = this.s,
        story = s.stories.find(x => x.id === Number(id)),
        a = story && this.talent(story.talentId);
        if (!story || story.status !== 'open' || story.expires < s.day || !a || !['support', 'space'].includes(choice)) throw Error('현재 대화할 수 있는 사건과 선택을 확인하세요.');
        const d = D.personalStories[story.kind],
        preferred = choice === 'space' ? this.personality(a.id).session === 'rest': this.personality(a.id).session !== 'rest';
        if (choice === 'support') this.spend(100, '개인 사건 상담: ' + D.roster[a.id].name);
        a.trust = clamp(a.trust +(preferred ? 5: 3), 0, 100);
        a.stress = clamp(a.stress -(choice === 'space' ? 10: 6), 0, 100);
        if (choice === 'space') a.energy = clamp(a.energy + 5, 0, 100);
        story.status = 'resolved';
        story.choice = choice;
        const reply = choice === 'support' ? d.replySupport: d.replySpace;
        this.remember([a.id], 'choice', d.title + ' · ' +(choice === 'support' ? '상담 지원': '부담을 덜어 주는 대화') + ' · “' + reply + '”');
        for (const r of s.reports) if (r.storyId === story.id) {
          r.resolved = true;
          r.read = true;
        }
        this.report(D.roster[a.id].name + '의 답장', '“' + reply + '”', 'info', false, { talentId: a.id });
      }
      trainingReaction(id) {
        const a = this.talent(id),
        memory = a?.memories?.filter(m => m.kind === 'choice').at(- 1);
        return memory && this.s.day - memory.day < 30 ? memory.text.slice(memory.text.indexOf('“') + 1, memory.text.lastIndexOf('”')): super.trainingReaction(id);
      }
      offerEligible(o, key) {
        const e = this.entity(key);
        if (!e || o.used || o.expires < this.s.day) return false;
        const u = this.s.units.find(u => u.key === key);
        return o.kind === 'fan' ? Math.max(e.members.reduce((n, a) => n + a.fans, 0), u?.fans || 0) >= 1000: o.kind === 'star' ?(u?.star ?? e.members[0].star) >= 3: o.kind === 'collab' ? this.metrics().profit > 0: this.stage >= 5;
      }
      acceptOffer(id, key) {
        const o = this.s.specialOffers.find(x => x.id === Number(id));
        if (!o || !this.offerEligible(o, key)) throw Error('제안 기한과 대상의 현재 조건을 확인하세요.');
        const spec = D.specialOffers[o.kind];
        this.startProject(key, spec.kind, spec.title, spec.budget, 'balanced');
        const j = this.s.jobs.at(- 1);
        j.specialOffer = o.kind;
        // A limited campaign advantage, never a guaranteed profit.
        if (spec.kind === 'single') j.coverBoost = Math.min(.20, (j.coverBoost || 0) + .04);
        else j.freeLivePromotion = true;
        o.used = true;
        this.log(spec.title + ' 승인 · 일반 비용·배분·일정 규칙 적용');
      }
      get pending() {
        const urgent = this.s.reports.filter(r => !r.resolved &&((r.kind === 'ad' && r.expires >= this.s.day) ||(r.kind === 'casting' && !r.read) ||(r.kind === 'crisis' && this.s.cash < 0) || r.storyId ||(r.incidentId && this.s.incidents.some(i => i.id === r.incidentId && i.state === 'open')) ||(r.kind === 'finance' && r.important && !r.read)));
        for (const r of this.s.reports) {
          const a = this.artist(r.talentId);
          if (!r.read && !r.resolved && r.kind === 'contract' && a && a.contract - this.s.day <= 30 && a.contract === r.contractDue && !urgent.includes(r)) urgent.push(r);
        }
        return urgent;
      }
      report(title, body, kind = 'info', important = false, extra = {}) {
        if (this.s.evolutionVersion === 1 && title === '목표 달성') return;
        if (this.s.evolutionVersion === 1 && title === '육성 담당 주간 보고') {
          const x = this.s.staffImpact || { saved: 0, trainingDays: 0, recoveryDays: 0 },
          ready = this.s.trainees.filter(a => this.s.day - a.signed >= 90 && this.readiness(a) >= 55).length,
          rest = this.s.trainees.filter(a => a.trainingPlan === 'rest').length;
          body = '데뷔 검토 ' + ready + '명 / 회복 계획 ' + rest + '명\n직원 지도 훈련 ' + x.trainingDays + '인일 · 직원 자동 회복 조정 ' + x.recoveryDays + '인일\n실제 연습생 훈련비 절감 ' + round(x.saved) + '만 원 (기록 ' + x.since + '일째부터)\n' + body;
        }
        return super.report(title, body, kind, important, extra);
      }
      trainTrainees() {
        const before = this.s.trainees.map(a =>({ id: a.id, trained: a.trainedDays || 0 }));
        super.trainTrainees();
        const x = this.s.staffImpact;
        if (!x) return;
        for (const b of before) {
          const a = this.talent(b.id);
          if (!a) continue;
          const trained =(a.trainedDays || 0) > b.trained;
          if (trained && this.coach(a.trainingPlan).staff) {
            x.trainingDays++;
            x.saved = round(x.saved + Base.trainingPlans[a.trainingPlan].cost * .2);
          }
          if (!trained && a.trainingMode === 'auto' && this.has('trainer') && a.trainingPlan === 'rest') x.recoveryDays++;
        }
      }
      advanceEvolution() {
        const s = this.s,
        cashBefore = s.cash,
        reportsBefore = new Set(s.reports.map(r => r.id));
        this.advanceSummary();
        for (const u of s.units) if (u.status === 'active' && u.ids.length >= 2 && u.ids.every(id => this.artist(id).energy >= 35)) u.cohesion = round(clamp((u.cohesion || 0) + .08, 0, 100));
        for (const st of s.stories) if (st.status === 'open' &&(st.expires < s.day || !this.talent(st.talentId))) {
          st.status = 'expired';
          for (const r of s.reports) if (r.storyId === st.id) {
            r.resolved = true;
            r.read = true;
          }
        }
        if (s.day % 60 === 0 && !s.stories.some(x => x.status === 'open')) {
          const pool = [... s.artists, ... s.trainees];
          for (const a of pool) {
            const kind = s.units.some(u => u.ids.includes(a.id)) ? 'team': this.personality(a.id).session === 'creative' ? 'creative': 'pressure';
            if (!a.storyKeys.includes(kind)) {
              this.openStory(a.id, kind);
              break;
            }
          }
        }
        if (s.day % 30 === 0 && s.day - 30 >= s.evolutionSince) {
          const bins = s.accounts.filter(b => b.day > s.day - 30 && b.day <= s.day),
          profit = round(bins.reduce((n, b) => n + b.revenue - b.expense, 0));
          s.monthProfits.push({ day: s.day, profit });
          s.monthProfits = s.monthProfits.slice(- 12);
        }
        // Management checks run before this complete day's receipts; settle goals once more now.
        for (const g of this.goalList()) if (!g.done && g.value >= g.target) {
          s.goals.push(g.id);
          this.log('목표 달성: ' + g.title);
        }
        this.grantGoalRewards();
        if (s.day % 7 === 0) {
          this.report('주간 운영 요약', '최근7일 훈련·정산은 하루 기록에 모았습니다.\n확정 정산 예정 ' + s.receivables.length + '건 · 현재 소속 ' + s.artists.length + '명 · 연습생 ' + s.trainees.length + '명\n훈련 성장과 회복은 연습생 상세, 실제 입출금은 재정에서 확인하세요.', 'info', false, { weeklySummary: true });
        }
        this.closeFinancialDay();
        // Include post-settlement grants in the daily cash record, without making them operating revenue.
        const summary = s.daySummaries.at(- 1);
        if (summary?.day === s.day) {
          summary.cashChange = round(s.cash - cashBefore);
          summary.newReports = s.reports.filter(r => !reportsBefore.has(r.id)).length;
        }
        return this.pending.length;
      }
    }
    return EvolutionGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installEvolution = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
