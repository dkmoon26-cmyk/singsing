/* FILE src/state.js */
(function(root) {
  'use strict';
  const legacy = typeof module !== 'undefined' ? require('./legacy-state.js'): root.validLegacyState;
  const D = typeof module !== 'undefined' ? require('./evolution-data.js'): root.DATA;
  function validState(s) {
    try {
      if (!legacy(s)) return false;
      if (s.managementVersion === undefined) return true;
      if (s.managementVersion !== 2) return false;
      const n =(x, min = 0, max = 1e12) => Number.isFinite(x) && x >= min && x <= max;
      const i =(x, min = 0, max = 1e9) => Number.isInteger(x) && x >= min && x <= max;
      const arr =(x, max = 10000) => Array.isArray(x) && x.length <= max && x.every(v => v !== null);
      const round2 = x => Math.round(x * 100) / 100;
      const unique = x => new Set(x).size === x.length;
      const text =(x, max = 500) => typeof x === 'string' && x.length <= max;
      const person = a => a && i(a.id, 0, D.roster.length - 1) && arr(a.stats, 8) && a.stats.length === 8 && a.stats.every(v => n(v, 0, 99)) &&['energy', 'stress', 'trust', 'fame'].every(k => n(a[k], 0, 100)) && i(a.fans) && i(a.contract) && i(a.signed, 0, s.day) && i(a.lastActive, 0, s.day) && a.terms && n(a.terms.share, 0, 1) && n(a.terms.fee) && i(a.terms.days, 1, 3650) && text(a.terms.name) &&['balanced', 'creative', 'stage', 'rest'].includes(a.focus) && i(a.star, 0, 4) && i(a.bestStar, 0, 4) &&(a.starSince == null || i(a.starSince, 0, s.day));
      if (!i(s.recordSince, 0, s.day) || !i(s.companyLevel, 1, 5) || !i(s.lowQuarters, 0, 1)) return false;
      for (const k of['accounts', 'trainees', 'departed', 'teamArchive', 'goals', 'performance', 'payments', 'industryNews', 'valuations', 'rivals']) if (!arr(s[k])) return false;
      if (![... s.artists, ... s.trainees, ... s.departed].every(a => person(a) &&(a.lastPersonalDay === undefined || i(a.lastPersonalDay, 0, s.day)))) return false;
      if (!unique(s.artists.concat(s.trainees).map(a => a.id)) || !unique(s.departed.map(a => a.id)) || s.departed.some(a => s.artists.concat(s.trainees).some(b => a.id === b.id))) return false;
      const key = x => typeof x === 'string' && /^(u[1-9]\d*|0|[1-9]\d*)$/.test(x);
      const bins = xs => arr(xs, 366) && xs.every(b => i(b.day, 0, s.day) && n(b.revenue) && n(b.expense));
      if (!bins(s.accounts) || !unique(s.accounts.map(b => b.day)) || !s.accounts.every(b => b.by && typeof b.by === 'object' && !Array.isArray(b.by) && Object.entries(b.by).every(([k, v]) => key(k) && n(v)))) return false;
      if (!s.units.every(u =>['active', 'hiatus'].includes(u.status) && n(u.fame, 0, 100) && i(u.fans) && i(u.star, 0, 4) && i(u.bestStar, 0, 4))) return false;
      const allPeople = [... s.artists, ... s.departed];
      const shares = x => arr(x, 5) && unique(x.map(v => v.id)) && x.every(v => i(v.id, 0, D.roster.length - 1) && n(v.rate, 0, 1)) && x.reduce((n, v) => n + v.rate, 0) <= 1.000001;
      if (!s.catalog.every(c => shares(c.shares) && text(c.ownerName))) return false;
      if (!s.jobs.every(j => j.kind === 'casting' || j.snapshot && key(j.snapshot.key) && j.entity === j.snapshot.key && text(j.snapshot.name, 30) &&['idol', 'band', 'rap'].includes(j.snapshot.type) && arr(j.snapshot.ids, 5) && j.snapshot.ids.length > 0 && unique(j.snapshot.ids) && j.snapshot.ids.every(id => allPeople.some(a => a.id === id)) && shares(j.shares))) return false;
      if (s.rivals.length !== 4 || !unique(s.rivals.map(r => r.id)) || !s.rivals.every(r => i(r.id, 0, 3) && text(r.name, 30) &&['idol', 'band', 'rap', 'any'].includes(r.type) && n(r.cash, - 1e12) && n(r.debt) && arr(r.artists, D.roster.length) && unique(r.artists) && r.artists.every(id => i(id, 0, D.roster.length - 1)) && arr(r.catalog, 240) && r.catalog.every(c => text(c.name) && n(c.quality, 0, 100) && i(c.age)) && bins(r.accounts) && i(r.serial) && i(r.fans) && n(r.reputation, 0, 100) && i(r.level, 1, 5) && n(r.value))) return false;
      const owners = s.artists.concat(s.trainees).map(a => a.id).concat(s.rivals.flatMap(r => r.artists));
      if (!unique(owners) || s.candidates.some(c => owners.includes(c.id))) return false;
      if (!s.goals.every(g =>['sign', 'trainee', 'debut', 'release', 'catalog', 'profit', 'staff', 'fans', 'renew', 'star', 'rival', 'large', 'live', 'liveprofit', 'team', 'physical', 'comeback', 'stable'].includes(g)) || !unique(s.goals)) return false;
      if (!s.performance.every(p => i(p.day, 0, s.day) && key(p.key) && arr(p.ids, 5) && p.ids.every(id => i(id, 0, D.roster.length - 1)) &&['single', 'live', 'cover'].includes(p.kind) && n(p.quality, 0, 99))) return false;
      if (!s.payments.every(p => i(p.day, 0, s.day) && i(p.id, 0, D.roster.length - 1) && n(p.amount) && text(p.label))) return false;
      if (!s.industryNews.every(p => i(p.day, 0, s.day) && text(p.text, 2000)) || !s.valuations.every(v => i(v.day, 0, s.day) && n(v.value) && n(v.revenue) && n(v.profit, - 1e12))) return false;
      if (!s.teamArchive.every(u => key(u.key) && text(u.name, 20) && arr(u.ids, 5) && u.ids.every(id => i(id, 0, D.roster.length - 1)) && i(u.ended, 0, s.day))) return false;
      for (const k of['debutCount', 'renewCount']) if (s[k] !== undefined && !i(s[k])) return false;
      if (s.balanceVersion !== undefined) {
        if (s.balanceVersion !== 1 || !n(s.image, 0, 100) || !i(s.lastIncidentDay, - 90, s.day) || !arr(s.incidents, 80) || !arr(s.settlements, 80)) return false;
        if (![... s.trainees, ... s.artists, ... s.departed].every(a =>['balanced', 'vocal', 'performance', 'creative', 'rest'].includes(a.trainingPlan) && i(a.trainedDays))) return false;
        if (!s.rivals.every(r => n(r.image, 0, 100) && text(r.lastAction, 100) && arr(r.talents, D.roster.length) && unique(r.talents.map(t => t.id)) && r.talents.length === r.artists.length && r.talents.every(t => r.artists.includes(t.id) && n(t.skill, 0, 99) && n(t.energy, 0, 100) && n(t.trust, 0, 100) && i(t.contract) && typeof t.active === 'boolean'))) return false;
        if (!unique(s.incidents.map(x => x.id)) || !s.incidents.every(x => i(x.id, 1, s.serial) &&['cancel', 'sound', 'notice', 'overwork'].includes(x.kind) && key(x.key) && text(x.name, 30) && i(x.day, 0, s.day) && i(x.expires, x.day) && i(x.severity, 1, 3) &&['open', 'investigating', 'closed'].includes(x.state) &&(x.choice === null ||['explain', 'repair', 'investigate', 'ignore'].includes(x.choice)) &&(x.responseDue === null || i(x.responseDue, x.day)) && arr(x.losses, 5) && unique(x.losses.map(l => l.id)) && x.losses.every(l => i(l.id, 0, D.roster.length - 1) && i(l.lost)) && i(x.teamLost) && n(x.imageLoss, 0, 100) && i(x.recovered))) return false;
        if (s.incidents.filter(x => x.state !== 'closed').length > 1) return false;
        if (!s.settlements.every(x => i(x.day, 0, s.day) && text(x.name, 60) &&['live', 'ad'].includes(x.kind) &&['gross', 'payout', 'variable', 'budget'].every(k => n(x[k])) && n(x.net, - 1e12) && i(x.attendance) && i(x.capacity) && x.attendance <= x.capacity)) return false;
      }
      if (s.marketVersion !== undefined) {
        if (s.marketVersion !== 1 || !n(s.lastReputation, 0, 100) || !text(s.reputationReason, 1000)) return false;
        const release =(c) => {
          let m = c.market;
          return m && typeof m.uid === 'string' && /^(p-\d+|r[0-3]-(?:old-)?\d+)$/.test(m.uid) &&(m.owner === 'player' || /^r[0-3]$/.test(m.owner)) && i(m.startDay, 0, s.day) && i(m.measuredFrom, 0, s.day + 1) && i(m.lastDay, - 1, s.day) && typeof m.legacy === 'boolean' &&['digital', 'physical'].includes(m.format) && m.price === 2.5 && m.unitCost === .6 && i(m.stock, 0, 100000) && i(m.manufactured) && m.sales + m.stock === m.manufactured &&['manufacturing', 'production', 'fanBase', 'gross', 'distribution', 'receipts', 'paid', 'payout', 'pending', 'streamGross', 'physicalGross', 'streamReceipts', 'physicalReceipts', 'pendingStream', 'pendingPhysical', 'paidStream', 'paidPhysical', 'payoutStream', 'payoutPhysical'].every(k => n(m[k])) && n(m.fame, 0, 100) && n(m.appeal, .3, 1.5) && n(m.discovery, 1, 1.7) && i(m.streams, 0, Number.MAX_SAFE_INTEGER) && i(m.sales) &&(m.firstWeekSales === null && m.legacy || i(m.firstWeekSales, 0, m.sales)) && i(m.pendingDays, 0, 6) && typeof m.hit === 'boolean' && arr(m.ids, D.roster.length) && m.ids.every(id => i(id, 0, D.roster.length - 1)) &&['idol', 'band', 'rap'].includes(m.type) && text(m.artistName, 60) && Math.abs(m.receipts - m.paid - m.pending) < .03 && Math.abs(m.gross - m.distribution - m.receipts) < .03 && Math.abs(m.paid - m.paidStream - m.paidPhysical) < .03 && Math.abs(m.payout - m.payoutStream - m.payoutPhysical) < .03 && Math.abs(m.pending - m.pendingStream - m.pendingPhysical) < .03 && Math.abs(m.receipts - m.streamReceipts - m.physicalReceipts) < .03 && arr(m.days, 28) && unique(m.days.map(d => d.day)) && m.days.every(d => i(d.day, 0, s.day) && i(d.streams, 0, Number.MAX_SAFE_INTEGER) && i(d.sales)) && arr(m.weeks, 104) && unique(m.weeks.map(w => w.week)) && m.weeks.every(w => i(w.week) && i(w.streams, 0, Number.MAX_SAFE_INTEGER) && i(w.sales));
        };
        const releases = [... s.catalog, ... s.rivals.flatMap(r => r.catalog)];
        if (!releases.every(release) || !unique(releases.map(c => c.market.uid))) return false;
        if (!s.jobs.every(j => j.kind !== 'single' || j.releaseOptions &&['digital', 'physical'].includes(j.releaseOptions.format) && n(j.manufacturing) && j.manufacturing === j.releaseOptions.quantity * .6 &&(j.releaseOptions.format === 'digital' ? j.releaseOptions.quantity === 0:[1000, 3000, 10000].includes(j.releaseOptions.quantity)))) return false;
        for (const a of[... s.artists, ... s.units]) if (a.marketStarSince !== undefined && a.marketStarSince !== null && !i(a.marketStarSince, 0, s.day)) return false;
      }
      if (s.feedbackVersion !== undefined) {
        if (s.feedbackVersion !== 1 || !arr(s.daySummaries, 30) || !unique(s.daySummaries.map(d => d.day)) || !s.daySummaries.every(d => i(d.day, 1, s.day) && d.fromDay === d.day - 1 && n(d.cashChange, - 1e12) && i(d.streams, 0, Number.MAX_SAFE_INTEGER) && i(d.sales) && i(d.fansChange, - 1e9) && i(d.teamFansChange, - 1e9) && i(d.trainingCount, 0, 100) && arr(d.completed, 100) && d.completed.every(j =>['casting', 'single', 'live', 'cover', 'ad'].includes(j.kind) && text(j.title, 60)) && i(d.newReports, 0, 1000) && arr(d.departed, D.roster.length) && d.departed.every(id => i(id, 0, D.roster.length - 1)))) return false;
      }
      if (s.operationsVersion !== undefined) {
        if (s.operationsVersion !== 1 || !i(s.operationsSince, 0, s.day) || !i(s.staffMarketSeed, 0, 4294967295) || !arr(s.receivables, 300) || !unique(s.receivables.map(x => x.id))) return false;
        if (s.staffBoard !== undefined &&(!s.staffBoard || !i(s.staffBoard.day, 0, s.day) || !arr(s.staffBoard.ids, 5) || !unique(s.staffBoard.ids) || !s.staffBoard.ids.every(id => D.staff.some(p => p.id === id)))) return false;
        if (!s.receivables.every(x => i(x.id, 1, s.serial) && i(x.due, s.day + 1, s.day + 30) && n(x.amount) && text(x.label, 200) && key(x.key) && shares(x.shares))) return false;
        if (![... s.trainees, ... s.artists, ... s.departed].every(a =>['auto', 'manual'].includes(a.trainingMode) &&['balanced', 'debut', 'longterm', 'vocal', 'performance', 'creative'].includes(a.trainingGoal) && i(a.recoveryUntil, 0, s.day + 30) && arr(a.growthHistory, 91) && a.growthHistory.length > 0 && unique(a.growthHistory.map(x => x.day)) && a.growthHistory.every((x, j) => i(x.day, 0, s.day) &&(!j || x.day > a.growthHistory[j - 1].day) && arr(x.stats, 8) && x.stats.length === 8 && x.stats.every(v => n(v, 0, 99)) && text(x.reason, 100)))) return false;
        if (!s.jobs.every(j =>(j.experience === undefined ||['any', 'career', 'trainee'].includes(j.experience)) &&(j.promotion === undefined || D.promotionPlans[j.promotion] && n(j.promotionCost) && j.promotionCost === D.promotionPlans[j.promotion].cost))) return false;
      }
      if (s.evolutionVersion !== undefined) {
        if (s.evolutionVersion !== 1 || !i(s.evolutionSince, 0, s.day) || typeof s.soundEnabled !== 'boolean') return false;
        const goalIds = Object.keys(D.goalRewards),
        people = [... s.artists, ... s.trainees, ... s.departed];
        if (!arr(s.rewardPaid, 18) || !unique(s.rewardPaid) || !s.rewardPaid.every(id => goalIds.includes(id) && s.goals.includes(id))) return false;
        if (!s.perks || !['debutPromo', 'productionVoucher', 'livePromo'].every(k => i(s.perks[k], 0, 1))) return false;
        if (!s.goalEvidence || !['live', 'liveprofit', 'team', 'comeback'].every(k => i(s.goalEvidence[k], 0, 1))) return false;
        if (!arr(s.monthProfits, 12) || !unique(s.monthProfits.map(x => x.day)) || !s.monthProfits.every((x, j) => i(x.day, 0, s.day) && x.day % 30 === 0 && x.day - 30 >= s.evolutionSince && n(x.profit, - 1e12) &&(!j || x.day > s.monthProfits[j - 1].day))) return false;
        if (!s.staffImpact || !i(s.staffImpact.since, 0, s.day) || !n(s.staffImpact.saved) || !i(s.staffImpact.trainingDays) || !i(s.staffImpact.recoveryDays)) return false;
        if (!(s.pinnedEntity === null || key(s.pinnedEntity)) || !arr(s.milestoneKeys, 1000) || !unique(s.milestoneKeys) || !s.milestoneKeys.every(k => text(k, 100))) return false;
        if (!people.every(a => arr(a.memories, 60) && a.memories.every(m => i(m.day, 0, s.day) &&['start', 'contract', 'debut', 'renew', 'team', 'activity', 'hit', 'choice', 'award'].includes(m.kind) && text(m.text, 500)) && arr(a.storyKeys, 5) && unique(a.storyKeys) && a.storyKeys.every(k => Object.hasOwn(D.personalStories, k)) && n(a.coverAttention, 0, .16) && i(a.coverAttentionDay, 0, s.day))) return false;
        if (!s.units.every(u => n(u.cohesion, 0, 100) && i(u.completedActivities))) return false;
        const talentIds = xs => arr(xs, 5) && unique(xs) && xs.every(id => i(id, 0, D.roster.length - 1));
        if (!arr(s.moments, 80) || !s.moments.every(m => i(m.id, 1, s.serial) && i(m.day, 0, s.day) && text(m.title, 200) && text(m.body, 2000) && talentIds(m.ids) && typeof m.seen === 'boolean')) return false;
        if (!arr(s.outcomes, 60) || !s.outcomes.every(o => i(o.id, 1, s.serial) && i(o.day, 0, s.day) &&['single', 'live', 'cover', 'ad'].includes(o.kind) && text(o.title, 60) && key(o.entity) && talentIds(o.ids) && n(o.quality, 0, 99) && i(o.fans, - 1e9) && i(o.attendance) && i(o.capacity) && o.attendance <= o.capacity &&(o.net === null || n(o.net, - 1e12)) && n(o.production))) return false;
        if (!arr(s.stories, 120) || !s.stories.every(st => i(st.id, 1, s.serial) && i(st.talentId, 0, D.roster.length - 1) && Object.hasOwn(D.personalStories, st.kind) && i(st.day, 0, s.day) && st.expires === st.day + 14 &&['open', 'resolved', 'expired'].includes(st.status) &&(st.choice === null ||['support', 'space'].includes(st.choice)))) return false;
        if (s.stories.filter(st => st.status === 'open').length > 1) return false;
        if (!arr(s.specialOffers, 4) || !unique(s.specialOffers.map(o => o.kind)) || !s.specialOffers.every(o => i(o.id, 1, s.serial) && Object.hasOwn(D.specialOffers, o.kind) && i(o.day, 0, s.day) && o.expires === o.day + D.specialOffers[o.kind].days && typeof o.used === 'boolean')) return false;
        const extraIds = [... s.moments, ... s.outcomes, ... s.stories, ... s.specialOffers].map(x => x.id),
        existingIds = [... s.jobs, ... s.reports, ... s.catalog, ... s.loans].map(x => x.id).concat(s.units.map(u => Number(u.key.slice(1))));
        if (!unique([... extraIds, ... existingIds])) return false;
        if (!s.jobs.every(j =>(j.productionDiscount === undefined || n(j.productionDiscount, 0, 200) && n(j.actualProductionCost) && j.actualProductionCost === round2(j.budget - j.productionDiscount)) &&(j.coverBoost === undefined || n(j.coverBoost, 0, .20)) &&(j.freePromotion === undefined || typeof j.freePromotion === 'boolean') &&(j.freeLivePromotion === undefined || typeof j.freeLivePromotion === 'boolean'))) return false;
        for (const c of s.catalog) {
          const m = c.market;
          if (m.resurfaceUntil !== undefined &&(!i(m.resurfacedDay, 0, s.day) || m.resurfaceUntil !== m.resurfacedDay + 14 || !text(m.resurfaceReason, 100))) return false;
        }
      }
      if (s.reliabilityVersion !== undefined) {
        if (s.reliabilityVersion !== 1) return false;
        if (!s.receivables.every(x =>['concert_settlement', 'ad_balance'].includes(x.kind))) return false;
      }
      if (s.campaignVersion !== undefined) {
        if (s.campaignVersion !== 1) return false;
        for (const j of s.jobs) {
          if (j.baselineDue !== undefined) {
            if (j.kind !== 'single' || !i(j.baselineDue, j.start + 1) || !i(j.delayDays, 0, 100000) ||(!s.seasonVersion && j.delayDays % 5 !== 0) || j.due !== j.baselineDue + j.delayDays || !arr(j.pauses, 60) || !unique(j.pauses.map(p => p.adId))) return false;
            if (!j.pauses.every((p, index) => i(p.adId, 1, s.serial) &&(p.kind === undefined || p.kind === 'festival') && i(p.start, j.start, s.day +(s.seasonVersion ? 365: 0)) &&(p.kind === 'festival' && s.seasonVersion ?[3, 4].includes(p.end - p.start): p.end === p.start + 5) &&(!index || j.pauses[index - 1].end <= p.start)) || j.pauses.reduce((n, p) => n + p.end - p.start, 0) > j.delayDays) return false;
          } else if (j.pauses !== undefined || j.delayDays !== undefined) return false;
          if (j.interrupts !== undefined &&(j.kind !== 'ad' || !arr(j.interrupts, 72) || !unique(j.interrupts) || !j.interrupts.every(id => i(id, 1, s.serial)))) return false;
        }
        if (!s.reports.every(r =>(r.decision === undefined ||['accept', 'decline'].includes(r.decision)) &&(r.closedReason === undefined ||['expired', 'funded'].includes(r.closedReason)))) return false;
        if (!s.outcomes.every(o => o.factors === undefined || arr(o.factors, 3) && o.factors.every(x => text(x, 200)))) return false;
      }
      if (s.seasonVersion !== undefined) {
        const check = typeof module !== 'undefined' ? require('./season-state.js'): root.validSeasonState;
        if (!check(s, D)) return false;
      }
      return true;
    } catch {
      return false;
    }
  }
  if (typeof module !== 'undefined') module.exports = validState;
  else root.validState = validState;
})(typeof window !== 'undefined' ? window: globalThis);


;
