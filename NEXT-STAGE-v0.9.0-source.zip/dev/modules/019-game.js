/* FILE src/game.js */
(function(root) {
  const D = typeof module !== 'undefined' ? require('./evolution-data.js'): root.DATA;
  class Game {
    constructor(state) {
      this.s = state || null;
    }
    newGame(company, boss) {
      this.s = {
        version: 1,
        company,
        boss,
        day: 0,
        cash: 30000,
        seed: Math.floor(Math.random() * 999999) + 1,
        artists:[],
        units:[],
        staff:[],
        jobs:[],
        candidates:[],
        reports:[],
        ledger:[],
        history:[],
        catalog:[],
        loans:[],
        reputation: 0,
        releases: 0,
        totalRevenue: 0,
        monthIn: 0,
        monthOut: 0,
        lastMonth: null,
        policy: 'balanced',
        serial: 0
      };
      this.report('회사 설립을 축하드립니다', `${boss} 대표님, ${company}의 첫날입니다. 캐스팅에서 오디션이나 발굴을 지시해 주세요. 초기 자금은 3억 원입니다. 기본 실장이 실무를 맡으며, 전문 직원과 외주를 활용할 수 있습니다.`, 'welcome', true);
      this.log('회사를 설립했습니다.');
      return this.s;
    }
    // Every user action and day has one commit boundary. Failed work cannot be saved.
    transaction(action) {
      if (this._transactionDepth) return action();
      const state = JSON.parse(JSON.stringify(this.s)),
      own = Object.fromEntries(Object.entries(this).filter(([key]) => key !== 's'));
      this._transactionDepth = 1;
      try {
        const result = action();
        const validate = typeof module !== 'undefined' ? require('./state.js'): root.validState;
        if (validate && !validate(this.s)) throw Error('처리 결과의 저장 검증에 실패했습니다. 변경 전 상태로 복원했습니다.');
        return result;
      } catch (error) {
        for (const key of Object.keys(this)) if (key !== 's' && !Object.hasOwn(own, key)) delete this[key];
        Object.assign(this, own);
        this.s = state;
        throw error;
      } finally {
        this._transactionDepth = 0;
      }
    }
    nextDay(options = {}) {
      return options.transactional === false ? this.advanceSeason(): this.transaction(() => this.advanceSeason());
    }
    finish(job) {
      return this.finishSeason(job);
    }
    contractQuote(id, offer = 'balanced') {
      const d = D.roster[Number(id)],
      terms = D.terms[offer];
      if (!d || !terms) throw Error('계약 후보와 제안서를 확인하세요.');
      const base = d.trainee ? D.rules.traineeFee: terms.fee,
      extra = d.career ? Math.round(250 + d.priorFame * 12): 0;
      return { base, extra, total: base + extra };
    }
    rng() {
      let s = this.s;
      s.seed =(s.seed * 1664525 + 1013904223) >>> 0;
      return s.seed / 4294967296;
    }
    id() {
      return++ this.s.serial;
    }
    report(title, body, kind = 'info', important = false, extra = {}) {
      this.s.reports.unshift({
        id: this.id(),
        day: this.s.day,
        title,
        body,
        kind,
        important,
        read: false,
        resolved: false,
        ... extra
      });
      this.s.reports = this.s.reports.slice(0, 120);
    }
    log(text) {
      this.s.history.unshift({ day: this.s.day, text });
      this.s.history = this.s.history.slice(0, 200);
    }
    change(amount, label, operating = true, meta = {}) {
      if (!Number.isFinite(amount)) throw Error('거래 금액이 올바르지 않습니다.');
      let s = this.s;
      s.cash = Math.round((s.cash + amount) * 100) / 100;
      s.ledger.unshift({
        day: s.day,
        amount: Math.round(amount * 100) / 100,
        label,
        kind: meta.kind ||(amount < 0 ? 'expense': 'income')
      });
      s.ledger = s.ledger.slice(0, 350);
      if (amount > 0) {
        s.monthIn += amount;
        if (operating) s.totalRevenue += amount;
      } else s.monthOut -= amount;
    }
    spend(n, label, meta = {}) {
      if (!Number.isFinite(n) || n < 0) throw Error('지출 금액이 올바르지 않습니다.');
      if (this.s.cash < n) throw Error('자금이 부족합니다. 재정에서 지출과 대출을 확인하세요.');
      this.change(- n, label, true, meta);
    }
    get stage() {
      return this.s.releases >= 6 && this.s.reputation >= 45 ? 3: this.s.releases >= 2 ? 2: 1;
    }
    get capacity() {
      return 6 + this.s.staff.length * 2;
    }
    get fixed() {
      return 800 + this.s.staff.reduce((n, id) => n + D.staff.find(x => x.id === id).salary, 0);
    }
    has(id) {
      return this.s.staff.includes(id);
    }
    get pending() {
      return this.s.reports.filter(r => r.important && !r.read && !r.resolved);
    }
    get loanLimit() {
      return Math.min(20000, 5000 + Math.floor(this.s.totalRevenue * .3) + this.s.releases * 500);
    }
    get debt() {
      return this.s.loans.reduce((n, x) => n + x.remaining, 0);
    }
    artist(id) {
      return this.s.artists.find(x => x.id === + id);
    }
    entity(key) {
      if (typeof key !== 'string') return null;
      if (key.startsWith('u')) {
        let u = this.s.units.find(u => u.key === key);
        if (!u) return null;
        return { ... u, members: u.ids.map(id => this.artist(id)) };
      }
      let a = this.artist(Number(key));
      return a ? {
        key: String(a.id),
        name: D.roster[a.id].name,
        type: D.roster[a.id].type,
        members:[a]
      }
      : null;
    }
    get entities() {
      let grouped = this.s.units.flatMap(u => u.ids);
      return [... this.s.units.map(u => this.entity(u.key)), ... this.s.artists.filter(a => !grouped.includes(a.id)).map(a => this.entity(String(a.id)))];
    }
    busy(key) {
      let e = this.entity(key);
      if (!e) return false;
      return this.s.jobs.some(j => {
        let ids = j.snapshot?.ids || this.entity(j.entity)?.members.map(a => a.id) ||[];
        return ids.some(id => e.members.some(a => a.id === id));
      });
    }
    mean(e, index) {
      return e.members.reduce((n, a) => n + a.stats[index], 0) / e.members.length;
    }
    startCasting(method, type) {
      if (!['audition', 'scout'].includes(method) || !['any', 'idol', 'band', 'rap'].includes(type)) throw Error('모집 설정을 확인하세요.');
      if (this.s.jobs.some(j => j.kind === 'casting')) throw Error('현재 인재를 모집 중입니다. 보고를 기다려 주세요.');
      if (!D.roster.some(a => !this.artist(a.id) &&(type === 'any' || a.type === type))) throw Error('이 분야의 모든 후보와 계약했습니다. 다른 분야를 찾아보세요.');
      let days = method === 'audition' ? 7: 10;
      if (this.has('casting')) days -= Math.max(1, Math.round(this.staffPower('casting') * 3));
      this.spend(method === 'audition' ? 500: 200, method === 'audition' ? '오디션 개최': '인재 발굴');
      this.s.jobs.push({
        id: this.id(),
        kind: 'casting',
        name: method === 'audition' ? '공개 오디션': '인재 발굴',
        type,
        method,
        start: this.s.day,
        due: this.s.day + days
      });
      this.log('첫 만남을 위한 인재 모집을 시작했습니다.');
    }
    sign(id) {
      let c = this.s.candidates.find(x => x.id === + id);
      if (!c || c.expires < this.s.day || this.artist(id)) throw Error('현재 계약 가능한 후보가 아닙니다.');
      if (this.s.artists.length >= this.capacity) throw Error('담당 인력이 부족합니다. 직원을 채용해 관리 인원을 늘려 주세요.');
      this.spend(200, '아티스트 계약 준비비');
      this.s.artists.push({
        id: + id,
        stats:[... D.roster[id].stats],
        energy: 95,
        stress: 10,
        trust: 70,
        fans: 50 + Math.floor(this.rng() * 120),
        fame: 2,
        focus: 'balanced',
        contract: this.s.day + 365
      });
      this.s.candidates = this.s.candidates.filter(c => c.id !== + id);
      this.report(`${D.roster[id].name}, 첫 인사를 전합니다`, `${this.s.boss} 대표님, 함께 좋은 음악을 만들고 싶습니다. 아티스트 화면에서 육성 방향을 정하고 프로젝트를 시작해 주세요.`, 'info', true);
      this.log(`${D.roster[id].name} 영입`);
    }
    evaluate(id) {
      let c = this.s.candidates.find(x => x.id === + id);
      if (!c || c.evaluated) throw Error('평가할 후보가 없습니다.');
      this.spend(50, '후보 추가 평가');
      c.evaluated = true;
    }
    formUnit(name, ids) {
      if (!name.trim() || ids.length < 2 || ids.length > 5) throw Error('팀 이름과 멤버 2~5명을 선택하세요.');
      ids = [... new Set(ids.map(Number))];
      if (ids.length < 2 || ids.length > 5) throw Error('서로 다른 멤버 2~5명을 선택하세요.');
      let members = ids.map(id => this.artist(id));
      if (members.some(a => !a) || new Set(ids.map(id => D.roster[id].type)).size > 1) throw Error('같은 분야의 소속 아티스트로 구성하세요.');
      if (ids.some(id => this.s.units.some(u => u.ids.includes(id)) || this.busy(String(id)))) throw Error('팀에 소속되었거나 활동 중인 멤버가 있습니다.');
      this.s.units.push({
        key: 'u' + this.id(),
        name: name.trim().slice(0, 20),
        ids,
        type: D.roster[ids[0]].type
      });
      this.log(`${name.trim()} 결성`);
    }
    setFocus(id, focus) {
      let a = this.artist(id);
      if (!a || !['balanced', 'creative', 'stage', 'rest'].includes(focus)) throw Error('육성 방향을 확인하세요.');
      a.focus = focus;
    }
    hire(id) {
      let p = D.staff.find(x => x.id === id);
      if (!p || p.level > this.stage || this.has(id)) throw Error('아직 채용할 수 없는 직무입니다.');
      this.spend(p.fee, '직원 채용: ' + p.name);
      this.s.staff.push(id);
      this.log(`${p.name} ${p.role} 채용`);
    }
    fire(id) {
      if (!this.has(id)) throw Error('재직 중이 아닙니다.');
      let p = D.staff.find(x => x.id === id);
      this.spend(p.salary, '퇴직 정산: ' + p.name);
      this.s.staff = this.s.staff.filter(x => x !== id);
      this.log(`${p.name} 퇴사`);
    }
    startProject(key, kind, title, budget, concept) {
      let e = this.entity(key);
      if (!e) throw Error('아티스트를 선택하세요.');
      if (this.busy(key)) throw Error('이미 프로젝트나 광고 일정이 진행 중입니다.');
      if (!['single', 'live', 'cover'].includes(kind)) throw Error('프로젝트를 선택하세요.');
      if (e.members.some(a => a.energy < 25)) throw Error('컨디션 회복이 먼저입니다. 육성 방향을 휴식으로 바꾸세요.');
      let b = Number(budget);
      if (!Number.isFinite(b) || b < D.rules.activity[kind].min || b > D.rules.activity[kind].max) throw Error('예산 범위를 확인하세요.');
      this.spend(b, `${e.name} ${title||'새 프로젝트'} 제작비`, { kind: 'production' });
      let days = D.rules.activity[kind].days;
      this.s.jobs.push({
        id: this.id(),
        kind,
        entity: key,
        name:(title ||({ single: '첫 번째 싱글', live: '라이브 공연', cover: '커버 영상' }[kind])).trim().slice(0, 30),
        budget: b,
        concept:['balanced', 'public', 'creative'].includes(concept) ? concept: 'balanced',
        start: this.s.day,
        due: this.s.day + days
      });
      this.log(`${e.name} · ${kind==='single'?'싱글':kind==='live'?'공연':'커버'} 준비 시작`);
    }
    borrow(amount) {
      let n = Number(amount);
      if (![1000, 3000, 5000].includes(n) || this.debt + n > this.loanLimit) throw Error('대출 가능 한도를 확인하세요.');
      this.s.loans.push({
        id: this.id(),
        remaining: n,
        principal: n,
        payment: n / 12,
        rate: .006,
        due: this.s.day + 30,
        missed: 0
      });
      this.change(n, '운영자금 대출 실행', false, { kind: 'loan' });
      this.log(`${n}만 원 대출 실행`);
    }
    repay(id) {
      let l = this.s.loans.find(x => x.id === + id);
      if (!l) throw Error('대출이 없습니다.');
      this.spend(l.remaining, '대출 조기 상환', { kind: 'loan_repayment' });
      this.s.loans = this.s.loans.filter(x => x !== l);
    }
    renewalCost(a) {
      return Math.round((300 + Math.floor(a.fame * 10)) *(1 +(70 - a.trust) / 200));
    }
    renew(id) {
      let a = this.artist(id);
      if (!a || a.contract - this.s.day > 60) throw Error('계약 만료 60일 전부터 재계약할 수 있습니다.');
      this.spend(this.renewalCost(a), '아티스트 재계약');
      a.contract = Math.max(this.s.day, a.contract) + 365;
      a.trust = Math.min(100, a.trust + 10);
      this.log(`${D.roster[id].name} 재계약`);
    }
    resolve(id, choice) {
      let r = this.s.reports.find(x => x.id === + id);
      if (!r || r.resolved) throw Error('이미 처리된 안건입니다.');
      if (r.kind === 'ad') {
        if (choice === 'accept') {
          let e = this.entity(r.entity);
          if (!e || this.busy(r.entity)) throw Error('진행 중인 활동을 마친 후 수락할 수 있습니다.');
          if (this.s.day > r.expires) throw Error('제안 기한이 지났습니다.');
          this.change(r.pay * .4, '광고 계약 선금');
          this.s.jobs.push({
            id: this.id(),
            kind: 'ad',
            entity: r.entity,
            name: r.brand + ' 광고 촬영',
            pay: r.pay * .6,
            start: this.s.day,
            due: this.s.day + 5
          });
        } else if (choice !== 'decline') throw Error('선택을 확인하세요.');
      } else if (r.kind === 'event') {
        let e = this.entity(r.entity);
        if (choice === 'invest') {
          this.spend(150, '아티스트 지원');
          e?.members.forEach(a => {
            a.trust = Math.min(100, a.trust + 8);
            a.stress = Math.max(0, a.stress - 15);
          });
        } else if (choice === 'rest') {
          e?.members.forEach(a => {
            a.energy = Math.min(100, a.energy + 15);
            a.stress = Math.max(0, a.stress - 8);
          });
        } else throw Error('선택을 확인하세요.');
      }
      r.resolved = true;
      r.read = true;
    }
    finishCore(j) {
      let s = this.s;
      if (j.kind === 'casting') {
        let pool = D.roster.filter(a => !this.artist(a.id) &&(j.type === 'any' || a.type === j.type));
        for (let i = pool.length - 1; i > 0; i--) {
          let k = Math.floor(this.rng() *(i + 1));
          [pool[i], pool[k]] = [pool[k], pool[i]];
        }
        let picks = pool.slice(0, j.method === 'audition' ? 6: 3);
        s.candidates = s.candidates.filter(c => c.expires >= s.day);
        picks.forEach(a => {
          if (!s.candidates.some(c => c.id === a.id)) s.candidates.push({ id: a.id, evaluated: this.has('casting'), expires: s.day + 30 });
        });
        this.report('새로운 영입 후보가 도착했습니다', `${picks.length}명의 후보를 찾았습니다. 캐스팅에서 평가와 계약을 진행하세요. 제안은 30일간 유효합니다. 한 명당 계약 준비비는 200만 원입니다.`, 'casting', true);
        return;
      }
      let e = this.projectEntity ? this.projectEntity(j): this.entity(j.entity);
      if (!e) return;
      let fan = e.members.reduce((n, a) => n + a.fans, 0),
      fame = e.members.reduce((n, a) => n + a.fame, 0) / e.members.length;
      let score = e.type === 'idol' ?(this.mean(e, 0) + this.mean(e, 2) + this.mean(e, 5)) / 3: e.type === 'band' ?(this.mean(e, 3) + this.mean(e, 4) + this.mean(e, 7)) / 3:(this.mean(e, 1) + this.mean(e, 4) + this.mean(e, 5)) / 3;
      let energy = e.members.reduce((n, a) => n + a.energy, 0) / e.members.length;
      let stress = e.members.reduce((n, a) => n + a.stress, 0) / e.members.length,
      trust = e.members.reduce((n, a) => n + a.trust, 0) / e.members.length;
      let synergy = e.members.length > 1 ? this.mean(e, 7) / 100 * Math.min(10, (e.members.length - 1) * 3): 0;
      let investment = { single: 18, live: 12, cover: 10 }[j.kind] || 0;
      let cap = { single: 7000, live: 1500, cover: 600 }[j.kind] || 1;
      let quality = Math.max(15, Math.min(99, score * .63 + energy * .17 +(this.has('producer') ? 3 + this.staffPower('producer') * 6: 0) +((j.budget || 0) / cap) * investment + synergy +(trust - 70) * .08 - stress * .10 + this.rng() * 15));
      j.factors = [];
      if (stress > 20) j.factors.push('스트레스 ' + Math.round(stress) + ' · 완성도 기여 -' +(stress * .10).toFixed(1));
      if (energy < 50) j.factors.push('완료 당시 평균 체력 ' + Math.round(energy) + ' · 체력 기여 ' +(energy * .17).toFixed(1));
      if (synergy > 0) j.factors.push('팀 협업 · 완성도 기여 +' + synergy.toFixed(1));
      j.factors.push('제작 투자 · 완성도 기여 +' +(((j.budget || 0) / cap) * investment).toFixed(1));
      this._lastQuality = quality;
      if (j.kind === 'ad') {
        this.receive(j.pay, '광고 잔금: ' + e.name, j.shares ||[], e.key, 'ad_balance');
        e.members.forEach(a => {
          a.fame = Math.min(100, a.fame + 2);
          a.energy = Math.max(0, a.energy - 12);
        });
        this.report('광고 촬영을 마쳤습니다', `${e.name}의 ${j.name}이 완료되어 잔금 ${Math.round(j.pay).toLocaleString()}만 원을 받았습니다.`, 'result', false);
        this.log(e.name + ' 광고 촬영 완료');
        return;
      }
      let fans = this.newFans(e, j, quality, fan);
      let income = 0;
      if (j.kind === 'single') {
        s.catalog.push({
          id: this.id(),
          entity: e.key,
          name: j.name,
          quality,
          age: 0,
          revenue: 0,
          fanBase: fan,
          concept: j.concept,
          shares: j.shares ||[],
          ownerName: e.name
        });
        s.releases++;
        if (j.concept === 'creative') e.members.forEach(a => a.trust = Math.min(100, a.trust + 5));
        s.reputation = Math.min(100, s.reputation + quality / 12);
      } else if (j.kind === 'live') {
        let live = this.concert(e, j, quality);
        income = live.gross;
        this.receive(income, '공연 정산: ' + j.name, j.shares ||[], e.key, 'concert_settlement');
        this.change(- live.variable, '공연 현장비: ' + j.name);
      } else {
        s.reputation = Math.min(100, s.reputation + 1);
      }
      e.members.forEach(a => {
        a.fans += Math.floor(fans / e.members.length);
        a.fame = Math.min(100, a.fame +({ single: 5, live: 2, cover: 1 }[j.kind]) *(1 - a.fame / 110) *(j.entity.startsWith('u') ? .35: 1));
        a.energy = Math.max(0, a.energy -({ single: 18, live: 20, cover: 8 }[j.kind]));
      });
      this.report(j.kind === 'single' ? '새로운 음악이 세상에 나왔습니다': '활동 결과가 도착했습니다', `${e.name} · 「${j.name}」\n완성도 ${Math.round(quality)} / 신규 팬 ${fans.toLocaleString()}명${income?' / 정산 '+income.toLocaleString()+'만 원':''}.\n${j.kind==='single'?'음원·음반 수익은 발매 후 매주 정산됩니다. ':''}${quality>=75?'실력과 준비가 좋은 반응으로 이어졌습니다. 후속 활동으로 관심을 이어가세요.':'아직 넓은 대중에게 닿지는 못했습니다. 육성과 소규모 활동으로 기반을 다져 보세요.'}`, 'result', false);
      this.log(`${e.name} · ${j.name} ${j.kind==='single'?'발매':'완료'}`);
    }
    applyScheduledExpenses() {
      const s = this.s;
      if (s.day % 30 === 0) {
        this.change(- this.fixed, '월 고정비·직원 급여');
        for (let l of[... s.loans]) {
          if (l.due > s.day) continue;
          let interest = Math.round(l.remaining * l.rate),
          principal = Math.min(l.remaining, l.payment),
          bill = principal + interest;
          if (s.cash >= bill) {
            this._interest = interest;
            this.change(- bill, '대출 원금·이자 상환', true, { kind: 'loan_repayment', interest });
            this._interest = 0;
            l.remaining -= principal;
            l.missed = 0;
          } else {
            l.remaining += interest;
            l.missed++;
            this.report('대출 상환이 연체되었습니다', '상환 자금이 부족해 이자가 원금에 가산되었습니다. 지출을 줄이고 재정에서 조기 상환을 검토하세요.', 'finance', true);
          }
          l.due = s.day + 30;
        }
        s.loans = s.loans.filter(l => l.remaining > .01);
      }
    }
    closeFinancialDay() {
      const s = this.s;
      if (s.day % 30 === 0) {
        s.lastMonth = { in: Math.round(s.monthIn * 100) / 100, out: Math.round(s.monthOut * 100) / 100, day: s.day };
        this.report('월간 정산 보고', `이번 기간 유입 ${Math.round(s.monthIn).toLocaleString()}만 원 / 지출 ${Math.round(s.monthOut).toLocaleString()}만 원. 대출 실행·상환을 포함한 현금 흐름입니다. 상세 항목은 재정에서 확인하세요.`, 'finance', false);
        s.monthIn = 0;
        s.monthOut = 0;
      }
      if (s.cash < 0 && !s.reports.some(r => r.kind === 'crisis' && !r.resolved)) {
        this.report('운영 자금이 부족합니다', '제작을 줄이고 광고·공연 수입 또는 대출로 자금을 확보하세요. 회생 지원을 받으면 3,000만 원을 받는 대신 평판이 10 감소합니다.', 'crisis', true);
      }
      if (s.cash >= 0) for (const r of s.reports) if (r.kind === 'crisis' && !r.resolved) {
        r.resolved = true;
        r.closedReason = 'funded';
      }
    }
    advanceCore() {
      let s = this.s;
      s.day++;
      this.settleReceivables();
      this.trainTrainees();
      for (let a of[... s.artists]) {
        let meta = D.roster[a.id],
        busy = this.busy(String(a.id));
        let rest = a.focus === 'rest' || a.energy < 30 || a.recoveryUntil > s.day;
        let load = busy ? 1.5: 0;
        let gain = rest ? 8: 2 -(s.policy === 'growth' ? 2: 0) - load +(this.has('manager') ? this.staffPower('manager') * 1.5: 0);
        a.energy = Math.max(0, Math.min(100, a.energy + gain));
        a.stress = Math.max(0, Math.min(100, a.stress +(rest ? - 5: busy ? 1: 0) -(this.has('manager') ? this.staffPower('manager') * 1.5: 0)));
        if (!rest) {
          this.change(-(this.has('trainer') ? 7: 10), '훈련·외주: ' + meta.name, true, { kind: 'training' });
          let indexes = this.weeklyTrainingIndexes?.(a) || (a.focus === 'creative' ?[4]: a.focus === 'stage' ?[5, 6]: meta.type === 'idol' ?[0, 2, 5]: meta.type === 'band' ?[3, 4, 7]:[1, 4, 5]);
          let idx = indexes[Math.floor(this.rng() * indexes.length)];
          a.stats[idx] = Math.min(99, a.stats[idx] +(.12 *(1 +(this.coach ? this.coach([1, 3, 4].includes(idx) ? 'creative':[2, 5, 6].includes(idx) ? 'performance': 'vocal').bonus: 0))) *(a.energy < 30 ? .3: 1) *(s.policy === 'growth' ? 1.35: 1) *(1 - a.stress * .005) *(.8 + a.trust * .004) *(a.focus === meta.personality.focus ? 1.08: 1));
        }
        if ([180, 90, 30].includes(a.contract - s.day)) this.report('재계약을 준비할 시기입니다', `${meta.name}의 계약이 ${a.contract-s.day}일 뒤 만료됩니다. 아티스트 상세에서 재계약을 결정하세요.`, 'contract', true, { talentId: a.id, contractDue: a.contract });
        if (a.contract <= s.day) {
          this.depart(a.id, '계약 만료');
        }
      }
      let finished = s.jobs.filter(j => j.due <= s.day);
      s.jobs = s.jobs.filter(j => j.due > s.day);
      finished.forEach(j => this.finish(j));
      this.tickCatalog();
      for (let r of s.reports) if (r.kind === 'ad' && !r.resolved && s.day > r.expires) {
        r.resolved = true;
        r.closedReason = 'expired';
        r.body += '\n제안 기한이 지나 자동 종료되었습니다.';
      }
      if (s.day %(14 - Math.round(this.staffPower('ads') * 5)) === 0 && s.artists.length) {
        let entities = this.entities,
        e = entities[Math.floor(this.rng() * entities.length)];
        if (!s.reports.some(r => r.kind === 'ad' && !r.resolved && r.entity === e.key)) {
          let fame = e.members.reduce((n, a) => n + a.fame, 0) / e.members.length;
          let pay = Math.round((200 + fame * 18 + s.reputation * 6 + Math.sqrt(e.members.reduce((n, a) => n + a.fans, 0)) * 8) *(1 + this.staffPower('ads') * .3) * this.imageFactor());
          let brand = e.type === 'band' ? '루트 사운드': e.type === 'rap' ? '모션 스트리트': '데일리 블룸';
          this.report(e.name + ' 광고 출연 제안', `${brand}에서 연락이 왔습니다.\n계약금 ${pay.toLocaleString()}만 원 / 계약 즉시 40%, 촬영 후 60% 지급\n촬영 준비 5일 / 단발 광고·독점 없음\n싱글 제작 중 수락하면 제작을 5일 중단하고 완료일을 늦춥니다. 연장된 제작이 예약 행사와 겹치면 해당 준비·출연 기간도 추가 반영합니다. 공연·커버·다른 광고 중에는 수락할 수 없습니다. 잔금은 촬영 종료 14일 뒤 입금됩니다.`, 'ad', true, {
            entity: e.key,
            pay,
            brand,
            expires: s.day + 10
          });
        }
      }
      if (s.day % 23 === 0 && s.artists.length) {
        let e = this.entities[Math.floor(this.rng() * this.entities.length)];
        this.report('새로운 곡을 위한 작은 고민', `${e.name}이 창작 방향에 대해 상담을 요청했습니다. 외부 멘토와 만남을 지원하거나, 잠시 쉬며 생각을 정리하도록 할 수 있습니다.`, 'event', true, { entity: e.key });
      }
      if (s.day % 17 === 0) this.report('음악계 소식', ['새로운 라이브 페스티벌이 발표되었습니다. 공연 활동으로 팬을 만나 보세요.', '짧은 라이브 영상이 주목받고 있습니다. 꾸준한 공개 활동이 인지도에 도움이 됩니다.', '신인들의 다양한 음악이 차트를 채우고 있습니다. 우리만의 색을 찾아보세요.'][Math.floor(this.rng() * 3)]);
      s.candidates = s.candidates.filter(c => c.expires >= s.day);
      return this.pending.length;
    }
    rescue(id) {
      let r = this.s.reports.find(x => x.id === + id && x.kind === 'crisis' && !x.resolved);
      if (!r || this.s.cash >= 0) throw Error('현재 회생 지원이 필요하지 않습니다.');
      this.change(3000, '회생 지원금', false, { kind: 'rescue' });
      this.s.reputation = Math.max(0, this.s.reputation - 10);
      r.resolved = true;
      r.read = true;
      this.log('회생 지원으로 운영을 재개했습니다.');
    }
  }
  const FinalGame = typeof module !== 'undefined' ? require('./day-feedback.js')(require('./operations.js')(require('./personality.js')(require('./market.js')(require('./progression.js')(require('./management.js')(Game, D), D), D), D), D), D): root.installDayFeedback(root.installOperations(root.installPersonality(root.installMarket(root.installProgression(root.installManagement(Game, D), D), D), D), D), D);
  if (typeof module !== 'undefined') module.exports = require('./season.js')(require('./campaign.js')(require('./evolution.js')(FinalGame, D), D), D, require('./season-data.js'));
  else root.Game = root.installSeason(root.installCampaign(root.installEvolution(FinalGame, D), D), D, root.SEASON_DATA);
})(typeof window !== 'undefined' ? window: globalThis);


;
