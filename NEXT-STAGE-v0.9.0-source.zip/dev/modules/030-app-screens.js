/* FILE src/app-screens.js */
'use strict';
// app-screens: see docs/MAINTENANCE.md for ownership and loading order.
function heading(title, desc, action = '') {
  return `<div class="page-head row between wrap"><div><h1>${title}</h1><p>${desc}</p></div>${action}</div>`;
}
function portraitCard(a) {
  let d = DATA.roster[a.id],
  e = game.entities.find(e => e.members.some(m => m.id === a.id)),
  busy = game.s.jobs.find(j => j.entity === e?.key);
  return btn(`<img loading="lazy" decoding="async" class="portrait" src="${d.image}" alt="${d.name}" loading="lazy"><div class="artist-caption"><strong>${d.name}</strong><small>${e?.members.length>1?esc(e.name):'솔로'} · ${d.style}</small><span class="pill">${busy?kindLabel[busy.kind]+' D-'+(busy.due-game.s.day):focusLabel[a.focus]}</span></div>`, 'artist', `data-id="${a.id}"`, 'artist-card');
}
function reportRows(reports) {
  return reports.length ? reports.map(r => `<div class="report-row"><span class="avatar">${ico(r.kind==='casting'?'star':r.kind==='ad'?'chart':'mail')}</span><div class="report-body"><div class="row between"><small>운영 실장 · ${date(r.day)}</small>${r.important&&!r.read?'<span class="pill coral">확인 필요</span>':''}</div><strong>${esc(r.title)}</strong>${btn(r.kind==='casting'?'후보 확인':r.kind==='ad'?'제안 보기':'보고서 확인','report',`data-id="${r.id}"`,'link small')}</div></div>`).join(''): '<p class="muted">모든 보고를 확인했습니다.</p>';
}
function guideCard() {
  let s = game.s;
  if (s.guideHidden) return '';
  s.guideStep = Guide.guideStep(s);
  if (s.guideStep >= Guide.steps.length) return '<section class="panel section"><strong>첫 운영 가이드 완료</strong><p>첫 작품의 정산까지 경험했습니다. 직원·회사에서 다음 성장 조건을 확인하세요.</p></section>';
  let[title, body, label, target] = Guide.steps[s.guideStep];
  if (s.guideStep === 3 && !s.artists.length && s.trainees.length) {
    title = '연습생을 데뷔시키세요';
    body = '훈련 90일·평균 능력 55 이상부터 데뷔 계약을 맺고 첫 작품을 준비할 수 있습니다.';
    label = '연습생 확인';
    target = 'training';
  }
  return '<section class="panel section" aria-label="첫 운영 가이드"><div class="row between wrap"><strong>첫 운영 가이드 · ' +(s.guideStep + 1) + ' / ' + Guide.steps.length + '</strong>' + btn('가이드 건너뛰기', 'guide-hide', '', 'link small') + '</div><h2>' + title + '</h2><p>' + body + '</p>' + btn(label, 'nav', 'data-page="' + target + '"', 'soft small') + '</section>';
}
function casting() {
  let s = game.s;
  let j = s.jobs.find(j => j.kind === 'casting');
  return heading('캐스팅', '아직 발견되지 않은 가능성, 회사의 다음 시작.', btn('모집 지시', 'casting-modal', '', 'primary', !!j)) + `<div class="two-col"><div class="panel"><span class="pill">공개 오디션</span><h2 style="margin:12px 0">여러 재능을 한자리에서</h2><p class="muted">개최비 500만 원 · ${game.has('casting')?5:7}일 · 최대 6명 보고<br>아이돌·밴드·힙합 분야를 지정할 수 있습니다.</p></div><div class="panel"><span class="pill coral">인재 발굴</span><h2 style="margin:12px 0">작은 무대에서 찾은 가능성</h2><p class="muted">활동비 200만 원 · ${game.has('casting')?8:10}일 · 최대 3명 보고<br>공연장과 온라인에서 활동 중인 인재를 찾습니다.</p></div></div>${j?`<div class="tip section">${ico('calendar')} ${esc(j.name)} 진행 중 · 결과 보고까지 ${j.due-s.day}일. ${btn('중요 일정까지 진행','skip','','link')}</div>`:''}<div class="panel-head section"><h2>영입 후보 <small>${s.candidates.length}명</small></h2><small>연습생 영입 100만 원 · 신인 계약금은 제안서별 적용 · 후보 유효기간 30일</small></div>${s.candidates.length?`<div class="candidate-grid">${s.candidates.map(c=>{let d=DATA.roster[c.id];return `<article class="panel candidate"><img loading="lazy" decoding="async" class="portrait" src="${d.image}" alt="${d.name}" loading="lazy"><div class="candidate-info"><div class="row between"><h2>${d.name}</h2><span class="pill">${DATA.labels[d.type]}</span></div><small>${d.age}세 · ${d.trainee?'연습생 후보':'신인 아티스트'} · ${d.position} · ${d.traits}</small><p>${d.story}</p><div class="row between wrap"><small>계약 제안 D-${c.expires-s.day}</small>${btn('프로필·계약','candidate',`data-id="${d.id}"`,'soft small')}</div></div></article>`;}).join('')}</div>`:`<div class="empty section"><h3>${j?'어떤 인재를 만나게 될까요?':'첫 만남을 준비하세요'}</h3><p>${j?'직원이 후보를 평가하고 있습니다. 날짜를 진행해 주세요.':'오디션이나 발굴을 지시하면 후보 보고가 도착합니다.'}</p></div>`}`;
}
function artists() {
  let list = game.s.artists.filter(a => filter === 'all' || DATA.roster[a.id].type === filter);
  return heading('아티스트', '같은 목표, 각자의 빛. 음악과 사람을 함께 키우세요.', btn('팀 결성', 'unit-modal', '', 'primary', game.s.artists.length < 2)) + `<div class="tabs">${[['all','전체'],['idol','아이돌'],['band','밴드'],['rap','힙합']].map(([id,l])=>btn(l,'filter',`data-filter="${id}"`,filter===id?'active':'')).join('')}</div>${game.s.units.length?`<div class="tip" style="margin-bottom:20px">소속 팀 · ${game.s.units.map(u=>esc(u.name)+' ('+u.ids.map(id=>DATA.roster[id].name).join(' · ')+')').join(' / ')}</div>`:''}${list.length?`<div class="candidate-grid">${list.map(portraitCard).join('')}</div>`:`<div class="empty">${ico('people')}<h3>아직 소속 아티스트가 없습니다</h3><p>캐스팅에서 새로운 인재와 만나세요.</p>${btn('캐스팅으로','nav','data-page="casting"','primary')}</div>`}`;
}
function statsHTML(stats, known = true, id = 0) {
  return DATA.specs.map((name, i) => {
    let v = Math.round(stats[i]),
    lo = Math.max(0, Math.floor(v / 10) * 10 - 5),
    hi = Math.min(100, lo + 20);
    return `<div class="statline"><span>${name}</span><div class="bar"><span style="width:${known?v:(lo+hi)/2}%"></span></div><b>${known?v:lo+'~'+hi}</b></div>`;
  }).join('');
}
function artistModal_app(id, candidate = false) {
  if (candidate) return talentModal(id);
  let d = DATA.roster[id],
  a = game.artist(id),
  c = game.s.candidates.find(c => c.id === id);
  if (!d ||(!a && !c)) throw Error('현재 확인 가능한 아티스트가 아닙니다.');
  let known = !candidate || c.evaluated;
  modal(d.name + ' · ' + DATA.labels[d.type], `<div class="detail-grid"><div class="detail-photo-wrap"><img class="detail-photo" src="${d.image}" alt="${d.name}"><p>${d.age}세 · ${d.traits}<br>${d.story}</p></div><div><span class="pill">${d.style}</span>${statsHTML(a?a.stats:d.stats,known,id)}${candidate?`<small>${known?'추가 평가 완료 · 현재 실력 확인':'현재 실력 추정치 · 평가 신뢰도 보통'}</small><p class="muted" style="font-size:12px;margin-top:12px">${c.evaluated?'직원 의견: '+(d.type==='band'?'합주 경험을 쌓으면 팀 활동에서 강점을 보일 후보입니다.':d.type==='rap'?'작사와 라이브에 투자하면 자신만의 색을 만들 후보입니다.':'기초 훈련과 무대 경험을 함께 쌓는 편이 좋겠습니다.'):'잠재력은 확정 수치가 아닙니다. 실제 육성 결과는 훈련과 활동에 따라 달라집니다.'}</p>`:''}</div></div>${personalityCard(id)}${a?`<div class="detail-state">${[['체력',Math.round(a.energy)],['스트레스',Math.round(a.stress)],['회사 신뢰',Math.round(a.trust)],['충성 팬',a.fans.toLocaleString()+'명'],['대중 인지도',Math.round(a.fame)],['계약 만료',date(a.contract)]].map(([n,v])=>`<div><small>${n}</small><b>${v}</b></div>`).join('')}</div><label for="focus">육성 방향</label><select id="focus" data-focus="${id}">${Object.entries(focusLabel).map(([k,v])=>`<option value="${k}" ${a.focus===k?'selected':''}>${v}</option>`).join('')}</select><small>세부 일정은 실장이 조율합니다. 체력이 낮으면 자동으로 휴식합니다.</small><div class="modal-actions">${a.contract-game.s.day<=90?btn('재계약 협상','m-renew',`data-id="${id}"`,'soft'):''}${btn('활동 준비','project-modal',`data-entity="${game.entities.find(e=>e.members.some(m=>m.id===id)).key}"`,'primary')}</div>`:`<div class="modal-actions">${!c.evaluated?btn('추가 평가 · 50만 원','evaluate',`data-id="${id}"`,'soft'):''}${btn('계약 승인 · 200만 원','sign',`data-id="${id}"`,'primary',game.s.artists.length>=game.capacity)}</div><small>제안서별 기간 적용 · 활동 수익의 아티스트 배분은 게임 정산액에 반영된 것으로 처리합니다.</small>`}`, true);
}
function projects_app() {
  let s = game.s;
  return heading('프로젝트', '방향과 예산을 승인하면, 실무는 직원이 맡습니다.', btn('새 프로젝트', 'project-modal', '', 'primary', !s.artists.length)) + `<div class="tip">${ico('music')} 승인한 예산 안에서 제작이 자동 진행됩니다. 동일 아티스트는 한 번에 하나의 프로젝트·광고를 진행할 수 있습니다.</div><h2 class="section" style="margin-bottom:15px">진행 중인 활동</h2>${s.jobs.filter(j=>j.kind!=='casting').length?`<div class="two-col">${s.jobs.filter(j=>j.kind!=='casting').map(j=>`<article class="project-row"><div class="row between"><span class="pill">${kindLabel[j.kind]}</span><small>D-${j.due-s.day}</small></div><h3 style="margin-top:12px">${esc(j.name)}</h3><small>${esc(j.snapshot?.name||game.entity(j.entity)?.name||'확정 일정')} · ${date(j.due)} 예정</small><div class="bar"><span style="width:${j.kind==='single'?Math.max(0,Math.min(100,(1-game.productionState(j).remaining/((j.baselineDue??j.due)-j.start))*100)):(s.day-j.start)/(j.due-j.start)*100}%"></span></div><small>${j.budget?'승인 예산 '+money(j.budget):'촬영 후 잔금 '+money(j.pay)}</small></article>`).join('')}</div>`:`<div class="empty"><h3>다음 무대를 준비하세요</h3><p>싱글 제작·공연·커버 공개 중 회사에 맞는 활동을 선택하세요.</p></div>`}<h2 class="section" style="margin-bottom:15px">발매 작품 · ${s.catalog.length}곡</h2><div class="list">${s.catalog.map(c=>`<div class="project-row row"><span class="avatar">${ico('music')}</span><div class="spacer"><h3>${esc(c.name)}</h3>${btn('성과 보기','m-release',`data-uid="${c.market.uid}"`,'link small')}<small>${esc(c.ownerName||game.entity(c.entity)?.name||'전속 종료 아티스트')} · 발매 ${c.age}일 · 완성도 ${Math.round(c.quality)}</small></div><div style="text-align:right"><small>누적 총수입</small><br><strong>${money(c.revenue)}</strong></div></div>`).join('')||'<p class="muted">첫 음악을 기다리고 있습니다.</p>'}</div>`;
}
function staff() {
  return staffScreen();
}
function inbox_app() {
  let s = game.s,
  r = s.reports.find(r => r.id === selectedReport);
  return heading('소식함', '중요한 판단은 대표에게, 일상의 실무는 직원에게.', btn('정보 보고 모두 읽음', 'read-info', '', 'soft')) + `<div class="inbox"><section class="panel inbox-list" style="padding:0">${s.reports.map(r=>btn(`<small>${date(r.day)} · ${r.resolved?'처리 완료':r.important?'주요 보고':'일반 보고'}</small><strong>${esc(r.title)}</strong>`,'open-report',`data-id="${r.id}"`,(r.id===selectedReport?'selected ':'')+(!r.read?'unread':''))).join('')}</section><section class="panel inbox-detail">${r?reportDetail(r):'<div class="report-placeholder">'+ico('mail')+'<p>왼쪽 목록에서 보고를 선택하세요.</p></div>'}</section></div>`;
}
function reportDetail_app(r) {
  if (r.incidentId) return incidentReport(r);
  let action = '';
  if (r.kind === 'casting') action = btn('후보 확인', 'nav', 'data-page="casting"', 'primary');
  if (r.kind === 'ad' && !r.resolved) action = `<div class="row wrap">${btn('광고 수락','resolve',`data-id="${r.id}" data-choice="accept"`,'primary',game.busy(r.entity))}${btn('제안 거절','resolve',`data-id="${r.id}" data-choice="decline"`)}<small>${game.busy(r.entity)?'현재 활동 중 · 일정 종료 후 수락 가능':'승인 시 촬영 일정 확정'} · 기한 ${date(r.expires)}</small></div>`;
  if (r.kind === 'event' && !r.resolved) action = `<div class="row wrap">${btn('외부 멘토 지원 · 150만','resolve',`data-id="${r.id}" data-choice="invest"`,'primary')}${btn('휴식 권유','resolve',`data-id="${r.id}" data-choice="rest"`,'soft')}</div>`;
  if (r.kind === 'contract') action = btn('아티스트 관리', 'nav', 'data-page="artists"', 'primary');
  if (r.kind === 'crisis' && !r.resolved) action = `<div class="row wrap">${btn('운영자금 대출','loan-modal','','primary')}${btn('재정 확인','nav','data-page="finance"','soft')}${btn('회생 지원 · 평판 -10','rescue',`data-id="${r.id}"`,'soft',game.s.cash>=0)}</div>`;
  return `<div class="row between"><span class="pill ${r.resolved?'green':''}">${r.resolved?'처리 완료':'운영 실장 보고'}</span><small>${date(r.day,true)}</small></div><h2 style="margin-top:18px">${esc(r.title)}</h2><div class="report-content">${esc(r.body)}</div>${action}`;
}
function finance_app() {
  let s = game.s,
  avail = Math.max(0, game.loanLimit - game.debt);
  return heading('재정·기록', '현금 흐름을 지키고, 다음 가능성에 투자하세요.', btn('운영자금 대출', 'loan-modal', '', 'primary')) + `<div class="metrics"><div class="panel metric"><div><small>현재 현금</small><strong>${money(s.cash)}</strong></div></div><div class="panel metric"><div><small>대출 잔액</small><strong>${money(game.debt)}</strong></div></div><div class="panel metric"><div><small>월 고정비</small><strong>${money(game.fixed)}</strong></div></div></div><div class="two-col section"><section class="panel"><div class="panel-head"><h2>대출 관리</h2><small>추가 한도 ${money(avail)}</small></div>${s.loans.map(l=>`<div class="project-row"><div class="row between"><strong>${money(l.remaining)}</strong>${btn('전액 조기 상환','repay-confirm',`data-id="${l.id}"`,'small')}</div><small>월 원금 ${money(l.payment)} + 잔액의 0.6% 이자<br>다음 납부 ${date(l.due)} · 연체 ${l.missed}회</small></div>`).join('')||'<p class="muted">이용 중인 대출이 없습니다.</p>'}<div class="tip section">대출금은 수익이 아닌 현금 유입입니다. 월 고정비와 훈련비 외에 매월 대출 상환액이 발생합니다.</div></section><section class="panel"><h2>이번 기간 현금 흐름</h2><div class="finance-mini"><div><small>유입 · 대출 포함</small><strong class="positive">${money(s.monthIn)}</strong></div><div><small>지출 · 상환 포함</small><strong>${money(s.monthOut)}</strong></div></div><small style="display:block;margin-top:15px">매 30일 정산 · 다음 정산 ${30-s.day%30}일 후<br>음원·음반은 각 작품 발매 후 매주 정산합니다.</small>${s.lastMonth?`<p class="muted" style="margin-top:15px;font-size:12px">지난 기간 · 유입 ${money(s.lastMonth.in)} / 지출 ${money(s.lastMonth.out)}</p>`:''}</section></div><div class="two-col section"><section class="panel"><h2 style="margin-bottom:15px">최근 거래</h2><div style="max-height:500px;overflow:auto"><table class="ledger"><thead><tr><th>날짜</th><th>내용</th><th>금액</th></tr></thead><tbody>${s.ledger.slice(0,100).map(t=>`<tr><td>${date(t.day)}</td><td>${esc(t.label)}</td><td class="${t.amount>0?'positive':'negative'}">${t.amount>0?'+':''}${money(t.amount)}</td></tr>`).join('')}</tbody></table>${!s.ledger.length?'<p class="muted">아직 거래가 없습니다.</p>':''}</div></section><section class="panel"><h2 style="margin-bottom:15px">회사의 발자취</h2><div class="list" style="max-height:500px;overflow:auto">${s.history.map(h=>`<div style="border-bottom:1px solid var(--line);padding-bottom:12px"><small>${date(h.day)}</small><p>${esc(h.text)}</p></div>`).join('')}</div></section></div>`;
}


;
