/* FILE src/market.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const clamp =(v, a, b) => Math.max(a, Math.min(b, v)),
    money = v => Math.round(v * 100) / 100;
    class MarketGame extends Base {
      upgrade() {
        super.upgrade();
        let s = this.s;
        if (!s || s.marketVersion === 1) return;
        s.marketVersion = 1;
        s.lastReputation = s.reputation;
        s.reputationReason = '판매·공연 성과 기록을 수집하고 있습니다.';
        for (const c of s.catalog) this.initRelease(c, { owner: 'player', legacy: true, snapshot: { name: c.ownerName || this.entity(c.entity)?.name || '이전 발매작', type: this.entity(c.entity)?.type || this.s.teamArchive.find(u => u.key === c.entity)?.type || D.roster[Number(c.entity)]?.type || 'idol', ids:(c.shares ||[]).map(x => x.id) } });
        for (const r of s.rivals) for (const[index, c] of r.catalog.entries()) this.initRelease(c, {
          owner: 'r' + r.id,
          legacy: true,
          uid: 'r' + r.id + '-old-' + index,
          snapshot: { name: r.name + ' 프로젝트팀', type: r.type === 'any' ? 'idol': r.type, ids:[] }
        });
        for (const p of s.performance) {
          p.hit = false;
          p.reach = 0;
        }
        for (const j of s.jobs) if (j.kind === 'single' && !j.releaseOptions) {
          j.releaseOptions = { format: 'digital', quantity: 0 };
          j.manufacturing = 0;
        }
      }
      initRelease(c, { owner = 'player', legacy = false, uid = null, options = {}, snapshot = null, budget = 0, fame = 0 } = {}) {
        if (c.market) return;
        c.market = {
          uid: uid || 'p-' + c.id,
          owner,
          startDay: legacy ? Math.max(0, this.s.day - Math.max(1, c.age) + 1): this.s.day,
          measuredFrom: legacy ? this.s.day + 1: this.s.day,
          lastDay: legacy ? this.s.day: this.s.day - 1,
          legacy,
          format: options.format || 'digital',
          price: 2.5,
          unitCost: .6,
          stock: options.quantity || 0,
          manufactured: options.quantity || 0,
          manufacturing: money((options.quantity || 0) * .6),
          production: budget,
          fame,
          fanBase: c.fanBase || 0,
          appeal: legacy ? 1: clamp((.4 + c.quality * .006) *(.75 + this.rng() * .5), .3, 1.5),
          discovery: legacy ? 1: this.rng() < .18 ? 1.7: 1,
          streams: 0,
          sales: 0,
          firstWeekSales: legacy ? null: 0,
          gross: 0,
          distribution: 0,
          receipts: 0,
          paid: 0,
          payout: 0,
          pending: 0,
          streamGross: 0,
          physicalGross: 0,
          streamReceipts: 0,
          physicalReceipts: 0,
          pendingStream: 0,
          pendingPhysical: 0,
          paidStream: 0,
          paidPhysical: 0,
          payoutStream: 0,
          payoutPhysical: 0,
          pendingDays: 0,
          days:[],
          weeks:[],
          hit: false,
          ids:[...(snapshot?.ids ||[])],
          type: snapshot?.type || 'idol',
          artistName: snapshot?.name || c.ownerName || '이전 발매작'
        };
      }
      startProject(key, kind, title, budget, concept, options = {}) {
        if (!options || typeof options !== 'object') throw Error('발매 설정을 확인하세요.');
        const format = options.format || 'digital',
        quantity = format === 'physical' ? Number(options.quantity): 0;
        if (!['digital', 'physical'].includes(format) || format === 'physical' &&(kind !== 'single' || ![1000, 3000, 10000].includes(quantity))) throw Error('실물 싱글은 초도 1,000/3,000/10,000장 중 선택하세요.');
        let manufacturing = quantity * .6;
        if (this.s.cash < Number(budget) + manufacturing -(this._affordabilityDiscount || 0)) throw Error('제작비와 실물 음반 제조비를 합친 자금이 부족합니다.');
        super.startProject(key, kind, title, budget, concept);
        let j = this.s.jobs.at(- 1);
        if (kind === 'single') {
          j.releaseOptions = { format, quantity };
          j.manufacturing = manufacturing;
          if (manufacturing) this.spend(manufacturing, '음반 초도 제조: ' + j.name);
        }
      }
      reprint(id, quantity) {
        let c = this.s.catalog.find(c => c.id === Number(id)),
        n = Number(quantity);
        if (!c || c.market.format !== 'physical' || ![1000, 3000, 10000].includes(n) || c.market.stock + n > 100000) throw Error('재제작할 작품과 수량을 확인하세요.');
        this.spend(n * .6, '음반 추가 제조: ' + c.name);
        c.market.stock += n;
        c.market.manufactured += n;
        c.market.manufacturing = money(c.market.manufacturing + n * .6);
      }
      newFans(e, j, quality, fan) {
        if (j.kind === 'single') {
          this._fanGain = Math.floor(Math.max(0, quality - 25) * .5 / Math.sqrt(1 + fan / 10000));
          return this._fanGain;
        }
        return super.newFans(e, j, quality, fan);
      }
      exposure(e, reach, scale) {
        let gain = Math.log10(1 + Math.max(0, reach)) * scale;
        let u = this.s.units.find(u => u.key === e.key);
        if (u) u.fame = clamp(u.fame + gain *(1 - u.fame / 110), 0, 100);
        for (const a of e.members) a.fame = clamp(a.fame + gain *(1 - a.fame / 110) *(u ? .35: 1), 0, 100);
      }
      finishMarket(j) {
        let e = j.kind === 'casting' ? null: this.projectEntity(j),
        fames = e?.members.map(a =>[a, a.fame]) ||[],
        u = e ? this.s.units.find(u => u.key === e.key): null,
        ufame = u?.fame,
        rep = this.s.reputation,
        count = this.s.catalog.length;
        this.finishProgression(j);
        if (!e) return;
        for (const[a, fame] of fames) a.fame = fame;
        if (u) u.fame = ufame;
        this.s.reputation = rep;
        if (j.kind === 'single') {
          let c = this.s.catalog[count];
          this.initRelease(c, {
            options: j.releaseOptions || {},
            snapshot: j.snapshot || this.snapshot(j.entity),
            budget: j.budget,
            fame: fames.reduce((n, x) => n + x[1], 0) / fames.length
          });
          let p = this.s.performance.at(- 1);
          if (p) {
            p.hit = false;
            p.reach = 0;
          }
        } else if (j.kind === 'live') {
          this.exposure(e, j.concert.attendance, .25);
          let p = this.s.performance.at(- 1);
          if (p) {
            p.reach = j.concert.attendance;
            p.hit = j.concert.attendance >= 500 && j.concert.attendance / j.concert.capacity >= .7 && this.s.settlements[0].net > 0;
          }
        } else if (j.kind === 'cover') {
          let reach = Math.round((this._lastQuality * 40 + e.members.reduce((n, a) => n + a.fans, 0) * .5) * this.imageFactor());
          this.exposure(e, reach, .12);
          let p = this.s.performance.at(- 1);
          if (p) {
            p.reach = reach;
            p.hit = false;
          }
        } else if (j.kind === 'ad') this.exposure(e, (j.pay || 0) * 100, .12);
      }
      releaseDay(c, owner) {
        let m = c.market;
        if (m.lastDay >= this.s.day) return null;
        let age = Math.max(0, this.s.day - m.startDay),
        tail = Math.exp(- age / 55),
        buzz = age >= 14 && age <= 70 ? m.discovery: 1,
        base = 3000 + c.quality * 100 + Math.min(300000, m.fanBase) * 16 + m.fame * 2000;
        let image = owner === 'player' ? this.imageFactor(): clamp(.6 + owner.image / 150, .6, 1.25),
        promo = owner === 'player' && this.has('promo') ? 1 + this.staffPower('promo') * .2: 1;
        let streams = Math.max(0, Math.floor(base * m.appeal *(tail * buzz + .025 /(1 + age / 180)) * image * promo *(c.concept === 'public' ? 1.15: 1)));
        let demand = m.format === 'physical' ? Math.max(0, Math.floor((m.fanBase * .5 + m.fame * 5 + c.quality * 2) * Math.exp(- age / 4) / 4 + m.fanBase * .0002 * tail)): 0,
        sales = Math.min(m.stock, demand);
        m.stock -= sales;
        m.sales += sales;
        m.streams += streams;
        if (m.firstWeekSales !== null && age < 7) m.firstWeekSales += sales;
        let sg = money(streams * .0006),
        pg = money(sales * m.price),
        sr = money(sg - money(sg * .15)),
        pr = money(pg - money(pg * .25)),
        gross = money(sg + pg),
        receipts = money(sr + pr),
        distribution = money(gross - receipts);
        m.streamGross = money(m.streamGross + sg);
        m.physicalGross = money(m.physicalGross + pg);
        m.streamReceipts = money(m.streamReceipts + sr);
        m.physicalReceipts = money(m.physicalReceipts + pr);
        m.pendingStream = money(m.pendingStream + sr);
        m.pendingPhysical = money(m.pendingPhysical + pr);
        m.gross = money(m.gross + gross);
        m.distribution = money(m.distribution + distribution);
        m.receipts = money(m.receipts + receipts);
        m.pending = money(m.pending + receipts);
        m.pendingDays++;
        m.lastDay = this.s.day;
        c.age++;
        m.days.push({ day: this.s.day, streams, sales });
        m.days = m.days.slice(- 28);
        let week = Math.floor(age / 7),
        bin = m.weeks.at(- 1);
        if (!bin || bin.week !== week) {
          bin = { week, streams: 0, sales: 0 };
          m.weeks.push(bin);
          m.weeks = m.weeks.slice(- 104);
        }
        bin.streams += streams;
        bin.sales += sales;
        if (m.pendingDays >= 7) {
          let pay = m.pending,
          payout = 0;
          if (owner === 'player') {
            payout =(c.shares ||[]).reduce((n, x) => n + money(pay * x.rate), 0);
            this.receive(pay, '음원·음반 정산: ' + c.name, c.shares ||[], c.entity, 'stream_settlement');
          } else {
            payout = money(pay * .35);
            owner.cash = money(owner.cash + pay - payout);
            let b = owner.accounts.at(- 1);
            if (!b || b.day !== this.s.day) {
              b = { day: this.s.day, revenue: 0, expense: 0 };
              owner.accounts.push(b);
            }
            b.revenue = money(b.revenue + pay);
            b.expense = money(b.expense + payout);
            owner.accounts = owner.accounts.filter(b => b.day > this.s.day - 365);
          }
          let streamPayout = pay ? money(payout * m.pendingStream / pay): 0;
          m.paidStream = money(m.paidStream + m.pendingStream);
          m.paidPhysical = money(m.paidPhysical + m.pendingPhysical);
          m.payoutStream = money(m.payoutStream + streamPayout);
          m.payoutPhysical = money(m.payoutPhysical + money(payout - streamPayout));
          m.pendingStream = 0;
          m.pendingPhysical = 0;
          m.paid = money(m.paid + pay);
          m.payout = money(m.payout + payout);
          c.revenue = money((c.revenue || 0) + pay);
          m.pending = 0;
          m.pendingDays = 0;
        }
        return { streams, sales };
      }
      weekStats(c) {
        return c.market.days.filter(d => d.day > this.s.day - 7).reduce((a, d) =>({ streams: a.streams + d.streams, sales: a.sales + d.sales }), { streams: 0, sales: 0 });
      }
      tickCatalog() {
        let exposure = new Map();
        for (const c of this.s.catalog) {
          let result = this.releaseDay(c, 'player');
          if (!result) continue;
          let m = c.market,
          e = this.entity(c.entity);
          if (e) {
            exposure.set(c.entity, (exposure.get(c.entity) || 0) + result.streams);
            let totalFans = e.members.reduce((n, a) => n + a.fans, 0),
            fans = Math.floor(result.streams * .0002 / Math.sqrt(1 + totalFans / 5000));
            for (const a of e.members) a.fans += Math.floor(fans / e.members.length);
            let u = this.s.units.find(u => u.key === e.key);
            if (u) u.fans += fans;
          }
          let week = this.weekStats(c);
          if (!m.hit &&(week.streams >= 300000 || m.firstWeekSales >= 500)) {
            m.hit = true;
            let p = this.s.performance.find(p => p.kind === 'single' && p.key === c.entity && p.releaseId === c.id);
            if (!p) {
              p = this.s.performance.find(p => p.kind === 'single' && p.key === c.entity && p.day === m.startDay && !p.releaseId);
              if (p) p.releaseId = c.id;
            }
            if (p) {
              p.hit = true;
              p.reach = week.streams;
              p.day = this.s.day;
            } else this.s.performance.push({
              day: this.s.day,
              key: c.entity,
              ids: m.ids.length ? m.ids:(e?.members.map(a => a.id) ||[]),
              kind: 'single',
              quality: c.quality,
              hit: true,
              reach: week.streams,
              releaseId: c.id
            });
          }
        }
        for (const[key, reach] of exposure) {
          let e = this.entity(key);
          if (e) this.exposure(e, reach, .02);
        }
        for (const r of this.s.rivals) for (const c of r.catalog) {
          if (!c.market) this.initRelease(c, {
            owner: 'r' + r.id,
            uid: 'r' + r.id + '-' + r.serial,
            snapshot: { name: r.name, type: r.type === 'any' ? 'idol': r.type, ids: r.artists },
            fame: r.reputation
          });
          let result = this.releaseDay(c, r);
          if (result) r.fans += Math.floor(result.streams * .0001 / Math.sqrt(1 + r.fans / 10000));
        }
      }
      rivalsMonth() {
        let known = new Set(this.s.rivals.flatMap(r => r.catalog.map(c => c)));
        super.rivalsMonth();
        for (const r of this.s.rivals) for (const c of r.catalog) if (!known.has(c)) {
          c.fanBase = r.fans;
          c.concept = 'balanced';
          c.revenue = 0;
          let physical = r.type === 'idol' && r.cash > 3000,
          quantity = physical ? 1000: 0,
          cost = quantity * .6;
          if (cost) {
            r.cash -= cost;
            let b = r.accounts.at(- 1);
            b.expense += cost;
          }
          let active = r.talents.filter(t => t.active).map(t => t.id).slice(0, 5),
          ids = r.type === 'rap' ? active.slice(0, 1): active;
          this.initRelease(c, {
            owner: 'r' + r.id,
            uid: 'r' + r.id + '-' + r.serial,
            options: { format: physical ? 'physical': 'digital', quantity },
            snapshot: { name: ids.length === 1 ? D.roster[ids[0]].name: r.name + ' 프로젝트팀', type: r.type === 'any' ?(ids.length ? D.roster[ids[0]].type: 'idol'): r.type, ids },
            budget: r.type === 'rap' ? 1800: 2500,
            fame: r.reputation
          });
        }
      }
      entityRecord(key) {
        let e = this.entity(key);
        if (!e) return null;
        return {
          key,
          name: e.name,
          fame: this.s.units.find(u => u.key === key)?.fame ?? e.members[0].fame,
          fans: this.s.units.find(u => u.key === key)?.fans ?? e.members[0].fans,
          events: this.s.performance.filter(p => p.key === key && p.day > this.s.day - 365)
        };
      }
      grade(record) {
        let hits = record.events.filter(p => p.hit === true).length;
        return record.fame >= 85 && record.fans >= 50000 && hits >= 4 ? 4: record.fame >= 70 && record.fans >= 10000 && hits >= 2 ? 3: record.fame >= 40 && record.events.length >= 2 ? 2: record.fame >= 15 ? 1: 0;
      }
      updateStars() {
        for (const a of this.s.artists) {
          if (this.s.day - a.lastActive > 30) {
            a.fame = Math.max(0, a.fame - 1);
            a.fans = Math.floor(a.fans * .99);
          }
          if (this.s.day - a.lastActive > 90) {
            a.trust = Math.max(0, a.trust - 2);
            if (a.trust < 50 && !a.concernSent) {
              a.concernSent = true;
              this.report('활동 계획 면담 요청', D.roster[a.id].name + '이 새로운 활동 계획을 요청합니다.', 'event', true, { entity: String(a.id) });
            }
          } else a.concernSent = false;
        }
        for (const u of this.s.units) if (!this.s.performance.some(p => p.key === u.key && p.day > this.s.day - 60)) {
          u.fame = Math.max(0, u.fame - 1);
          u.fans = Math.floor(u.fans * .99);
        }
        for (const a of this.s.artists) {
          let rec = { fame: a.fame, fans: a.fans, events: this.s.performance.filter(p => p.key === String(a.id) && p.day > this.s.day - 365) },
          level = this.grade(rec);
          a.marketStarSince = level >= 3 ?(a.marketStarSince ?? this.s.day): null;
          if (level >= 3 && this.s.day - a.marketStarSince < 180) level = 2;
          a.star = level;
          a.bestStar = Math.max(a.bestStar || 0, level);
        }
        for (const u of this.s.units) {
          let level = this.grade(this.entityRecord(u.key));
          u.marketStarSince = level >= 3 ?(u.marketStarSince ?? this.s.day): null;
          if (level >= 3 && this.s.day - u.marketStarSince < 180) level = 2;
          u.star = level;
          u.bestStar = Math.max(u.bestStar || 0, level);
        }
        let streams = this.s.catalog.reduce((n, c) => n + c.market.days.filter(d => d.day > this.s.day - 28).reduce((v, d) => v + d.streams, 0), 0),
        sales = this.s.catalog.reduce((n, c) => n + c.market.days.filter(d => d.day > this.s.day - 28).reduce((v, d) => v + d.sales, 0), 0),
        hits = this.s.performance.filter(p => p.hit && p.day > this.s.day - 365).length,
        target = clamp(Math.log10(1 + streams) * 5 + Math.log10(1 + sales) * 4 + Math.sqrt(hits) * 4, 0, 100),
        old = this.s.reputation;
        this.s.reputation = clamp(old + clamp(target - old, - 2, 3), 0, 100);
        this.s.reputationReason = '최근' + ' 28일 재생 ' + streams.toLocaleString() + '회·판매 ' + sales.toLocaleString() + '장 / 최근 1년 흥행 ' + hits + '회';
        this.s.lastReputation = old;
      }
      startIncident(kind, key) {
        let incident = super.startIncident(kind, key);
        this.syncStarEligibility();
        return incident;
      }
      closeIncident(incident, choice) {
        super.closeIncident(incident, choice);
        this.syncStarEligibility();
      }
      syncStarEligibility() {
        for (const a of this.s.artists) {
          let r = { fame: a.fame, fans: a.fans, events: this.s.performance.filter(p => p.key === String(a.id) && p.day > this.s.day - 365) };
          a.marketStarSince = this.grade(r) >= 3 ?(a.marketStarSince ?? this.s.day): null;
        }
        for (const u of this.s.units) u.marketStarSince = this.grade(this.entityRecord(u.key)) >= 3 ?(u.marketStarSince ?? this.s.day): null;
      }
      advanceMarket() {
        let result = this.advanceIncidents();
        this.syncStarEligibility();
        return result;
      }
      charts(metric = 'streams') {
        if (!['streams', 'sales'].includes(metric)) throw Error('차트 종류를 확인하세요.');
        return this.allReleases().map(row =>({ ... row, week: this.weekStats(row.release) })).filter(row => row.week[metric] > 0).sort((a, b) => b.week[metric] - a.week[metric] || a.release.market.uid.localeCompare(b.release.market.uid));
      }
      allReleases() {
        return [... this.s.catalog.map(c =>({ release: c, company: this.s.company, own: true })), ... this.s.rivals.flatMap(r => r.catalog.map(c =>({ release: c, company: r.name, own: false })))];
      }
    }
    return MarketGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installMarket = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
