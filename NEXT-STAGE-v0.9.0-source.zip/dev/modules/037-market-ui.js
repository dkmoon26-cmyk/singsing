/* FILE src/market-ui.js */
'use strict';
let releaseScope = 'own', chartMetric = 'streams', compareReleases = [], traineeView = 'all';
const menuGroups = {
  home:[['home', '홈'], ['goals', '목표']],
  inbox:[['inbox', '수신함']],
  artists:[['artists', '아티스트'], ['development', '개인 육성'], ['training', '연습생'], ['casting', '캐스팅'], ['teams', '팀·계약']],
  projects:[['projects', '프로젝트'], ['music', '발매 성과'], ['schedule', '통합 일정']],
  company:[['company', '회사·가치'], ['staff', '직원 관리'], ['recruit', '직원 고용'], ['finance', '재정']],
  industry:[['industry', '라이벌'], ['charts', '음악 차트']]
};
function pageGroup(p) {
  return Object.keys(menuGroups).find(group => menuGroups[group].some(([id]) => id === p)) || 'home';
}
function sectionTabs() {
  return `<nav class="section-tabs" aria-label="영역 내 메뉴">${menuGroups[pageGroup(page)].map(([id,label])=>btn(label,'nav',`data-page="${id}"`,page===id?'active':'')).join('')}${btn('하루 기록','m-day-log','','link')}${btn('저장·복구','m-saves','','link')}</nav>`;
}
function saveStatusLabel() {
  let meta = saveStore.read('next-stage-save-meta'),
  date = meta?.at ? new Date(meta.at): null;
  if (!saveOK && saveStore.hasAutoChanged()) return '다른 탭 저장 감지 · 현재 진행 백업 필요';
  return saveOK ? '저장됨' +(date && Number.isFinite(date.getTime()) ? ' · ' + date.toLocaleTimeString('ko-KR', { timeZone: 'Asia/Seoul', hour: '2-digit', minute: '2-digit' }): ''): '저장 실패 · JSON 백업 필요';
}
function todayTasks_market() {
  let s = game.s,
  tasks = [];
  for (const i of s.incidents) if (i.state === 'open') tasks.push({
    priority: 0,
    label: '사건 대응 · ' + i.name + ' · ' +(i.expires - s.day) + '일 남음',
    action: 'm-incident-open',
    args: `data-id="${i.id}"`
  });
  if (s.cash < game.fixed * 2) tasks.push({
    priority: 0,
    label: '운영 자금 확인 · ' + money(s.cash),
    action: 'nav',
    args: 'data-page="finance"'
  });
  for (const a of s.artists) if (a.contract - s.day <= 90) tasks.push({
    priority: 1,
    label: DATA.roster[a.id].name + ' 재계약 · ' +(a.contract - s.day) + '일 남음',
    action: 'm-renew',
    args: `data-id="${a.id}"`
  });
  for (const a of s.trainees) if (s.day - a.signed >= 90 && game.readiness(a) >= 55) tasks.push({
    priority: 2,
    label: DATA.roster[a.id].name + ' 데뷔 조건 충족',
    action: 'm-debut',
    args: `data-id="${a.id}"`
  });
  if (!s.artists.length && !s.trainees.length) tasks.push({
    priority: 2,
    label: '첫 인재 모집 시작',
    action: 'casting-modal',
    args: ''
  });
  return tasks.sort((a, b) => a.priority - b.priority);
};
function releaseRow(row) {
  let c = row.release,
  m = c.market,
  w = game.weekStats(c);
  return `<article class="contract-row"><div class="row between wrap"><div><h3>${esc(c.name)}</h3><small>${esc(m.artistName)} · ${esc(row.company)} · ${date(m.startDay)} · ${m.format==='physical'?'실물 싱글':'음원 싱글'}</small></div>${btn('작품 성과','m-release',`data-uid="${m.uid}"`,'soft small')}</div><p>최근 7일 ${w.streams.toLocaleString()}회 재생 · ${m.format==='physical'?w.sales.toLocaleString()+'장 판매':'실물 미제작'} / 누적 ${m.streams.toLocaleString()}회${m.format==='physical'?' · '+m.sales.toLocaleString()+'장':''}</p>${btn(compareReleases.includes(m.uid)?'비교 선택됨':'비교에 추가','m-compare-select',`data-uid="${m.uid}"`,'link small')}</article>`;
}
function music() {
  let rows = game.allReleases().filter(row => releaseScope === 'all' || releaseScope === 'own' && row.own || releaseScope === 'rival' && !row.own).sort((a, b) => b.release.market.startDay - a.release.market.startDay);
  return heading('발매 성과', '판매·재생·정산을 작품별로 확인하세요.', btn('선택 작품 비교 (' + compareReleases.length + '/3)', 'm-compare', '', 'primary', compareReleases.length < 2)) + `<div class="tabs">${[['own','우리 회사'],['rival','라이벌'],['all','전체']].map(([id,label])=>btn(label,'m-release-scope',`data-scope="${id}"`,releaseScope===id?'active':'')).join('')}</div>` + panel('최근 발매작', rows.slice(0, 60).map(releaseRow).join('') || '<p>아직 집계할 작품이 없습니다.</p>') + `<p class="muted">최근 60개 작품 표시. 이전 작품은 프로젝트의 발매 목록에서도 열 수 있습니다.</p>`;
}
function charts_market() {
  let rows = game.charts(chartMetric);
  return heading('참여 레이블 차트', '우리 회사와 라이벌 4곳만 포함합니다. 전체 음악 시장 순위가 아닙니다.', btn('선택 작품 비교', 'm-compare', '', 'soft', compareReleases.length < 2)) + `<div class="tabs">${btn('주간 스트리밍','m-chart','data-metric="streams"',chartMetric==='streams'?'active':'')}${btn('주간 음반 판매','m-chart','data-metric="sales"',chartMetric==='sales'?'active':'')}</div>` + panel('최근 7일 순위', rows.slice(0, 30).map((row, index) => `<div class="chart-row"><strong class="rank">${index+1}</strong><div class="spacer"><h3>${esc(row.release.name)}</h3><small>${esc(row.company)} · ${esc(row.release.market.artistName)}</small><p>${row.week[chartMetric].toLocaleString()}${chartMetric==='streams'?'회':'장'}</p>${btn('성과 보기','m-release',`data-uid="${row.release.market.uid}"`,'link small')}${btn('비교 선택','m-compare-select',`data-uid="${row.release.market.uid}"`,'link small')}</div></div>`).join('') || '<p>최근 7일 집계가 없습니다.</p>');
}
function releaseGraph(c, metric) {
  let bins = c.market.weeks.slice(- 12);
  if (!bins.length) return '<p>아직 주간 기록이 없습니다.</p>';
  let max = Math.max(1, ... bins.map(w => w[metric]));
  return `<svg viewBox="0 0 520 170" class="release-graph" role="img" aria-label="최근 12주 ${metric==='streams'?'스트리밍':'판매'} 추이"><title>${metric==='streams'?'스트리밍':'음반 판매'} · 최고 ${max.toLocaleString()}</title><line x1="12" y1="135" x2="508" y2="135" stroke="#cbd5e1"/>${bins.map((w,i)=>{let width=480/bins.length-6,x=20+i*480/bins.length,h=w[metric]/max*110;return `<rect x="${x}" y="${135-h}" width="${Math.max(4,width)}" height="${h}" rx="3" fill="#1265ef"><title>${w.week+1}주차 ${w[metric].toLocaleString()}</title></rect><text x="${x}" y="154" font-size="10" fill="#52627c">${w.week+1}주</text>`;}).join('')}</svg><small>최근 ${bins.length}개 주간 · 현재 주는 집계 중 · 최고 ${max.toLocaleString()}${metric==='streams'?'회':'장'}</small>`;
}
function releaseModal_market(uid) {
  let row = game.allReleases().find(row => row.release.market.uid === uid);
  if (!row) throw Error('작품을 찾을 수 없습니다.');
  let c = row.release,
  m = c.market,
  w = game.weekStats(c),
  today = m.days.find(d => d.day === game.s.day),
  first = m.firstWeekSales === null ? '과거 기록 없음': m.firstWeekSales.toLocaleString() + '장' +(game.s.day - m.startDay < 6 ? ' · 집계 중': '');
  modal(c.name + ' · 발매 성과', `<p>${esc(m.artistName)} · ${esc(row.company)} · ${DATA.labels[m.type]} · 완성도 ${Math.round(c.quality)}</p><p>${m.legacy?'이전 작품: 업데이트 이후 측정분만 표시합니다.':'발매 '+date(m.startDay,true)} · 측정 시작 ${date(m.measuredFrom)}</p><div class="detail-state"><div><small>오늘 스트리밍</small><b>${(today?.streams||0).toLocaleString()}회</b></div><div><small>최근 7일 스트리밍</small><b>${w.streams.toLocaleString()}회</b></div><div><small>누적 스트리밍</small><b>${m.streams.toLocaleString()}회</b></div><div><small>초동 7일 판매</small><b>${m.format==='physical'?first:'음원 전용'}</b></div><div><small>최근 7일 판매</small><b>${m.format==='physical'?w.sales.toLocaleString()+'장':'음원 전용'}</b></div><div><small>누적 판매</small><b>${m.format==='physical'?m.sales.toLocaleString()+'장':'음원 전용'}</b></div></div><h3>주간 스트리밍 추이</h3>${releaseGraph(c,'streams')}${m.format==='physical'?'<h3>주간 판매 추이</h3>'+releaseGraph(c,'sales'):''}${row.own?`<section class="panel section"><h3>업데이트 이후 정산</h3><p>스트리밍: 발생 ${money(m.streamReceipts)} / 지급 ${money(m.paidStream)} / 배분 ${money(m.payoutStream)} / 회사 ${money(m.paidStream-m.payoutStream)}</p><p>음반: 발생 ${money(m.physicalReceipts)} / 지급 ${money(m.paidPhysical)} / 배분 ${money(m.payoutPhysical)} / 회사 ${money(m.paidPhysical-m.payoutPhysical)}</p><p>매출 합계 ${money(m.gross)} − 유통 공제 ${money(m.distribution)} = 정산 발생액 ${money(m.receipts)}</p><p>지급 완료 ${money(m.paid)} − 아티스트 배분 ${money(m.payout)} = 회사 입금 ${money(m.paid-m.payout)}</p><p>미정산 ${money(m.pending)} · 다음 정산까지 ${7-m.pendingDays}일</p><p>음악 제작비 ${money(m.production)} · 음반 제조비 ${money(m.manufacturing)}</p><strong>입금 기준 누적 손익 ${money(m.paid-m.payout-m.production-m.manufacturing)}</strong><p>일 훈련·월 고정비 별도. 이전 작품의 과거 비용·판매량은 소급 복원하지 않습니다.</p>${m.format==='physical'?`<p>재고 ${m.stock.toLocaleString()}장 / 누적 제조 ${m.manufactured.toLocaleString()}장 · 제조원가 장당 ${money(m.unitCost)}</p>${btn('1,000장 추가 제조 검토','m-reprint',`data-id="${c.id}"`,'soft')}`:''}</section>`:`<p>타사 내부 원가·배분은 비공개입니다. 공개 지표 기반 수입 추정 ${money(m.receipts*.8)}~${money(m.receipts*1.2)}이며 실제 회사 이익이 아닙니다.</p>`}<p>${m.hit?'이 작품은 실제 성과 기준 흥행으로 기록됐습니다.':'흥행 기준: 최근 7일 30만 회 재생 또는 초동 500장. 완성도만으로 판정하지 않습니다.'}</p>${btn(compareReleases.includes(uid)?'비교 선택 해제':'비교에 추가','m-compare-select',`data-uid="${uid}"`,'soft')}`, true);
}
function compareModal() {
  let rows = game.allReleases().filter(row => compareReleases.includes(row.release.market.uid));
  if (rows.length < 2) throw Error('비교할 작품 2~3개를 선택하세요.');
  modal('작품 비교', `<p>최근 7일은 같은 날짜 구간입니다. 누적 성과는 발매 후 경과 기간도 함께 비교하세요.</p><div class="compare-grid">${rows.map(row=>{let c=row.release,m=c.market,w=game.weekStats(c);return `<article class="panel"><h3>${esc(c.name)}</h3><p>${esc(row.company)} · 발매 ${Math.max(0,game.s.day-m.startDay)}일</p><p>최근 7일 재생 ${w.streams.toLocaleString()}회</p><p>누적 재생 ${m.streams.toLocaleString()}회</p><p>최근 7일 판매 ${m.format==='physical'?w.sales.toLocaleString()+'장':'음원 전용'}</p><p>누적 판매 ${m.format==='physical'?m.sales.toLocaleString()+'장':'음원 전용'}</p>${releaseGraph(c,'streams')}</article>`;}).join('')}</div>`, true);
}
const marketProjectModal = projectModal_app, marketArtistModal = artistModal_app, marketManagementClick = managementClick_progression, marketCompany = company_progression;
function projectModal_market(key) {
  marketProjectModal(key);
  $('#budget-preview').insertAdjacentHTML('afterend', `<div id="release-options" class="field"><label for="release-format">싱글 발매 형태</label><select id="release-format" name="format"><option value="digital">음원 전용</option><option value="physical">실물 음반 + 음원</option></select><label for="release-quantity">실물 초도 수량 (실물 선택 시 적용)</label><select id="release-quantity" name="quantity"><option value="1000">1,000장 · 제조비 600만 원</option><option value="3000">3,000장 · 제조비 1,800만 원</option><option value="10000">10,000장 · 제조비 6,000만 원</option></select><small>음반 가격 2.5만 원 · 장당 제조원가 0.6만 원. 제조비는 음악 제작비와 별도이며 미판매 재고 위험이 있습니다.</small></div>`);
  budgetPreview();
};
;
function gradeSummary(key) {
  let rec = game.entityRecord(key);
  if (!rec) return '';
  let star = key.startsWith('u') ? game.s.units.find(u => u.key === key): game.artist(Number(key)),
  hits = rec.events.filter(p => p.hit).length,
  next = Math.min(4, star.star + 1),
  targets = [{}, { fame: 15, fans: 0, hits: 0 }, { fame: 40, fans: 0, hits: 0 }, { fame: 70, fans: 10000, hits: 2 }, { fame: 85, fans: 50000, hits: 4 }],
  t = targets[next];
  return `<section class="panel section"><h3>${starNames[star.star]} → ${star.star===4?'최고 등급 유지':starNames[next]}</h3><p>개인/팀 인지도 ${rec.fame.toFixed(1)} / ${t.fame} · 충성 팬 ${rec.fans.toLocaleString()} / ${t.fans.toLocaleString()} · 최근 1년 실제 흥행 ${hits} / ${t.hits}</p><p>${next===2?'인기 등급에는 최근 1년 활동 2회도 필요합니다.':next>=3?'스타 이상은 인지도·팬·흥행 조건을 180일 유지해야 합니다. 현재 유지 '+(star.marketStarSince==null?0:game.s.day-star.marketStarSince)+'일.':''}</p><small>음원: 최근 7일 30만 회 또는 초동 500장. 공연: 관객500명 이상·점유70% 이상·회사 손익 양수. 충성 팬은 구매·관람 가능성이 높은 팬층이며 인지도는 대중 노출 정도입니다.</small></section>`;
}
function artistModal_market(id, candidate = false) {
  marketArtistModal(id, candidate);
  if (!candidate && game.artist(id)) $('#modal-error').insertAdjacentHTML('beforebegin', gradeSummary(String(id)));
};
function company_market() {
  return marketCompany() + panel('평판 변동 근거', `<h3>${game.s.reputation.toFixed(1)} / 100 · 최근 월간 조정 ${(game.s.reputation-game.s.lastReputation).toFixed(1)}</h3><p>${esc(game.s.reputationReason)}</p><p>최근 판매·스트리밍·흥행으로 월간 목표 평판을 계산해 최대 +3 / −2씩 조정합니다. 사건·회생 지원의 별도 감소는 유지합니다.</p>`);
};
;
function managementClick_market(action, d) {
  switch (action) {
    case 'm-slot-delete-confirm': modal('슬롯 삭제 확인', `<p>슬롯 ${Number(d.index)}의 저장을 삭제합니다. 자동 저장은 유지됩니다. 필요한 진행은 먼저 JSON으로 백업하세요.</p>${btn('이 슬롯 삭제','m-slot-delete',`data-index="${Number(d.index)}"`,'danger')}`);
    return;
    case 'm-slot-delete': saveStore.removeSlot(Number(d.index));
    savePanel();
    return;
    case 'm-points-clear-confirm': modal('복구 지점 삭제 확인', `<p>자동 복구 지점3개를 비웁니다. 현재 자동 저장과 수동 슬롯은 유지됩니다.</p>${btn('복구 지점 비우기','m-points-clear','','danger')}`);
    return;
    case 'm-points-clear': saveStore.clearCheckpoints();
    savePanel();
    return;
    case 'm-release': return releaseModal(d.uid);
    case 'm-release-scope': releaseScope = d.scope;
    render();
    return;
    case 'm-chart': chartMetric = d.metric;
    render();
    return;
    case 'm-compare-select': if (compareReleases.includes(d.uid)) compareReleases = compareReleases.filter(uid => uid !== d.uid);
    else {
      if (compareReleases.length >= 3) throw Error('작품은 최대3개까지 비교할 수 있습니다.');
      compareReleases.push(d.uid);
    }
    render();
    if ($('#modal-root').children.length) releaseModal(d.uid);
    toast('비교 작품 ' + compareReleases.length + '/3개 선택');
    return;
    case 'm-compare': return compareModal();
    case 'm-reprint': modal('추가 제조 확인', `<p>1,000장 추가 제조에 600만 원을 지출합니다. 기존 재고와 판매 추이를 확인한 뒤 결정하세요.</p>${btn('추가 제조 승인','m-reprint-apply',`data-id="${d.id}"`,'primary')}`);
    return;
    case 'm-reprint-apply': return mutate(() => game.reprint(d.id, 1000), '음반 추가 제조를 승인했습니다.');
    case 'm-trainee-filter': traineeView = d.filter;
    render();
    return;
    default: throw Error("처리할 수 없는 동작입니다.");
  }
};
UIEvents.onChange('market', ev => {
  if (['release-format', 'release-quantity'].includes(ev.target.id)) budgetPreview();
});


;
