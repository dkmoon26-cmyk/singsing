/* FILE src/day-feedback-ui.js */
'use strict';
function progressSummaryContent() {
  const s = game.s;
  if (!s) return '';
  const notice = lastAdvanceNotice;
  let rows = notice ? s.daySummaries.filter(d => d.day > notice.from && d.day <= notice.to): s.daySummaries.slice(- 1);
  if (!rows.length && !running) return '';
  const from = notice?.from ?? rows[0]?.fromDay ?? s.day,
  to = notice?.to ?? rows.at(- 1)?.day ?? s.day,
  elapsed = to - from;
  const sum = rows.reduce((a, d) =>({
    cash: a.cash + d.cashChange,
    streams: a.streams + d.streams,
    sales: a.sales + d.sales,
    training: a.training + d.trainingCount,
    fans: a.fans + d.fansChange,
    teamFans: a.teamFans + d.teamFansChange,
    completed: a.completed + d.completed.length + festivalCount(d),
    reports: a.reports + d.newReports
  }), {
    cash: 0,
    streams: 0,
    sales: 0,
    training: 0,
    fans: 0,
    teamFans: 0,
    completed: 0,
    reports: 0
  });
  const fresh = notice?.at && Date.now() - notice.at < 1800;
  const label = running ?(notice?.mode === 'skip' ? '중요 일정까지 진행 중…': '하루 진행 중…'): notice?.stop ||(elapsed === 1 ? '최근 하루 진행 기록': '최근 진행 기록');
  return `<section class="panel progress-summary ${running?'is-running':fresh?'is-new':''}" role="status" aria-live="polite"><div class="row between wrap"><div><strong>${esc(label)}</strong><p><span class="progress-date">${date(from)} → ${date(to)}</span> · ${elapsed}일 경과</p></div>${btn('하루 기록 보기','m-day-log','','soft small')}</div>${rows.length?`<p>훈련 ${sum.training}건 · 스트리밍 ${sum.streams.toLocaleString()}회 · 음반 ${sum.sales.toLocaleString()}장 · 일정 완료 ${sum.completed}건</p><p>현금 ${sum.cash>=0?'+':''}${money(sum.cash)} · 개인 팬 ${sum.fans>=0?'+':''}${sum.fans.toLocaleString()}명 · 팀 팬 ${sum.teamFans>=0?'+':''}${sum.teamFans.toLocaleString()}명</p>${!sum.completed&&!sum.reports?'<small>훈련과 성과 집계를 마쳤습니다. 새로운 주요 일정·보고는 없습니다.</small>':''}${sum.reports?`<small>새 보고 ${sum.reports}건 · </small>${btn('소식함 확인','nav','data-page="inbox"','link small')}`:''}`:'<p>날짜와 훈련·정산 결과를 계산하고 있습니다.</p>'}</section>`;
}
function progressSummaryCard() {
  return running ? progressSummaryContent(): '';
}
function dayLogModal() {
  modal('최근 30일 진행 기록', game.s.daySummaries.length ? `<p>날짜 진행으로 생긴 변화입니다. 그 전에 직접 승인한 지출은 포함하지 않습니다. 팬 수는 현재 소속 기준으로 계약 종료도 반영됩니다.</p>${[...game.s.daySummaries].reverse().map(d=>`<article class="contract-row"><h3>${date(d.fromDay)} → ${date(d.day)} · 하루 진행</h3><p>현금 ${d.cashChange>=0?'+':''}${money(d.cashChange)} · 훈련 ${d.trainingCount}건 · 재생 ${d.streams.toLocaleString()}회 · 판매 ${d.sales.toLocaleString()}장</p><p>개인 팬 ${d.fansChange>=0?'+':''}${d.fansChange} · 팀 팬 ${d.teamFansChange>=0?'+':''}${d.teamFansChange}</p>${dayFestivalHTML(d)}${d.completed.length?'<p>완료: '+d.completed.map(j=>esc(j.title)).join(' · ')+'</p>':festivalCount(d)?'':'<p>완료된 주요 일정 없음</p>'}${d.departed.length?'<p>전속 종료: '+d.departed.map(id=>DATA.roster[id].name).join(' · ')+'</p>':''}<small>새 보고 ${d.newReports}건</small></article>`).join('')}`: '<p>업데이트 이후 날짜를 진행하면 기록이 생깁니다.</p>', true);
}
const feedbackManagementClick = managementClick_market, feedbackApplyRestore = applyRestore_progression;
function managementClick_dayfeedback(action, d) {
  if (action === 'm-day-log') return dayLogModal();
  return feedbackManagementClick(action, d);
};
function applyRestore_dayfeedback() {
  feedbackApplyRestore();
  lastAdvanceNotice = null;
  selectedReport = null;
  render();
};


;
