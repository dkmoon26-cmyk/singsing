# NEXT STAGE · 넥스트 스테이지

음악 기획사 운영 게임. 서버 API나 별도 npm 의존성 없이 정적 파일로 실행합니다.

```sh
python3 scripts/build.py --check
python3 -m http.server 8000 --bind 127.0.0.1
```

브라우저에서 로컬 서버의 `index.html`을 엽니다. 저장은 브라우저·주소별로 분리됩니다.
기존 서비스를 업데이트할 때는 같은 주소를 유지하고, 먼저 설정에서 JSON 백업을 내보내세요.

개발·검증·배포 방법은 [유지보수 문서](docs/MAINTENANCE.md)를 참고하세요.

전체 캐릭터 72명은 `character-gallery.html`에서 검색하고 크게 확인할 수 있습니다.
