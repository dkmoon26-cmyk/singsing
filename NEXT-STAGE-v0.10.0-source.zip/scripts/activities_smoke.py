"""Real browser activity settlement, migration and responsive UI regression."""
import functools,http.server,json,os,tempfile,threading
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(os.environ.get('WEB_ROOT',Path(__file__).resolve().parents[1]));out=Path(os.environ.get('UI_SCREENSHOT_DIR','/tmp/next-stage-activities'));out.mkdir(parents=True,exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(ROOT)));threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':1440,'height':1050});errors=[];bad=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('response',lambda r:bad.append(r.url) if r.status>=400 else None);page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle')
  result=page.evaluate('''()=>{
    const assert=(ok,msg)=>{if(!ok)throw Error(msg)},copy=x=>JSON.parse(JSON.stringify(x));
    const fixture=new Game(),random=Math.random;Math.random=()=>.42;try{fixture.newGame('활동 개편 검증','대표')}finally{Math.random=random}
    fixture.startCasting('audition','idol','any','career');for(let i=0;i<10;i++)fixture.nextDay();fixture.sign(fixture.s.candidates[0].id,'balanced');
    fixture.change(500000,'테스트 운영 자금');fixture.s.artists.forEach(a=>{a.focus='rest';a.energy=100;a.stress=0;a.fans=10000;a.fame=40});const initial=copy(fixture.s),key=String(initial.artists[0].id),newGame=()=>new Game(copy(initial));
    const albumResults=[];
    for(const [type,def] of Object.entries(ActivityData.albums)){
      const g=newGame();g.s.perks.productionVoucher=1;
      const options={albumType:type,format:type==='digital'?'digital':'physical',quantity:1000,promotion:'session'};
      const quote=g.activityPlan(key,'single',7000,options),cash=g.s.cash;
      const j=g.startProject(key,'single',def.label,7000,'balanced',options);
      assert(j.trackCount===def.tracks&&j.due-j.start===def.days+4,'album tracks/duration '+type);assert(Math.abs(cash-g.s.cash-quote.quote.total)<.01,'album exact approval cost '+type);assert(g.s.perks.productionVoucher===0,'voucher once');
      const restored=new Game(copy(g.s));assert(validState(restored.s)&&restored.s.jobs[0].albumType===type,'active album save roundtrip');
      for(let i=0;i<def.days+4;i++)g.nextDay();const c=g.s.catalog.find(c=>c.name===def.label);assert(c&&c.trackCount===def.tracks&&c.albumType===type,'release metadata '+type);
      assert(c.market.production===quote.quote.production+quote.quote.promo,'investment includes promotion '+type);assert(validState(g.s),'released album valid '+type);
      for(let i=0;i<8;i++)g.nextDay();assert(c.market.paid>0&&c.market.sales+c.market.stock===c.market.manufactured,'album settlements/stock');
      albumResults.push({type,tracks:c.trackCount,investment:c.market.production+c.market.manufacturing,streams:c.market.streams});
    }
    // Digital packages and future reservations must use the same complete production duration.
    for(const type of ['mini','album']){
      const h=newGame();h.startProject(key,'single','음원 '+type,1000,'balanced',{albumType:type,format:'digital'});
      for(let i=0;i<ActivityData.albums[type].days;i++)h.nextDay();assert(validState(h.s)&&h.s.catalog[0].albumType===type,'digital package valid '+type);
    }
    const reserved=newGame(),offer=reserved.createFestivalOffer('genre',key,reserved.s.day+30);reserved.resolveFestival(offer,'accept');
    const preview=reserved.activityPlan(key,'single',1000,{albumType:'album',promotion:'session'}),project=reserved.startProject(key,'single','행사와 정규앨범',1000,'balanced',{albumType:'album',promotion:'session'});
    assert(project.due===preview.due&&project.due-project.start===56&&project.delayDays===3,'full album reservation preview matches actual');
    const rejectedBefore=JSON.stringify(reserved.s);let rejected=false;try{reserved.resolveFestival(offer,'accept')}catch{rejected=true}assert(rejected&&JSON.stringify(reserved.s)===rejectedBefore,'external offer cannot pay twice');
    for(let i=0;i<56;i++)reserved.nextDay();assert(reserved.s.festivalHistory.length===1&&reserved.s.catalog.some(c=>c.name==='행사와 정규앨범')&&validState(reserved.s),'reserved festival and album both finish once');
    const venues=[];
    for(const [venue,v] of Object.entries(ActivityData.venues)){
      const g=newGame(),before=JSON.stringify(g.s),p=g.concertPreview(key,venue);assert(JSON.stringify(g.s)===before,'preview no mutation');
      const cash=g.s.cash,j=g.startProject(key,'live',v.label,300,'balanced',{venue});assert(cash-g.s.cash===v.cost&&j.due-j.start===v.days,'venue approval');
      for(let i=0;i<v.days;i++)g.nextDay();const row=g.s.settlements.find(r=>r.name===v.label),o=g.s.outcomes.find(o=>o.venue===venue);
      assert(row&&o&&row.capacity===v.capacity&&row.attendance<=v.capacity,'venue actual capacity');assert(Math.abs(row.net-(row.gross-row.payout-row.variable-row.budget))<.02,'venue net reconciliation');assert(row.budget===v.cost,'venue paid investment');
      const due=g.s.receivables.filter(r=>r.kind==='concert_settlement');assert(due.length===1&&due[0].due===g.s.day+7,'concert payment scheduled once');
      for(let i=0;i<7;i++)g.nextDay();assert(!g.s.receivables.some(r=>r.kind==='concert_settlement'),'concert paid');assert(validState(g.s),'venue save valid');
      venues.push({venue,capacity:row.capacity,attendance:row.attendance,net:row.net,breakEven:p.breakEven});
    }
    const g=newGame();let effect=g.contentEffect(g.entity(key),'daily');assert(effect.multiplier===1,'first content full effect');
    for(let n=0;n<3;n++){
      const a=g.s.artists[0];a.recoveryUntil=0;a.energy=100;const pre=g.contentEffect(g.entity(key),'daily');g.startProject(key,'cover','소통 '+n,100,'balanced',{contentType:'daily'});for(let i=0;i<3;i++)g.nextDay();const o=g.s.outcomes.at(-1);assert(o.contentType==='daily'&&o.net===null,'content metadata/no direct payout');assert(g.contentEffect(g.entity(key),'daily').multiplier<pre.multiplier,'same content diminishing returns');
    }
    assert(g.contentEffect(g.entity(key),'practice').multiplier===1,'different content separate repeats');
    for(const type of ['practice','cover']){g.s.artists[0].recoveryUntil=0;g.s.artists[0].energy=100;const j=g.startProject(key,'cover',type,100,'balanced',{contentType:type});for(let i=0;i<ActivityData.content[type].days;i++)g.nextDay();assert(g.s.outcomes.at(-1).contentType===type,'content completes '+type);}
    const old=newGame();old.startProject(key,'single','기존 싱글',1000,'balanced');assert(old.s.jobs[0].albumType===undefined&&validState(old.s),'legacy jobs accepted');assert(new Game(copy(old.s)).s.jobs[0].due===old.s.jobs[0].due,'legacy due preserved');
    for(const args of [['single',1000,{albumType:'wrong'}],['single',1000,{albumType:'digital',format:'physical',quantity:1000}],['cover',-1,{contentType:'daily'}],['live',300,{venue:'wrong'}]]){
      const h=newGame(),before=JSON.stringify(h.s);let failed=false;try{h.startProject(key,args[0],'실패 검증',args[1],'balanced',args[2])}catch{failed=true}assert(failed&&JSON.stringify(h.s)===before,'invalid request atomic');
    }
    const poor=newGame();poor.s.cash=299;let failed=false;const before=JSON.stringify(poor.s);try{poor.startProject(key,'live','돈 부족',300,'balanced',{venue:'small'})}catch{failed=true}assert(failed&&JSON.stringify(poor.s)===before,'insufficient funds atomic');
    const broken=copy(g.s);broken.outcomes[0].contentType='broken';assert(!validState(broken),'corrupt activity metadata rejected');
    window.activityFixture=copy(initial);window.activityOutcomeFixture=copy(g.s);return{albumResults,venues,contentEffects:g.s.outcomes.map(o=>o.factors?.[0])};
  }''')
  print('PASS model',json.dumps(result,ensure_ascii=False))
  fixtures=page.evaluate('({initial:activityFixture,outcomes:activityOutcomeFixture})')
  page.evaluate('''()=>{game=new Game(JSON.parse(JSON.stringify(activityFixture)));game.s.moments.forEach(m=>m.seen=true);save();navigate('projects')}''')
  assert page.get_by_role('heading',name='앨범 준비',exact=True).count()==1
  page.locator('[data-action=m-activity-new][data-subtype=mini]').click()
  assert page.locator('#activity-album').input_value()=='mini'
  page.locator('#activity-name').fill('UI 미니앨범');page.locator('#activity-format').select_option('physical');page.locator('#activity-promotion').select_option('session')
  expected=page.evaluate('game.activityPlan(activityFormValues().key,"single",activityFormValues().budget,activityFormValues().options).quote.total')
  before=page.evaluate('game.s.cash');page.locator('#activity-form [type=submit]').click()
  assert page.evaluate('game.s.jobs.at(-1).albumType')=='mini'
  assert abs(before-page.evaluate('game.s.cash')-expected)<.01
  page.reload(wait_until='networkidle');page.locator('[data-action=continue]').click();page.wait_for_function('game.s && document.querySelector(".main")');assert page.evaluate('game.s.jobs.some(j=>j.albumType==="mini")')
  page.evaluate('v=>{window.activityFixture=v.initial;window.activityOutcomeFixture=v.outcomes}',fixtures)
  print('PASS actual approval UI, exact charge and reload')
  screens=['projects','concerts','content','offers','activity-progress','activity-results','artists','development','home']
  for width in [1440,1024,768,390,360]:
   page.set_viewport_size({'width':width,'height':1050 if width>768 else 844})
   for screen in screens:
    page.evaluate('''screen=>{game=new Game(JSON.parse(JSON.stringify(screen==='activity-results'?activityOutcomeFixture:activityFixture)));navigate(screen)}''',screen)
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),(width,screen,'overflow')
    assert page.locator('[data-action=m-day-log]').count()==0
    assert '하루 기록' not in page.locator('.main').inner_text()
    if screen in ['projects','concerts','content'] and width in [1440,390]:page.screenshot(path=str(out/(screen+'-'+str(width)+'.png')),full_page=True)
   for kind,subtype in [('single','album'),('live','arena'),('cover','daily')]:
    page.evaluate('''v=>{game=new Game(JSON.parse(JSON.stringify(activityFixture)));projectModal_activity(undefined,v[0],v[1])}''',[kind,subtype])
    assert page.evaluate('document.querySelector(".modal").scrollWidth<=document.querySelector(".modal").clientWidth+1'),(width,kind,'modal overflow')
    if kind=='live':
     text=page.locator('#activity-preview').inner_text();assert all(s in text for s in ['예상 관객','총비용','손익분기','회사 손익'])
    page.evaluate('close()')
  assert not errors,errors
  assert not bad,bad
  print('PASS nine screens and three approval dialogs at five widths; no day-log controls, HTTP or JS errors')
  browser.close()
finally:server.shutdown();server.server_close()
