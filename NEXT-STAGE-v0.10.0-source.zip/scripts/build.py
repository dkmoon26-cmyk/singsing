#!/usr/bin/env python3
"""Build or verify the static browser bundle using only Python's standard library."""
import argparse
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--check', action='store_true', help='Fail if the bundle is stale')
parser.add_argument('--zip', type=Path, help='Write a deployment ZIP to this path')
args = parser.parse_args()
parts = json.loads((ROOT / 'dev/manifest.json').read_text())
bundle = ''.join((ROOT / 'dev' / name).read_text() for name in parts)
target = ROOT / 'src/game-bundle.js'
if args.check:
    if target.read_text() != bundle:
        raise SystemExit('Bundle is stale: run python3 scripts/build.py')
    print('Bundle matches editable sources')
else:
    target.write_text(bundle)
    print(f'Built {len(bundle.encode())} bytes from {len(parts)} modules')
if args.zip:
    args.zip.parent.mkdir(parents=True, exist_ok=True)
    files = [ROOT / 'index.html', ROOT / 'character-gallery.html']
    for folder in ('src', 'assets', 'vendor'):
        files.extend(p for p in (ROOT / folder).rglob('*') if p.is_file())
    with ZipFile(args.zip, 'w', ZIP_DEFLATED) as archive:
        for path in sorted(files):
            archive.write(path, path.relative_to(ROOT))
    print(f'Deployment ZIP: {args.zip} ({len(files)} files)')
