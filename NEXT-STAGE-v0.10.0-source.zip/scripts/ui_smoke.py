"""Run the current concept UI and development feature regression checks."""
from pathlib import Path
import runpy

runpy.run_path(str(Path(__file__).with_name('development_smoke.py')), run_name='__main__')
