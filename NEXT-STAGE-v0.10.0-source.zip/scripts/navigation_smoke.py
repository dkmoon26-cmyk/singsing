"""Verify shared progress controls, inbox placement, and actual stop behavior."""
from pathlib import Path
import functools,http.server,os,tempfile,threading
from playwright.sync_api import sync_playwright
root=Path(os.environ.get('WEB_ROOT',Path(__file__).resolve().parents[1]));tmp=tempfile.TemporaryDirectory(prefix='next-stage-nav-');out=Path(os.environ.get('UI_SCREENSHOT_DIR',tmp.name));out.mkdir(parents=True,exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root)));threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle');page.evaluate("game.newGame('진행 위치 검증','대표');save();navigate('home')")
  for width in [1440,1024,768,390,360]:
   page.set_viewport_size({'width':width,'height':1000 if width>600 else 844})
   for menu in ['home','artists','training','projects','finance','schedule','inbox','company','development']:
    page.evaluate('(name)=>navigate(name)',menu)
    assert page.locator('.topbar [data-action=day]').is_visible(),(width,menu,'day hidden')
    assert page.locator('.topbar [data-action=skip]').is_visible(),(width,menu,'skip hidden')
    assert page.locator('.topbar .cash').count()==0
    assert page.locator('.topbar [data-page=inbox]').count()==0
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),(width,menu,'overflow')
   page.evaluate("navigate('home')");assert page.locator('.concept-roster [data-action=day]').count()==0
   assert page.locator('.concept-page-title [data-page=inbox]').count()==0
   if width in [1440,390]:page.screenshot(path=str(out/f'home-{width}.png'),full_page=True)
  page.set_viewport_size({'width':1440,'height':1000});assert page.locator('.sidebar [data-page=inbox]').is_visible();assert page.locator('.sidebar [data-page=inbox] .badge').inner_text()=='1'
  page.locator('.sidebar [data-page=inbox]').click();assert page.evaluate("page==='inbox'")
  page.evaluate("game.s.reports.forEach(r=>r.read=true);navigate('home')");assert page.locator('.sidebar [data-page=inbox] .badge').count()==0
  before=page.evaluate('game.s.day');page.locator('.topbar [data-action=day]').click();page.wait_for_function('(before)=>!running && game.s.day===before+1',arg=before);page.keyboard.press('Escape')
  page.evaluate("game.s.reports.forEach(r=>{r.read=true;r.resolved=true});navigate('home')")
  page.locator('.topbar [data-action=skip]').click();page.wait_for_function('running && game.s.day>=2');assert page.locator('.topbar [data-action=stop]').is_visible();page.locator('.topbar [data-action=stop]').click();page.wait_for_function('!running');stopped=page.evaluate('game.s.day');page.wait_for_timeout(250);assert page.evaluate('game.s.day')==stopped
  assert page.evaluate('validState(game.s)&&saveOK');assert not errors,errors
  print('PASS controls at 5 widths × 9 screens, sidebar inbox/badge, single day, automatic progress and manual stop')
  browser.close()
finally:server.shutdown();server.server_close();tmp.cleanup()
