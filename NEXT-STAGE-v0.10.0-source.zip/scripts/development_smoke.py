"""Functional regression for weekly training, targets, forecasts and concept UI."""
import functools,http.server,json,os,tempfile,threading
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(os.environ.get('WEB_ROOT',Path(__file__).resolve().parents[1]));temporary=tempfile.TemporaryDirectory(prefix='next-stage-development-');out=Path(os.environ.get('UI_SCREENSHOT_DIR',temporary.name));out.mkdir(parents=True,exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(ROOT)));threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':1440,'height':1050});page.set_default_timeout(15000);errors=[];bad=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('response',lambda r:bad.append((r.status,r.url)) if r.status>=400 else None);page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle')
  result=page.evaluate('''()=>{
    const assert=(ok,message)=>{if(!ok)throw Error(message)};
    const g=new Game();const random=Math.random;Math.random=()=>0.42;try{g.newGame('기능 검증','대표')}finally{Math.random=random}
    g.startCasting('audition','idol','any','career');for(let i=0;i<10;i++)g.nextDay();g.sign(g.s.candidates[0].id,'balanced');
    g.startCasting('audition','idol','any','trainee');for(let i=0;i<10;i++)g.nextDay();g.sign(g.s.candidates.find(c=>DATA.roster[c.id].trainee).id,'balanced');
    let artist=g.s.artists[0],trainee=g.s.trainees[0];
    assert(validState(g.s),'new state');
    artist.energy=100;artist.stress=0;artist.recoveryUntil=0;
    const artistBefore=[...artist.stats],trained=trainee.trainedDays,originalMode=trainee.trainingMode;
    g.setWeeklyPlan(artist.id,Array(7).fill('vocal'));g.setWeeklyPlan(trainee.id,Array(7).fill('rest'));g.nextDay();
    assert(artist.stats[0]+artist.stats[7]>artistBefore[0]+artistBefore[7],'vocal plan increases vocal/cooperation');assert(artist.stats.every((x,i)=>[0,7].includes(i)||x===artistBefore[i]),'vocal plan does not train unrelated abilities');
    assert(trainee.trainedDays===trained,'trainee scheduled rest');assert(trainee.trainingPlan==='rest','rest plan applied');
    const snapshot=JSON.stringify(g.s);try{g.setWeeklyPlan(artist.id,['bad']);}catch{}assert(JSON.stringify(g.s)===snapshot,'invalid plan rollback');
    try{g.setTraining(trainee.id,'bad');}catch{}assert(JSON.stringify(g.s)===snapshot,'invalid training rollback');
    artist=g.ownedTalent(artist.id);trainee=g.ownedTalent(trainee.id);
    g.transaction(()=>g.clearWeeklyPlan(trainee.id));assert(trainee.trainingMode===originalMode,'restore auto mode');
    const mixed=['rest','vocal','performance','creative','balanced','rest','vocal'];g.setWeeklyPlan(trainee.id,mixed);
    for(let i=0;i<7;i++){g.nextDay();assert(trainee.trainingPlan===mixed[DevelopmentWeekday(g.s.day)],'weekday plan ordering');}
    trainee.stats[0]=40;g.setGrowthTarget(trainee.id,0,41);g.setWeeklyPlan(trainee.id,Array(7).fill('vocal'));
    for(let i=0;i<100&&trainee.growthTarget.achievedDay===null;i++)g.nextDay();assert(trainee.growthTarget.achievedDay!==null,'goal achieved');assert(g.s.daySummaries.at(-1).newReports===g.s.reports.filter(r=>r.day===g.s.day).length,'day log includes goal report');
    const reportCount=g.s.reports.filter(r=>r.title==='개인 육성 목표 달성').length;for(let i=0;i<3;i++)g.nextDay();assert(g.s.reports.filter(r=>r.title==='개인 육성 목표 달성').length===reportCount,'goal reports once');
    const restored=new Game(JSON.parse(JSON.stringify(g.s)));assert(validState(restored.s)&&JSON.stringify(restored.s.trainees[0].weeklyPlan)===JSON.stringify(trainee.weeklyPlan),'weekly save roundtrip');
    const corrupt=JSON.parse(JSON.stringify(g.s));corrupt.trainees[0].weeklyPlan[0]='broken';assert(!validState(corrupt),'invalid saved plan rejected');
    const corruptGoal=JSON.parse(JSON.stringify(g.s));corruptGoal.trainees[0].growthTarget.metric=100;assert(!validState(corruptGoal),'invalid saved target rejected');
    const corruptDate=JSON.parse(JSON.stringify(g.s));corruptDate.trainees[0].milestone={kind:'debut',day:-1,completedDay:null};assert(!validState(corruptDate),'invalid saved date rejected');
    const beforeForecast=JSON.stringify(g.s),start=performance.now(),forecast=g.monthlyOperatingForecast(),elapsed=performance.now()-start;
    assert(JSON.stringify(g.s)===beforeForecast,'forecast does not mutate state or RNG');assert(g.monthlyOperatingForecast()===forecast,'forecast cached');
    const sim=new Game(JSON.parse(beforeForecast));let revenue=0,expense=0;const change=sim.change.bind(sim);
    sim.change=(n,label,op=true,meta={})=>{if(op&&!['loan','loan_repayment','rescue'].includes(meta.kind)){if(n>0)revenue+=n;else expense-=n;}return change(n,label,op,meta)};
    for(let i=0;i<30;i++)sim.nextDay({transactional:false});assert(Math.abs(forecast.profit-(revenue-expense))<0.02,'forecast equals separate 30-day ledger');
    // Migration of a real pre-feature schema must preserve finances and abilities.
    const legacy=JSON.parse(beforeForecast);delete legacy.developmentVersion;for(const a of [...legacy.artists,...legacy.trainees,...legacy.departed])for(const k of ['weeklyPlan','weeklyBase','growthTarget','milestone'])delete a[k];
    assert(validState(legacy),'old save accepted');const migrated=new Game(legacy);assert(migrated.s.cash===g.s.cash&&migrated.s.seed===g.s.seed,'old finances and RNG preserved');assert(migrated.s.trainees[0].weeklyPlan===null&&validState(migrated.s),'old save upgraded');
    // A fresh fixture for countdown and financial exclusions.
    const h=new Game(JSON.parse(beforeForecast));let t=h.s.trainees[0];
    try{h.setMilestone(t.id,'debut',Math.max(h.s.day,t.signed+89));assert(h.s.day>t.signed+89,'too early date rejected')}catch(e){assert(!t.milestone,'no invalid milestone')}
    t=h.ownedTalent(t.id);h.setMilestone(t.id,'debut',Math.max(h.s.day+10,t.signed+90));assert(h.developmentCountdown(t).confirmed===false,'target date is not booking');
    const m=h.s.artists[0];h.startProject(String(m.id),'single','목표 음원',1000,'balanced');h.setMilestone(m.id,'live',h.s.day+1);assert(h.developmentCountdown(m).day===h.s.jobs.at(-1).due&&h.developmentCountdown(m).confirmed,'confirmed job overrides aspiration');
    const cashGame=new Game();cashGame.newGame('손익 검증','대표');const noLoan=cashGame.monthlyOperatingForecast();cashGame.borrow(1000);const withLoan=cashGame.monthlyOperatingForecast();
    assert(noLoan.profit===-cashGame.fixed,'no-artist operating loss equals fixed cost');assert(withLoan.profit===noLoan.profit,'loan interest and principal excluded from operating profit');assert(withLoan.cashChange<noLoan.cashChange,'cash change includes loan repayment');
    h.setWeeklyPlan(t.id,Array(7).fill('rest'));t.stats=Array(8).fill(65);while(h.s.day-t.signed<90)h.nextDay();h.debut(t.id,'balanced');assert(h.ownedTalent(t.id).milestone.completedDay===h.s.day,'debut goal completed on actual debut');
    assert(forecast.revenue>=0&&forecast.expense>=0&&Number.isFinite(forecast.cashChange),'finite forecast components');
    game=new Game(JSON.parse(beforeForecast));save();navigate('home');
    return {checks:'weekly, goals, migration, invalid data, countdown, forecast',forecastMs:Math.round(elapsed),artistId:artist.id,traineeId:trainee.id};
  }''');print('PASS model',json.dumps(result))
  # Actual form submissions and navigating to the dedicated screen.
  page.locator('.concept-person').first.click();assert page.locator('.development-page').is_visible();assert not page.locator('[role=dialog]').count()
  page.locator('#development-person').select_option(str(result['traineeId']))
  for day in range(7):page.locator(f'input[name="plan-{day}"][value="rest"]').check()
  page.locator('#weekly-plan-form button[type=submit]').click();assert page.evaluate('game.s.trainees[0].weeklyPlan.every(x=>x==="rest")')
  page.locator('.personal-goal .target-editor summary').click()
  page.locator('#goal-metric').select_option('0');page.locator('#goal-target').fill('50');page.locator('#personal-goal-form button').click();assert page.evaluate('game.s.trainees[0].growthTarget.target===50')
  page.locator('.personal-countdown .target-editor summary').click();date=page.evaluate('new Date(Date.UTC(2027,0,1+Math.max(game.s.day+14,game.s.trainees[0].signed+90))).toISOString().slice(0,10)');page.locator('#milestone-date').fill(date);page.locator('#milestone-form button').click();assert page.evaluate('game.s.trainees[0].milestone!==null')
  page.reload(wait_until='networkidle');page.locator('[data-action=continue]').click();page.wait_for_function('game.s && document.querySelector(".main")')
  assert page.evaluate('game.s.trainees[0].weeklyPlan.every(x=>x==="rest") && game.s.trainees[0].growthTarget.target===50 && game.s.trainees[0].milestone.kind==="debut"')
  page.evaluate('(id)=>openDevelopment(id)',result['traineeId'])
  print('PASS persisted weekly plan, personal target and milestone after reload')
  for width in [1440,1024,768,390,360]:
   page.set_viewport_size({'width':width,'height':1000 if width>600 else 844})
   for menu in ['home','development','artists','training','casting','projects','finance','schedule','inbox','company','charts','goals','staff']:
    page.evaluate('(p)=>navigate(p)',menu);assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),(width,menu)
   for menu in ['home','development']:
    page.evaluate('(p)=>navigate(p)',menu)
    if menu=='development':
     img=page.locator('.development-portrait img');assert img.evaluate('(img)=>getComputedStyle(img).objectFit')=='contain';assert img.evaluate('(img)=>img.naturalWidth>0')
    if width in [1440,390]:page.wait_for_timeout(150);page.screenshot(path=str(out/f'{menu}-{width}.png'),full_page=True)
  page.evaluate("navigate('home')");page.locator('[data-action=m-month-forecast]').first.click();assert page.locator('[role=dialog]').is_visible();page.keyboard.press('Escape')
  assert not errors,errors;assert not bad,bad;assert page.evaluate('validState(game.s)&&saveOK')
  print('PASS UI forms, 13 screens at 5 widths, full portrait, forecast dialog, no HTTP/JS errors')
  browser.close()
finally:server.shutdown();server.server_close();temporary.cleanup()
