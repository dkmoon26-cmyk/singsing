/* Validate optional activity metadata without rejecting old saves. */
(function(root){
  'use strict';
  const base=root.validState,D=root.ActivityData,has=(map,key)=>Object.hasOwn(map,key);
  root.validState=function(s){
    if(!base(s))return false;
    try{
      const metadata=(x,kind)=>{
        if(x.albumType!==undefined&&(!has(D.albums,x.albumType)||kind!=='single'||x.trackCount!==D.albums[x.albumType].tracks))return false;
        if(x.trackCount!==undefined&&x.albumType===undefined)return false;
        if(x.venue!==undefined&&(!has(D.venues,x.venue)||kind!=='live'))return false;
        if(x.contentType!==undefined&&(!has(D.content,x.contentType)||kind!=='cover'))return false;
        return true;
      };
      return s.jobs.every(j=>metadata(j,j.kind)&&(j.kind!=='single'||j.albumType||j.budget<=7000)&&(j.kind!=='live'||j.venue||j.budget<=1500)&&(!j.albumType||j.budget>=1000*D.albums[j.albumType].factor&&j.budget<=7000*D.albums[j.albumType].factor)&&(!j.venue||j.budget===D.venues[j.venue].cost))&&s.catalog.every(c=>metadata(c,'single'))&&s.outcomes.every(o=>metadata(o,o.kind));
    }catch{return false;}
  };
})(typeof window!=='undefined'?window:globalThis);

;
