/* FILE src/campaign-ui.js */
'use strict';
let inboxView = 'all', inboxCategory = 'all';
function reportBadge(r) {
  const state = game.reportState(r);
  return `<span class="pill report-${state.status}">${esc(state.status==='info'?'일반 보고':state.label)}</span> <span class="read-label">${r.read?'읽음':'● 안 읽음'}</span>${state.expires!==undefined?` <small>기한 ${date(state.expires)}</small>`:''}`;
}
function inbox_campaign() {
  const counts = game.inboxCounts(),
  selected = game.s.reports.find(r => r.id === selectedReport);
  const rows = game.s.reports.filter(r =>(inboxView === 'all' || inboxView === 'unread' && !r.read || inboxView === 'decision' && game.reportState(r).needsDecision) &&(inboxCategory === 'all' || game.reportCategory(r) === inboxCategory)).sort((a, b) => Number(game.reportState(b).needsDecision) - Number(game.reportState(a).needsDecision) || b.day - a.day || b.id - a.id);
  const row = r => btn(`<small>${date(r.day)} · ${reportBadge(r)}</small><strong>${esc(r.title)}</strong>`, 'open-report', `data-id="${r.id}"`, `${r.id===selectedReport?'selected ':''}${!r.read?'unread ':''}${game.reportState(r).needsDecision?'decision-row':''}`);
  const groups = new Map();
  for (const r of rows) {
    const key = game.reportState(r).status === 'info' && !r.important ? r.day: 'r' + r.id;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(r);
  }
  return heading('수신함', `안 읽음 ${counts.unread}건 · 결정 필요 ${counts.decision}건. 읽음 여부와 처리 상태를 별도로 표시합니다.`, btn('일반 보고 모두 읽음', 'read-info', '', 'soft')) + `<div class="tabs">${[['all','전체'],['unread','안 읽음'],['decision','결정 필요']].map(([v,t])=>btn(t,'m-inbox-filter',`data-value="${v}"`,inboxView===v?'active':'')).join('')}</div><div class="tabs section">${[['all','모든 분야'],['training','육성'],['activity','활동'],['finance','재정'],['general','운영']].map(([v,t])=>btn(t,'m-inbox-category',`data-value="${v}"`,inboxCategory===v?'active':'')).join('')}</div><div class="inbox"><section class="panel inbox-list" style="padding:0">${[...groups.values()].map(rs=>rs.length>=3?`<details ${rs.some(r=>r.id===selectedReport)?'open':''}><summary>${date(rs[0].day)} 일반 보고 ${rs.length}건 · 안 읽음 ${rs.filter(r=>!r.read).length}건</summary>${rs.map(row).join('')}</details>`:rs.map(row).join('')).join('')||'<p>조건에 맞는 보고가 없습니다.</p>'}</section><section class="panel inbox-detail">${selected?reportDetail(selected):'<p>보고를 선택하세요.</p>'}</section></div>`;
}
function reportDetail_campaign(r) {
  let body;
  if (r.kind === 'ad') {
    const p = game.adPlan(r.id),
    active = game.reportState(r).needsDecision;
    body = `<h2>${esc(r.title)}</h2><p class="report-content">${esc(r.body)}</p>${active?`<section class="tip"><h3>광고 수락 시 변경</h3><p>촬영 ${p.days}일 · 완료 ${date(p.shootingDay)} · 잔금 입금 ${date(p.paymentDay)}</p><p>계약 총액 ${money(p.pay)} · 선금 40% ${money(p.advance)} · 잔금 60% ${money(p.balance)}. 아티스트 약정 배분을 차감합니다.</p>${p.productions.map(j=>`<p><strong>${esc(j.title)}</strong><br>완료 ${date(j.oldDue)} → ${date(j.newDue)} (+${j.newDue-j.oldDue}일) · 예약 행사 반영<br>제작 잔여 ${j.remaining}일 보존 · 촬영 후 재개</p>`).join('')||'<p>변경되는 제작 일정 없음</p>'}${p.reasons.map(x=>`<p class="negative">${esc(x)}</p>`).join('')}</section><div class="row wrap">${btn('광고 수락','resolve',`data-id="${r.id}" data-choice="accept"`,'primary',!p.allowed)}${btn('제안 거절','resolve',`data-id="${r.id}" data-choice="decline"`)}</div>`:''}`;
  } else body = reportDetail_evolution(['done', 'expired'].includes(game.reportState(r).status) ? { ... r, resolved: true }: r);
  return `<div class="row between">${reportBadge(r)}${btn(r.read?'안 읽음으로 표시':'읽음으로 표시','m-report-unread',`data-id="${r.id}" data-read="${r.read?'false':'true'}"`,'soft small')}</div>` + body;
}
function projects_campaign() {
  return projects_app().replace('동일 아티스트는 한 번에 하나의 프로젝트·광고를 진행할 수 있습니다.', '제작 중 광고를 수락하면 해당 제작을 촬영 기간만큼 중단하고 완료일을 늦춥니다.') + panel('제작 일정 상세', game.s.jobs.filter(j => j.kind === 'single').map(j => {
    const p = game.productionState(j);
    return `<p><strong>${esc(j.name)}</strong> · ${p.paused?game.productionState(j).reason+'으로 중단 · '+date(p.resume)+' 재개':'제작 진행 중'}<br>실제 제작 잔여 ${p.remaining}일 · 누적 연장 ${p.delay}일 · 완료 ${date(j.due)}</p>`;
  }).join('') || '<p>진행 중인 제작 없음</p>');
}
function finance_campaign() {
  const p = game.cashPlan();
  return finance_operations() + panel('향후 30일 자금 계획', `<p>현재 잔액 ${money(game.s.cash)} + 확정 입금 ${money(p.confirmed)} − 예정 지출 ${money(p.scheduled)} − 유지 훈련비 추정 ${money(p.maintenance)}</p><p><strong>보수적 예상 잔액 ${money(p.balance)}</strong></p><p>별도 조건부·예상 입금 ${money(p.conditional)} (예상 잔액에서 제외)</p><small>현재 훈련 방침을 30일 유지하는 추정입니다. 회복·일정·직원·인원 변경에 따라 달라집니다. 신규 승인·확률 사건은 포함하지 않습니다.</small>`);
}
function budgetPreview_campaign() {
  budgetPreview_evolution();
  const key = $('#entity')?.value || game.entities[0]?.key;
  if (!key) return;
  const a = game.activityAvailability(key);
  $('#budget-preview').innerHTML += `<p class="${a.allowed?'positive':'negative'}">${a.allowed?'일정 승인 가능':a.reasons.map(esc).join(' · ')}</p>`;
  const submit = $('#project-form button[type="submit"]');
  if (submit) submit.disabled = !a.allowed;
}
function staffDetail_campaign(id) {
  staffDetail_evolution(id);
  const x = game.staffComparison(id);
  $('#modal-error').insertAdjacentHTML('beforebegin', `<section class="panel"><h3>현재 직원과 비교</h3><p>후보 ${esc(x.candidate.name)} · 지도 ${x.candidate.coaching} · 월급 ${money(x.candidate.salary)}</p><p>${x.current?'현재 최고 '+esc(x.current.name)+' · 지도 '+x.current.coaching+' · 월급 '+money(x.current.salary):'같은 직무의 기존 직원 없음'}</p></section>`);
}
function managementClick_campaign(action, d) {
  if (action === 'm-inbox-filter') inboxView = d.value;
  else if (action === 'm-inbox-category') inboxCategory = d.value;
  else if (action === 'm-report-unread') {
    mutate(() => game.setReportRead(d.id, d.read === 'true'));
    return;
  }
  render();
}


;
