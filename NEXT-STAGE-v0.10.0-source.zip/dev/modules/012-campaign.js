/* FILE src/campaign.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const round = n => Math.round(n * 100) / 100;
    class CampaignGame extends Base {
      upgrade() {
        super.upgrade();
        const s = this.s;
        if (!s || s.campaignVersion === 1) return;
        s.campaignVersion = 1;
        for (const j of s.jobs) if (j.kind === 'single') {
          j.baselineDue = j.due;
          j.delayDays = 0;
          j.pauses = [];
        }
      }
      participantIds(job) {
        return job.snapshot?.ids || this.entity(job.entity)?.members.map(a => a.id) ||[];
      }
      productionState(job) {
        const active =(job.pauses ||[]).find(p => p.start <= this.s.day && p.end > this.s.day);
        return {
          paused: !!active,
          resume: active?.end ?? null,
          remaining: Math.max(0, job.due - this.s.day -(active ? active.end - this.s.day: 0)),
          delay: job.delayDays || 0
        };
      }
      adPlan(id) {
        const r = this.s.reports.find(r => r.id === Number(id)),
        e = r && this.entity(r.entity),
        reasons = [],
        days = D.rules.advertisement.days;
        if (!r || r.kind !== 'ad' || r.resolved || r.expires < this.s.day) reasons.push('이미 처리됐거나 기한이 끝난 제안입니다.');
        if (!e || e.key.startsWith('u') &&(e.status !== 'active' || e.members.length < 2)) reasons.push('현재 활동 가능한 대상이 아닙니다.');
        if (e?.members.some(a => a.recoveryUntil > this.s.day)) reasons.push('활동 후 회복 중입니다.');
        if (e?.members.some(a => a.energy < 25)) reasons.push('촬영을 준비할 체력이 부족합니다.');
        const ids = e?.members.map(a => a.id) ||[],
        linked = this.s.jobs.filter(j => this.participantIds(j).some(id => ids.includes(id))),
        productions = linked.filter(j => j.kind === 'single');
        if (linked.some(j => j.kind !== 'single')) reasons.push('공연·커버·다른 광고와 일정이 겹칩니다.');
        const family = new Set(ids);
        for (const u of this.s.units) if (u.ids.some(id => ids.includes(id))) u.ids.forEach(id => family.add(id));
        for (const j of productions) this.participantIds(j).forEach(id => family.add(id));
        if (this.s.jobs.some(j => j.kind === 'ad' && this.participantIds(j).some(id => family.has(id)))) reasons.push('같은 팀 또는 제작 참여자의 광고가 진행 중입니다.');
        if (productions.some(j => this.productionState(j).paused)) reasons.push('해당 제작은 이미 광고로 중단돼 있습니다.');
        return {
          allowed: reasons.length === 0,
          reasons:[... new Set(reasons)],
          days,
          name: e?.name || '종료된 대상',
          pay: r?.pay || 0,
          advance: round((r?.pay || 0) * .4),
          balance: round((r?.pay || 0) * .6),
          shootingDay: this.s.day + days,
          paymentDay: this.s.day + days + D.rules.advertisement.balanceDays,
          productions: productions.map(j =>({
            id: j.id,
            title: j.name,
            artist: j.snapshot?.name || e?.name || '',
            oldDue: j.due,
            newDue: j.due + days,
            remaining: this.productionState(j).remaining
          }))
        };
      }
      // One extension path for approval and previews; Season adds future reservations.
      pauseProduction(j, pause) {
        if ((j.pauses || []).some(p => p.adId === pause.adId)) return j;
        if (j.baselineDue === undefined) j.baselineDue = j.due;
        const days = pause.end - pause.start;
        j.delayDays = (j.delayDays || 0) + days;
        j.due += days;
        const pauses = (j.pauses || []).concat(pause).sort((a, b) => a.start - b.start);
        if (pauses.slice(0, -60).some(p => p.end > this.s.day)) throw Error('예약된 제작 중단 일정이 너무 많습니다.');
        j.pauses = pauses.slice(-60);
        return j;
      }
      reconcileProduction(j, events = []) { return j; }
      resolve(id, choice) {
        const r = this.s.reports.find(r => r.id === Number(id));
        if (r?.kind !== 'ad') return super.resolve(id, choice);
        return this.transaction(() => {
          if (!r || r.resolved || r.expires < this.s.day) throw Error('현재 처리할 수 있는 광고 제안이 아닙니다.');
          if (choice === 'decline') {
            r.resolved = true;
            r.read = true;
            r.decision = 'decline';
            return;
          }
          if (choice !== 'accept') throw Error('광고 응답을 확인하세요.');
          const plan = this.adPlan(id);
          if (!plan.allowed) throw Error(plan.reasons.join(' '));
          const snapshot = this.snapshot(r.entity),
          shares = this.shares(snapshot),
          adId = this.id();
          this.receive(plan.advance, '광고 계약 선금', shares, r.entity, 'ad_advance');
          this.s.jobs.push({
            id: adId,
            kind: 'ad',
            entity: r.entity,
            name: r.brand + ' 광고 촬영',
            pay: plan.balance,
            start: this.s.day,
            due: plan.shootingDay,
            snapshot,
            shares,
            reportId: r.id,
            interrupts: plan.productions.map(p => p.id)
          });
          for (const p of plan.productions) {
            const j = this.s.jobs.find(j => j.id === p.id);
            this.pauseProduction(j, { adId, start: this.s.day, end: plan.shootingDay });
            this.reconcileProduction(j);
            this.log(j.name + ' · 광고로 제작 중단 ' + plan.days + '일 · 예약 행사 반영 완료일 ' + j.due + '일째');
          }
          r.resolved = true;
          r.read = true;
          r.decision = 'accept';
          this.report('광고 일정 확정', plan.name + ' · 촬영 완료 ' + plan.shootingDay + '일째 / 잔금 ' + plan.paymentDay + '일째.\n' +(plan.productions.length ? plan.productions.map(p => p.title + ': ' + p.oldDue + ' → ' + p.newDue + '일째').join('\n'): '진행 중인 음반 제작의 변경은 없습니다.'), 'info', false, { entity: r.entity });
        });
      }
      finishCampaign(j) {
        super.finishEvolution(j);
        if (j.kind === 'ad' && j.interrupts?.length) {
          const jobs = this.s.jobs.filter(x => j.interrupts.includes(x.id));
          if (jobs.length) this.report('광고 촬영 종료 · 제작 재개', jobs.map(x => x.name + ' · 제작 잔여 ' + this.productionState(x).remaining + '일 / 완료 ' + x.due + '일째').join('\n'), 'info', false);
        }
      }
      reportState(r) {
        if (r.closedReason === 'expired') return { status: 'expired', label: '기한 종료', needsDecision: false };
        if (r.incidentId) {
          const i = this.s.incidents.find(i => i.id === r.incidentId);
          if (i?.state === 'open') return {
            status: 'decision',
            label: '결정 필요',
            needsDecision: true,
            expires: i.expires
          };
          if (i?.state === 'investigating') return { status: 'working', label: '조사 중', needsDecision: false };
          return { status: 'done', label: '처리 완료', needsDecision: false };
        }
        if (r.storyId) {
          const s = this.s.stories.find(s => s.id === r.storyId);
          if (s?.status === 'open') return {
            status: 'decision',
            label: '결정 필요',
            needsDecision: true,
            expires: s.expires
          };
          return { status: s?.status === 'resolved' ? 'done': 'expired', label: s?.status === 'resolved' ? '처리 완료': '기한 종료', needsDecision: false };
        }
        if (r.kind === 'ad') {
          if (r.resolved) return { status: 'done', label: r.decision === 'decline' ? '거절 완료': '처리 완료', needsDecision: false };
          if (r.expires < this.s.day || !this.entity(r.entity)) return { status: 'expired', label: '기한 종료', needsDecision: false };
          return {
            status: 'decision',
            label: '결정 필요',
            needsDecision: true,
            expires: r.expires
          };
        }
        if (r.kind === 'contract') {
          const a = this.artist(r.talentId),
          active = a && a.contract === r.contractDue && a.contract - this.s.day <= 90;
          return active ? {
            status: 'decision',
            label: '재계약 검토',
            needsDecision: true,
            expires: a.contract
          }
          : { status: 'done', label: '확인 종료', needsDecision: false };
        }
        if (r.resolved) return { status: 'done', label: '처리 완료', needsDecision: false };
        if (r.kind === 'event' && this.entity(r.entity) || r.kind === 'crisis' && this.s.cash < 0) return { status: 'decision', label: '결정 필요', needsDecision: true };
        return { status: 'info', label: r.read ? '읽음': '안 읽음', needsDecision: false };
      }
      setReportRead(id, read) {
        const r = this.s.reports.find(r => r.id === Number(id));
        if (!r) throw Error('보고가 없습니다.');
        r.read = !!read;
      }
      markGeneralRead() {
        for (const r of this.s.reports) if (!this.reportState(r).needsDecision) r.read = true;
      }
      inboxCounts() {
        return { unread: this.s.reports.filter(r => !r.read).length, decision: this.s.reports.filter(r => this.reportState(r).needsDecision).length };
      }
      reportCategory(r) {
        return r.storyId || r.kind === 'event' || r.title === '육성 담당 주간 보고' ? 'training': r.kind === 'result' || r.kind === 'ad' ? 'activity':['finance', 'crisis'].includes(r.kind) || r.goalRewardIds ? 'finance': 'general';
      }
      get pending() {
        const base = super.pending.filter(r => !['done', 'expired', 'working'].includes(this.reportState(r).status));
        for (const r of this.s.reports) if (this.reportState(r).needsDecision && r.kind !== 'contract' && !base.includes(r)) base.push(r);
        return base;
      }
      activityAvailability(key) {
        const e = this.entity(key);
        if (!e) return { allowed: false, reasons:['활동 대상 없음'] };
        const reasons = [];
        if (e.key.startsWith('u') &&(e.status !== 'active' || e.members.length < 2)) reasons.push('팀 활동 중단·멤버 부족');
        const jobs = this.s.jobs.filter(j => this.participantIds(j).some(id => e.members.some(a => a.id === id)));
        for (const j of jobs) reasons.push((j.kind === 'single' ? '음반 제작': j.kind === 'ad' ? '광고 촬영': j.kind === 'live' ? '공연': '커버') + ' 일정 ' + Math.max(0, j.due - this.s.day) + '일 남음');
        const recovery = Math.max(0, ... e.members.map(a => a.recoveryUntil - this.s.day));
        if (recovery) reasons.push('회복 ' + recovery + '일 남음');
        if (e.members.some(a => a.energy < 25)) reasons.push('체력 부족');
        return { allowed: reasons.length === 0, reasons };
      }
      cashPlan(days = 30) {
        const end = this.s.day + days,
        entries = this.cashForecast().filter(x => x.day <= end),
        confirmed = entries.filter(x => x.amount > 0 && x.type === '입금 확정').reduce((n, x) => n + x.amount, 0),
        conditional = entries.filter(x => x.amount > 0 && x.type !== '입금 확정').reduce((n, x) => n + x.amount, 0),
        scheduled = - entries.filter(x => x.amount < 0).reduce((n, x) => n + x.amount, 0);
        let daily = 0;
        for (const a of this.s.artists) if (a.focus !== 'rest') daily += this.has('trainer') ? 7: 10;
        for (const a of this.s.trainees) {
          const plan = Base.trainingPlans[a.trainingPlan];
          daily += plan.cost *(this.coach(a.trainingPlan).staff ? .8: 1);
        }
        const maintenance = round(daily * days);
        return {
          days,
          entries,
          confirmed: round(confirmed),
          conditional: round(conditional),
          scheduled: round(scheduled),
          maintenance,
          balance: round(this.s.cash + confirmed - scheduled - maintenance)
        };
      }
      staffComparison(id) {
        const p = D.staff.find(p => p.id === id);
        if (!p) throw Error('직원이 없습니다.');
        const current = this.s.staff.map(id => D.staff.find(p => p.id === id)).filter(x => x.kind === p.kind && x.id !== id).sort((a, b) => b.coaching - a.coaching)[0] || null;
        return { candidate: p, current };
      }
      teamImpact(key) {
        const u = this.s.units.find(u => u.key === key);
        if (!u) throw Error('팀이 없습니다.');
        return {
          name: u.name,
          jobs: this.s.jobs.filter(j => j.entity === key).map(j =>({ name: j.name, due: j.due })),
          catalog: this.s.catalog.filter(c => c.entity === key).length,
          cohesion: u.cohesion || 0
        };
      }
    }
    return CampaignGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installCampaign = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
