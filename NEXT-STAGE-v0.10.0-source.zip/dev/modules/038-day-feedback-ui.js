/* FILE src/day-feedback-ui.js */
'use strict';
function progressSummaryContent() {
  const s = game.s;
  if (!s) return '';
  const notice = lastAdvanceNotice;
  let rows = notice ? s.daySummaries.filter(d => d.day > notice.from && d.day <= notice.to): s.daySummaries.slice(- 1);
  if (!rows.length && !running) return '';
  const from = notice?.from ?? rows[0]?.fromDay ?? s.day,
  to = notice?.to ?? rows.at(- 1)?.day ?? s.day,
  elapsed = to - from;
  const sum = rows.reduce((a, d) =>({
    cash: a.cash + d.cashChange,
    streams: a.streams + d.streams,
    sales: a.sales + d.sales,
    training: a.training + d.trainingCount,
    fans: a.fans + d.fansChange,
    teamFans: a.teamFans + d.teamFansChange,
    completed: a.completed + d.completed.length + festivalCount(d),
    reports: a.reports + d.newReports
  }), {
    cash: 0,
    streams: 0,
    sales: 0,
    training: 0,
    fans: 0,
    teamFans: 0,
    completed: 0,
    reports: 0
  });
  const fresh = notice?.at && Date.now() - notice.at < 1800;
  const label = running ?(notice?.mode === 'skip' ? '중요 일정까지 진행 중…': '하루 진행 중…'): notice?.stop ||(elapsed === 1 ? '최근 하루 진행 기록': '최근 진행 기록');
  return `<section class="panel progress-summary ${running?'is-running':fresh?'is-new':''}" role="status" aria-live="polite"><div class="row between wrap"><div><strong>${esc(label)}</strong><p><span class="progress-date">${date(from)} → ${date(to)}</span> · ${elapsed}일 경과</p></div></div>${rows.length?`<p>훈련 ${sum.training}건 · 스트리밍 ${sum.streams.toLocaleString()}회 · 음반 ${sum.sales.toLocaleString()}장 · 일정 완료 ${sum.completed}건</p><p>현금 ${sum.cash>=0?'+':''}${money(sum.cash)} · 개인 팬 ${sum.fans>=0?'+':''}${sum.fans.toLocaleString()}명 · 팀 팬 ${sum.teamFans>=0?'+':''}${sum.teamFans.toLocaleString()}명</p>${!sum.completed&&!sum.reports?'<small>훈련과 성과 집계를 마쳤습니다. 새로운 주요 일정·보고는 없습니다.</small>':''}${sum.reports?`<small>새 보고 ${sum.reports}건 · </small>${btn('소식함 확인','nav','data-page="inbox"','link small')}`:''}`:'<p>날짜와 훈련·정산 결과를 계산하고 있습니다.</p>'}</section>`;
}
function progressSummaryCard() {
  return running ? progressSummaryContent(): '';
}
const feedbackManagementClick = managementClick_market, feedbackApplyRestore = applyRestore_progression;
function managementClick_dayfeedback(action, d) {
  return feedbackManagementClick(action, d);
};
function applyRestore_dayfeedback() {
  feedbackApplyRestore();
  lastAdvanceNotice = null;
  selectedReport = null;
  render();
};


;
