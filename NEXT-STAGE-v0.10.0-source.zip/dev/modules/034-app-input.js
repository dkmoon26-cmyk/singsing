/* FILE src/app-input.js */
'use strict';
// Form submission, field changes, backup import and keyboard accessibility.
$('#modal-root').addEventListener('submit', ev => {
  ev.preventDefault();
  let f = ev.target,
  data = new FormData(f);
  try {
    switch (f.getAttribute('id')) {
      case 'new-form': {
        let company = data.get('company').trim(),
        boss = data.get('boss').trim();
        if (!company || !boss) throw Error('회사 이름과 사장 이름을 입력하세요.');
        checkSaveSession();
        let previous = game.s || loadSaved();
        if (previous && validState(previous)) saveStore.checkpoint(previous, '새 회사 설립 전');
        game = new Game();
        game.newGame(company, boss);
        page = 'home';
        mutate(() => {
        }, '새로운 이야기가 시작됩니다.');
        showReport(game.s.reports[0].id, true);
        break;
      }
      case 'casting-form': mutate(() => game.startCasting(data.get('method'), data.get('type'), data.get('position'), data.get('experience') || 'any'), '모집을 시작했습니다. 날짜를 진행해 주세요.');
      break;
      case 'project-form': mutate(() => game.startProject(data.get('entity'), data.get('kind'), data.get('title'), data.get('budget'), data.get('concept'), { format: data.get('kind') === 'single' ?(data.get('format') || 'digital'): 'digital', quantity: Number(data.get('quantity') || 0), promotion: data.get('kind') === 'single' ?(data.get('promotion') || 'none'): 'none' }), '프로젝트를 승인했습니다.');
      break;
      case 'unit-form': mutate(() => game.formUnit(data.get('name'), data.getAll('members')), '새로운 팀을 결성했습니다.');
      break;
      case 'loan-form': mutate(() => game.borrow(data.get('amount')), '운영자금 대출이 실행되었습니다.');
      break;
    }
  } catch (e) {
    $('#modal-error').textContent = e.message;
  }
});

UIEvents.onChange('app', ev => {
  try {
    if (ev.target.dataset.focus) {
      game.setFocus(+ ev.target.dataset.focus, ev.target.value);
      save();
      render();
      toast('육성 방향을 변경했습니다.');
    }
    if (ev.target.id === 'policy') {
      game.s.policy = ev.target.value;
      save();
      toast('회사 운영 방침을 변경했습니다.');
    }
    if (ev.target.id === 'project-kind') {
      let k = ev.target.value,
      options = Object.fromEntries(Object.entries(DATA.rules.activity).map(([key, rule]) =>[key, rule.budgets]));
      $('#budget').innerHTML = options[k].map(([n, l]) => `<option value="${n}">${l} · ${money(n)}</option>`).join('');
      budgetPreview();
    }
    if (ev.target.id === 'budget') budgetPreview();
    if (ev.target.id === 'import-save') {
      let file = ev.target.files[0];
      if (!file) return;
      if (file.size > 20000000) throw Error('백업 파일이 너무 큽니다.');
      file.text().then(raw => {
        try {
          let s = JSON.parse(raw);
          if (!validState(s)) throw Error('지원하지 않거나 손상된 저장 파일입니다.');
          modal('백업 불러오기 확인', `<p><strong>${esc(s.company)}</strong> · ${date(s.day,true)}<br>현재 자동 저장을 이 백업으로 교체합니다.</p><div class="modal-actions">${btn('불러오기','confirm-import','','primary')}</div>`);
          let b = $('[data-action="confirm-import"]');
          b.addEventListener('click', () => {
            try {
              let previous = game.s || loadSaved();
              if (previous && validState(previous)) saveStore.checkpoint(previous, '백업 불러오기 전');
              s = new Game(s).s;
              saveStore.writeAuto(s);
            } catch {
              toast('백업을 저장할 수 없습니다. 기존 진행을 유지합니다.');
              return;
            }
            game = new Game(s);
            saveOK = true;
            page = 'home';
            close();
            render();
            toast('백업을 불러왔습니다.');
          });
        } catch (e) {
          toast(e.message);
        }
      }).catch(() => toast('백업 파일을 읽지 못했습니다. 기존 진행을 유지합니다.'));
    }
  } catch (e) {
    toast(e.message);
  }
});

document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && !running) close();
  if (e.key === 'Tab' && $('#modal-root').children.length) {
    let items = [... $('#modal-root').querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled)')].filter(x => x.getClientRects().length);
    if (!items.length) return;
    let first = items[0],
    last = items[items.length - 1];
    if (e.shiftKey &&(document.activeElement === first || !$('#modal-root').contains(document.activeElement))) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey &&(document.activeElement === last || !$('#modal-root').contains(document.activeElement))) {
      e.preventDefault();
      first.focus();
    }
  }
});


;
