/* Album packages, ticketed venues and artist content. Legacy job kinds stay compatible. */
(function(root){
  'use strict';
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,n)),round=n=>Math.round(n*100)/100;
  const albums={digital:{label:'디지털 싱글',tracks:1,days:21,factor:1,reach:1,tail:1},mini:{label:'미니앨범',tracks:5,days:35,factor:1.8,reach:1.15,tail:1.3},album:{label:'정규앨범',tracks:10,days:49,factor:2.8,reach:1.3,tail:1.6}};
  const venues={small:{label:'소공연장',capacity:300,cost:300,ticket:6,variable:.8,days:7},hall:{label:'콘서트홀',capacity:1500,cost:1500,ticket:8,variable:1.2,days:14},large:{label:'대형 콘서트장',capacity:5000,cost:6000,ticket:10,variable:1.8,days:21},arena:{label:'아레나',capacity:20000,cost:24000,ticket:12,variable:2.5,days:35}};
  const content={cover:{label:'커버 영상',days:5,fans:1,attention:1,desc:'새로운 팬 유입과 다음 발매에 대한 관심을 모읍니다.'},practice:{label:'연습 영상',days:4,fans:.7,attention:.7,desc:'댄스·합주·랩 연습을 공개해 실력과 준비 과정을 전합니다.'},daily:{label:'일상·소통 콘텐츠',days:3,fans:.5,attention:.4,desc:'팬과 소통하고 아티스트의 신뢰와 긴장을 돌봅니다.'}};
  for(const group of [albums,venues,content]){Object.values(group).forEach(Object.freeze);Object.freeze(group);}
  root.ActivityData=Object.freeze({albums,venues,content});
  class ActivityGame extends root.Game{
    activityPlan(key,kind,budget,options={}){
      if(!options||typeof options!=='object')throw Error('활동 설정을 확인하세요.');
      const album=Object.hasOwn(albums,options.albumType)?albums[options.albumType]:null,venue=Object.hasOwn(venues,options.venue)?venues[options.venue]:null,clip=Object.hasOwn(content,options.contentType)?content[options.contentType]:null;
      if(!['single','live','cover'].includes(kind)||options.albumType&&!album||options.venue&&!venue||options.contentType&&!clip||album&&kind!=='single'||venue&&kind!=='live'||clip&&kind!=='cover')throw Error('활동 종류와 세부 설정을 확인하세요.');
      if(album===albums.digital&&options.format==='physical')throw Error('디지털 싱글은 음원 전용입니다.');
      const b=Number(budget),factor=album?.factor||1;
      if(!Number.isFinite(b)||kind==='single'&&(b<1000||b>7000)||kind==='cover'&&(b<100||b>600)||kind==='live'&&!venue&&(b<300||b>1500))throw Error('예산 범위를 확인하세요.');
      const production=venue?venue.cost:round(b*factor),q=this.projectQuote(key,kind,production,options),e=this.entity(key);
      if(!e)throw Error('활동할 아티스트·팀을 선택하세요.');
      const duration=album?.days||venue?.days||clip?.days||({single:21,live:7,cover:5}[kind]),promotion=kind==='single'?root.DATA.promotionPlans[options.promotion||'none']:null;
      const days=duration+(promotion?.days||0),availability=this.projectAvailability(key,kind),reasons=[...availability.reasons];
      if(kind!=='single'&&this.reservationOverlaps(e.members.map(a=>a.id),this.s.day,this.s.day+duration+3)&&!reasons.some(x=>x.includes('행사')))reasons.push('확정 행사 준비·출연·회복 기간과 겹칩니다.');
      let due=this.s.day+days;
      if(kind==='single')due=this.reconcileProduction({kind,entity:key,start:this.s.day,due,snapshot:this.snapshot(key)}).due;
      return{kind,production,quote:q,duration,days,due,allowed:reasons.length===0,reasons};
    }
    startProject(key,kind,title,budget,concept,options={}){
      return this.transaction(()=>{
        const p=this.activityPlan(key,kind,budget,options);
        if(!p.allowed)throw Error(p.reasons.join(' · '));
        super.startProject(key,kind,title,p.production,concept,options);
        const j=this.s.jobs.at(-1);
        if(options.albumType){
          j.albumType=options.albumType;j.trackCount=albums[j.albumType].tracks;
          // Rebuild reservation delays for the full package, including reservations crossed by an extension.
          const promoDays=j.due-j.start-21-(j.delayDays||0);
          j.due=j.start+albums[j.albumType].days+promoDays;
          delete j.baselineDue;delete j.delayDays;delete j.pauses;this.reconcileProduction(j);
        }
        if(options.venue){j.venue=options.venue;j.due=j.start+venues[j.venue].days;}
        if(options.contentType){j.contentType=options.contentType;j.due=j.start+content[j.contentType].days;}
        return j;
      });
    }
    contentEffect(e,type){
      const ids=e.members.map(a=>a.id),repeats=this.s.outcomes.filter(o=>o.kind==='cover'&&(o.contentType||'cover')===type&&o.day>this.s.day-30&&o.ids.some(id=>ids.includes(id))).length;
      return{repeats,multiplier:1/(1+repeats*.45)};
    }
    newFans(e,j,quality,fan){
      const n=super.newFans(e,j,quality,fan);
      if(!j.contentType)return n;
      const effect=this.contentEffect(e,j.contentType);j.contentRepeat=effect.repeats;
      this._fanGain=Math.floor(n*content[j.contentType].fans*effect.multiplier);
      return this._fanGain;
    }
    venueResult(e,j,quality){
      const v=venues[j.venue],ids=e.members.map(a=>a.id),u=this.s.units.find(u=>u.key===e.key),fans=e.members.reduce((n,a)=>n+a.fans,0),recent=this.s.performance.filter(p=>p.kind==='live'&&p.day>this.s.day-30&&p.ids.some(id=>ids.includes(id))).length;
      const release=this.s.catalog.filter(c=>c.market.ids.some(id=>ids.includes(id))).at(-1),fresh=release&&this.s.day-release.market.startDay<=45?1.08:1;
      const demand=(quality*(e.members.length>1?2.4:1.5)+fans*.22+(u?.fans||0)*.30)*(8/v.ticket)*this.imageFactor()*(1+this.staffPower('live')*.2)*(1+(u?.cohesion||0)*.0015)*fresh*(j.freeLivePromotion?1.08:1)/(1+recent*.32);
      const attendance=clamp(Math.floor(demand),0,v.capacity);
      return{name:v.label,capacity:v.capacity,ticket:v.ticket,attendance,gross:round(attendance*v.ticket),variable:round(attendance*v.variable),recent};
    }
    concert(e,j,quality){
      if(!j.venue)return super.concert(e,j,quality);
      const result=this.venueResult(e,j,quality);j.concert=result;
      j.factors=j.factors||[];
      const factor=result.name+' · '+result.attendance.toLocaleString()+'/'+result.capacity.toLocaleString()+'석 · 최근 30일 공연 '+result.recent+'회';
      if(!j.factors.includes(factor))j.factors.unshift(factor);
      return result;
    }
    concertPreview(key,venue){
      if(!venues[venue])throw Error('공연장을 선택하세요.');
      const e=this.entity(key);if(!e)throw Error('공연할 아티스트·팀을 선택하세요.');
      const v=venues[venue],j={venue,freeLivePromotion:this.s.perks.livePromo>0},low=this.venueResult(e,j,40),high=this.venueResult(e,j,85),share=this.shares(this.snapshot(key)).reduce((n,x)=>n+x.rate,0),q=this.projectQuote(key,'live',v.cost),margin=v.ticket*(1-share)-v.variable;
      const estimate=r=>({attendance:r.attendance,gross:r.gross,payout:round(r.gross*share),variable:r.variable,totalCost:round(q.total+r.gross*share+r.variable),net:round(r.gross*(1-share)-r.variable-q.total)});
      return{venue,capacity:v.capacity,days:v.days,cost:q.total,ticket:v.ticket,low:estimate(low),high:estimate(high),breakEven:margin>0?Math.ceil(q.total/margin):null};
    }
    finish(j){
      const e=j.kind==='casting'?null:this.projectEntity(j),count=this.s.catalog.length,attention=e?.members.map(a=>this.coverAttention(a))||[],effect=e&&j.contentType?this.contentEffect(e,j.contentType):null;
      super.finish(j);
      const outcome=this.s.outcomes.find(o=>o.day===this.s.day&&o.title===j.name&&o.entity===j.entity);
      if(j.albumType&&this.s.catalog.length>count){const c=this.s.catalog[count];c.albumType=j.albumType;c.trackCount=j.trackCount;if(c.market.format==='physical')c.market.price=j.albumType==='album'?3.5:j.albumType==='mini'?3:2.5;}
      for(const field of ['albumType','trackCount','venue','contentType'])if(j[field]!==undefined&&outcome)outcome[field]=j[field];
      if(effect){
        e.members.forEach((a,i)=>{const gain=Math.max(0,this.coverAttention(a)-attention[i]);a.coverAttention=clamp(attention[i]+gain*content[j.contentType].attention*effect.multiplier,0,.16);a.coverAttentionDay=this.s.day;if(j.contentType==='daily'){a.trust=clamp(a.trust+2*effect.multiplier,0,100);a.stress=clamp(a.stress-3*effect.multiplier,0,100);}});
        if(outcome)outcome.factors=['최근 30일 같은 콘텐츠 '+effect.repeats+'회 · 추가 효과 '+Math.round(effect.multiplier*100)+'%',...(outcome.factors||[])].slice(0,3);
      }
    }
  }
  root.Game=ActivityGame;
})(typeof window!=='undefined'?window:globalThis);

;
