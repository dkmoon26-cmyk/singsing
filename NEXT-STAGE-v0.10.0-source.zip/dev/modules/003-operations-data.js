/* FILE src/operations-data.js */
(function(root) {
  'use strict';
  const D = typeof module !== 'undefined' ? require('./data.js'): root.DATA;
  const careers = [['한울', 'band', 28, '보컬', '인디 무대에서 8년간 노래했습니다. 음색과 라이브에는 자신 있지만 넓은 관객을 만나고 싶습니다.', [78, 35, 32, 65, 72, 80, 40, 75], 650, 9], ['도희', 'band', 26, '기타', '소규모 클럽에서 기타를 연주해 왔습니다. 해산한 밴드의 경험을 새 음악으로 이어가려 합니다.', [58, 30, 35, 83, 77, 68, 33, 72], 380, 6], ['문호', 'band', 30, '베이스', '투어 세션과 밴드 활동을 병행했습니다. 안정적인 합주와 오래가는 팀을 원합니다.', [50, 35, 28, 85, 61, 72, 38, 87], 500, 7], ['빛나', 'band', 27, '드럼', '공연 경험이 많은 드러머입니다. 작은 팬 커뮤니티가 새로운 활동을 기다리고 있습니다.', [48, 30, 46, 82, 62, 83, 45, 79], 750, 8], ['서린', 'idol', 25, '보컬·퍼포먼스', '활동을 마친 그룹의 리드보컬 출신입니다. 남은 팬들과 차분한 재출발을 준비합니다.', [80, 42, 76, 33, 50, 83, 72, 70], 1600, 18], ['태겸', 'idol', 29, '보컬·퍼포먼스', '그룹 해체 후 오랜 공백을 보냈습니다. 무대 감각은 좋지만 컨디션 회복이 필요합니다.', [67, 68, 84, 30, 52, 85, 65, 64], 900, 13], ['예원', 'idol', 28, '보컬·퍼포먼스', '짧았던 아이돌 활동 이후 보컬과 작곡을 다시 공부했습니다. 자신만의 방향을 찾고 있습니다.', [76, 40, 65, 42, 74, 72, 68, 73], 1100, 15], ['준혁', 'idol', 31, '보컬·퍼포먼스', '팀의 리더로 활동했습니다. 방송 경험과 팀 조율 능력을 새 팀에서도 살리고 싶어 합니다.', [72, 63, 78, 35, 60, 81, 80, 85], 1300, 17], ['예슬', 'idol', 32, '보컬·퍼포먼스', '두 장의 음반이 큰 성과를 내지는 못했지만 꾸준히 찾아 듣는 팬들이 있습니다.', [85, 32, 45, 50, 74, 75, 48, 66], 500, 7], ['건호', 'band', 34, '보컬', '음반 흥행은 부진했지만 공연으로 활동을 이어온 싱어송라이터입니다.', [83, 38, 30, 76, 85, 78, 40, 73], 850, 10], ['소연', 'idol', 30, '보컬·퍼포먼스', '전 소속사와 계약 종료 후 보컬 트레이닝을 하며 신곡을 준비해 왔습니다.', [82, 40, 62, 40, 66, 77, 61, 78], 400, 6], ['현준', 'rap', 27, '래퍼', '첫 음반 이후 주목도가 줄었지만 작사와 작은 공연을 멈추지 않은 래퍼입니다.', [55, 85, 50, 32, 83, 78, 55, 70], 700, 9]];
  careers.forEach((v, i) => {
    const id = 60 + i;
    D.roster.push({
      id,
      name: v[0],
      type: v[1],
      age: v[2],
      position: v[3],
      story: v[4],
      stats: v[5],
      image: nextStagePortraitUrl(`assets/portraits/artist-${id}-anime-v1.webp`),
      style: D.roster[v[1] === 'band' ? 1: v[1] === 'rap' ? 2: 0].style,
      traits:['무대 경험', '재출발', '자기 음악'][i % 3],
      trainee: false,
      available: 0,
      career: i < 4 ? '인디 출신': i < 8 ? '전직 아이돌': '솔로 재도전',
      priorFans: v[6],
      priorFame: v[7],
      personality: { ... D.roster[(i * 5) % 60].personality, intro: v[4] }
    });
  });
  const kinds = ['manager', 'casting', 'trainer', 'producer', 'promo', 'ads', 'live'];
  const extraNames = ['박도영', '이현서', '최지민', '정수현', '한도경', '문지수', '김하준', '이서하', '권민서', '백서율', '오윤서', '신도하', '조은우', '임지완', '송예진', '고서희', '남지훈', '유하늘', '장수호', '신유정', '강태윤', '차예빈', '윤세아'];
  D.staff.forEach(p => {
    p.kind = p.id;
    p.specialty = p.id === 'trainer' ? 'balanced': 'general';
    p.coaching = p.stats[0];
    p.expertise = p.stats[1];
    p.care = p.stats[4];
  });
  let serial = 0;
  for (const kind of kinds) {
    const count = kind === 'trainer' ? 6: kind === 'live' ? 2: 3;
    for (let i = 0; i < count; i++) {
      const template = D.staff.find(p => p.id === kind),
      level = i % 3,
      skill = 40 + level * 20 +(serial * 7) % 15;
      D.staff.push({
        id: kind + '-' +(i + 1),
        kind,
        name: extraNames[serial],
        role: template.role,
        level: 1,
        salary: Math.round(130 + skill * 2.6 +(kind === 'trainer' ? i * 15: 0)),
        fee: Math.round(80 + skill * 1.3),
        spec: template.spec,
        stats:[skill, 45 +(serial * 9) % 50, 40 +(serial * 11) % 50, 45 +(serial * 7) % 50, 45 +(serial * 13) % 50],
        coaching: skill,
        expertise: 50 +(serial * 11) % 50,
        care: 45 +(serial * 13) % 50,
        specialty: kind === 'trainer' ?['vocal', 'performance', 'creative', 'balanced', 'vocal', 'performance'][i]: 'general'
      });
      serial++;
    }
  }
  D.staffKinds = {
    manager: '매니저',
    casting: '캐스팅',
    trainer: '육성',
    producer: '음악 제작',
    promo: '홍보',
    ads: '광고 영업',
    live: '공연'
  };
  D.promotionPlans = { none: {
    name: '기본 발매',
    cost: 0,
    days: 0,
    boost: 0
  }, teaser: {
    name: '티저 캠페인',
    cost: 200,
    days: 2,
    boost: .08
  }, session: {
    name: '라이브 영상',
    cost: 400,
    days: 4,
    boost: .14
  }
  };
  if (typeof module !== 'undefined') module.exports = D;
})(typeof window !== 'undefined' ? window: globalThis);


;
