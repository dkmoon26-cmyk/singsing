/* FILE src/season-state.js */
(function(root) {
  'use strict';
  function valid(s, D) {
    try {
      const int =(v, a = 0, b = 1e12) => Number.isSafeInteger(v) && v >= a && v <= b,
      num =(v, a = 0, b = 1e14) => Number.isFinite(v) && v >= a && v <= b,
      text =(v, n = 120) => typeof v === 'string' && v.length <= n,
      arr =(v, n) => Array.isArray(v) && v.length <= n,
      unique = a => new Set(a).size === a.length,
      obj = x => x && typeof x === 'object' && !Array.isArray(x),
      ids = x => arr(x, 5) && unique(x) && x.every(v => int(v, 0, D.roster.length - 1)),
      key = x => typeof x === 'string' && /^(u[1-9]\d*|0|[1-9]\d*)$/.test(x),
      kinds = ['campus', 'summer', 'genre'];
      if (s.seasonVersion !== 1 || !int(s.seasonSince, 0, s.day) || s.seasonYear !== new Date(Date.UTC(2027, 0, 1 + s.day)).getUTCFullYear() || !obj(s.debutYears) || !Object.entries(s.debutYears).every(([k, v]) => /^\d+$/.test(k) && int(+ k, 0, D.roster.length - 1) && int(v, 1900, 10000))) return false;
      if (!arr(s.festivalOffers, 60) || !arr(s.engagements, 72) || !arr(s.festivalHistory, 100) || !arr(s.external, 220) || !arr(s.awardHistory, 10) || !obj(s.yearStats) || Object.keys(s.yearStats).length > 6000) return false;
      const people = [... s.artists, ... s.departed],
      snapshot = x => obj(x) && key(x.key) && text(x.name, 30) &&['idol', 'band', 'rap'].includes(x.type) && ids(x.ids) && x.ids.length > 0 && x.ids.every(id => people.some(a => a.id === id)),
      shares = x => arr(x, 5) && unique(x.map(v => v.id)) && x.every(v => int(v.id, 0, D.roster.length - 1) && num(v.rate, 0, 1)) && x.reduce((n, v) => n + v.rate, 0) <= 1.000001;
      if (!s.festivalOffers.every(o => int(o.id, 1, s.serial) && kinds.includes(o.kind) && key(o.entity) && int(o.day, 0, s.day + 365) && num(o.pay) && num(o.cost) && int(o.expires, 0, o.day) &&['open', 'accepted', 'declined', 'expired'].includes(o.status))) return false;
      if (!s.festivalOffers.every(o => o.approval === undefined || obj(o.approval) && text(o.approval.name) && int(o.approval.start, 0, o.day) && o.approval.day === o.day && o.approval.duration ===(o.kind === 'summer' ? 4: 3) && num(o.approval.pay) && num(o.approval.cost) && num(o.approval.net, - 1e12) && arr(o.approval.productions, 72) && o.approval.productions.every(p => int(p.id, 1, s.serial) && text(p.title, 60) && int(p.oldDue) && int(p.newDue, p.oldDue + o.approval.duration)))) return false;
      if (!s.engagements.every(e => int(e.id, 1, s.serial) && int(e.offerId, 1, s.serial) && kinds.includes(e.kind) && key(e.entity) && text(e.name) && int(e.start, 0, s.day + 365) && int(e.due, e.start + 1, s.day + 365) && e.due - e.start ===(e.kind === 'summer' ? 4: 3) && e.due > s.day && snapshot(e.snapshot) && e.snapshot.key === e.entity && shares(e.shares) && num(e.pay) && num(e.cost))) return false;
      if (s.engagements.some((e, i) => s.engagements.slice(i + 1).some(f => e.start < f.due + 2 && e.due + 2 > f.start && e.snapshot.ids.some(id => f.snapshot.ids.includes(id))))) return false;
      if (!s.festivalHistory.every(e => int(e.id, 1, s.serial) && int(e.day, 0, s.day) && key(e.entity) && text(e.name) && text(e.artist, 30) && ids(e.ids) && num(e.quality, 0, 99) && int(e.fans) && int(e.attendance) && num(e.net, - 1e12))) return false;
      const all = [... s.festivalOffers, ... s.engagements, ... s.festivalHistory].map(x => x.id).concat([... s.jobs, ... s.reports, ... s.catalog, ... s.loans, ... s.outcomes, ... s.moments, ... s.stories, ... s.specialOffers].map(x => x.id), s.units.map(u => + u.key.slice(1)));
      if (!unique(all)) return false;
      if (!unique(s.external.map(c => c.uid)) || !s.external.every(c => text(c.uid, 80) && c.uid.startsWith('x-') && text(c.name) && int(c.artist, 0, 100000) && int(c.debutYear, 1900, s.seasonYear) && text(c.artistName) && text(c.company) && int(c.startDay, - 365, s.day) && int(c.base, 0, 1e7) && typeof c.physical === 'boolean' && arr(c.days, 14) && unique(c.days.map(d => d.day)) && c.days.every(d => int(d.day, - 365, s.day) && int(d.streams) && int(d.sales)))) return false;
      if (!Object.entries(s.yearStats).every(([k, v]) => text(k, 160) && obj(v) && v.key === k && text(v.name) && typeof v.own === 'boolean' && ids(v.ids) && int(v.debut, 1900, 10000) &&['streams', 'sales', 'live', 'liveCount', 'quality'].every(k => num(v[k])) &&(v.releaseId === null || text(v.releaseId, 100)))) return false;
      const nominee = n => obj(n) && text(n.key, 160) && text(n.name) && text(n.artist) && typeof n.own === 'boolean' && ids(n.ids) &&(n.releaseId === null || text(n.releaseId, 100));
      if (!unique(s.awardHistory.map(a => a.year)) || !s.awardHistory.every(a => int(a.year, 2027, s.seasonYear) && int(a.since, 0, s.day) && int(a.nominationDay, 0, s.day) &&(a.resultDay === null || int(a.resultDay, a.nominationDay, s.day)) && arr(a.categories, 4) && a.categories.length === 4 && unique(a.categories.map(c => c.key)) && a.categories.every(c =>['rookie', 'song', 'live', 'artist'].includes(c.key) && arr(c.nominees, 5) && unique(c.nominees.map(n => n.key)) && c.nominees.every(nominee) &&(c.winner === null || nominee(c.winner) && c.nominees.some(n => n.key === c.winner.key))))) return false;
      for (const metric of['streams', 'sales']) {
        const h = s.chartHistory?.[metric];
        if (!obj(h) || !(h.day === null || int(h.day, 0, s.day))) return false;
        for (const k of['current', 'previous', 'best']) if (!obj(h[k]) || Object.keys(h[k]).length > 10000 || !Object.entries(h[k]).every(([id, rank]) => text(id, 100) && int(rank, 1, 100000))) return false;
      }
      if (!s.reports.every(r =>(r.festivalOfferId === undefined || int(r.festivalOfferId, 1, s.serial)) &&(r.festivalResultId === undefined || int(r.festivalResultId, 1, s.serial)) &&(r.awardYear === undefined || int(r.awardYear, 2027, s.seasonYear)))) return false;
      return true;
    } catch {
      return false;
    }
  }
  if (typeof module !== 'undefined') module.exports = valid;
  else root.validSeasonState = valid;
})(typeof window !== 'undefined' ? window: globalThis);


;
