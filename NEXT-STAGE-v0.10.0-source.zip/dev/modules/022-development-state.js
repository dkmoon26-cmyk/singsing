/* FILE src/development-state.js */
(function(root){
  'use strict';
  const base=root.validState,plans=['balanced','vocal','performance','creative','rest'];
  root.validState=function(s){
    if(!base(s))return false;
    try{
      const people=[...s.artists,...(s.trainees||[]),...(s.departed||[])];
      const fields=['weeklyPlan','weeklyBase','growthTarget','milestone'];
      if(s.developmentVersion===undefined)return people.every(a=>fields.every(k=>a[k]===undefined));
      if(s.developmentVersion!==1)return false;
      const day=v=>Number.isInteger(v)&&v>=0&&v<=1e9;
      return people.every(a=>{
        if(a.weeklyPlan!==null && (!Array.isArray(a.weeklyPlan)||a.weeklyPlan.length!==7||!a.weeklyPlan.every(p=>plans.includes(p))))return false;
        if((a.weeklyPlan===null)!==(a.weeklyBase===null))return false;
        if(a.weeklyBase && (!['balanced','creative','stage','rest'].includes(a.weeklyBase.focus)||!plans.includes(a.weeklyBase.plan)||!['auto','manual'].includes(a.weeklyBase.mode)))return false;
        const g=a.growthTarget;
        if(g!==null && (!g||!Number.isInteger(g.metric)||g.metric<0||g.metric>7||!Number.isInteger(g.target)||g.target<1||g.target>99||!day(g.setDay)||g.setDay>s.day||!(g.achievedDay===null||day(g.achievedDay)&&g.achievedDay>=g.setDay&&g.achievedDay<=s.day)))return false;
        const m=a.milestone;
        return m===null||!!m&&['debut','live','single'].includes(m.kind)&&day(m.day)&&(m.completedDay===null||day(m.completedDay)&&m.completedDay<=s.day);
      });
    }catch{return false;}
  };
})(typeof window!=='undefined'?window:globalThis);

;
