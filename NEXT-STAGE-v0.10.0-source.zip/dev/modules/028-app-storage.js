/* FILE src/app-storage.js */
'use strict';
// app-storage: see docs/MAINTENANCE.md for ownership and loading order.
let autoLoadStatus = 'missing';
function save() {
  if (!game.s) return false;
  game.s.guideStep = Guide.guideStep(game.s);
  try {
    saveStore.writeAuto(game.s);
    saveOK = true;
    return true;
  } catch (error) {
    saveOK = false;
    if (error.code === 'SAVE_CONFLICT') {
      running = false;
      stopReason = error.message;
      toast(error.message);
      return false;
    }
    toast('자동 저장이 제한되어 있습니다. 설정에서 백업을 내보내 주세요.');
    return false;
  }
}
function loadSaved(adopt = false) {
  const loaded = saveStore.readAuto(adopt);
  autoLoadStatus = loaded.status;
  return loaded.state;
}
window.addEventListener('storage', event => {
  if (event.key !== KEY || !game.s || !saveStore.hasAutoChanged()) return;
  saveOK = false;
  running = false;
  stopReason = '다른 탭에서 저장이 변경됐습니다. 현재 진행을 백업한 뒤 설정에서 최신 저장을 검토해 주세요.';
  render();
  toast(stopReason);
});
window.addEventListener('pagehide', () => {
  if (game.s) save();
});

const BACKUP_META_KEY = 'next-stage-backup-meta-v1';
function backupMeta(state) {
  try {
    const meta = JSON.parse(localStorage.getItem(BACKUP_META_KEY));
    return meta && meta.company === state.company && meta.boss === state.boss &&
      Number.isFinite(meta.at) && meta.at > 0 && meta.at <= Date.now() &&
      Number.isInteger(meta.day) && meta.day >= 0 && meta.day <= state.day ? meta : null;
  } catch { return null; }
}
function backupDue(state) {
  const meta = backupMeta(state);
  return meta ? state.day - meta.day >= 30 || Date.now() - meta.at >= 7 * 86400000 : state.day >= 30;
}
function backupStatusHTML(state) {
  if (!state) return '';
  const meta = backupMeta(state);
  return `<p class="muted">${meta ? '마지막 백업 내보내기 요청: ' + esc(new Date(meta.at).toLocaleString('ko-KR')) + ' · ' + date(meta.day, true) : '이 회사의 백업 내보내기 기록이 없습니다.'}</p><p class="muted">내보낸 파일이 다운로드 폴더에 있는지 확인하세요. 백업 기록은 이 브라우저에만 보관됩니다.</p>`;
}
function backupReminderHTML() {
  if (!game.s || !backupDue(game.s)) return '';
  return `<section class="panel section backup-reminder" aria-label="저장 백업 안내"><strong>진행 내용을 파일로 보관해 주세요.</strong><p>백업은 게임 내 30일 또는 실제 7일마다 권장합니다. 브라우저 데이터가 삭제되면 자동 저장과 슬롯도 사라집니다.</p>${btn('백업·저장 관리', 'settings', '', 'soft')}</section>`;
}

function settings_app() {
  modal('설정 · 저장 관리', `<div class="tip">이 브라우저에 자동 저장됩니다. 다른 기기·주소로 이동할 때는 백업 파일을 내보낸 뒤 불러와 주세요.</div>${backupStatusHTML(game.s || loadSaved())}<div class="list section">${btn('현재 진행 저장','manual-save','','primary',!game.s)}${btn('저장 백업 내보내기','export','','soft',!game.s&&!loadSaved())}<label class="check-row" style="justify-content:center;cursor:pointer">백업 파일 불러오기<input type="file" id="import-save" accept="application/json,.json" style="max-width:180px;font-size:11px"></label>${saveStore.hasAutoChanged()?btn('최신 저장 검토','latest-save','','soft'):''}${btn('저장 슬롯·복구 지점','m-saves','','soft')}${game.s?btn(game.s.guideHidden?'가이드 다시 켜기':'가이드 숨기기','guide-toggle','','soft')+btn('타이틀로 돌아가기','to-title'):''}</div><p class="muted" style="font-size:12px;margin-top:18px">v${DATA.rules.version} · 초반부터 후속 활동까지 계속 운영할 수 있습니다. 오프라인 파일 실행도 지원하며 PC·모바일 저장은 자동 동기화되지 않습니다.</p>`);
}

function reviewLatestSave() {
  const latest = saveStore.readAuto();
  if (!latest.state) throw Error('최신 자동 저장을 읽을 수 없습니다. 슬롯·복구 지점 또는 JSON 백업을 선택하세요.');
  previewRestore(latest.state, '다른 탭의 최신 자동 저장', latest.raw);
}

function checkSaveSession() {
  try { if (saveStore.hasAutoChanged()) saveStore.assertAutoCurrent(); }
  catch (error) {
    if (error.code === 'SAVE_CONFLICT') {
      saveOK = false;
      running = false;
      stopReason = error.message;
    }
    throw error;
  }
}


;
