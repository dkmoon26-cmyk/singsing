/* FILE src/operations.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const clamp =(n, a, b) => Math.max(a, Math.min(b, n)),
    round = x => Math.round(x * 100) / 100;
    class OperationsGame extends Base {
      upgrade() {
        super.upgrade();
        const s = this.s;
        if (!s || s.operationsVersion === 1) return;
        s.operationsVersion = 1;
        s.operationsSince = s.day;
        s.staffMarketSeed =(s.seed ^ 0x51a7) >>> 0;
        s.receivables = [];
        for (const a of[... s.trainees, ... s.artists, ... s.departed]) this.initOperationsTalent(a);
      }
      initOperationsTalent(a) {
        if (!a.trainingMode) a.trainingMode = 'auto';
        if (!a.trainingGoal) a.trainingGoal = 'balanced';
        if (!a.growthHistory) a.growthHistory = [{ day: this.s.day, stats:[... a.stats], reason: '기록 시작' }];
        if (!Number.isInteger(a.recoveryUntil)) a.recoveryUntil = 0;
      }
      has(id) {
        if (D.staffKinds[id]) return this.s.staff.some(sid => D.staff.find(p => p.id === sid)?.kind === id);
        return this.s.staff.includes(id);
      }
      staffPower(kind) {
        return Math.max(0, ... this.s.staff.map(id => D.staff.find(p => p.id === id)).filter(p => p.kind === kind).map(p => p.coaching / 100));
      }
      get traineeCapacity() {
        return D.roster.length;
      }
      buildStaffBoard() {
        let seed =(this.s.staffMarketSeed + Math.imul(this.s.day + 1, 2654435761)) >>> 0;
        const pool = D.staff.filter(p => !this.s.staff.includes(p.id));
        for (let i = pool.length - 1; i > 0; i--) {
          seed =(Math.imul(seed, 1664525) + 1013904223) >>> 0;
          const j = seed %(i + 1);
          [pool[i], pool[j]] = [pool[j], pool[i]];
        }
        return { day: this.s.day, ids: pool.slice(0, 5).map(p => p.id) };
      }
      staffCandidates() {
        if (!this.s.staffBoard || this.s.staffBoard.day !== this.s.day) this.s.staffBoard = this.buildStaffBoard();
        return this.s.staffBoard.ids.filter(id => !this.s.staff.includes(id)).map(id => D.staff.find(p => p.id === id));
      }
      hire(id) {
        const p = this.staffCandidates().find(p => p.id === id);
        if (!p) throw Error('오늘의 채용 후보를 확인하세요.');
        this.spend(p.fee, '직원 채용: ' + p.name);
        this.s.staff.push(id);
        this.log(p.name + ' 채용');
      }
      fire(id) {
        if (!this.s.staff.includes(id)) throw Error('재직 중인 직원이 아닙니다.');
        super.fire(id);
      }
      coach(plan) {
        return this.s.staff.map(id => D.staff.find(p => p.id === id)).filter(p => p.kind === 'trainer').map(p =>({ staff: p, bonus: Math.min(.6, p.coaching * .004 +(p.specialty === plan ? p.expertise * .002: 0)) })).sort((a, b) => b.bonus - a.bonus)[0] || { staff: null, bonus: 0 };
      }
      startCasting(method, type, position = 'any', experience = 'any') {
        if (!['any', 'career', 'trainee'].includes(experience) || !D.roster.some(d => this.available(d.id) &&(type === 'any' || d.type === type) &&(position === 'any' || d.position === position) &&(experience === 'any' ||(experience === 'career' ? !!d.career: d.trainee)))) throw Error('조건에 맞는 모집 후보가 없습니다.');
        super.startCasting(method, type, position);
        this.s.jobs.at(- 1).experience = experience;
      }
      sign(id, offer = 'balanced') {
        const d = D.roster[Number(id)],
        prior = this.s.departed.some(a => a.id === Number(id));
        if (d?.career && offer === 'company') throw Error('경력 아티스트는 균형 또는 아티스트 중심 계약을 요청합니다.');
        const extra = d?.career ? Math.round(250 + d.priorFame * 12): 0;
        if (this.s.cash < this.contractQuote(id, offer).total) throw Error('계약금과 경력 영입 지원금이 부족합니다.');
        super.sign(id, offer);
        const a = this.talent(id);
        this.initOperationsTalent(a);
        if (d.career) {
          this.spend(extra, '경력 영입 지원금: ' + d.name);
          if (!prior) {
            a.fans = d.priorFans;
            a.fame = d.priorFame;
            a.energy = d.id === 65 ? 65: 85;
          }
          this.s.reports[0].body += '\n육성 대기 없이 제작·공연 가능. 이전 소속사 작품 권리는 취득하지 않습니다.';
        }
      }
      setTraining(id, plan) {
        super.setTraining(id, plan);
        this.s.trainees.find(a => a.id === Number(id)).trainingMode = 'manual';
      }
      setTrainingControl(id, mode, goal) {
        const a = this.s.trainees.find(a => a.id === Number(id));
        if (!a || !['auto', 'manual'].includes(mode) || !['balanced', 'debut', 'longterm', 'vocal', 'performance', 'creative'].includes(goal)) throw Error('육성 목표를 확인하세요.');
        a.trainingMode = mode;
        a.trainingGoal = goal;
      }
      trainingAdvice(a) {
        const d = D.roster[a.id],
        required = d.type === 'idol' ?[0, 2, 5]: d.type === 'band' ?(d.position === '보컬' ?[0, 4, 7]:[3, 4, 7]):[1, 4, 5];
        const sorted = [... required].sort((x, y) => a.stats[x] - a.stats[y]),
        weak = sorted[0],
        strong = [... required].sort((x, y) => a.stats[y] - a.stats[x])[0];
        const plan = weak === 0 ? 'vocal':[2, 5, 6].includes(weak) ? 'performance': 'creative';
        return {
          weak,
          strong,
          plan,
          text: DATA_NAME(d) + ' · ' + D.specs[strong] + ' 강점 / ' + D.specs[weak] + ' 보완 권장'
        };
      }
      autoPlan(a) {
        if (a.energy < 40 || a.stress > 65) return 'rest';
        if (['vocal', 'performance', 'creative'].includes(a.trainingGoal)) return a.trainingGoal;
        if (a.trainingGoal === 'longterm' && a.energy < 65) return 'rest';
        return a.trainingGoal === 'balanced' ? 'balanced': this.trainingAdvice(a).plan;
      }
      trainTrainees() {
        for (const a of[... this.s.trainees]) {
          this.initOperationsTalent(a);
          if (a.trainingMode === 'auto' && this.has('trainer')) a.trainingPlan = this.autoPlan(a);
          const p = Base.trainingPlans[a.trainingPlan],
          profile = this.profile(a.id),
          coach = this.coach(a.trainingPlan);
          let reason = '훈련';
          if (a.trainingPlan === 'rest' || a.energy < 30 || a.stress > 80) {
            a.energy = clamp(a.energy + 8, 0, 100);
            a.stress = clamp(a.stress - 6, 0, 100);
            reason = '회복';
          } else {
            const cost = p.cost *(coach.staff ? .8: 1);
            if (this.s.cash < cost) {
              a.energy = clamp(a.energy + 5, 0, 100);
              a.stress = clamp(a.stress - 3, 0, 100);
              reason = '훈련비 부족';
            } else {
              this.change(- cost, '연습생 훈련: ' + D.roster[a.id].name, true, { kind: 'training' });
              const care = coach.staff ? coach.staff.care / 100: 0;
              a.energy = clamp(a.energy - p.load *(1 - care * .25), 0, 100);
              a.stress = clamp(a.stress + p.load * .5 *(1 - care * .5), 0, 100);
              a.trainedDays++;
              for (const idx of p.indexes) {
                const preference = a.trainingPlan === this.personality(a.id).training ? 1.08: 1,
                gain = .10 *(1 + coach.bonus) * preference * profile.learning *(p.indexes.length === 8 ? 1: 2.2) *(idx === profile.strength ? 1.35: idx === profile.weakness ? .7: 1) *(1 - a.stress * .005);
                if (a.stats[idx] < profile.potential) a.stats[idx] = Math.min(profile.potential, a.stats[idx] + gain);
              }
              reason = p.indexes.every(idx => a.stats[idx] >= profile.potential - .5) ? '성장 한계 접근': '훈련';
            }
          }
          a.lastTrainingReason = reason;
          if (a.contract <= this.s.day) this.releaseTrainee(a.id);
        }
      }
      startProject(key, kind, title, budget, concept, options = {}) {
        const e = this.entity(key);
        if (e?.members.some(a => a.recoveryUntil > this.s.day)) throw Error('활동 후 회복 중입니다. 일정에서 회복 종료일을 확인하세요.');
        const promo = D.promotionPlans[options.promotion || 'none'];
        if (!promo || kind !== 'single' && options.promotion && options.promotion !== 'none') throw Error('사전 홍보는 싱글 제작에서 선택하세요.');
        const manufacture = options.format === 'physical' ? Number(options.quantity) * .6: 0;
        if (this.s.cash < Number(budget) + manufacture + promo.cost -(this._affordabilityDiscount || 0)) throw Error('제작·제조·홍보비를 합친 자금이 부족합니다.');
        super.startProject(key, kind, title, budget, concept, options);
        const j = this.s.jobs.at(- 1);
        if (kind === 'single') {
          if (promo.cost) this.spend(promo.cost, '사전 홍보: ' + j.name);
          j.promotion = options.promotion || 'none';
          j.promotionCost = promo.cost;
          j.due += promo.days;
        }
      }
      resolve(id, choice) {
        const r = this.s.reports.find(r => r.id === Number(id));
        if (r?.kind === 'ad' && choice === 'accept' && this.entity(r.entity)?.members.some(a => a.recoveryUntil > this.s.day)) throw Error('회복 중에는 광고 촬영을 추가할 수 없습니다.');
        return super.resolve(id, choice);
      }
      receive(amount, label, shares = [], key = null, kind = 'income') {
        if (this.s.receivables &&['concert_settlement', 'ad_balance'].includes(kind)) {
          this.s.receivables.push({
            id: this.id(),
            due: this.s.day +(kind === 'concert_settlement' ? 7: 14),
            amount: round(amount),
            label,
            kind,
            shares: shares.map(x =>({ ... x })),
            key
          });
          return;
        }
        super.receive(amount, label, shares, key, kind);
      }
      finishOperations(j) {
        const count = this.s.catalog.length;
        this.finishMarket(j);
        if (j.kind === 'casting') return;
        const e = this.projectEntity(j);
        if (!e) return;
        const low = e.members.some(a => a.energy < 35 || a.stress > 75);
        const recovery = j.kind === 'live' ? 3: j.kind === 'ad' ? 2: 1;
        for (const a of e.members) {
          this.initOperationsTalent(a);
          a.recoveryUntil = Math.max(a.recoveryUntil, this.s.day + recovery +(low ? 3: 0));
          a.stress = clamp(a.stress +(low ? 5: 1), 0, 100);
        }
        if (low) {
          this.s.image = clamp(this.s.image - .5, 0, 100);
          this.report('컨디션 점검 · ' + e.name, '피로 누적으로 회복 기간이 늘었습니다. 무리한 일정은 실수 위험을 높입니다. 회복 종료까지 새 활동을 잡지 않습니다.', 'info', true);
        }
        if (j.kind === 'single') {
          const c = this.s.catalog[count],
          promo = D.promotionPlans[j.promotion || 'none'];
          c.market.production = round(c.market.production +(j.promotionCost || 0));
          c.market.appeal = Math.min(1.5, c.market.appeal *(1 + promo.boost));
        }
        if (j.kind === 'ad' || j.kind === 'live') {
          const r = this.s.reports.find(r => r.day === this.s.day && r.kind === 'result');
          if (r) {
            r.body = r.body.replace('원을 받았습니다.', '원은 촬영 후 14일 뒤 지급됩니다.');
            r.body += '\n실제 입금은 ' +(j.kind === 'live' ? '7': '14') + '일 뒤이며 재정의 예정 입출금에서 확인할 수 있습니다.';
          }
        }
      }
      settleReceivables() {
        const due = this.s.receivables.filter(x => x.due <= this.s.day);
        for (const item of due) super.receive(item.amount, item.label, item.shares, item.key, item.kind);
        const ids = new Set(due.map(x => x.id));
        this.s.receivables = this.s.receivables.filter(x => !ids.has(x.id));
      }
      advanceOperations() {
        this.advanceMarket();
        this.staffCandidates();
        for (const a of[... this.s.trainees, ... this.s.artists]) {
          this.initOperationsTalent(a);
          const history = a.growthHistory;
          if (history.at(- 1)?.day !== this.s.day) history.push({ day: this.s.day, stats:[... a.stats], reason: this.s.trainees.includes(a) ? a.lastTrainingReason || '훈련': a.recoveryUntil > this.s.day ? '활동 후 회복': '활동·육성' });
          a.growthHistory = history.filter(x => x.day >= this.s.day - 90);
        }
        if (this.s.day % 7 === 0 && this.has('trainer') && this.s.trainees.length) this.report('육성 담당 주간 보고', this.s.trainees.map(a => D.roster[a.id].name + ': ' + this.trainingAdvice(a).text + ' / ' +(a.lastTrainingReason || '기록 시작') + ' / 평균 ' + this.readiness(a).toFixed(1)).join('\n'), 'info');
        return this.pending.length;
      }
      cashForecast() {
        const s = this.s,
        items = s.receivables.map(x =>({
          day: x.due,
          label: x.label,
          amount: round(x.amount - x.shares.reduce((n, a) => n + round(x.amount * a.rate), 0)),
          type: '입금 확정'
        }));
        for (const j of s.jobs) if (j.kind === 'ad') items.push({
          day: j.due + 14,
          label: j.name + ' 잔금 (촬영 완료 조건)',
          amount: round(j.pay -(j.shares ||[]).reduce((n, x) => n + round(j.pay * x.rate), 0)),
          type: '입금 예정'
        });
        for (const c of s.catalog) if (c.market.pending) items.push({
          day: s.day + 7 - c.market.pendingDays,
          label: c.name + ' 누적 미정산',
          amount: round(c.market.pending *(1 - c.shares.reduce((n, a) => n + a.rate, 0))),
          type: '입금 추정'
        });
        const month = s.day + 30 - s.day % 30;
        items.push({
          day: month,
          label: '월 고정비·연습생 지원비',
          amount: - this.fixed,
          type: '예정 지출'
        });
        for (const l of s.loans) items.push({
          day: Math.max(month, Math.ceil(l.due / 30) * 30),
          label: '대출 원금·이자',
          amount: - round(Math.min(l.remaining, l.payment) + Math.round(l.remaining * l.rate)),
          type: '예정 지출'
        });
        return items.sort((a, b) => a.day - b.day);
      }
    }
    function DATA_NAME(d) {
      return d.position;
    }
    return OperationsGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installOperations = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
