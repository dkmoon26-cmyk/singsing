/* FILE src/management-ui.js */
'use strict';
const starNames = ['신인', '주목받는 신예', '인기 아티스트', '스타', '톱스타'];
const panel =(title, body) => `<section class="panel section"><h2>${title}</h2>${body}</section>`;
function offerOptions() {
  return Object.entries(DATA.terms).map(([k, t]) => `<option value="${k}" ${k==='balanced'?'selected':''}>${t.name} · ${t.days/365}년 · 회사 ${Math.round(t.share*100)}% · 기본 계약금 ${money(t.fee)}</option>`).join('');
}
function talentModal_management(id) {
  let d = DATA.roster[id],
  c = game.s.candidates.find(c => c.id === id);
  if (!c) throw Error('유효한 후보가 없습니다.');
  modal(d.name + ' · ' +(d.trainee ? '연습생': '신인 계약'), `<div class="detail-grid"><img class="detail-photo" src="${d.image}" alt="${d.name}"><div><p>${d.position} · ${d.traits}</p>${statsHTML(d.stats,c.evaluated)}<p>${d.story}</p></div></div>${personalityCard(id)}<form id="m-contract"><input type="hidden" name="id" value="${id}"><label for="offer">${d.trainee?'데뷔 시 적용할 기본 제안서 (현재 영입비 100만 원·육성계약 2년)':'전속계약 제안서'}</label><select id="offer" name="offer">${offerOptions()}</select><p class="muted">${d.trainee?'월 지원비 60만 원과 일 훈련비 2만 원. 90일 훈련·평균 능력 55부터 데뷔 평가가 가능합니다.':'기간·배분은 계약 이후 작품에 적용됩니다. 기존 작품의 약정 배분은 계약 종료 후에도 유지됩니다.'}</p><div class="modal-actions">${!c.evaluated?btn('추가 평가 · 50만','evaluate',`data-id="${id}"`):''}<button class="primary">${d.trainee?'연습생 영입':'전속계약 승인'}</button></div></form>`, true);
}
function termsText(a) {
  return `${a.terms.name} · 회사 ${Math.round(a.terms.share*100)}% / 아티스트 ${Math.round((1-a.terms.share)*100)}% · 만료 ${date(a.contract,true)}`;
}
function teams_management() {
  let s = game.s;
  return heading('팀·계약', '팀 활동·개인 전속계약·작품 권리는 별도로 유지됩니다.', btn('팀 결성', 'unit-modal', '', 'primary', s.artists.length < 2)) + `<div class="two-col section">${s.units.map(u=>`<article class="panel"><h2>${esc(u.name)}</h2><p>${u.ids.map(id=>DATA.roster[id].name).join(' · ')} · ${u.status==='active'?'활동':'휴지·재편'}</p><p>팀 인지도 ${u.fame.toFixed(1)} · 팀 팬 ${u.fans.toLocaleString()} · ${starNames[u.star]}</p><div class="row wrap">${btn('팀 관리','m-team',`data-key="${u.key}"`,'soft')}${btn(u.status==='active'?'활동 중단':'활동 재개','m-team-confirm',`data-key="${u.key}" data-op="${u.status==='active'?'pause':'resume'}"`)}${btn('해체 검토','m-team-confirm',`data-key="${u.key}" data-op="dissolve"`,'danger')}</div></article>`).join('')}</div>` + panel('개인 전속계약', s.artists.map(a => `<article class="contract-row"><h3>${DATA.roster[a.id].name} · ${starNames[a.star]} <small>최고 ${starNames[a.bestStar]}</small></h3><p>${termsText(a)}</p><p>개인 인지도 ${a.fame.toFixed(1)} · 개인 팬 ${a.fans.toLocaleString()} · 회사 신뢰 ${Math.round(a.trust)}</p><div class="row wrap">${btn('상세·육성','artist',`data-id="${a.id}"`)}${a.contract-s.day<=90?btn('재계약 협상','m-renew',`data-id="${a.id}"`,'primary'):''}${btn('합의 이적 검토','m-transfer',`data-id="${a.id}"`)}${s.units.some(u=>u.ids.includes(a.id))?btn('팀 탈퇴 검토','m-leave-confirm',`data-id="${a.id}"`):''}</div></article>`).join('') || '<p>전속 아티스트가 없습니다.</p>') + panel('최근 작품 배분 내역', `<p>회사가 보유한 기존 작품은 계약 종료·해체 후에도 약정 비율로 정산합니다.</p>${s.payments.slice(0,12).map(p=>`<p>${date(p.day)} · ${DATA.roster[p.id].name} · ${money(p.amount)} · ${esc(p.label)}</p>`).join('')||'<p>배분 내역 없음</p>'}`);
}
function company_management() {
  let m = game.metrics(),
  v = game.valuation(),
  s = game.s,
  previous = s.valuations.length > 1 ? s.valuations.at(- 2): null;
  return heading('회사·기업가치', '규모·수익·상장 여부를 구분해 평가합니다.') + `<div class="metrics"><div class="panel"><small>회사 규모</small><h2>${DATA.stageNames[game.stage]}</h2><p>비상장 · 대표 지분 100%</p></div><div class="panel"><small>추정 지분가치</small><h2>${money(v.low)} ~ ${money(v.high)}</h2><p>평가 신뢰도 ${v.confidence}</p></div><div class="panel"><small>운영 여유</small><h2>${m.runway.toFixed(1)}개월</h2><p>훈련·월 고정비 기준 / 새 제작·대출상환 제외</p></div></div>` + panel('최근 1년 운영 손익 (현금 기준)', `<p>기록 ${m.days}일 / 365일 · 기존 저장은 업데이트 이후부터 집계합니다.</p><div class="finance-mini"><div>총매출 <strong>${money(m.revenue)}</strong></div><div>영업비용 <strong>${money(m.expense)}</strong></div><div>영업이익 <strong>${money(m.profit)}</strong></div></div><p>아티스트 배분·제작비·급여·훈련·이자 포함. 대출 원금·회생금·이적금은 영업 실적에서 제외합니다.</p>`) + panel('평가 근거', `<p>영업가치 ${money(v.operating)} + 현금 ${money(s.cash)} − 부채 ${money(game.debt)}</p><p>주력 활동 매출 의존도 ${Math.round(m.concentration*100)}% · 계약 안정성 ${Math.round(v.contractRisk*100)}%</p><p>관측된 영업이익·매출과 계약 안정성으로 계산합니다. 음원 자산을 별도로 더하지 않아 중복 평가를 방지합니다.</p><p>${previous?'지난 평가 대비 '+money(v.value-previous.value)+' · 영업 실적, 현금·부채와 잔여 계약 기간 변화 반영':'비교할 평가 이력이 아직 없습니다.'}</p>`) + panel('5단계 승급 조건', `<p>분기 말 평가 · 2개 분기 연속 미달 시 한 단계 재평가 · 직원·기능 유지</p><div class="table-scroll"><table class="ledger"><thead><tr><th>단계</th><th>운영기간</th><th>연매출</th><th>영업이익</th><th>운영 여유</th></tr></thead><tbody><tr><td>신생 레이블</td><td>설립</td><td>—</td><td>—</td><td>—</td></tr>${DATA.stageRules.map(r=>`<tr><td>${DATA.stageNames[r.level]}</td><td>${r.days}일</td><td>${money(r.revenue)}</td><td>${money(r.profit)}</td><td>${r.runway}개월</td></tr>`).join('')}</tbody></table></div><p>규모 기준은 게임용 초기 밸런스입니다. 고수익 솔로 회사도 승급할 수 있습니다.</p>`);
}
function industry_management() {
  let s = game.s,
  v = game.valuation();
  return heading('업계·라이벌', '가상 회사 4곳의 활동과 추정치를 비교하세요.') + `<div class="two-col section">${s.rivals.map(r=>`<article class="panel"><h2>${esc(r.name)}</h2><p>${DATA.stageNames[r.level]} · ${r.type==='any'?'종합':DATA.labels[r.type]} · 소속 ${r.artists.length}명</p><h3>추정 기업가치 ${money(r.value*.8)} ~ ${money(r.value*1.2)}</h3><p>${r.artists.map(id=>DATA.roster[id].name).join(' · ')||'소속 없음'}</p><p>최근 공개 프로젝트 ${r.catalog.length}건 · 평판 ${Math.round(r.reputation)}</p><p>우리 회사와 추정 중앙값 차이 ${money(v.value-r.value)}</p></article>`).join('')}</div>` + panel('업계 소식', s.industryNews.map(n => `<p>${date(n.day)} · ${esc(n.text)}</p>`).join('') || '<p>첫 월간 업데이트를 기다리고 있습니다.</p>');
}
function managementClick_management(action, d) {
  let id = Number(d.id),
  a = game.artist(id);
  switch (action) {
    case 'm-renew': case 'm-debut': modal(action === 'm-renew' ? '재계약 제안서': '데뷔 계약 제안서', `<form id="${action}" class="list"><input type="hidden" name="id" value="${id}"><label for="offer">계약 제안</label><select name="offer" id="offer">${offerOptions()}</select><p>${a?'기존 작품 배분은 유지하며 새 활동부터 변경됩니다. 최종 계약금은 인지도·신뢰에 따라 조정됩니다. 아래에서 확인하세요.':'90일 훈련·평균 능력 55 이상 필요'}</p>${a?Object.entries(DATA.terms).map(([k,t])=>`<p>${t.name}: 실제 계약금 ${money(game.renewalCost(a,k))}</p>`).join(''):''}<button class="primary">계약 승인</button></form>`);
    break;
    case 'm-release-trainee': case 'm-leave-confirm': modal('계약·소속 변경 확인', `<p>${action==='m-release-trainee'?'연습생 계약을 합의 종료합니다.':'팀에서 탈퇴합니다. 개인 계약과 기존 작품 배분·확정 일정은 유지됩니다. 1명만 남으면 팀은 휴지 상태가 됩니다.'}</p><div class="modal-actions">${btn('변경 승인',action==='m-release-trainee'?'m-trainee-release':'m-leave',`data-id="${id}"`,'danger')}</div>`);
    break;
    case 'm-trainee-release': mutate(() => game.releaseTrainee(id), '연습생 계약을 종료했습니다.');
    break;
    case 'm-leave': mutate(() => game.leaveTeam(id), '팀에서 탈퇴했습니다.');
    break;
    case 'm-team-confirm': {
      const impact = game.teamImpact(d.key);
      modal('팀 운영 변경', `<p>확정 일정 ${impact.jobs.length}건 · 기존 작품 ${impact.catalog}개 유지. 현재 협업 호흡 ${Math.round(impact.cohesion)}.</p>${impact.jobs.map(j=>`<p>${esc(j.name)} · ${date(j.due)}</p>`).join('')}<p>${d.op==='dissolve'?'팀을 해체합니다. 이름과 활동 이력은 보존되며, 개인 계약·기존 작품 배분·확정 일정은 유지됩니다.':d.op==='pause'?'새 팀 활동을 중단합니다. 이미 확정된 일정은 완료합니다.':'멤버 2명 이상이면 활동을 재개합니다.'}</p><div class="modal-actions">${btn('승인','m-team-apply',`data-key="${d.key}" data-op="${d.op}"`,'primary')}</div>`);
      break;
    }
    case 'm-team-apply': mutate(() => game.teamAction(d.key, d.op), '팀 설정을 변경했습니다.');
    break;
    case 'm-team': {
      let u = game.s.units.find(u => u.key === d.key);
      let list = game.s.artists.filter(a => DATA.roster[a.id].type === u.type && !game.s.units.some(u => u.ids.includes(a.id)));
      modal(esc(u.name) + ' 멤버 관리', `<p>새 멤버는 활동 중인 일정이 없어야 합니다. 기존 작품의 배분은 변경되지 않습니다.</p><form id="m-team-add"><input type="hidden" name="key" value="${u.key}"><label for="member">합류할 멤버</label><select name="id" id="member">${list.map(a=>`<option value="${a.id}">${DATA.roster[a.id].name}</option>`).join('')}</select><div class="modal-actions"><button class="primary" ${list.length?'':'disabled'}>팀 합류 승인</button></div></form>`);
      break;
    }
    case 'm-transfer': modal('삼자 합의 이적 검토', `<p>${DATA.roster[id].name} · 활동 중이면 일정 종료 후 진행하세요. 기존 작품 권리와 배분은 유지됩니다.</p>${game.s.rivals.map(r=>{let q=game.transferQuote(id,r.id);return `<div class="contract-row"><h3>${esc(r.name)}</h3><p>합의금 ${money(q.fee)} · 본인 ${q.consent?'동의':'거절'} · 상대 자금 ${q.affordable?'충족':'부족'} · 분야 ${q.fit?'적합':'불일치'}</p>${btn('이적 최종 검토','m-transfer-confirm',`data-id="${id}" data-rival="${r.id}"`,'soft',!q.consent||!q.affordable||!q.fit||game.busy(String(id)))}</div>`;}).join('')}`);
    break;
    case 'm-transfer-confirm': {
      let q = game.transferQuote(id, d.rival),
      r = game.s.rivals.find(r => r.id === Number(d.rival));
      modal('합의 이적 승인', `<p>${DATA.roster[id].name} → ${esc(r.name)}</p><p>회사는 ${money(q.fee)}을 받습니다. 전속계약과 팀 소속은 종료되고 작품 배분은 유지됩니다.</p>${btn('삼자 합의 승인','m-transfer-apply',`data-id="${id}" data-rival="${r.id}"`,'primary')}`);
      break;
    }
    case 'm-transfer-apply': mutate(() => game.transfer(id, d.rival), '합의 이적을 완료했습니다.');
    break;
  }
}
$('#modal-root').addEventListener('submit', ev => {
  let f = ev.target;
  if (!f.getAttribute('id')?.startsWith('m-')) return;
  ev.preventDefault();
  let data = new FormData(f);
  try {
    switch (f.getAttribute('id')) {
      case 'm-contract': mutate(() => game.sign(data.get('id'), data.get('offer')), '계약을 체결했습니다.');
      break;
      case 'm-renew': mutate(() => game.renew(data.get('id'), data.get('offer')), '재계약했습니다.');
      break;
      case 'm-debut': mutate(() => game.debut(data.get('id'), data.get('offer')), '정식 아티스트로 데뷔했습니다.');
      break;
      case 'm-team-add': mutate(() => game.teamAction(data.get('key'), 'add', Number(data.get('id'))), '팀 멤버가 합류했습니다.');
      break;
    }
  } catch (e) {
    $('#modal-error').textContent = e.message;
  }
});


;
