/* FILE src/day-feedback.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const round = n => Math.round(n * 100) / 100;
    class FeedbackGame extends Base {
      upgrade() {
        super.upgrade();
        if (!this.s || this.s.feedbackVersion === 1) return;
        this.s.feedbackVersion = 1;
        this.s.daySummaries = [];
      }
      advanceSummary() {
        let s = this.s,
        fromDay = s.day,
        cash = s.cash,
        streams = s.catalog.reduce((n, c) => n + c.market.streams, 0),
        sales = s.catalog.reduce((n, c) => n + c.market.sales, 0),
        fans = s.artists.reduce((n, a) => n + a.fans, 0),
        teamFans = s.units.reduce((n, u) => n + u.fans, 0),
        beforeIds = s.artists.map(a => a.id),
        reports = new Set(s.reports.map(r => r.id)),
        due = s.jobs.filter(j => j.due <= s.day + 1).map(j =>({ kind: j.kind, title: j.name }));
        let result = this.advanceOperations();
        let training = new Set(s.ledger.filter(l => l.day === s.day && l.kind === 'training').map(l => l.label));
        let summary = {
          fromDay,
          day: s.day,
          cashChange: round(s.cash - cash),
          streams: s.catalog.reduce((n, c) => n + c.market.streams, 0) - streams,
          sales: s.catalog.reduce((n, c) => n + c.market.sales, 0) - sales,
          fansChange: s.artists.reduce((n, a) => n + a.fans, 0) - fans,
          teamFansChange: s.units.reduce((n, u) => n + u.fans, 0) - teamFans,
          trainingCount: training.size,
          completed: due,
          newReports: s.reports.filter(r => !reports.has(r.id)).length,
          departed: beforeIds.filter(id => !s.artists.some(a => a.id === id))
        };
        s.daySummaries.push(summary);
        s.daySummaries = s.daySummaries.slice(- 30);
        return this.pending.length;
      }
    }
    return FeedbackGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installDayFeedback = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
