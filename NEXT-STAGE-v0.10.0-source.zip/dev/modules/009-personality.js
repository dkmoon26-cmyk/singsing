/* FILE src/personality.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const clamp =(x, a, b) => Math.max(a, Math.min(b, x));
    class PersonalityGame extends Base {
      personality(id) {
        return D.roster[id].personality;
      }
      talent(id) {
        return this.artist(id) || this.s.trainees.find(a => a.id === Number(id));
      }
      trainingReaction(id) {
        const a = this.talent(id),
        p = this.personality(id);
        if (!a) return p.intro;
        if (a.energy < 30 || a.stress > 80) return '오늘은 잠깐 쉬고 싶어요. 컨디션을 되찾고 다시 해볼게요.';
        const plan = D.roster[id].trainee && this.s.trainees.includes(a) ? a.trainingPlan: a.focus;
        return plan === 'rest' ? '쉬는 동안 다음 활동을 차분히 준비하고 있어요.': plan === p.training ? p.reaction: '기본기를 쌓으면서 제 색깔도 찾아가고 싶어요.';
      }
      sign(id, offer) {
        super.sign(id, offer);
        const d = D.roster[Number(id)];
        this.s.reports[0].body += '\n' + d.name + ': “' + d.personality.intro + '”';
      }
      renewalCost(a, offer = 'balanced') {
        return Math.round(super.renewalCost(a, offer) *(offer === this.personality(a.id).offer ? .95: 1));
      }
      trainTrainees() {
        const before = new Map(this.s.trainees.map(a =>[a.id, [... a.stats]]));
        super.trainTrainees();
        for (const a of this.s.trainees) {
          const p = this.personality(a.id),
          old = before.get(a.id);
          if (!old || a.trainingPlan !== p.training) continue;
          a.stats = a.stats.map((v, i) => v > old[i] ? Math.min(this.profile(a.id).potential, v +(v - old[i]) * .08): v);
        }
      }
      personalSession(id, choice) {
        id = Number(id);
        const a = this.talent(id),
        p = D.roster[id]?.personality;
        if (!a || !p || !['creative', 'stage', 'rest'].includes(choice)) throw Error('소속 인물과 상담 방식을 확인하세요.');
        if (a.lastPersonalDay !== undefined && this.s.day - a.lastPersonalDay < 30) throw Error('개인 상담은 인물별 30일에 한 번 가능합니다.');
        if (choice !== 'rest' && this.busy(String(id))) throw Error('확정 활동 중에는 추가 워크숍을 진행할 수 없습니다. 휴식 상담을 이용하세요.');
        if (choice !== 'rest') this.spend(100, '개인 상담·워크숍: ' + D.roster[id].name);
        const trust = choice === p.session ? 5: 2;
        a.trust = clamp(a.trust + trust, 0, 100);
        a.stress = clamp(a.stress -(choice === 'rest' ? 8: 3), 0, 100);
        if (choice === 'rest') a.energy = clamp(a.energy + 10, 0, 100);
        else {
          const idx = choice === 'creative' ? 4: 5,
          cap = this.s.trainees.includes(a) ? this.profile(id).potential: 99;
          if (a.stats[idx] < cap) a.stats[idx] = Math.min(cap, a.stats[idx] + .4);
        }
        a.lastPersonalDay = this.s.day;
        const reply = choice === p.session ? p.reaction: '제 이야기를 들어주셔서 고마워요. 함께 방향을 맞춰 볼게요.';
        this.report(D.roster[id].name + ' · 개인 상담', reply + '\n신뢰 +' + trust + ' · ' +(choice === 'rest' ? '체력 +10 · 스트레스 -8': '스트레스 -3 · ' +(choice === 'creative' ? '창작': '무대') + ' 능력 +0.4 (성장 한계 이내)'), 'info');
        this.log(D.roster[id].name + ' 개인 상담 완료');
        return reply;
      }
    }
    return PersonalityGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installPersonality = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
