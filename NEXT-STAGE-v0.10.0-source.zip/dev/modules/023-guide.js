/* FILE src/guide.js */
(function(root) {
  'use strict';
  function guideStep(s) {
    const previous = Number.isInteger(s.guideStep) ? s.guideStep: 0;
    let step = 0;
    if (s.jobs.some(j => j.kind === 'casting')) step = 1;
    if (s.candidates.length) step = 2;
    if (s.artists.length || s.trainees?.length) step = 3;
    if (s.jobs.some(j => j.kind === 'single')) step = 4;
    if (s.releases > 0) step = 5;
    if (s.catalog.some(c => c.revenue > 0)) step = 6;
    return Math.max(previous, step);
  }
  const steps = [['첫 인재 찾기', '오디션은 500만 원·7일, 발굴은 200만 원·10일입니다. 원하는 분야의 모집을 시작하세요.', '캐스팅으로', 'casting'], ['후보 보고 기다리기', '날짜를 진행하면 후보 보고가 도착합니다. 주요 보고를 확인하면 날짜 건너뛰기를 사용할 수 있습니다.', '소식함으로', 'inbox'], ['첫 계약 맺기', '후보를 비교하고 계약하세요. 연습생 영입은100만 원, 전속계약은 제안서별 금액이며 경력자는 영입 지원금이 추가됩니다.', '후보 확인', 'casting'], ['첫 싱글 준비하기', '아티스트에서 육성 방향과 컨디션을 확인하세요. 싱글은 최소 1,000만 원이며 운영비는 별도입니다.', '아티스트 확인', 'artists'], ['첫 발매 기다리기', '싱글 제작은 21일입니다. 기다리는 동안 현금과 컨디션을 확인하세요.', '진행 중 확인', 'activity-progress'], ['첫 음원 정산 확인하기', '발매 후 매주 수익이 들어옵니다. 날짜를 진행한 뒤 재정에서 수입과 지출을 비교하세요.', '재정 확인', 'finance']];
  const api = { guideStep, steps };
  if (typeof module !== 'undefined') module.exports = api;
  else root.Guide = api;
})(typeof window !== 'undefined' ? window: globalThis);


;
