/* FILE src/evolution-ui.js */
'use strict';
let momentAudio = null, goalView = 'all';
function portraitsStrip(ids, cls = '') {
  return `<div class="ensemble ${cls}">${ids.map(id=>`<img src="${DATA.roster[id].image}" alt="${esc(DATA.roster[id].name)}" loading="lazy">`).join('')}</div>`;
}
function spotlightEntity() {
  return game.entity(game.s.pinnedEntity) || game.entities.find(e => game.s.jobs.some(j => j.entity === e.key)) || game.entities.find(e => e.key.startsWith('u')) || game.entities[0] || null;
}
function spotlight() {
  const e = spotlightEntity(),
  job = e && game.s.jobs.find(j => j.snapshot?.ids.some(id => e.members.some(a => a.id === id))),
  latest = e && game.s.outcomes.filter(o => o.ids.some(id => e.members.some(a => a.id === id))).at(- 1);
  return `<section class="spotlight ${e?'':'empty-spotlight'}" aria-label="오늘의 아티스트"><div class="spotlight-copy"><span class="eyebrow">OUR NEXT STAGE</span><h1>${e?esc(e.name):'아직 만나지 못한 가능성'}</h1><p>${job?esc(job.name)+' · '+Math.max(0,job.due-game.s.day)+'일 후 완료':latest?'최근 활동 · '+esc(latest.title):e?'오늘의 연습이 내일의 무대가 됩니다.':'첫 인재를 만나 우리만의 음악을 시작하세요.'}</p>${e?`<p class="spotlight-line">“${esc(game.trainingReaction(e.members[0].id))}”</p><div class="row wrap">${btn('함께한 기록','m-memory',`data-id="${e.members[0].id}"`,'primary')}${btn('활동 준비','project-modal',`data-entity="${e.key}"`,'soft')}</div><label for="spotlight-select">홈에서 볼 아티스트</label><select id="spotlight-select"><option value="">활동 중인 대상 자동 선택</option>${game.entities.map(x=>`<option value="${x.key}" ${game.s.pinnedEntity===x.key?'selected':''}>${esc(x.name)}${x.key.startsWith('u')?' · 팀':' · 개인'}</option>`).join('')}</select>`:btn('인재 모집 시작','casting-modal','','primary')}</div>${e?portraitsStrip(e.members.map(a=>a.id),'spotlight-portraits'):'<img class="office-scene" src="assets/office.webp" alt="햇빛이 드는 첫 기획사 사무실">'}</section>`;
}
const evolutionTasks = todayTasks_market;
function todayTasks_evolution() {
  let tasks = evolutionTasks();
  if (game.s.jobs.some(j => j.kind === 'casting')) tasks = tasks.filter(t => t.label !== '첫 인재 모집 시작');
  else if (game.s.candidates.length) tasks = tasks.map(t => t.label === '첫 인재 모집 시작' ? {
    priority: 2,
    label: '도착한 영입 후보 비교',
    action: 'nav',
    args: 'data-page="casting"'
  }
  : t);
  for (const st of game.s.stories) if (st.status === 'open') tasks.push({
    priority: 1,
    label: DATA.roster[st.talentId].name + '의 이야기 · ' + Math.max(0, st.expires - game.s.day) + '일 남음',
    action: 'm-story',
    args: `data-id="${st.id}"`
  });
  for (const r of game.s.reports) if (r.kind === 'ad' && game.reportState(r).needsDecision) tasks.push({
    priority: 2,
    label: r.title + ' · ' +(r.expires - game.s.day) + '일 남음',
    action: 'report',
    args: `data-id="${r.id}"`
  });
  return tasks.sort((a, b) => a.priority - b.priority);
};
function home_evolution() {
  const s = game.s,
  tasks = todayTasks(),
  forecast = game.cashForecast(),
  incoming = forecast.find(x => x.amount > 0),
  outgoing = forecast.find(x => x.amount < 0),
  moments = s.moments.slice(- 2).reverse();
  return spotlight() + guideCard() + panel('오늘 결정할 일', tasks.length ? `<div class="task-list">${tasks.slice(0,3).map(t=>btn(`<span class="pill ${t.priority===0?'coral':''}">${t.priority===0?'긴급':'확인'}</span> ${esc(t.label)}`,t.action,t.args,'task-button')).join('')}</div>${tasks.length>3?btn('전체 할 일 '+tasks.length+'건','m-all-tasks','','link'):''}`: '<p>급한 결정이 없습니다. 다음 무대를 준비하거나 날짜를 진행하세요.</p>') + `<section class="cash-ribbon panel section" aria-label="가까운 자금 흐름"><div><small>현재 운영 자금</small><h2>${money(s.cash)}</h2><p>평판 ${s.reputation.toFixed(1)} · ${DATA.stageNames[game.stage]}</p></div><div><small>가까운 지출</small><strong>${outgoing?date(outgoing.day)+' · '+money(-outgoing.amount):'확정 지출 없음'}</strong><p>${outgoing?esc(outgoing.label):''}</p></div><div><small>다음 입금</small><strong>${incoming?date(incoming.day)+' · '+money(incoming.amount):'집계 중'}</strong><p>${incoming?esc(incoming.type+' · '+incoming.label):'새 활동이나 작품의 정산이 필요합니다.'}</p></div><div class="row wrap">${btn('재정','nav','data-page="finance"','soft')}${btn('운영자금 대출','loan-modal','','link')}</div><small class="cash-note">예정 금액은 현재 기록 기준. 미래 훈련비·신규 제작비·판매 증가분은 별도입니다.</small></section>` + recentWeekHTML() + panel('다가오는 일주일', `<div class="next-week">${scheduleEvents().filter(x=>x.end>=s.day&&x.start<=s.day+7).slice(0,5).map(x=>`<div><span>${date(Math.max(s.day,x.start))}</span><strong>${esc(x.title)}</strong>${btn('보기','nav',`data-page="${x.page}"`,'link small')}</div>`).join('')||'<p>등록된 주요 일정이 없습니다. 훈련과 음원 집계는 매일 진행됩니다.</p>'}</div>${btn('전체 일정','nav','data-page="schedule"','soft')}`) + panel('우리의 최근 순간', moments.map(m => `<div class="contract-row"><small>${date(m.day)} · ${m.seen?'함께한 기록':'새로운 순간'}</small><h3>${esc(m.title)}</h3>${btn('다시 보기','m-moment',`data-id="${m.id}"`,'link')}</div>`).join('') || '<p>첫 계약부터 우리의 기록이 쌓입니다.</p>') + panel('최근 발매', s.catalog.slice(- 3).reverse().map(c => releaseRow({ release: c, company: s.company, own: true })).join('') || '<p>아직 발매작이 없습니다.</p>');
};
function memoriesHTML(id) {
  const a = game.talent(Number(id)) || game.s.departed.find(x => x.id === Number(id));
  return a ? `<section class="memories"><h3>함께한 기록</h3>${a.memories.slice(-8).reverse().map(m=>`<div><small>${date(m.day)}</small><p>${esc(m.text)}</p></div>`).join('')||'<p>첫 순간을 기다리고 있습니다.</p>'}${a.memories.length>8?btn('전체 기록 ('+a.memories.length+')','m-memory',`data-id="${id}"`,'link'):''}</section>`: '';
}
const evolutionArtistModal = artistModal_market, evolutionTraineeDetail = traineeDetail_operations;
function artistModal_evolution(id, candidate = false) {
  evolutionArtistModal(id, candidate);
  if (!candidate) $('#modal-error').insertAdjacentHTML('beforebegin', memoriesHTML(id));
};
function traineeDetail_evolution(id) {
  evolutionTraineeDetail(id);
  $('#modal-error').insertAdjacentHTML('beforebegin', memoriesHTML(id));
};
function storyModal(id) {
  const st = game.s.stories.find(x => x.id === Number(id));
  if (!st) throw Error('이야기 기록이 없습니다.');
  const d = DATA.personalStories[st.kind],
  a = game.talent(st.talentId),
  p = game.personality(st.talentId),
  open = st.status === 'open' && a && st.expires >= game.s.day;
  modal(DATA.roster[st.talentId].name + ' · ' + d.title, portraitsStrip([st.talentId], 'story-portrait') + `<span class="pill">${esc(p.name)} · ${esc(DATA.roster[st.talentId].career||'우리의 아티스트')}</span><p class="story-quote">“${esc(d.body)}”</p><p>${esc(p.intro)}</p>${open?`<p>대화 기한 ${date(st.expires)} · 선호와 맞는 선택은 신뢰 +5, 다른 선택 +3 (상한100)</p><div class="story-options">${btn(d.support,'m-story-choice',`data-id="${st.id}" data-choice="support"`,'primary',game.s.cash<100)}<small>스트레스 -6 · 창작/무대 상담 선호 시 신뢰 +5</small>${btn(d.space,'m-story-choice',`data-id="${st.id}" data-choice="space"`,'soft')}<small>체력 +5 · 스트레스 -10 · 휴식 상담 선호 시 신뢰 +5</small></div><p>기존 확정 일정은 유지됩니다. 기한이 지나도 별도 페널티는 없습니다.</p>`:`<p>${st.status==='resolved'?'대화를 마쳤습니다. 함께한 기록에 선택과 답장이 남습니다.':'대화 기한이 지났거나 계약이 종료됐습니다.'}</p>`}${btn('함께한 기록','m-memory',`data-id="${st.talentId}"`,'link')}`);
}
function momentTone() {
  if (!game.s.soundEnabled) return;
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    momentAudio = momentAudio || new AC();
    momentAudio.resume().catch (() => {
    });
    [523.25, 659.25, 783.99].forEach((hz, i) => {
      const oscillator = momentAudio.createOscillator(),
      gain = momentAudio.createGain(),
      t = momentAudio.currentTime + i * .12;
      oscillator.frequency.value = hz;
      gain.gain.setValueAtTime(0, t);
      gain.gain.linearRampToValueAtTime(.035, t + .015);
      gain.gain.exponentialRampToValueAtTime(.001, t + .28);
      oscillator.connect(gain);
      gain.connect(momentAudio.destination);
      oscillator.start(t);
      oscillator.stop(t + .3);
    });
  } catch {
  }
}
function momentModal(id) {
  const m = game.s.moments.find(x => x.id === Number(id));
  if (!m) throw Error('기념 기록이 없습니다.');
  m.seen = true;
  save();
  modal('함께 만든 순간', `<section class="milestone-scene">${portraitsStrip(m.ids)}<span class="eyebrow">A MOMENT TO REMEMBER</span><h2>${esc(m.title)}</h2><p>${esc(m.body).replace(/\n/g,'<br>')}</p><small>${date(m.day,true)} · ${esc(game.s.company)}</small></section><div class="modal-actions">${btn('다음 순간 / 계속','m-next-moment','','primary')}${btn('목표와 보상','nav','data-page="goals"','soft')}${btn('모두 건너뛰기','m-skip-moments','','link')}</div><small>건너뛴 순간도 홈·목표 화면에서 다시 볼 수 있습니다.</small>`);
  momentTone();
}
function nextMoment() {
  const m = game.s.moments.find(x => !x.seen);
  if (m) return momentModal(m.id);
  close();
  render();
}
function outcomeHTML(o) {
  const settlement = outcomeSettlementHTML(o);
  if (o.kind === 'ad') return settlement + `<section class="activity-scene">${portraitsStrip(o.ids)}<span class="eyebrow">CAMPAIGN COMPLETE</span><h2>${esc(o.title)}</h2></section><p>촬영을 완료했습니다. 잔금은 ${date(o.day+DATA.rules.advertisement.balanceDays)} 입금 예정이며, 아티스트 약정 배분을 차감합니다.</p><p>중단된 음반 제작은 오늘부터 재개합니다. 활동 화면에서 남은 제작일과 변경된 완료일을 확인하세요.</p>`;
  const commentary = o.kind === 'live' ?(o.attendance === o.capacity ? '관객으로 가득 찬 객석이 마지막 곡까지 함께했습니다.': o.attendance > 0 ? '작은 객석에서도 우리의 음악을 듣는 사람들이 있었습니다.': '관객 확보에 어려움을 겪었습니다. 팬층에 맞는 규모부터 다시 준비해 보세요.'): o.quality >= 75 ? '준비한 음악과 표현이 좋은 반응으로 이어졌습니다.': '이번 활동의 경험을 다음 무대에 이어 가세요.';
  return settlement + `<section class="activity-scene">${portraitsStrip(o.ids)}<span class="eyebrow">${o.kind==='live'?'ON STAGE':o.kind==='single'?'NEW RELEASE':'OUR MUSIC'}</span><h2>${esc(o.title)}</h2><p>“${o.quality>=75?'오늘의 무대를 오래 기억할 것 같아요.':'다음에는 조금 더 잘 전하고 싶어요.'}”</p></section><p>${commentary}</p>${o.factors?.length?`<section class="tip"><strong>실제 결과에 반영된 요인</strong>${o.factors.map(x=>`<p>${esc(x)}</p>`).join('')}</section>`:''}<div class="result-metrics"><div><small>완성도</small><strong>${Math.round(o.quality)}</strong></div><div><small>새로운 팬</small><strong>+${o.fans.toLocaleString()}명</strong></div>${o.kind==='live'?`<div><small>유료 관객</small><strong>${o.attendance} / ${o.capacity}</strong></div><div><small>회사 손익</small><strong class="${o.net>=0?'positive':'negative'}">${money(o.net)}</strong></div>`:''}</div><p>${o.kind==='live'?'공연 손익은 제작비·현장비·아티스트 배분 포함. 훈련·고정비 별도. 실제 정산은 종료7일 후 입금됩니다.':o.kind==='single'?'발매 시점의 반응입니다. 실제 흥행은 판매·재생으로 판정하고 매주 정산합니다.':'활동 완료 기록입니다. 실제 입출금은 재정에서 확인하세요.'}</p>`;
}
const evolutionReportDetail = reportDetail_app;
function reportDetail_evolution(r) {
  if (r.storyId) {
    const st = game.s.stories.find(x => x.id === r.storyId);
    return `<h2>${esc(r.title)}</h2><p class="report-content">${esc(r.body)}</p>${st?btn(st.status==='open'?'이야기 듣기':'대화 기록','m-story',`data-id="${st.id}"`,'primary'):''}`;
  }
  let html = evolutionReportDetail(r);
  if (r.outcomeId) {
    const o = game.s.outcomes.find(x => x.id === r.outcomeId);
    if (o) html = outcomeHTML(o) + `<details><summary>상세 정산 보고</summary>${html}</details>`;
  }
  if (r.talentId !== undefined) html += btn('인물·함께한 기록', 'm-memory', `data-id="${r.talentId}"`, 'soft');
  if (r.goalRewardIds) html += btn('목표와 지급 보상', 'nav', 'data-page="goals"', 'primary');
  if (r.weeklySummary || r.title === '육성 담당 주간 보고') html += `<div class="row wrap">${btn('연습생 관리','nav','data-page="training"','soft')}${btn('재정','nav','data-page="finance"','soft')}</div>`;
  return html;
};
function goals_evolution() {
  const allRows = game.goalList(),
  rows = allRows.filter(g => goalView === 'all' ||(goalView === 'done' ? g.done: !g.done)),
  offers = game.s.specialOffers;
  return heading('성장 목표와 보상', '날짜 진행 시 달성을 확인하고 1회 자동 지급합니다. 지원금은 영업이익에 포함하지 않습니다.') + `<div class="reward-wallet panel"><h2>사용 가능한 지원</h2><p>싱글 제작비5% 할인권 ${game.s.perks.productionVoucher}장 (최대200만 원) · 싱글 홍보 ${game.s.perks.debutPromo}회 · 공연 홍보 ${game.s.perks.livePromo}회</p><small>해당 활동의 다음 승인에 자동 적용. 할인은 기본 제작비만 적용하며 홍보·제조비는 별도. 홍보 지원은 관심/관객 수요 +8%, 흥행 보장 없음.</small></div><div class="tabs section">${[['all','전체'],['progress','진행 중'],['done','달성 완료']].map(([key,label])=>btn(label,'m-goal-filter',`data-filter="${key}"`,goalView===key?'active':'')).join('')}</div><div class="two-col section">${rows.map(g=>`<article class="panel goal-card ${g.done?'goal-done':''}"><span class="pill">${g.done?'달성 완료':'진행 중'}</span><h2>${esc(g.title)}</h2><p>${esc(g.reward.description)}</p><div class="bar" role="progressbar" aria-label="${esc(g.title)}" aria-valuemin="0" aria-valuemax="${g.target}" aria-valuenow="${Math.floor(Math.min(g.value,g.target))}"><span style="width:${g.done?100:Math.max(0,Math.min(100,g.value/g.target*100))}%"></span></div><p>${g.done?'회사 연혁에 기록됨':Math.floor(Math.min(g.value,g.target)).toLocaleString()+' / '+g.target.toLocaleString()}</p><strong>${esc(g.reward.text)}</strong><small>${g.paid?'자동 지급 완료':g.done?'다음 날짜 진행 시 보상 반영':'날짜 진행 시 달성 확인·자동 지급'}</small>${g.done&&game.s.moments.some(m=>m.title===g.title)?btn('기념 장면','m-moment',`data-id="${game.s.moments.find(m=>m.title===g.title).id}"`,'link'):''}</article>`).join('')}</div>` + panel('특별 활동 제안', offers.map(o => `<div class="contract-row"><h3>${esc(DATA.specialOffers[o.kind].title)}</h3><p>${esc(DATA.specialOffers[o.kind].note)}</p><p>${o.used?'승인 완료':o.expires<game.s.day?'기한 종료':'제안 기한 '+date(o.expires)}</p>${btn('대상과 비용 검토','m-offer',`data-id="${o.id}"`,'soft',o.used||o.expires<game.s.day)}</div>`).join('') || '<p>팬·스타·업계 목표를 달성하면 제안이 도착합니다.</p>');
};
function offerModal(id) {
  const o = game.s.specialOffers.find(x => x.id === Number(id));
  if (!o) throw Error('제안이 없습니다.');
  const d = DATA.specialOffers[o.kind],
  eligible = game.entities.filter(e => game.offerEligible(o, e.key));
  modal(d.title, `<p>${esc(d.note)}</p><p>특별 캠페인: 싱글 초기 관심 +4% / 공연 홍보 수요 +8%. 일반 배분·회복·일정 규칙이 적용됩니다.</p>${eligible.map(e=>{const q=game.projectQuote(e.key,d.kind,d.budget);return `<article class="contract-row"><h3>${esc(e.name)}</h3><p>실제 승인비 ${money(q.total)}${q.discount?' · 할인 '+money(q.discount):''} / 승인 후 ${money(game.s.cash-q.total)}</p>${btn('이 대상으로 활동 승인','m-offer-accept',`data-id="${o.id}" data-key="${e.key}"`,'primary',game.busy(e.key)||e.members.some(a=>a.recoveryUntil>game.s.day||a.energy<25)||game.s.cash<q.total)}</article>`;}).join('')||'<p>현재 조건을 충족하는 대상이 없습니다. 팬·현재 스타 등급·영업이익·회사 단계를 확인하세요.</p>'}<p>추가 실물 제조 없이 진행합니다. 지원 할인권은 해당되는 경우 자동 적용합니다. 제안 기한 ${date(o.expires,true)}</p>`);
}
const evolutionProjectModal = projectModal_operations;
function projectModal_evolution(key) {
  evolutionProjectModal(key);
  budgetPreview();
};
function budgetPreview_evolution() {
  const kind = $('#project-kind')?.value || 'single',
  key = $('#entity')?.value || game.entities[0]?.key,
  b = Number($('#budget')?.value || 2000),
  e = game.entity(key),
  options = { format: $('#release-format')?.value || 'digital', quantity: Number($('#release-quantity')?.value || 1000), promotion: $('#promotion')?.value || 'none' },
  q = game.projectQuote(key, kind, b, options),
  box = $('#release-options');
  if (box) box.hidden = kind !== 'single';
  let caution = '완성도와 흥행은 다릅니다. 제작비는 즉시 집행하며 회수는 보장되지 않습니다.';
  if (kind === 'single') caution = b === 1000 ? '신인 제작: 적은 초기 투자로 시작합니다. 투자 규모에 따른 완성도 기여는 작으며 판매·재생은 발매 후 집계합니다.': '작품은 발매 이후 장기 정산됩니다. 팬층과 후속 활동이 수요에 영향을 줍니다.';
  if (kind === 'cover') caution = '직접 수익보다 노출을 위한 활동입니다. 최근 커버의 관심은 다음 싱글에 최대16% 반영되며60일 동안 감소합니다. 반복 효과는 줄어듭니다.';
  if (kind === 'live' && e) {
    const team = e.members.length > 1,
    cap = b <= 300 ?(team ? 500: 200): b <= 800 ?(team ? 1400: 700):(team ? 3200: 1800),
    fans = e.members.reduce((n, a) => n + a.fans, 0),
    recent = game.s.performance.filter(p => p.kind === 'live' && p.day > game.s.day - 30 && p.ids.some(id => e.members.some(a => a.id === id))).length;
    caution = `수용 ${cap}명 · ${fans<cap?'현재 팬층에 비해 공연장이 큽니다. 신규 관객 확보가 필요합니다.':'팬층에 맞는 규모와 관객 반응을 함께 확인하세요.'} ${recent?'최근30일 공연 '+recent+'회 · 반복 수요 둔화가 적용됩니다.':''} 신곡 발매 후45일은 관심에 도움이 됩니다.`;
  }
  const due = game.s.day +(DATA.rules.activity[kind]?.days || 0) +(kind === 'single' ? DATA.promotionPlans[options.promotion].days: 0),
  forecast = game.cashForecast().find(x => x.amount < 0),
  p = kind === 'single' && game.s.perks.debutPromo ? '싱글 홍보 지원 자동 사용 · 초기 관심 +8%': kind === 'live' && game.s.perks.livePromo ? '공연 홍보 지원 자동 사용 · 관객 수요 +8%': '';
  $('#budget-preview').innerHTML = `<strong>총 집행 ${money(q.total)}</strong><br>기본 제작 ${money(q.base)}${q.discount?' − 할인 '+money(q.discount):''} + 제조 ${money(q.manufacturing)} + 홍보 ${money(q.promo)}<br>승인 후 잔액 <strong class="${game.s.cash<q.total?'negative':''}">${money(game.s.cash-q.total)}</strong><br>${forecast?'가까운 지출 '+date(forecast.day)+' · '+money(-forecast.amount)+' ('+esc(forecast.label)+')<br>':''}활동 완료 ${date(due)} · ${kind==='live'?'종료7일 후 정산':kind==='single'?'발매일부터7일 단위 정산':'직접 정산 없음'}${p?'<br>'+p:''}<p>${caution}</p><small>미래 일 훈련비·신규 지출 별도. 정확한 관객·수익·성공 확률은 미리 확정되지 않습니다.</small>`;
};
function teamSummary(e) {
  const p = game.teamProfile(e);
  return `<p><strong>${DATA.specs[p.strength]} 강점 · ${DATA.specs[p.weak]} 보완</strong></p><p>협업 호흡 ${p.cohesion.toFixed(1)} / 100 · 역할 ${p.roles}종</p><small>각 분야의 강점이 팀 평균을 보완합니다. 함께한 활동과 안정적인 연습으로 호흡이 성장하며 멤버 변경 시 일부 조정됩니다.</small>`;
}
const evolutionTeams = teams_management, evolutionUnitModal = unitModal_app;
function teams_evolution() {
  return evolutionTeams() + panel('팀 프로필과 개인 활동', game.s.units.map(u => {
    const e = game.entity(u.key);
    return `<article class="contract-row">${portraitsStrip(u.ids,'team-lineup')}<h3>${esc(u.name)}</h3>${teamSummary(e)}${btn('팀 활동 준비','project-modal',`data-entity="${u.key}"`,'primary',u.status!=='active'||u.ids.length<2)}<div class="row wrap">${u.ids.map(id=>btn(DATA.roster[id].name+' 개인 활동','project-modal',`data-entity="${id}"`,'soft small')).join('')}</div><small>개인 활동도 가능하지만 같은 멤버의 팀·개인 일정은 겹칠 수 없습니다.</small></article>`;
  }).join('') || '<p>팀을 결성하면 단체 프로필과 협업 상태를 볼 수 있습니다.</p>');
};
function unitModal_evolution() {
  evolutionUnitModal();
  $('#modal-error').insertAdjacentHTML('beforebegin', '<div id="team-composition" aria-live="polite"><p>멤버를 선택하면 조합의 강점과 보완점을 표시합니다.</p></div>');
};
const evolutionStaffDetail = staffDetail_operations;
function staffDetail_evolution(id) {
  evolutionStaffDetail(id);
  const p = DATA.staff.find(x => x.id === id),
  current = game.s.staff.map(x => DATA.staff.find(y => y.id === x)).filter(x => x.kind === p.kind),
  best = Math.max(0, ... current.map(x => x.coaching));
  let message = p.kind === 'trainer' ? '육성은 훈련 분야별 최적 직원1명을 적용합니다. 기존 직원보다 적합한 전문 분야가 있을 때 효과가 바뀌며 성장·절감률은 중복 합산하지 않습니다.': current.length ?(p.coaching > best ? '현재 직무 최고 능력을 갱신합니다.': '현재 최고 직무 능력보다 낮거나 같아 직무 보너스가 늘지 않습니다.'): '해당 직무의 첫 전문 직원입니다.';
  $('#modal-error').insertAdjacentHTML('beforebegin', `<section class="tip"><strong>추가 채용 효과</strong><p>${message}</p><small>관리 정원 증가는 해당 직무 보유 여부로 적용하며 같은 직무 추가 인원만큼 늘지 않습니다.</small></section>`);
};
const evolutionStaffScreen = staffScreen_operations;
function staffScreen_evolution() {
  const x = game.s.staffImpact;
  return evolutionStaffScreen() + panel('직원의 실제 기여', `<p>기록 시작 ${date(x.since)} 이후 연습생 훈련비 <strong>${money(x.saved)}</strong> 절감</p><p>직원 지도 훈련 ${x.trainingDays}인일 · 자동 회복 조정 ${x.recoveryDays}인일</p><small>실제로 실행한 연습생 훈련·회복만 집계합니다. 능력 성장의 차이를 가정해서 소급 계산하지 않습니다.</small>`);
};
const evolutionReleaseModal = releaseModal_market;
function releaseModal_evolution(uid) {
  evolutionReleaseModal(uid);
  const c = game.allReleases().find(x => x.release.market.uid === uid)?.release;
  if (c?.market.resurfaceUntil > game.s.day) $('#modal-error').insertAdjacentHTML('beforebegin', `<p class="pill">다시 듣는 음악 · ${esc(c.market.resurfaceReason)} · ${date(c.market.resurfaceUntil-1)}까지 관심 보강</p>`);
};
const evolutionSettings = settings_app;
function settings_evolution() {
  evolutionSettings();
  if (game.s) $('#modal-error').insertAdjacentHTML('beforebegin', `<div class="row wrap section">${btn('기념 순간 효과음: '+(game.s.soundEnabled?'켜짐':'꺼짐'),'m-sound','','soft')}${btn('기념 순간 모아 보기','m-moments','','soft')}</div><small>효과음은 짧은 합성음이며 기본은 꺼짐입니다.</small>`);
};
const evolutionMutate = mutate_app;
function mutate_evolution(fn, message) {
  evolutionMutate(fn, message);
  if (saveOK && game.s?.moments.some(m => !m.seen)) nextMoment();
};
function showAdvanceNotice_evolution() {
  if (!game.s || !lastAdvanceNotice) return;
  if (!saveOK) {
    modal('저장 확인 필요', progressSummaryContent() + btn('설정·백업', 'settings', '', 'primary'));
    return;
  }
  if (game.s.moments.some(m => !m.seen)) return nextMoment();
  const result = game.s.outcomes.filter(o => o.day > lastAdvanceNotice.from && o.day <= lastAdvanceNotice.to).at(- 1);
  if (result) return modal('활동을 마쳤습니다', outcomeHTML(result) + btn('계속', 'close', '', 'primary'));
  if (game.pending.length) return modal('확인할 소식이 있습니다', progressSummaryContent() + btn('수신함 확인', 'nav', 'data-page="inbox"', 'primary'));
  toast((lastAdvanceNotice.to - lastAdvanceNotice.from) + '일 진행 완료 · 활동 결과와 수신함을 확인하세요.');
};
const evolutionManagementClick = managementClick_operations;
function managementClick_evolution(action, d) {
  switch (action) {
    case 'm-goal-filter': goalView = ['all', 'progress', 'done'].includes(d.filter) ? d.filter: 'all';
    render();
    return;
    case 'm-skip-moments': game.s.moments.forEach(m => m.seen = true);
    save();
    close();
    render();
    return;
    case 'm-memory': {
      const a = game.talent(Number(d.id)) || game.s.departed.find(x => x.id === Number(d.id));
      if (!a) throw Error('인물 기록이 없습니다.');
      return modal(DATA.roster[a.id].name + ' · 함께한 기록', portraitsStrip([a.id], 'story-portrait') + a.memories.slice().reverse().map(m => `<article class="contract-row"><small>${date(m.day,true)}</small><p>${esc(m.text)}</p></article>`).join(''));
    }
    case 'm-story': return storyModal(d.id);
    case 'm-story-choice': return mutate(() => game.resolveStory(d.id, d.choice), '대화를 기록했습니다.');
    case 'm-moment': return momentModal(d.id);
    case 'm-next-moment': return nextMoment();
    case 'm-moments': return modal('함께 만든 순간', game.s.moments.slice().reverse().map(m => `<article class="contract-row"><h3>${esc(m.title)}</h3><small>${date(m.day,true)}</small>${btn('다시 보기','m-moment',`data-id="${m.id}"`,'soft')}</article>`).join('') || '<p>첫 순간을 기다리고 있습니다.</p>');
    case 'm-offer': return offerModal(d.id);
    case 'm-offer-accept': return mutate(() => game.acceptOffer(d.id, d.key), '특별 활동을 승인했습니다.');
    case 'm-all-tasks': return modal('오늘의 전체 할 일', todayTasks().map(t => btn(esc(t.label), t.action, t.args, 'task-button')).join(''));
    case 'm-sound': game.s.soundEnabled = !game.s.soundEnabled;
    save();
    settings();
    if (game.s.soundEnabled) momentTone();
    return;
    default: throw Error("처리할 수 없는 동작입니다.");
  }
};
UIEvents.onChange('evolution', ev => {
  try {
    const t = ev.target;
    if (t.id === 'spotlight-select') {
      game.s.pinnedEntity = t.value || null;
      save();
      render();
    }
    if (t.closest?.('#unit-form') && t.name === 'members') {
      const ids = [...(document.querySelectorAll?.('#unit-form input[name="members"]:checked') ||[])].map(x => Number(x.value)),
      e = { key: 'preview', type: DATA.roster[ids[0]]?.type || 'idol', members: ids.map(id => game.artist(id)) };
      $('#team-composition').innerHTML = ids.length >= 2 ? teamSummary(e): '<p>멤버2명 이상을 선택하세요.</p>';
    }
  } catch (e) {
    toast(e.message);
  }
});


;
