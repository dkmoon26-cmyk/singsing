/* FILE src/app-clicks.js */
'use strict';
// app-clicks: see docs/MAINTENANCE.md for ownership and loading order.
$('#app').addEventListener('click', handleClick);
$('#modal-root').addEventListener('click', handleClick);
function handleClick(ev) {
  let b = ev.target.closest('[data-action]');
  if (!b) return;
  let action = b.dataset.action,
  id = b.dataset.id;
  if (running && action !== 'stop') return;
  try {
    if (action.startsWith('m-')) return managementClick(action, b.dataset);
    switch (action) {
      case 'close': close();
      break;
      case 'new': newModal();
      break;
      case 'continue': {
        let s = loadSaved(true);
        if (!validState(s)) throw Error('저장 정보를 읽을 수 없습니다. 백업을 불러와 주세요.');
        game = new Game(s);
        $('#app').insertAdjacentHTML('beforeend', '<div class="loading-progress"><div><div class="brand" style="justify-content:center">NEXT STAGE</div><h2 style="margin-top:16px">우리의 다음 무대를 준비하고 있어요.</h2><div class="bar"><span></span></div><small>당신의 아티스트들이 기다리고 있습니다.</small></div></div>');
        setTimeout(() => {
          page = 'home';
          render();
        }, 850);
        break;
      }
      case 'nav': navigate(b.dataset.page);
      break;
      case 'more': modal('회사 업무', `<div class="list">${[['casting','캐스팅 · 인재 발굴'],['staff','직원·회사'],['finance','재정·기록'],['training','연습생·데뷔'],['teams','팀·계약'],['company','회사·가치'],['industry','업계·라이벌'],['goals','목표'],['schedule','통합 일정']].map(([p,n])=>btn(n,'nav',`data-page="${p}"`,'soft')).join('')}${btn('설정 · 저장','settings')}</div>`);
      break;
      case 'latest-save': reviewLatestSave();
      break;
      case 'settings': settings();
      break;
      case 'guide-hide': mutate(() => {
        game.s.guideHidden = true;
      }, '가이드를 건너뛰었습니다. 설정에서 다시 켤 수 있습니다.');
      break;
      case 'guide-toggle': game.s.guideHidden = !game.s.guideHidden;
      save();
      render();
      settings();
      break;
      case 'day': advance();
      break;
      case 'skip': close();
      skip();
      break;
      case 'stop': running = false;
      stopReason = '사용자가 진행을 중지했습니다.';
      if (lastAdvanceNotice) lastAdvanceNotice.stop = stopReason;
      save();
      render();
      break;
      case 'casting-modal': castingModal();
      break;
      case 'candidate': artistModal(+ id, true);
      break;
      case 'artist': artistModal(+ id);
      break;
      case 'evaluate': game.evaluate(+ id);
      save();
      artistModal(+ id, true);
      break;
      case 'sign': mutate(() => game.sign(+ id), '새로운 아티스트와 함께하게 되었습니다.');
      break;
      case 'filter': filter = b.dataset.filter;
      render();
      break;
      case 'unit-modal': unitModal();
      break;
      case 'project-modal': projectModal(b.dataset.entity);
      break;
      case 'report': showReport(id, true);
      break;
      case 'open-report': showReport(id, false);
      break;
      case 'resolve': mutate(() => game.resolve(+ id, b.dataset.choice), '안건을 처리했습니다.');
      break;
      case 'rescue': mutate(() => game.rescue(+ id), '회생 지원금을 받았습니다.');
      break;
      case 'read-info': mutate(() => game.markGeneralRead(), '일반 보고를 읽음 처리했습니다.');
      break;
      case 'staff-confirm': {
        let p = DATA.staff.find(x => x.id === id),
        h = game.has(id);
        modal(h ? '직원 퇴직 협의': '직원 채용 승인', `<h3>${p.name} · ${p.role}</h3><p class="report-content">${h?'퇴직 정산금 '+money(p.salary)+'을 지출합니다. 남은 직원과 실장이 업무를 분담합니다.':'채용비 '+money(p.fee)+' / 월 급여 '+money(p.salary)+'\n'+p.spec+' 업무를 담당합니다. 직무별 정원 효과는 직원 화면에서 확인하세요.'}</p><div class="modal-actions">${btn(h?'퇴직 승인':'채용 승인',h?'fire':'hire',`data-id="${id}"`,'primary')}</div>`);
        break;
      }
      case 'hire': mutate(() => game.hire(id), '직원을 채용했습니다.');
      break;
      case 'fire': mutate(() => game.fire(id), '퇴직 정산을 완료했습니다.');
      break;
      case 'loan-modal': modal('운영자금 대출', `<form id="loan-form"><div class="tip">현재 추가 가능 한도 ${money(Math.max(0,game.loanLimit-game.debt))}<br>12개월 원금 분할 상환 · 월 이자 잔액의 0.6% · 조기 상환 수수료 없음</div><div class="field section"><label for="amount">대출 금액</label><select name="amount" id="amount"><option value="1000">1,000만 원 · 월 원금 약 83만 + 이자</option><option value="3000">3,000만 원 · 월 원금 250만 + 이자</option><option value="5000">5,000만 원 · 월 원금 약 417만 + 이자</option></select></div><small>첫 납부는 실행 후 최소 30일이 지난 월 정산일입니다. 연체 시 이자가 원금에 가산됩니다.</small><div class="modal-actions"><button class="primary">대출 실행 승인</button></div></form>`);
      break;
      case 'repay-confirm': {
        let l = game.s.loans.find(l => l.id === + id);
        modal('대출 조기 상환', `<p>잔액 ${money(l.remaining)}을 전액 상환합니다.</p><div class="modal-actions">${btn('상환 승인','repay',`data-id="${id}"`,'primary')}</div>`);
        break;
      }
      case 'repay': mutate(() => game.repay(+ id), '상환을 완료했습니다.');
      break;
      case 'renew': mutate(() => game.renew(+ id), '재계약을 완료했습니다.');
      break;
      case 'manual-save': if (save()) toast('현재 진행을 저장했습니다.');
      break;
      case 'export': {
        let s = game.s || loadSaved();
        if (!s) throw Error('백업할 진행이 없습니다.');
        let blob = new Blob([JSON.stringify(s, null, 2)], { type: 'application/json' }),
        url = URL.createObjectURL(blob),
        a = document.createElement('a');
        a.href = url;
        a.download = 'next-stage-save-day-' + s.day + '.json';
        document.body.appendChild(a);
        a.click();
        a.remove();
        try { localStorage.setItem(BACKUP_META_KEY, JSON.stringify({company:s.company, boss:s.boss, day:s.day, at:Date.now()})); } catch {}
        if (game.s) render();
        if ($('#modal-root').children.length) settings();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        toast('백업 다운로드를 요청했습니다. 다운로드 폴더를 확인해 주세요.');
        break;
      }
      case 'to-title':
      if (game.s && !save()) {
        if ($('#modal-error')) $('#modal-error').textContent = '저장하지 못해 현재 게임을 유지했습니다. 백업 내보내기로 진행을 보관해 주세요.';
        break;
      }
      close();
      title();
      break;
    }
  } catch (e) {
    if ($('#modal-error')) $('#modal-error').textContent = e.message;
    else toast(e.message);
  }
}


;
