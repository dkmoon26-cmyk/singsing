/* FILE src/progression-ui.js */
'use strict';
const originalCompany = company_management, originalFinance = finance_app, originalIndustry = industry_management, originalManagementClick = managementClick_management;
let pendingRestore = null;
;
function company_progression() {
  return originalCompany() + panel('회사 이미지', `<h2>${game.s.image.toFixed(1)} / 100</h2><p>평판은 활동 성과, 이미지는 운영 신뢰를 뜻합니다. 사건·대응과 안정적인 활동에 따라 변합니다.</p><p>이미지는 관객 수요·신규 팬·광고 대가·기업가치에 영향을 줍니다. 이미 발생한 사건 피해를 즉시 모두 되돌릴 수는 없습니다.</p><h3>최근 사건</h3>${game.s.incidents.slice(0,8).map(i=>`<div class="contract-row"><strong>${Game.incidentTypes[i.kind].title} · ${esc(i.name)}</strong><p>${date(i.day)} · ${i.state==='closed'?'처리 완료':i.state==='investigating'?'조사 중':'대응 필요'} · 최초 팬 이탈 ${i.losses.reduce((n,x)=>n+x.lost,0)}명 · 회복 ${i.recovered}명</p>${i.state==='open'?btn('사건 보고','m-incident-open',`data-id="${i.id}"`,'soft'):''}</div>`).join('')||'<p>사건 이력 없음</p>'}`);
};
function finance_progression() {
  return originalFinance() + activityFinanceHTML();
};
function industry_progression() {
  return originalIndustry() + panel('라이벌 운영 상태', game.s.rivals.map(r => `<div class="contract-row"><h3>${esc(r.name)}</h3><p>최근 행동: ${esc(r.lastAction)} · 활동 인원 ${r.talents.filter(t=>t.active).length} / 연습생 ${r.talents.filter(t=>!t.active).length}</p><p>회사 이미지 추정 ${Math.round(r.image/10)*10} · 신작·공연·육성·홍보·긴축·재계약·영입을 자금과 인재 상태에 따라 결정합니다.</p></div>`).join(''));
};
function incidentReport(r) {
  let i = game.s.incidents.find(i => i.id === r.incidentId);
  if (!i) return `<h2>${esc(r.title)}</h2><p>${esc(r.body)}</p>`;
  return `<h2>${esc(r.title)}</h2><div class="report-content">${esc(r.body)}</div><p>회사 이미지 ${game.s.image.toFixed(1)} / 100 · ${i.state==='closed'?'처리 완료':i.state==='investigating'?'조사 중 · 완료 '+date(i.responseDue):'대응 기한 '+date(i.expires)}</p>${i.state==='open'?`<div class="list">${btn('공식 설명 · '+money(100*i.severity)+' · 팬 20% 회복','m-incident-respond',`data-id="${i.id}" data-choice="explain"`,'soft')}${btn('보완 행사 · '+money(300*i.severity)+' · 팬 50% 회복','m-incident-respond',`data-id="${i.id}" data-choice="repair"`,'primary')}${btn('3일 조사·결과 공개 · '+money(50*i.severity)+' · 팬 30% 회복','m-incident-respond',`data-id="${i.id}" data-choice="investigate"`)}${btn('미대응 · 추가 이미지 하락·팬 이탈','m-incident-respond',`data-id="${i.id}" data-choice="ignore"`,'danger')}</div><p>회복 비율은 이번 사건으로 이탈한 팬 기준입니다. 회사에 남은 대상만 회복합니다. 자금 부족 시 유료 대응은 실행되지 않습니다.</p>`:''}`;
}
function savePanel() {
  let points = saveStore.checkpoints();
  modal('저장 슬롯·복구 지점', `<p>자동 저장 외에 수동 슬롯 3개와 복구 지점 3개를 보관합니다. 브라우저별로 분리되므로 JSON 백업도 권장합니다.</p><div class="list">${[1,2,3].map(index=>{let entry=saveStore.read(saveStore.slot(index)),valid=entry&&validState(entry.state);return `<section class="panel"><h3>슬롯 ${index}</h3><p>${valid?esc(entry.state.company)+' · '+date(entry.state.day,true):entry?'저장 손상·불러오기 불가':'비어 있음'}</p><div class="row wrap">${btn('현재 진행 저장','m-slot-save-confirm',`data-index="${index}"`,'soft',!game.s)}${btn('불러오기','m-slot-load',`data-index="${index}"`,'',!valid)}${btn('슬롯 비우기','m-slot-delete-confirm',`data-index="${index}"`,'link',!entry)}</div></section>`;}).join('')}<h3>자동 복구 지점</h3>${btn('복구 지점 비우기','m-points-clear-confirm','','link',!points.length)}<p>저장 공간이 부족하면 JSON 백업 후 사용하지 않는 슬롯이나 복구 지점을 비워주세요.</p>${points.map((p,index)=>`<section class="panel"><strong>${esc(p.reason)}</strong><p>${esc(p.state.company)} · ${date(p.state.day,true)}</p>${btn('복원 검토','m-point-load',`data-index="${index}"`,'soft')}</section>`).join('')||'<p>아직 복구 지점이 없습니다.</p>'}</div>`, true);
}
function previewRestore(state, label, expectedAuto) {
  pendingRestore = { state: JSON.parse(JSON.stringify(state)), label, expectedAuto };
  modal('저장 복원 확인', `<h3>${esc(state.company)}</h3><p>${date(state.day,true)} · 현금 ${money(state.cash)}</p><p>${esc(label)}의 상태로 자동 저장과 현재 진행을 교체합니다. 진행 중인 게임이 있으면 복구 지점으로 보관합니다.</p>${btn('이 저장으로 복원','m-restore-apply','','primary')}`);
}
function applyRestore_progression() {
  if (!pendingRestore) throw Error('복원할 저장을 다시 선택하세요.');
  let restored = new Game(pendingRestore.state);
  if (!validState(restored.s)) throw Error('저장을 변환하지 못했습니다.');
  let previous = game.s || loadSaved();
  if (previous && validState(previous)) saveStore.checkpoint(previous, '저장 복원 전');
  saveStore.writeAuto(restored.s, pendingRestore.expectedAuto);
  game = restored;
  pendingRestore = null;
  page = 'home';
  running = false;
  stopReason = '';
  saveOK = true;
  close();
  render();
  toast('저장을 복원했습니다.');
}
function managementClick_progression(action, d) {
  switch (action) {
    case 'm-saves': return savePanel();
    case 'm-slot-save-confirm': {
      let index = Number(d.index);
      saveStore.slot(index);
      let old = saveStore.read(saveStore.slot(index));
      if (!old) return managementClick('m-slot-save', d);
      modal('슬롯 덮어쓰기 확인', `<p>슬롯 ${index}를 현재 회사 진행으로 교체합니다. 정상인 기존 슬롯은 복구 지점으로 보관합니다.</p>${btn('슬롯 교체 승인','m-slot-save',`data-index="${index}"`,'primary')}`);
      return;
    }
    case 'm-slot-save': {
      if (!game.s) throw Error('진행 중인 회사가 없습니다.');
      let index = Number(d.index),
      old = saveStore.read(saveStore.slot(index));
      if (old && validState(old.state)) saveStore.checkpoint(old.state, '슬롯 ' + index + ' 덮어쓰기 전');
      saveStore.saveSlot(index, game.s);
      savePanel();
      toast('슬롯에 저장했습니다.');
      return;
    }
    case 'm-slot-load': return previewRestore(saveStore.loadSlot(Number(d.index)), '슬롯 ' + d.index);
    case 'm-point-load': return previewRestore(saveStore.restorePoint(Number(d.index)), '복구 지점');
    case 'm-restore-apply': return applyRestore();
    case 'm-incident-open': {
      let r = game.s.reports.find(r => r.incidentId === Number(d.id));
      if (r) return showReport(r.id, true);
      throw Error('사건 보고가 없습니다.');
    }
    case 'm-incident-respond': return mutate(() => game.respondIncident(d.id, d.choice), '사건 대응을 진행했습니다.');
    default: throw Error("처리할 수 없는 동작입니다.");
  }
};
UIEvents.onChange('progression', ev => {
  if (ev.target.id === 'entity') budgetPreview();
});
;


;
