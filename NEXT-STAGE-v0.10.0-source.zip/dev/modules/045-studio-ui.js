/* FILE src/studio-ui.js */
'use strict';
// Presentation only: every action delegates to the existing game handlers.
let studioArchiveOpen = false;
function home_studio() {
  const s = game.s, tasks = todayTasks(), events = scheduleEvents()
    .filter(x => x.end >= s.day && x.start <= s.day + 7)
    .sort((a, b) => Math.max(s.day, a.start) - Math.max(s.day, b.start));
  const people = [...s.artists, ...s.trainees], focus = spotlightEntity();
  const forecast = game.cashForecast(), outgoing = forecast.find(x => x.amount < 0), incoming = forecast.find(x => x.amount > 0);
  const profit = s.monthIn - s.monthOut, urgent = tasks.filter(t => t.priority === 0).length;
  const sectionHead = (title, note, action = '') => `<div class="studio-section-head"><div><h2>${title}</h2><p>${note}</p></div>${action}</div>`;
  return `<div class="studio-dashboard">
    <section class="studio-hero" aria-label="기획사 운영 현황">
      <div class="studio-hero-copy"><span class="eyebrow">YOUR AGENCY, YOUR NEXT STAGE</span><h1>오늘도, 다음 무대를 향해.</h1><p>${esc(s.company)}의 이야기는 오늘도 이어집니다.<br>${focus?`${esc(focus.name)}의 다음 활동을 함께 준비해 보세요.`:'첫 인재를 만나 우리만의 음악을 시작하세요.'}</p><div class="row wrap">${focus?btn('다음 활동 준비 '+ico('arrow'),'project-modal',`data-entity="${focus.key}"`,'primary'):btn('첫 인재 만나기 '+ico('arrow'),'casting-modal','','primary')}${btn('회사 운영 살펴보기','nav','data-page="company"','hero-secondary')}</div><span class="studio-hero-caption">${esc(DATA.stageNames[game.stage])} · ${s.artists.length}명의 아티스트 · ${s.trainees.length}명의 연습생</span></div><div class="studio-hero-art"><img src="${focus?DATA.roster[focus.members[0].id].image:'assets/office.webp'}" alt="${focus?esc(focus.name)+' · 오늘의 아티스트':'햇빛이 드는 기획사 사무실'}"><span>${focus?'ARTIST SPOTLIGHT':'OUR FIRST CHAPTER'}</span></div>
    </section>
    <section class="studio-metrics" aria-label="핵심 경영 지표">
      <article class="studio-metric"><span class="studio-metric-icon">${ico('wallet')}</span><div><small>보유 자금</small><strong class="${s.cash<0?'negative':''}">${money(s.cash)}</strong><span>현재 사용할 수 있는 운영 자금</span></div></article>
      <article class="studio-metric"><span class="studio-metric-icon">${ico('chart')}</span><div><small>이번 달 현금 수지</small><strong class="${profit<0?'negative':'positive'}">${profit>0?'+':''}${money(profit)}</strong><span>기록된 입금 − 지출 · 대출 포함</span></div></article>
      <article class="studio-metric"><span class="studio-metric-icon">${ico('people')}</span><div><small>함께하는 인재</small><strong>${people.length}<em>명</em></strong><span>아티스트 ${s.artists.length} · 연습생 ${s.trainees.length}</span></div></article>
      <article class="studio-metric"><span class="studio-metric-icon">${ico('calendar')}</span><div><small>진행 중인 일정</small><strong>${s.jobs.length+(s.engagements?.length||0)}<em>건</em></strong><span>확인이 필요한 업무 ${tasks.length}건</span></div></article>
    </section>
    <div class="studio-workspace"><div class="studio-primary">
      <section class="panel studio-tasks">${sectionHead('오늘 결정할 일',urgent?`기한이 가까운 업무 ${urgent}건을 먼저 확인하세요.`:'중요한 결정은 대표에게, 실무는 직원에게.',tasks.length?`<span class="studio-count">${tasks.length}</span>`:'')}${tasks.length?`<div class="studio-task-list">${tasks.slice(0,5).map((t,i)=>btn(`<span class="studio-task-mark ${t.priority===0?'urgent':''}">${t.priority===0?ico('mail'):String(i+1).padStart(2,'0')}</span><span class="studio-task-copy"><strong>${esc(t.label)}</strong><small>${t.priority===0?'우선 확인이 필요한 업무':'다음 성장을 위한 선택'}</small></span>${ico('arrow')}`,t.action,t.args,'studio-task')).join('')}</div>${tasks.length>5?btn('전체 업무 '+tasks.length+'건 보기','m-all-tasks','','link section'):''}`:`<div class="studio-empty">${ico('check')}<h3>급한 업무를 모두 확인했어요.</h3><p>다음 활동을 준비하거나 하루를 진행해 보세요.</p></div>`}</section>
      ${!s.guideHidden?`<details class="studio-guide" ${s.day===0?'open':''}><summary>첫 운영 가이드 <span>시작부터 첫 정산까지</span></summary>${guideCard()}</details>`:''}
      <section class="panel studio-roster">${sectionHead('함께 성장하는 아티스트','작은 연습이 쌓여, 다음 무대가 됩니다.',btn('전체 보기','nav',`data-page="${s.artists.length?'artists':'training'}"`,'link small'))}${people.length?`<div class="studio-people">${people.slice(0,6).map(a=>{const d=DATA.roster[a.id],trainee=s.trainees.some(t=>t.id===a.id);return btn(`<img src="${d.image}" alt="" loading="lazy"><span><strong>${esc(d.name)}</strong><small>${trainee?'연습생':DATA.labels[d.type]+' 아티스트'}</small><span class="studio-condition ${a.energy<40?'tired':''}">컨디션 ${a.energy<40?'회복 필요':a.energy<70?'보통':'좋음'}</span><span class="bar"><span style="width:${Math.max(0,Math.min(100,a.energy))}%"></span></span></span>`,trainee?'m-trainee-detail':'artist',`data-id="${a.id}"`,'studio-person');}).join('')}</div>`:`<div class="studio-empty"><h3>우리의 첫 아티스트를 기다리고 있어요.</h3><p>공개 오디션과 인재 발굴에서 새로운 가능성을 만나보세요.</p>${btn('캐스팅 살펴보기','nav','data-page="casting"','soft')}</div>`}</section>
    </div><aside class="studio-secondary" aria-label="일정과 자금 계획">
      <section class="panel studio-agenda">${sectionHead('다가오는 일정','오늘부터 일주일',btn('전체 일정','nav','data-page="schedule"','link small'))}<div class="studio-event-list">${events.slice(0,5).map(x=>btn(`<span class="studio-event-date">${Math.max(s.day,x.start)===s.day?'오늘':'D-'+(x.start-s.day)}</span><span><strong>${esc(x.title)}</strong><small>${date(Math.max(s.day,x.start))}${x.end>x.start?' ~ '+date(x.end):''}</small></span>`, 'nav',`data-page="${x.page}"`,'studio-event')).join('')||'<div class="studio-empty"><p>예정된 주요 일정이 없습니다.<br>새 활동을 준비해 보세요.</p></div>'}</div></section>
      <section class="panel studio-cash">${sectionHead('앞으로의 자금 흐름','예정과 실제 지출을 구분해 확인하세요.')}<div class="studio-cash-item"><span class="pill">가까운 지출</span><strong>${outgoing?money(-outgoing.amount):'확정 지출 없음'}</strong><small>${outgoing?date(outgoing.day)+' · '+esc(outgoing.label):'등록된 지출이 없습니다.'}</small></div><div class="studio-cash-item"><span class="pill green">다음 입금</span><strong>${incoming?money(incoming.amount):'새로운 수익을 준비해요'}</strong><small>${incoming?date(incoming.day)+' · '+esc(incoming.type)+' · '+esc(incoming.label):'활동과 작품 정산이 여기에 표시됩니다.'}</small></div><p class="studio-note">현재 기록에 따른 예정 금액입니다. 추가 훈련·제작비와 향후 판매 변화는 포함하지 않습니다.</p>${btn('재정 자세히 보기','nav','data-page="finance"','soft')}</section>
    </aside></div>
    <details class="studio-archive" ${studioArchiveOpen?'open':''}><summary>함께한 기록과 최근 성과 <span>진행 기록 · 기념 순간 · 발매작</span></summary><div class="studio-archive-body">${spotlight()}${recentWeekHTML()}${panel('우리의 최근 순간',s.moments.slice(-3).reverse().map(m=>`<div class="contract-row"><small>${date(m.day)}</small><h3>${esc(m.title)}</h3>${btn('다시 보기','m-moment',`data-id="${m.id}"`,'link')}</div>`).join('')||'<p>첫 계약부터 우리의 기록이 쌓입니다.</p>')}${panel('최근 발매',s.catalog.slice(-3).reverse().map(c=>releaseRow({release:c,company:s.company,own:true})).join('')||'<p>첫 음악을 기다리고 있습니다.</p>')}</div></details>
  </div>`;
}

;
