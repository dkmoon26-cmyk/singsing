// Stable artist IDs map to individually generated studio portraits.
function nextStagePortraitUrl(path) {
  const match = /^assets\/portraits\/artist-(\d+)-anime-v\d+\.webp$/.exec(path);
  return match ? `assets/portraits/artist-${Number(match[1])}-studio-v3.webp` : path;
}

;
