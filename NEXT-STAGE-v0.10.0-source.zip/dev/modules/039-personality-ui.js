/* FILE src/personality-ui.js */
'use strict';
function personalityCard(id) {
  const p = game.personality(id),
  a = game.talent(id),
  d = DATA.roster[id];
  const trainee = a && game.s.trainees.includes(a);
  const plan = trainee ? Game.trainingPlans[p.training].name: focusLabel[p.focus];
  const remaining = a && a.lastPersonalDay !== undefined ? Math.max(0, 30 - game.s.day + a.lastPersonalDay): 0;
  return `<section class="personality-card" aria-label="${esc(d.name)}의 성격과 상담"><strong>${esc(p.name)}</strong><p>“${esc(p.intro)}”</p><p class="muted">선호 육성: ${esc(a?plan:Game.trainingPlans[p.training].name+' / '+focusLabel[p.focus])} · 해당 방향의 실제 훈련 성장량 +8%<br>선호 재계약: ${DATA.terms[p.offer].name} · 재계약금 5% 절감</p>${a?`<p class="personal-reaction">${esc(game.trainingReaction(id))}</p><p>개인 상담 · ${remaining?'다음 상담까지 '+remaining+'일':'지금 가능'}<br><small>선호 상담: ${{creative:'창작',stage:'무대',rest:'휴식'}[p.session]} · 신뢰 +5, 다른 상담 +2 (상한 100)</small></p><div class="personal-actions">${[['creative','창작 워크숍 · 100만'],['stage','무대 리허설 · 100만'],['rest','휴식 상담 · 무료']].map(([choice,label])=>btn(label,'m-personal',`data-id="${id}" data-choice="${choice}"`,'soft small',remaining>0||(choice!=='rest'&&game.busy(String(id))))).join('')}</div><small>워크숍: 해당 능력 +0.4·스트레스 -3. 휴식: 체력 +10·스트레스 -8. 효과는 각 상한 이내이며 확정 활동 중에는 워크숍을 진행할 수 없습니다.</small>`:''}</section>`;
}
const personalityManagementClick = managementClick_dayfeedback;
function managementClick_personality(action, data) {
  mutate(() => game.personalSession(data.id, data.choice), '상담을 마쳤습니다. 소식함에서 반응을 확인하세요.');
};


;
