/* FILE src/progression.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const clamp =(n, min, max) => Math.max(min, Math.min(max, n));
    const plans = {
      balanced: {
        name: '균형 기초',
        indexes:[0, 1, 2, 3, 4, 5, 6, 7],
        cost: 2,
        load: 1
      },
      vocal: {
        name: '보컬 집중',
        indexes:[0, 7],
        cost: 3,
        load: 2
      },
      performance: {
        name: '무대 집중',
        indexes:[2, 5, 6],
        cost: 3,
        load: 3
      },
      creative: {
        name: '창작 집중',
        indexes:[1, 3, 4],
        cost: 3,
        load: 2
      },
      rest: {
        name: '회복',
        indexes:[],
        cost: 0,
        load: 0
      }
    };
    const incidents = {
      cancel: { title: '공연 준비 차질·취소', body: '준비 차질로 예정 공연을 취소했습니다. 집행한 제작비는 회수되지 않습니다. 티켓 선판매는 없으므로 티켓 환불을 이중 차감하지 않습니다.' },
      sound: { title: '공연 음향 사고', body: '현장 음향 문제로 관객 불만이 접수됐습니다.' },
      notice: { title: '일정 공지 혼선', body: '일정 안내가 일치하지 않아 팬들이 불편을 겪었습니다.' },
      overwork: { title: '과도한 활동에 대한 우려', body: '컨디션 저하와 빡빡한 일정에 대한 우려가 제기됐습니다.' }
    };
    class ProgressionGame extends Base {
      upgrade() {
        super.upgrade();
        let s = this.s;
        if (!s || s.balanceVersion === 1) return;
        s.balanceVersion = 1;
        s.image = 60;
        s.incidents = [];
        s.lastIncidentDay = - 90;
        s.settlements = [];
        for (const a of[... s.trainees, ... s.artists, ... s.departed]) this.initTalent(a);
        for (const r of s.rivals) {
          r.image = 60;
          r.lastAction = '운영 계획 수립';
          r.talents = r.artists.map(id => this.rivalTalent(id));
        }
      }
      initTalent(a) {
        if (!a.trainingPlan) a.trainingPlan = 'balanced';
        if (!Number.isInteger(a.trainedDays)) a.trainedDays = 0;
      }
      sign(id, offer) {
        super.sign(id, offer);
        this.initTalent(this.artist(id) || this.s.trainees.find(a => a.id === Number(id)));
      }
      profile(id) {
        let d = D.roster[id],
        strengths = d.type === 'idol' ?[0, 2, 5]: d.type === 'band' ?[3, 4, 7]:[1, 4, 5];
        return {
          strength: strengths[id % 3],
          weakness:[6, 7, 0][id % 3],
          potential: 78 +(id * 7) % 20,
          learning: .8 +(id % 6) * .08,
          temperament: d.personality.name
        };
      }
      setTraining(id, plan) {
        let a = this.s.trainees.find(a => a.id === Number(id));
        if (!a || !plans[plan]) throw Error('연습생과 훈련 계획을 확인하세요.');
        a.trainingPlan = plan;
      }
      trainTrainees() {
        for (const a of[... this.s.trainees]) {
          this.initTalent(a);
          let p = plans[a.trainingPlan],
          profile = this.profile(a.id),
          rest = p === plans.rest || a.energy < 30 || a.stress > 80;
          if (rest) {
            a.energy = clamp(a.energy + 8, 0, 100);
            a.stress = clamp(a.stress - 6, 0, 100);
          } else {
            let cost = this.has('trainer') ? p.cost * .8: p.cost;
            if (this.s.cash < cost) {
              a.energy = clamp(a.energy + 5, 0, 100);
              a.stress = clamp(a.stress - 3, 0, 100);
            } else {
              this.change(- cost, '연습생 훈련: ' + D.roster[a.id].name, true, { kind: 'training' });
              a.energy = clamp(a.energy - p.load, 0, 100);
              a.stress = clamp(a.stress + p.load * .5 -(this.has('trainer') ? 1: 0), 0, 100);
              a.trainedDays++;
              for (const idx of p.indexes) {
                let gain =(this.has('trainer') ? .16: .10) * profile.learning *(p.indexes.length === 8 ? 1: 2.2) *(idx === profile.strength ? 1.35: idx === profile.weakness ? .7: 1) *(1 - a.stress * .005);
                if (a.stats[idx] < profile.potential) a.stats[idx] = Math.min(profile.potential, a.stats[idx] + gain);
              }
            }
          }
          if (a.contract <= this.s.day + 1) this.releaseTrainee(a.id);
        }
      }
      imageFactor() {
        return clamp(.6 + this.s.image / 150, .6, 1.25);
      }
      concert(e, j, quality) {
        const venue = j.budget <= 300 ? {
          name: '소규모 클럽',
          capacity: 200,
          ticket: 9,
          variable: .8
        }
        : j.budget <= 800 ? {
          name: '중형 공연장',
          capacity: 700,
          ticket: 10,
          variable: 1.2
        }
        : {
          name: '대형 공연장',
          capacity: 1800,
          ticket: 12,
          variable: 1.8
        };
        let fans = e.members.reduce((n, a) => n + a.fans, 0),
        recent = this.s.performance.filter(p => p.kind === 'live' && p.day > this.s.day - 30 && p.ids.some(id => e.members.some(a => a.id === id))).length;
        let demand =(quality * 1.5 + fans * .2) *(9 / venue.ticket) * this.imageFactor() *(1 + this.staffPower('live') * .2) /(1 + recent * .2);
        let attendance = clamp(Math.floor(demand), 0, venue.capacity),
        result = {
          ... venue,
          attendance,
          gross: attendance * venue.ticket,
          variable: Math.round(attendance * venue.variable * 100) / 100,
          recent
        };
        j.concert = result;
        return result;
      }
      newFans(e, j, quality, fan) {
        let recent = this.s.performance.filter(p => p.kind === j.kind && p.day > this.s.day - 60 && p.ids.some(id => e.members.some(a => a.id === id))).length;
        let reach = Math.max(0, quality - 25) *({ single: 11, live: 2.2, cover: 3 }[j.kind]);
        if (j.kind === 'live') reach = Math.min(reach, this.concert(e, j, quality).attendance * .35);
        let gain = Math.floor(reach * this.imageFactor() *(1 + this.staffPower('promo') * .2) * this.marketFactor(e.type) /(Math.sqrt(1 + fan / 10000) *(1 + recent * .12)));
        this._fanGain = Math.max(0, gain);
        return this._fanGain;
      }
      finishProgression(j) {
        let before = this.s.cash,
        e = j.kind === 'casting' ? null: this.projectEntity(j);
        this.finishManagement(j);
        if (!e) return;
        const quality = this._lastQuality || 0;
        if (quality >= 75 && !this.s.incidents.some(i => i.state !== 'closed')) this.s.image = clamp(this.s.image + .15, 0, 100);
        if (quality < 40 && j.kind !== 'ad') {
          for (const a of e.members) a.fans = Math.max(0, Math.floor(a.fans * .99));
          this.s.image = clamp(this.s.image - 1, 0, 100);
        }
        if (j.kind === 'live' || j.kind === 'ad') {
          let gross = j.kind === 'live' ? j.concert.gross: j.pay,
          payout = Math.round((j.shares ||[]).reduce((n, x) => n + Math.round(gross * x.rate * 100) / 100, 0) * 100) / 100,
          variable = j.concert?.variable || 0;
          let entry = {
            day: this.s.day,
            name: j.name,
            kind: j.kind,
            gross,
            payout,
            variable,
            budget: j.kind === 'live' ? j.budget: 0,
            net: Math.round((gross - payout - variable -(j.kind === 'live' ? j.budget: 0)) * 100) / 100,
            attendance: j.concert?.attendance || 0,
            capacity: j.concert?.capacity || 0
          };
          this.s.settlements.unshift(entry);
          this.s.settlements = this.s.settlements.slice(0, 80);
          let r = this.s.reports.find(r => r.day === this.s.day && r.kind === 'result');
          if (r) r.body += '\n총수입 ' + gross.toLocaleString() + '만 / 배분 ' + payout.toLocaleString() + '만 / 현장비 ' + variable.toLocaleString() + '만 / 선집행 제작비 ' + entry.budget.toLocaleString() + '만 / 회사 손익 ' + entry.net.toLocaleString() + '만 원.' +(j.kind === 'live' ? '\n유료 관객 ' + entry.attendance + ' / 수용 ' + entry.capacity + '명.': ' (광고 잔금 구간만)');
        }
      }
      valuation() {
        let v = super.valuation(),
        factor = .7 + this.s.image / 200,
        operating = v.operating * factor,
        value = Math.max(0, operating + this.s.cash - this.debt),
        spread = this.metrics().days < 180 ? .35: .15;
        return {
          ... v,
          operating: Math.round(operating),
          value,
          low: Math.round(value *(1 - spread)),
          high: Math.round(value *(1 + spread))
        };
      }
      incidentRisk(e) {
        let stress = e.members.reduce((n, a) => n + a.stress, 0) / e.members.length,
        energy = e.members.reduce((n, a) => n + a.energy, 0) / e.members.length,
        recent = this.s.performance.filter(p => p.day > this.s.day - 30 && p.ids.some(id => e.members.some(a => a.id === id))).length;
        return clamp(.04 + stress * .002 + Math.max(0, 50 - energy) * .003 + Math.max(0, recent - 3) * .02 -(this.has('manager') ? .04: 0), .02, .4);
      }
      startIncident(kind, key) {
        let e = this.entity(key),
        s = this.s;
        if (!e || !incidents[kind]) throw Error('사건 대상과 종류를 확인하세요.');
        if (s.incidents.some(i => i.state !== 'closed') || s.day - s.lastIncidentDay < 90) throw Error('진행 중인 사건 또는 재발 제한 기간입니다.');
        let cancelled = kind === 'cancel' ? s.jobs.find(j => j.kind === 'live' && j.entity === key): null;
        if (kind === 'cancel' && !cancelled) throw Error('취소할 진행 중 공연이 없습니다.');
        if (cancelled) s.jobs = s.jobs.filter(j => j !== cancelled);
        let risk = this.incidentRisk(e),
        severity = risk > .25 ? 3: risk > .12 ? 2: 1,
        rate = [0, .01, .03, .06][severity],
        imageLoss = severity * 4,
        losses = e.members.map(a =>({ id: a.id, lost: Math.floor(a.fans * rate) }));
        for (const x of losses) {
          let a = this.artist(x.id);
          a.fans -= x.lost;
        }
        const unit = s.units.find(u => u.key === key);
        let teamLost = unit ? Math.floor(unit.fans * rate): 0;
        if (unit) unit.fans -= teamLost;
        s.image = clamp(s.image - imageLoss, 0, 100);
        s.reputation = clamp(s.reputation - severity, 0, 100);
        let i = {
          id: this.id(),
          kind,
          key,
          name: e.name,
          day: s.day,
          expires: s.day + 7,
          severity,
          state: 'open',
          choice: null,
          responseDue: null,
          losses,
          teamLost,
          imageLoss,
          recovered: 0
        };
        s.incidents.unshift(i);
        s.incidents = s.incidents.slice(0, 80);
        s.lastIncidentDay = s.day;
        this.report(incidents[kind].title, e.name + ' · ' + incidents[kind].body + '\n팬 ' + losses.reduce((n, x) => n + x.lost, 0) + '명 이탈 / 회사 이미지 -' + imageLoss + '\n7일 안에 대응을 결정하세요.', 'info', true, { incidentId: i.id });
        this.log(incidents[kind].title + ' · ' + e.name);
        return i;
      }
      respondIncident(id, choice) {
        let i = this.s.incidents.find(i => i.id === Number(id));
        if (!i || i.state !== 'open') throw Error('이미 대응했거나 종료된 사건입니다.');
        if (!['explain', 'repair', 'investigate', 'ignore'].includes(choice)) throw Error('대응을 선택하세요.');
        let cost = {
          explain: 100,
          repair: 300,
          investigate: 50,
          ignore: 0
        }
        [choice] * i.severity;
        if (cost) this.spend(cost, '사건 대응: ' + incidents[i.kind].title);
        i.choice = choice;
        if (choice === 'investigate') {
          i.state = 'investigating';
          i.responseDue = this.s.day + 3;
          this.log('사건 조사 시작 · 3일 후 결과');
          return;
        }
        this.closeIncident(i, choice);
      }
      closeIncident(i, choice) {
        if (i.state === 'closed') return;
        i.choice = choice;
        i.state = 'closed';
        let ratio = choice === 'repair' ? .5: choice === 'explain' ? .2: choice === 'investigate' ? .3: 0;
        for (const x of i.losses) {
          let a = this.artist(x.id);
          if (a) {
            let gain = Math.floor(x.lost * ratio);
            a.fans += gain;
            i.recovered += gain;
          }
        }
        let u = this.s.units.find(u => u.key === i.key);
        if (u) u.fans += Math.floor(i.teamLost * ratio);
        this.s.image = clamp(this.s.image +(choice === 'repair' ? 2 * i.severity: choice === 'explain' ? i.severity: choice === 'investigate' ? i.severity: - 3 * i.severity), 0, 100);
        if (choice === 'ignore') {
          for (const x of i.losses) {
            let a = this.artist(x.id);
            if (a) a.fans = Math.floor(a.fans * .99);
          }
        }
        let r = this.s.reports.find(r => r.incidentId === i.id);
        if (r) {
          r.resolved = true;
          r.read = true;
          r.body += '\n대응 완료 · ' +({
            repair: '보완 행사',
            explain: '공식 설명',
            investigate: '조사·결과 공개',
            ignore: '미대응'
          }
          [choice]) + ' / 팬 회복 ' + i.recovered + '명';
        }
        this.log('사건 대응 종료 · ' + incidents[i.kind].title);
        this.report('사건 대응 결과', i.name + ' · ' +({
          repair: '보완 행사를 진행했습니다.',
          explain: '공식 설명과 안내를 제공했습니다.',
          investigate: '조사를 마치고 결과를 공개했습니다.',
          ignore: '기한 내 대응하지 않아 추가 불만이 발생했습니다.'
        }
        [choice]) + ' 팬 회복 ' + i.recovered + '명. 사건으로 생긴 피해가 모두 복구되지는 않습니다.', 'info', false);
      }
      tickIncidents() {
        for (const i of this.s.incidents) {
          if (i.state === 'open' && this.s.day > i.expires) this.closeIncident(i, 'ignore');
          if (i.state === 'investigating' && this.s.day >= i.responseDue) this.closeIncident(i, 'investigate');
        }
        if (this.s.day % 30 !== 0) return;
        if (!this.s.incidents.some(i => i.state !== 'closed') && this.s.day - this.s.lastIncidentDay >= 90) {
          if (this.s.image < 80) this.s.image = Math.min(80, this.s.image + 1);
          if (this.s.day >= 60) {
            let pool = this.entities.filter(e => this.s.jobs.some(j => j.entity === e.key && j.kind === 'live') || this.s.performance.some(p => p.day > this.s.day - 30 && p.ids.some(id => e.members.some(a => a.id === id))));
            if (pool.length) {
              let e = pool[Math.floor(this.rng() * pool.length)];
              if (this.rng() < this.incidentRisk(e)) {
                let stress = e.members.reduce((n, a) => n + a.stress, 0) / e.members.length;
                this.startIncident(this.s.jobs.some(j => j.kind === 'live' && j.entity === e.key) && stress > 70 ? 'cancel': stress > 65 ? 'overwork': this.rng() < .5 ? 'sound': 'notice', e.key);
              }
            }
          }
        }
      }
      depart(id, reason, rivalId = null) {
        let a = this.artist(id);
        super.depart(id, reason, rivalId);
        if (a) {
          for (const r of this.s.rivals) if (r.artists.includes(a.id) && !r.talents.some(t => t.id === a.id)) {
            let t = this.rivalTalent(a.id);
            t.active = true;
            t.skill = a.stats.reduce((n, v) => n + v, 0) / 8;
            r.talents.push(t);
          }
        }
      }
      rivalTalent(id) {
        return {
          id,
          skill: D.roster[id].stats.reduce((n, x) => n + x, 0) / 8,
          energy: 90,
          trust: 70,
          contract: this.s.day + 730,
          active: !D.roster[id].trainee
        };
      }
      rivalsMonth() {
        for (const r of this.s.rivals) {
          let income = 0,
          expense = 0,
          overhead = 250 + r.artists.length * 70;
          const spend = n => {
            if (r.cash < n) return false;
            r.cash -= n;
            expense += n;
            return true;
          };
          let take =(n) => {
            r.cash += n;
            income += n;
          };
          if (r.image < 90) r.image = clamp(r.image + 1, 0, 90);
          if (r.cash < overhead && r.debt < 10000) {
            let loan = Math.min(3000, 10000 - r.debt);
            r.cash += loan;
            r.debt += loan;
          }
          if (!spend(overhead)) {
            spend(Math.max(0, r.cash));
            r.reputation = Math.max(0, r.reputation - 3);
            if (r.artists.length) {
              let id = r.artists.pop();
              r.talents = r.talents.filter(t => t.id !== id);
              this.news(r.name + ' · 재정난으로 ' + D.roster[id].name + ' 계약 종료');
            }
          }
          if (r.debt && r.cash > overhead * 4) {
            let payment = Math.min(r.debt, 250);
            r.cash -= payment;
            r.debt -= payment;
          }
          for (const t of[... r.talents]) {
            t.energy = clamp(t.energy + 15, 0, 100);
            if (t.contract - this.s.day <= 90) {
              let fee = 200 + t.skill * 5;
              if (r.cash > fee + overhead * 2) {
                spend(fee);
                t.contract += 730;
                t.trust = clamp(t.trust + 5, 0, 100);
              } else if (t.contract <= this.s.day) {
                r.artists = r.artists.filter(id => id !== t.id);
                r.talents = r.talents.filter(x => x !== t);
                this.news(r.name + ' · ' + D.roster[t.id].name + ' 자유계약 전환');
              }
            }
          }
          let active = r.talents.filter(t => t.active),
          trainees = r.talents.filter(t => !t.active),
          action = '휴식·현금 확보',
          chance = this.rng();
          if (r.cash < overhead * 3) {
            action = '긴축 운영';
            for (const t of r.talents) t.energy = clamp(t.energy + 15, 0, 100);
          } else if (trainees.length &&(chance < .35 || !active.length)) {
            if (spend(150 * trainees.length)) {
              action = '연습생 집중 육성';
              for (const t of trainees) {
                t.skill = Math.min(90, t.skill + 1.5 + this.rng());
                if (t.skill >= 58 && spend(200)) {
                  t.active = true;
                  action = '신인 데뷔';
                  this.news(r.name + ' · ' + D.roster[t.id].name + ' 데뷔');
                }
              }
            }
          } else if (active.length &&((r.type === 'band' && chance < .75) || chance < .3)) {
            if (spend(600)) {
              let quality = active.reduce((n, t) => n + t.skill, 0) / active.length,
              attendance = Math.min(700, Math.floor(r.fans * .12 + quality * 2));
              take(attendance * 8);
              spend(Math.min(r.cash, attendance * .8));
              r.fans += Math.floor(attendance * .12 /(1 + r.fans / 30000));
              r.reputation = clamp(r.reputation + 1, 0, 100);
              active.forEach(t => t.energy = Math.max(0, t.energy - 15));
              action = '공연 중심 활동';
            }
          } else if (active.length &&(r.type === 'rap' ? chance < .9: chance < .8)) {
            let budget = r.type === 'rap' ? 1800: 2500;
            if (spend(budget)) {
              let quality = clamp(active.reduce((n, t) => n + t.skill, 0) / active.length + this.rng() * 15, 20, 95);
              r.catalog.push({ name: '신작 ' +(++ r.serial), quality, age: 0 });
              r.catalog = r.catalog.slice(- 240);
              r.fans += Math.floor(quality * 5 / Math.sqrt(1 + r.fans / 30000));
              r.reputation = clamp(r.reputation + quality / 50, 0, 100);
              action = '신작 제작·발매';
            }
          } else if (spend(200)) {
            action = '팬 소통·홍보';
            r.fans += Math.floor(100 / Math.sqrt(1 + r.fans / 10000));
            r.image = clamp(r.image + 2, 0, 100);
          }
          if (r.talents.some(t => t.energy < 35)) {
            r.talents.forEach(t => t.energy = clamp(t.energy + 20, 0, 100));
            action += '·컨디션 회복';
          }
          if (r.cash > overhead * 6 && r.artists.length < 6 && this.rng() < .18) {
            let pool = D.roster.filter(a => this.available(a.id) && !this.s.candidates.some(c => c.id === a.id) &&(r.type === 'any' || a.type === r.type));
            if (pool.length && spend(200)) {
              let a = pool[Math.floor(this.rng() * pool.length)];
              r.artists.push(a.id);
              r.talents.push(this.rivalTalent(a.id));
              this.news(r.name + ' · ' + a.name + ' 영입');
              action += '·영입';
            }
          }
          if (r.talents.length && this.rng() < .06) {
            r.fans = Math.floor(r.fans * .98);
            r.image = Math.max(0, r.image - 5);
            action += '·운영 사고';
          }
          r.lastAction = action;
          let bin = r.accounts.at(- 1);
          if (bin && bin.day === this.s.day) {
            bin.revenue += income;
            bin.expense += expense;
          } else r.accounts.push({ day: this.s.day, revenue: income, expense });
          r.accounts = r.accounts.filter(b => b.day > this.s.day - 365);
          let profit = r.accounts.reduce((n, b) => n + b.revenue - b.expense, 0);
          r.value = Math.max(0, r.cash - r.debt + Math.max(0, profit * 4) *(.7 + r.image / 200));
          r.level = r.value >= 3000000 ? 5: r.value >= 700000 ? 4: r.value >= 150000 ? 3: r.value >= 30000 ? 2: 1;
          this.news(r.name + ' · ' + action);
        }
      }
      advanceIncidents() {
        let result = this.advanceManagement();
        this.tickIncidents();
        return this.pending.length;
      }
    }
    ProgressionGame.trainingPlans = plans;
    ProgressionGame.incidentTypes = incidents;
    return ProgressionGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installProgression = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
