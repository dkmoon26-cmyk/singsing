/* FILE src/season-schedule.js */
(function(root) {
  'use strict';
  function install(Base, D, S) {
    const {clamp, round, hash, calendar} = typeof module !== 'undefined' ? require('./season-utils.js'): root.SeasonUtils;
    class SeasonSchedule extends Base {
      reservationOverlaps(ids, start, end) {
        return this.s.engagements.some(e => e.start < end && e.due + 2 > start && e.snapshot.ids.some(id => ids.includes(id)));
      }
      busy(key) {
        const e = this.entity(key);
        return super.busy(key) || !!e && this.s.engagements.some(x => x.start <= this.s.day && x.due > this.s.day && x.snapshot.ids.some(id => e.members.some(a => a.id === id)));
      }
      productionState(j) {
        const active =(j.pauses ||[]).find(p => p.start <= this.s.day && p.end > this.s.day),
        reserved =(j.pauses ||[]).reduce((n, p) => n + Math.max(0, p.end - Math.max(this.s.day, p.start)), 0);
        return {
          paused: !!active,
          resume: active?.end ?? null,
          remaining: Math.max(0, j.due - this.s.day - reserved),
          delay: j.delayDays || 0,
          reason: active?.kind === 'festival' ? '행사 준비·출연': '광고 촬영'
        };
      }
      delayProduction(j, e) {
        if (j.due <= e.start || e.due <= j.start || !this.participantIds(j).some(id => e.snapshot.ids.includes(id))) return;
        this.pauseProduction(j, { adId: e.id, start: e.start, end: e.due, kind: 'festival' });
      }
      reconcileProduction(j, events = this.s.engagements) {
        // Dates only extend. Revisit reservations until no newly crossed pause remains.
        // delayDays retains earlier pauses even when the 60-entry display history rolls off.
        const ordered = [...events].sort((a, b) => a.start - b.start);
        const recorded = new Set((j.pauses || []).map(p => p.adId));
        let due;
        do {
          due = j.due;
          for (const e of ordered) {
            if (recorded.has(e.id)) continue;
            this.delayProduction(j, e);
            if ((j.pauses || []).some(p => p.adId === e.id)) recorded.add(e.id);
          }
        } while (j.due !== due);
        return j;
      }
      previewProduction(j, event) {
        const copy = { ...j, pauses: (j.pauses || []).map(p => ({ ...p })) };
        return this.reconcileProduction(copy, this.s.engagements.concat(event));
      }
      productionPreview(key, promotion = 'none') {
        const e = this.entity(key), plan = D.promotionPlans[promotion];
        if (!e || !plan) throw Error('제작 대상과 홍보 계획을 확인하세요.');
        const job = {kind:'single', entity:key, start:this.s.day,
          due:this.s.day + D.rules.activity.single.days + plan.days, snapshot:this.snapshot(key)};
        return this.reconcileProduction(job);
      }
      festivalPlan(id) {
        const approved = this.s.festivalOffers.find(o => o.id === Number(id));
        if (approved?.status === 'accepted' && approved.approval) return { ... approved.approval, allowed: false, reasons:['이미 출연을 확정했습니다.'] };
        const o = this.s.festivalOffers.find(x => x.id === Number(id)),
        e = o && this.entity(o.entity),
        f = o && S.festivals[o.kind],
        reasons = [];
        if (!o || o.status !== 'open' || o.expires < this.s.day) reasons.push('처리했거나 기한이 끝난 섭외입니다.');
        if (!e || e.key.startsWith('u') &&(e.status !== 'active' || e.members.length < 2)) reasons.push('활동 가능한 대상이 없습니다.');
        const ids = e?.members.map(a => a.id) ||[],
        start = o ? o.day - f.duration: 0,
        end = o?.day || 0;
        if (start < this.s.day) reasons.push('준비 기간이 부족합니다.');
        if (e?.members.some(a => a.energy < 25 || a.recoveryUntil > start)) reasons.push('체력·회복 상태를 확인하세요.');
        const jobs = this.s.jobs.filter(j => this.participantIds(j).some(id => ids.includes(id)));
        if (jobs.some(j => j.kind !== 'single' && j.due + 3 > start)) reasons.push('공연·커버·광고 일정과 겹칩니다.');
        if (this.reservationOverlaps(ids, start, end)) reasons.push('다른 행사 준비·회복 기간과 겹칩니다.');
        const productions = jobs.filter(j => j.kind === 'single' && j.due > start);
        if (productions.some(j =>(j.pauses ||[]).some(p => p.start < end && p.end > start))) reasons.push('제작 중단 일정이 겹칩니다.');
        const snapshot = e && this.snapshot(e.key),
        shares = snapshot ? this.shares(snapshot):[],
        pay = o?.pay || 0,
        payout = round(shares.reduce((n, x) => n + round(pay * x.rate), 0));
        return {
          allowed: reasons.length === 0,
          reasons:[... new Set(reasons)],
          name: f?.name || '',
          start,
          day: end,
          duration: f?.duration || 0,
          pay,
          cost: o?.cost || 0,
          net: round(pay - payout -(o?.cost || 0)),
          productions: productions.map(j =>({
            id: j.id,
            title: j.name,
            oldDue: j.due,
            newDue: this.previewProduction(j, { id: -1, start, due: end, snapshot }).due
          })),
          snapshot,
          shares
        };
      }
      createFestivalOffer(kind, key, day) {
        const f = S.festivals[kind],
        e = this.entity(key),
        month = calendar(day).getUTCMonth() + 1;
        if (!f || !e || !Number.isInteger(day) || day < this.s.day + f.duration || !f.months.includes(month)) throw Error('행사 종류·계절·날짜를 확인하세요.');
        if (e.members.reduce((n, a) => n + a.fame, 0) / e.members.length < f.fame) throw Error('행사 인지도 조건 미달입니다.');
        if (this.s.festivalOffers.some(o => o.entity === key && o.status === 'open')) throw Error('대기 중인 행사 섭외가 있습니다.');
        const id = this.id(),
        fame = e.members.reduce((n, a) => n + a.fame, 0) / e.members.length,
        pay = Math.round(f.fee + fame * 12 + Math.sqrt(e.members.reduce((n, a) => n + a.fans, 0)) * 5);
        this.s.festivalOffers.unshift({
          id,
          kind,
          entity: key,
          day,
          pay,
          cost: f.cost,
          expires: Math.min(this.s.day + 7, day - f.duration),
          status: 'open'
        });
        this.s.festivalOffers = this.s.festivalOffers.slice(0, 60);
        this.report(f.name + ' 출연 섭외', e.name + '에게 출연 요청이 왔습니다. 출연료와 준비 일정을 검토하세요.', 'info', true, { festivalOfferId: id });
        return id;
      }
      resolveFestival(id, choice) {
        return this.transaction(() => {
          const o = this.s.festivalOffers.find(x => x.id === Number(id));
          if (!o || o.status !== 'open' || o.expires < this.s.day) throw Error('현재 처리할 수 없는 섭외입니다.');
          if (!['accept', 'decline'].includes(choice)) throw Error('응답을 확인하세요.');
          if (choice === 'accept') {
            const p = this.festivalPlan(id);
            if (!p.allowed) throw Error(p.reasons.join(' '));
            const e = {
              id: this.id(),
              offerId: o.id,
              kind: o.kind,
              entity: o.entity,
              name: p.name,
              start: p.start,
              due: p.day,
              pay: p.pay,
              cost: p.cost,
              snapshot: p.snapshot,
              shares: p.shares
            };
            o.approval = {
              name: p.name,
              start: p.start,
              day: p.day,
              duration: p.duration,
              pay: p.pay,
              cost: p.cost,
              net: p.net,
              productions: p.productions
            };
            this.s.engagements.push(e);
            for (const j of this.s.jobs.filter(j => j.kind === 'single')) this.reconcileProduction(j);
            o.status = 'accepted';
            this.report('행사 출연 확정', p.name + ' · ' + p.duration + '일 준비·출연. 출연료는 행사 완료일 입금하며 약정 배분과 출연비를 차감합니다.', 'info', false);
          } else o.status = 'declined';
          for (const r of this.s.reports) if (r.festivalOfferId === o.id) {
            r.resolved = true;
            r.read = true;
            r.decision = choice;
          }
        });
      }
      adPlan(id) {
        const p = super.adPlan(id),
        r = this.s.reports.find(r => r.id === Number(id)),
        e = r && this.entity(r.entity);
        if (e && this.reservationOverlaps([... new Set(e.members.map(a => a.id).concat(p.productions.flatMap(p => this.participantIds(this.s.jobs.find(j => j.id === p.id)))))], this.s.day, p.shootingDay + 2)) {
          p.allowed = false;
          p.reasons.push('확정 행사 준비·출연 일정과 겹칩니다.');
        }
        for (const production of p.productions) {
          const j = this.s.jobs.find(j => j.id === production.id);
          const copy = { ...j, pauses: (j.pauses || []).map(p => ({ ...p })) };
          this.pauseProduction(copy, { adId: -1, start: this.s.day, end: p.shootingDay });
          production.newDue = this.reconcileProduction(copy).due;
        }
        return p;
      }
      startProject(key, kind, ... args) {
        const e = this.entity(key),
        ids = e?.members.map(a => a.id) ||[];
        if (kind !== 'single' && this.reservationOverlaps(ids, this.s.day, this.s.day +(D.rules.activity[kind]?.days || 0) + 3)) throw Error('확정 행사 일정과 겹칩니다.');
        super.startProject(key, kind, ... args);
        if (kind === 'single') {
          const j = this.s.jobs.at(- 1);
          this.reconcileProduction(j);
        }
      }
      activityAvailability(key) {
        const p = super.activityAvailability(key),
        e = this.entity(key);
        if (e && this.s.engagements.some(x => x.start <= this.s.day && x.due > this.s.day && x.snapshot.ids.some(id => e.members.some(a => a.id === id)))) p.reasons.push('행사 준비·출연 중');
        p.allowed = p.reasons.length === 0;
        return p;
      }
      projectAvailability(key, kind) {
        const p = this.activityAvailability(key),
        e = this.entity(key);
        if (e && kind !== 'single' && this.reservationOverlaps(e.members.map(a => a.id), this.s.day, this.s.day +(D.rules.activity[kind]?.days || 0) + 3)) p.reasons.push('확정 행사 준비·출연·회복 기간과 겹칩니다.');
        p.allowed = p.reasons.length === 0;
        return p;
      }
      settleReceivables() {
        super.settleReceivables();
        if (!this.s.engagements) return;
        const due = this.s.engagements.filter(e => e.due <= this.s.day);
        this.s.engagements = this.s.engagements.filter(e => e.due > this.s.day);
        for (const e of due) this.finishFestival(e);
      }
      finishFestival(e) {
        const entity = this.projectEntity({ entity: e.entity, snapshot: e.snapshot }),
        members = entity?.members ||[];
        const skill = members.length ? members.reduce((n, a) => n +(a.stats[5] + a.stats[6]) / 2, 0) / members.length: 40,
        energy = members.length ? members.reduce((n, a) => n + a.energy, 0) / members.length: 50,
        quality = clamp(Math.round(skill * .7 + energy * .2 +(hash(e.id + ':festival') % 11)), 15, 99),
        fans = Math.round((80 + quality * 3) *(e.kind === 'summer' ? 1.6: 1)),
        share = round(e.shares.reduce((n, x) => n + round(e.pay * x.rate), 0));
        this.receive(e.pay, '행사 출연료: ' + e.name, e.shares, e.entity, 'festival_fee');
        this.change(- e.cost, '행사 출연비: ' + e.name, true, { kind: 'festival_cost' });
        for (const a of members) {
          a.fans += Math.floor(fans / Math.max(1, members.length));
          a.fame = clamp(a.fame + quality / 40, 0, 100);
          a.energy = Math.max(0, a.energy - 12);
          a.recoveryUntil = Math.max(a.recoveryUntil, this.s.day + 2);
        }
        const u = this.s.units.find(u => u.key === e.entity);
        if (u) {
          u.fans += Math.round(fans * .6);
          u.fame = clamp(u.fame + quality / 40, 0, 100);
        }
        this.s.reputation = clamp(this.s.reputation + quality / 100, 0, 100);
        const record = {
          id: e.id,
          day: this.s.day,
          entity: e.entity,
          name: e.name,
          artist: e.snapshot.name,
          ids: e.snapshot.ids,
          quality,
          fans,
          attendance: Math.floor((e.kind === 'summer' ? 12000: e.kind === 'campus' ? 4000: 6000) *(.35 + quality / 200)),
          net: round(e.pay - share - e.cost)
        };
        this.s.festivalHistory.push(record);
        this.s.festivalHistory = this.s.festivalHistory.slice(- 100);
        this.addLiveStat('p:' + e.entity, e.snapshot.name, true, e.snapshot.ids, quality, record.attendance);
        this.report('행사 출연 완료 · ' + e.name, e.snapshot.name + ' · 무대 반응 ' + quality + ' / 새로운 팬 ' + fans + '명 / 회사 실수령 ' + record.net + '만 원. 중단한 제작은 재개합니다.', 'result', false, { festivalResultId: e.id });
      }
      cashForecast() {
        const rows = super.cashForecast();
        if (this.s.engagements) for (const e of this.s.engagements) rows.push({
          day: e.due,
          label: e.name + ' (출연 완료 조건·비용 차감)',
          amount: round(e.pay - e.shares.reduce((n, x) => n + round(e.pay * x.rate), 0) - e.cost),
          type: '입금 예정'
        });
        return rows.sort((a, b) => a.day - b.day);
      }
      reportState(r) {
        if (r.festivalOfferId) {
          const o = this.s.festivalOffers.find(o => o.id === r.festivalOfferId);
          if (!o || o.status === 'expired' || o.expires < this.s.day && o.status === 'open') return { status: 'expired', label: '기한 종료', needsDecision: false };
          return o.status === 'open' ? {
            status: 'decision',
            label: '결정 필요',
            needsDecision: true,
            expires: o.expires
          }
          : { status: 'done', label: o.status === 'declined' ? '거절 완료': '출연 확정', needsDecision: false };
        }
        return super.reportState(r);
      }
      get pending() {
        const rows = super.pending;
        if (this.s.seasonVersion) for (const r of this.s.reports) if (!r.read &&(r.awardYear || r.festivalResultId) && !rows.includes(r)) rows.push(r);
        return rows;
      }
      reportCategory(r) {
        return r.festivalOfferId || r.festivalResultId ? 'activity': super.reportCategory(r);
      }

    }
    return SeasonSchedule;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installSeasonSchedule = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
