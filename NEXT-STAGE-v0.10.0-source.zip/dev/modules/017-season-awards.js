/* FILE src/season-awards.js */
(function(root) {
  'use strict';
  function install(Base, D, S) {
    const {clamp, round, hash, calendar} = typeof module !== 'undefined' ? require('./season-utils.js'): root.SeasonUtils;
    class SeasonAwards extends Base {
      sign(id, ... args) {
        super.sign(id, ... args);
        if (this.artist(id) && this.s.debutYears && this.s.debutYears[id] === undefined) this.s.debutYears[id] = D.roster[id].career ? 2020: calendar(this.s.day).getUTCFullYear();
      }
      debut(id, ... args) {
        super.debut(id, ... args);
        if (this.s.debutYears[id] === undefined) this.s.debutYears[id] = calendar(this.s.day).getUTCFullYear();
      }
      stat(key, name, own, ids = [], debut = 2020) {
        const stats = this.s.yearStats;
        if (!stats[key]) stats[key] = {
          key,
          name,
          own,
          ids:[... ids],
          debut,
          streams: 0,
          sales: 0,
          live: 0,
          liveCount: 0,
          quality: 0,
          releaseId: null
        };
        return stats[key];
      }
      addLiveStat(key, name, own, ids, quality, attendance) {
        const stat = this.stat(key, name, own, ids, ids.length ? Math.min(... ids.map(id => this.s.debutYears[id] ?? 2020)): 2020);
        stat.live += Math.round(attendance * Math.max(0, quality) / 100);
        stat.liveCount++;
        stat.quality += quality;
      }
      recordYear() {
        for (const row of this.globalReleases()) {
          const c = row.release,
          m = c.market,
          day = m.days.at(- 1);
          if (!day || day.day !== this.s.day) continue;
          const actor = row.external ? 'x:' + row.externalArtist: row.own ? 'p:' + c.entity: 'r:' + m.owner + ':' + m.ids.join('-'),
          ids = m.ids ||[],
          debut = row.own ?(ids.length ? Math.min(... ids.map(id => this.s.debutYears[id] ?? 2020)): 2020): row.external ? row.externalDebut:(ids.length ? Math.min(... ids.map(id => this.s.debutYears[id] ?? 2020)): 2020);
          const person = this.stat(actor, m.artistName, row.own, ids, debut),
          song = this.stat('song:' + m.uid, c.name, row.own, ids, debut);
          song.artist = m.artistName;
          song.releaseId = m.uid;
          song.streams += day.streams;
          song.sales += day.sales;
          person.streams += day.streams;
          person.sales += day.sales;
        }
        // External/rival live activity is an inexpensive monthly model, independent of player growth.
        if (this.s.day % 30 === 0) {
          for (const r of this.s.rivals) {
            if (r.lastAction?.includes('공연')) {
              const active = r.talents.filter(t => t.active),
              ids =(r.type === 'rap' ? active.slice(0, 1): active.slice(0, 5)).map(t => t.id),
              name = ids.length === 1 ? D.roster[ids[0]].name: r.name + ' 프로젝트팀',
              quality = active.reduce((n, t) => n + t.skill, 0) / Math.max(1, active.length);
              this.addLiveStat('r:r' + r.id + ':' + ids.join('-'), name, false, ids, quality, Math.min(700, Math.floor(r.fans * .12 + quality * 2)));
            }
          }
          for (let a = 0; a < S.names.length; a++) {
            const quality = 55 + hash('live' + a) % 35;
            this.addLiveStat('x:' + a, S.names[a], false, [], quality, 100 + hash('attendance' + a) % 3000);
          }
        }
      }
      awardScore(stat, key) {
        if (key === 'song') return stat.streams + stat.sales * 120;
        if (key === 'live') return stat.live;
        if (key === 'rookie') return stat.streams + stat.sales * 120 + stat.live * 30;
        return stat.streams + stat.sales * 120 + stat.live * 80;
      }
      nominateAwards() {
        const year = this.s.seasonYear;
        if (this.s.awardHistory.some(a => a.year === year)) return;
        const categories = Object.keys(S.awards).map(key => {
          const nominees = Object.values(this.s.yearStats).filter(x =>(key === 'song' ? x.key.startsWith('song:'): !x.key.startsWith('song:')) &&(key !== 'rookie' || x.debut === year) &&(key !== 'live' || x.liveCount > 0) && this.awardScore(x, key) > 0).sort((a, b) => this.awardScore(b, key) - this.awardScore(a, key) || a.key.localeCompare(b.key)).slice(0, 5).map(x =>({
            key: x.key,
            name: x.name,
            artist: x.artist || x.name,
            own: x.own,
            ids:[... x.ids],
            releaseId: x.releaseId
          }));
          return { key, nominees, winner: null };
        });
        this.s.awardHistory.push({
          year,
          since: this.s.seasonSince,
          nominationDay: this.s.day,
          resultDay: null,
          categories
        });
        this.s.awardHistory = this.s.awardHistory.slice(- 10);
        this.report(year + ' NEXT MUSIC AWARDS 후보 발표', '올해 기록된 판매·재생과 무대 성과로 후보를 선정했습니다. 12월 28일 결과를 발표합니다. 이전 저장에서 기록되지 않은 과거 성과는 소급하지 않습니다.', 'info', true, { awardYear: year });
      }
      finishAwards() {
        this.nominateAwards();
        const award = this.s.awardHistory.find(a => a.year === this.s.seasonYear);
        if (award.resultDay !== null) return;
        for (const category of award.categories) {
          const ranked = category.nominees.map(n =>({ ... n, score: this.awardScore(this.s.yearStats[n.key] || { streams: 0, sales: 0, live: 0 }, category.key) *(0.97 +(hash(award.year + ':' + category.key + ':' + n.key) % 7) / 100) })).sort((a, b) => b.score - a.score || a.key.localeCompare(b.key));
          if (!ranked.length) continue;
          const { score, ... winner } = ranked[0];
          category.winner = winner;
          if (winner.own) {
            this.s.reputation = clamp(this.s.reputation + 2, 0, 100);
            for (const id of winner.ids) {
              const a = this.artist(id);
              if (a) a.fame = clamp(a.fame + 3, 0, 100);
            }
            this.remember(winner.ids, 'award', award.year + ' ' + S.awards[category.key] + ' 수상');
            this.moment('award-' + award.year + '-' + category.key, S.awards[category.key] + ' 수상', winner.name + ' · 한 해의 활동이 인정받았습니다.\n“함께해 주신 분들 덕분이에요. 다음 무대도 기대해 주세요.”', winner.ids);
          } else if (winner.key.startsWith('r:')) {
            const rid = Number(winner.key.split(':')[1].slice(1)),
            r = this.s.rivals.find(r => r.id === rid);
            if (r) r.reputation = clamp(r.reputation + 2, 0, 100);
          }
        }
        award.resultDay = this.s.day;
        const own = Object.values(this.s.yearStats).filter(x => x.own && !x.key.startsWith('song:'));
        award.summary = { streams: own.reduce((n, x) => n + x.streams, 0), sales: own.reduce((n, x) => n + x.sales, 0), live: own.reduce((n, x) => n + x.liveCount, 0) };
        this.report(award.year + ' NEXT MUSIC AWARDS 결과', award.categories.map(c => S.awards[c.key] + ' · ' +(c.winner ? c.winner.name + ' / ' + c.winner.artist: '해당 후보 없음')).join('\n') + '\n인지도·평판 및 수상 이력 반영. 상금은 없습니다.', 'info', true, { awardYear: award.year });
      }

    }
    return SeasonAwards;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installSeasonAwards = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
