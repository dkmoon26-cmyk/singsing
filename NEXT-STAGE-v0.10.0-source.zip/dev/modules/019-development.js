/* FILE src/development.js */
(function(root) {
  'use strict';
  const Base = root.Game, plans = ['balanced','vocal','performance','creative','rest'];
  const weekday = day => (new Date(Date.UTC(2027,0,1+day)).getUTCDay()+6)%7;
  class DevelopmentGame extends Base {
    upgrade() {
      super.upgrade();
      if (!this.s) return;
      if (this.s.developmentVersion === undefined) this.s.developmentVersion = 1;
      for (const a of [...this.s.artists,...this.s.trainees,...this.s.departed]) this.initDevelopmentTalent(a);
    }
    initDevelopmentTalent(a) {
      for (const key of ['weeklyPlan','weeklyBase','growthTarget','milestone']) if (a[key] === undefined) a[key] = null;
    }
    initOperationsTalent(a) { super.initOperationsTalent(a); this.initDevelopmentTalent(a); }
    sign(id, offer = 'balanced') {
      return this.transaction(() => { super.sign(id,offer); this.initDevelopmentTalent(this.talent(Number(id))); });
    }
    ownedTalent(id) {
      const a = [...this.s.artists,...this.s.trainees].find(a=>a.id===Number(id));
      if (!a) throw Error('현재 소속된 인물을 선택하세요.');
      return a;
    }
    setWeeklyPlan(id, days) {
      return this.transaction(() => {
        const a = this.ownedTalent(id);
        if (!Array.isArray(days) || days.length!==7 || !days.every(p=>plans.includes(p))) throw Error('월요일부터 일요일까지 훈련을 지정하세요.');
        if (!a.weeklyPlan) a.weeklyBase = {focus:a.focus, plan:a.trainingPlan, mode:a.trainingMode};
        a.weeklyPlan = [...days];
      });
    }
    clearWeeklyPlan(id) {
      const a = this.ownedTalent(id);
      if (a.weeklyBase) { a.focus=a.weeklyBase.focus; a.trainingPlan=a.weeklyBase.plan; a.trainingMode=a.weeklyBase.mode; }
      a.weeklyPlan = null; a.weeklyBase = null;
    }
    setTraining(id, plan) { return this.transaction(()=>{ this.clearWeeklyPlan(id); return super.setTraining(id,plan); }); }
    setTrainingControl(id, mode, goal) {
      // Validate before touching the existing weekly schedule.
      if (!['auto','manual'].includes(mode) || !['balanced','debut','longterm','vocal','performance','creative'].includes(goal)) throw Error('육성 목표를 확인하세요.');
      return this.transaction(()=>{ this.clearWeeklyPlan(id); return super.setTrainingControl(id,mode,goal); });
    }
    setFocus(id, focus) {
      if (!['balanced','creative','stage','rest'].includes(focus)) throw Error('육성 방향을 확인하세요.');
      return this.transaction(()=>{ this.clearWeeklyPlan(id); return super.setFocus(id,focus); });
    }
    trainTrainees() {
      for (const a of [...this.s.artists,...this.s.trainees]) {
        this.initDevelopmentTalent(a);
        if (!a.weeklyPlan) continue;
        const plan = a.weeklyPlan[weekday(this.s.day)];
        a.trainingPlan = plan;
        a.focus = {balanced:'balanced',vocal:'balanced',performance:'stage',creative:'creative',rest:'rest'}[plan];
        if (this.s.trainees.includes(a)) a.trainingMode = 'manual';
      }
      return super.trainTrainees();
    }
    weeklyTrainingIndexes(a) { return a.weeklyPlan ? Base.trainingPlans[a.weeklyPlan[weekday(this.s.day)]].indexes : null; }
    setGrowthTarget(id, metric, target) {
      return this.transaction(()=>{
        const a=this.ownedTalent(id); metric=Number(metric);target=Number(target);
        if (!Number.isInteger(metric)||metric<0||metric>7||!Number.isInteger(target)||target<1||target>99) throw Error('능력과 목표값(1~99)을 확인하세요.');
        a.growthTarget={metric,target,setDay:this.s.day,achievedDay:a.stats[metric]>=target?this.s.day:null};
      });
    }
    setMilestone(id, kind, day) {
      return this.transaction(()=>{
        const a=this.ownedTalent(id), trainee=this.s.trainees.includes(a);day=Number(day);
        if (!(trainee?['debut']:['live','single']).includes(kind)||!Number.isInteger(day)||day<this.s.day||day>this.s.day+365) throw Error('오늘부터 365일 이내의 목표 날짜를 선택하세요.');
        if (kind==='debut' && day<a.signed+90) throw Error('데뷔 목표일은 입소 후 90일 이후로 지정하세요.');
        a.milestone={kind,day,completedDay:null};
      });
    }
    debut(id, offer) {
      return this.transaction(()=>{ super.debut(id,offer);const a=this.ownedTalent(id);if(a.milestone?.kind==='debut')a.milestone.completedDay=this.s.day; });
    }
    developmentCountdown(a) {
      const job=[...this.s.jobs.filter(j=>['single','live'].includes(j.kind)),...(this.s.engagements||[]).map(e=>({...e,kind:'live'}))].filter(j=>(j.snapshot?.ids||[]).includes(a.id)).sort((x,y)=>x.due-y.due)[0];
      if(job)return {kind:job.kind,day:job.due,confirmed:true,completedDay:null};
      return a.milestone ? {...a.milestone,confirmed:false} : null;
    }
    advanceSeason() {
      const result=super.advanceSeason();
      let developmentReports=0;
      for(const a of [...this.s.artists,...this.s.trainees]) {
        const target=a.growthTarget;
        if(target && target.achievedDay===null && a.stats[target.metric]>=target.target) {
          target.achievedDay=this.s.day;
          this.report('개인 육성 목표 달성',root.DATA.roster[a.id].name+' · '+root.DATA.specs[target.metric]+' '+target.target+' 달성','info',false);
          developmentReports++;
        }
        const mark=a.milestone;
        if(mark && mark.completedDay===null && ['live','single'].includes(mark.kind) && (this.s.performance.some(p=>p.day===this.s.day&&p.kind===mark.kind&&p.ids.includes(a.id))||mark.kind==='live'&&(this.s.festivalHistory||[]).some(e=>e.day===this.s.day&&e.ids.includes(a.id))))mark.completedDay=this.s.day;
      }
      const summary=this.s.daySummaries.at(-1);
      if(summary?.day===this.s.day)summary.newReports+=developmentReports;
      return result;
    }
    monthlyOperatingForecast() {
      const signature=JSON.stringify(this.s);
      if(this._developmentForecast?.signature===signature)return this._developmentForecast.value;
      const sim=new DevelopmentGame(JSON.parse(signature));
      let revenue=0,expense=0;
      const change=sim.change.bind(sim);
      sim.change=(amount,label,operating=true,meta={})=>{
        if(operating&&!['loan','loan_repayment','rescue'].includes(meta.kind)) {
          if(amount>0)revenue+=amount;else expense-=amount;
        }
        return change(amount,label,operating,meta);
      };
      for(let day=0;day<30;day++)sim.nextDay({transactional:false});
      const round=x=>Math.round(x*100)/100;
      const value={revenue:round(revenue),expense:round(expense),profit:round(revenue-expense),cashChange:round(sim.s.cash-this.s.cash),from:this.s.day+1,to:this.s.day+30};
      this._developmentForecast={signature,value};return value;
    }
  }
  root.DevelopmentWeekday=weekday;
  root.Game=DevelopmentGame;
})(typeof window!=='undefined'?window:globalThis);

;
