/* FILE src/evolution-data.js */
(function(root) {
  'use strict';
  const D = typeof module !== 'undefined' ? require('./operations-data.js'): root.DATA;
  D.goalRewards = {
    sign: { cash: 100, text: '계약 기념 · 지원금 100만 원', description: '소속 아티스트 1명과 전속계약' },
    trainee: { cash: 200, text: '육성 지원금 200만 원', description: '연습생 1명 영입' },
    debut: { perk: 'debutPromo', text: '데뷔 기념 · 다음 싱글 홍보 1회 지원', description: '연습생의 정식 데뷔 1회' },
    release: { perk: 'productionVoucher', text: '다음 싱글 기본 제작비 5% 할인 · 최대200만 원', description: '싱글 1회 발매' },
    catalog: { cash: 100, text: '첫 정산 기념 · 지원금 100만 원', description: '음원 주간 정산에서 회사 몫 실제 입금 발생' },
    profit: { cash: 300, text: '운영 지원금 300만 원', description: '최소30일 기록 · 최근365일 영업이익 1,000만 원' },
    staff: { cash: 100, text: '직원 소개 · 채용 지원금 100만 원', description: '전문 직원 1명 채용' },
    fans: { offer: 'fan', text: '팬 메시지 · 소규모 팬 공연 제안', description: '개인 또는 팀 하나의 합산 팬1,000명' },
    renew: { text: '감사 대화 · 함께한 재계약 기록', description: '전속 아티스트 재계약 1회' },
    star: { offer: 'star', text: '특별 기사 · 스타 신곡 기획 제안', description: '개인 또는 팀의 스타 등급 최초 달성' },
    rival: { offer: 'collab', text: '업계 기사 · 협업 싱글 제안', description: '최소180일 기록 · 양의 최근365일 영업이익으로 라이벌 한 곳 추월' },
    large: { offer: 'large', text: '회사 성장 회고 · 대형 공연 기획 제안', description: '회사 성장5단계 도달' },
    live: { text: '첫 무대 기념 카드', description: '유료 관객이 있는 공연 완료' },
    liveprofit: { perk: 'livePromo', text: '다음 공연 홍보 1회 지원', description: '제작비·현장비·배분 차감 후 공연 손익 양수' },
    team: { text: '팀 단체 프로필 · 첫 활동 기록', description: '팀 결성 후 싱글·공연·커버 중 첫 활동 완료' },
    physical: { text: '첫 구매자 메시지 · 실물 판매 기념', description: '실물 음반 실제 판매1장 이상' },
    comeback: { text: '복귀 기사 · 아티스트의 감사 대화', description: '경력 아티스트가 자사에서 첫 음악·공연·커버 활동 완료' },
    stable: { cash: 300, text: '운영 지원금 300만 원', description: '업데이트 이후 완전한30일 정산3회 연속 영업흑자' }
  };
  D.specialOffers = {
    fan: {
      title: '팬들과 가까이 · 소규모 팬 공연',
      kind: 'live',
      budget: 300,
      days: 60,
      note: '팬1,000명 이상인 대상 · 공연비300만 원 · 준비7일 + 정산7일. 수익 보장 없음.'
    },
    star: {
      title: '우리의 다음 장 · 스타 싱글',
      kind: 'single',
      budget: 4000,
      days: 90,
      note: '스타 등급 이상 대상 · 기본 제작비4,000만 원 · 준비21일. 일반 제작·회복 조건 적용.'
    },
    collab: {
      title: '같은 무대의 다른 색 · 협업 싱글',
      kind: 'single',
      budget: 2000,
      days: 90,
      note: '현재 영업흑자 필요 · 기본 제작비2,000만 원 · 준비21일. 외부 세션과의 단발 협업이며 타사 인물·권리는 취득하지 않습니다.'
    },
    large: {
      title: 'NEXT STAGE LIVE · 대형 기획',
      kind: 'live',
      budget: 1500,
      days: 90,
      note: '현재 회사5단계 필요 · 공연비1,500만 원 · 준비7일 + 정산7일. 관객 부족 위험이 있습니다.'
    }
  };
  D.personalStories = {
    firststage: {
      title: '첫 무대 앞에서',
      body: '첫 공연을 앞두고 마음이 복잡합니다. 무대가 설레지만, 준비한 것을 잘 전할 수 있을지 걱정돼요.',
      support: '마음 정리·무대 조언 · 100만 원',
      space: '부담을 덜어 주는 대화 · 무료',
      replySupport: '제 속도에 맞춰 준비를 도와주셔서 고마워요.',
      replySpace: '실수해도 괜찮다는 말이 큰 힘이 됐어요.'
    },
    comeback: {
      title: '다시 시작하는 마음',
      body: '이전 활동의 기억이 아직 남아 있습니다. 이번에는 오래 이어 갈 수 있는 음악을 하고 싶어요.',
      support: '복귀 방향 상담 · 100만 원',
      space: '서두르지 않고 이야기 듣기 · 무료',
      replySupport: '지난 경험을 실패로만 보지 않아 주셔서 고마워요.',
      replySpace: '다시 시작할 시간을 믿고 기다려 주셨네요.'
    },
    creative: {
      title: '내 음악의 방향',
      body: '떠오르는 아이디어가 있지만 회사의 방향과 맞을지 고민입니다. 제 색을 어디까지 표현해도 될까요?',
      support: '아이디어 검토 지원 · 100만 원',
      space: '지금의 고민을 함께 듣기 · 무료',
      replySupport: '제 아이디어를 진지하게 봐주셔서 다음 곡이 기대돼요.',
      replySpace: '서둘러 답을 내지 않아도 된다는 말에 마음이 편해졌어요.'
    },
    pressure: {
      title: '조금 더 잘하고 싶은 마음',
      body: '기대에 부응하고 싶어 작은 실수도 오래 마음에 남습니다. 지금 페이스로 잘하고 있는 걸까요?',
      support: '멘토 상담 지원 · 100만 원',
      space: '휴식과 안심의 대화 · 무료',
      replySupport: '혼자 고민할 때보다 다음 목표가 선명해졌어요.',
      replySpace: '쉬어 가도 괜찮다는 말을 기억할게요.'
    },
    team: {
      title: '함께 맞추는 호흡',
      body: '같은 무대에 서지만 서로 생각하는 표현이 조금씩 다릅니다. 팀 안에서 제 목소리도 잘 전하고 싶어요.',
      support: '팀 소통 상담 · 100만 원',
      space: '각자의 생각부터 듣기 · 무료',
      replySupport: '다른 생각을 맞춰 가는 방법을 배웠어요.',
      replySpace: '제 의견도 팀의 일부라는 느낌이 들어요.'
    }
  };
  if (typeof module !== 'undefined') module.exports = D;
})(typeof window !== 'undefined' ? window: globalThis);


;
