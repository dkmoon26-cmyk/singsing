/* FILE src/legacy-state.js */
(function(root) {
  'use strict';
  function validLegacyState(s) {
    try {
      const D = typeof module !== 'undefined' ? require('./data.js'): root.DATA;
      const num =(v, min = - 1e12, max = 1e12) => Number.isFinite(v) && v >= min && v <= max;
      const int =(v, min = 0, max = 1e9) => Number.isInteger(v) && v >= min && v <= max;
      const str =(v, max = 300) => typeof v === 'string' && v.length <= max;
      const ids = xs => new Set(xs).size === xs.length;
      const choice =(v, xs) => xs.includes(v);
      if (!s || s.version !== 1 || !str(s.company, 30) || !str(s.boss, 20) || !int(s.day, 0, 1000000) || !int(s.seed, 0, 4294967295) || !int(s.serial) || !int(s.releases) || !num(s.reputation, 0, 100) || !choice(s.policy, ['balanced', 'growth'])) return false;
      if (s.guideHidden !== undefined && typeof s.guideHidden !== 'boolean') return false;
      if (s.guideStep !== undefined && !int(s.guideStep, 0, 6)) return false;
      for (const k of['cash', 'totalRevenue', 'monthIn', 'monthOut']) if (!num(s[k])) return false;
      for (const k of['artists', 'units', 'staff', 'jobs', 'candidates', 'reports', 'ledger', 'history', 'catalog', 'loans']) if (!Array.isArray(s[k]) || s[k].length > 10000 || s[k].some(x => x == null)) return false;
      if (!s.artists.every(a => int(a.id, 0, D.roster.length - 1) && Array.isArray(a.stats) && a.stats.length === 8 && a.stats.every(v => num(v, 0, 99)) &&['energy', 'stress', 'trust', 'fame'].every(k => num(a[k], 0, 100)) && int(a.fans) && int(a.contract) && choice(a.focus, ['balanced', 'creative', 'stage', 'rest']))) return false;
      if (!ids(s.artists.map(a => a.id)) || !ids(s.staff) || !s.staff.every(id => D.staff.some(p => p.id === id))) return false;
      const artist = id => s.artists.some(a => a.id === id);
      if (!s.units.every(u => /^u[1-9]\d*$/.test(u.key) && str(u.name, 20) && Array.isArray(u.ids) && u.ids.length >= 1 && u.ids.length <= 5 && ids(u.ids) && u.ids.every(artist) && choice(u.type, ['idol', 'band', 'rap']) && u.ids.every(id => D.roster[id].type === u.type)) || !ids(s.units.map(u => u.key)) || !ids(s.units.flatMap(u => u.ids))) return false;
      const entity = k => typeof k === 'string' &&(s.units.some(u => u.key === k) || s.artists.some(a => String(a.id) === k) ||(s.managementVersion === 2 && s.jobs.some(j => j.entity === k && j.snapshot)));
      const key = k => typeof k === 'string' &&(/^(0|[1-9]\d*)$/.test(k) || /^u[1-9]\d*$/.test(k));
      if (!s.jobs.every(j => int(j.id, 1, s.serial) && int(j.start, 0, s.day) && int(j.due, j.start + 1) && str(j.name, 60) && choice(j.kind, ['casting', 'single', 'live', 'cover', 'ad']) &&(j.kind === 'casting' ? choice(j.method, ['audition', 'scout']) && choice(j.type, ['any', 'idol', 'band', 'rap']): entity(j.entity) &&(j.kind === 'ad' ? num(j.pay, 0): num(j.budget, D.rules.activity[j.kind]?.min, D.rules.activity[j.kind]?.max) && choice(j.concept, ['balanced', 'creative', 'public']))))) return false;
      if (!s.candidates.every(c => int(c.id, 0, D.roster.length - 1) && !artist(c.id) && int(c.expires) && typeof c.evaluated === 'boolean') || !ids(s.candidates.map(c => c.id))) return false;
      if (!s.loans.every(l => int(l.id, 1, s.serial) && num(l.remaining, 0) && num(l.principal, 0) && num(l.payment, Number.EPSILON) && num(l.rate, 0, 1) && int(l.due) && int(l.missed))) return false;
      if (!s.reports.every(r => int(r.id, 1, s.serial) && int(r.day, 0, s.day) && str(r.title, 500) && str(r.body, 10000) && choice(r.kind, ['info', 'welcome', 'casting', 'ad', 'event', 'result', 'contract', 'finance', 'crisis']) &&['read', 'resolved', 'important'].every(k => typeof r[k] === 'boolean') &&(r.kind !== 'ad' || key(r.entity) && str(r.brand) && num(r.pay, 0) && int(r.expires)) &&(r.kind !== 'event' || key(r.entity)))) return false;
      if (!s.catalog.every(c => int(c.id, 1, s.serial) && key(c.entity) && str(c.name, 30) && num(c.quality, 0, 99) && int(c.age) && num(c.revenue, 0) && num(c.fanBase, 0) && choice(c.concept, ['balanced', 'creative', 'public'])) || !s.ledger.every(l => int(l.day, 0, s.day) && num(l.amount) && str(l.label, 500)) || !s.history.every(h => int(h.day, 0, s.day) && str(h.text, 500))) return false;
      if (s.lastMonth !== null &&(!s.lastMonth || !num(s.lastMonth.in, 0) || !num(s.lastMonth.out, 0) || !int(s.lastMonth.day, 0, s.day))) return false;
      const serials = [... s.jobs, ... s.reports, ... s.catalog, ... s.loans].map(x => x.id).concat(s.units.map(u => Number(u.key.slice(1))));
      return ids(serials);
    } catch {
      return false;
    }
  }
  if (typeof module !== 'undefined') module.exports = validLegacyState;
  else root.validLegacyState = validLegacyState;
})(typeof window !== 'undefined' ? window: globalThis);


;
