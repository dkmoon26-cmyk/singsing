/* Activity screens share jobs, outcomes, reports and the existing calendar. */
'use strict';
function activityHeading(title,desc){return heading(title,desc,btn('통합 일정','nav','data-page="schedule"','soft'));}
function activityTypeLabel(x){return x.albumType?ActivityData.albums[x.albumType].label+' · '+x.trackCount+'곡':x.venue?ActivityData.venues[x.venue].label:x.contentType?ActivityData.content[x.contentType].label:kindLabel[x.kind]||'활동';}
function activityChoiceCards(kind,items){return `<div class="activity-choice-grid">${Object.entries(items).map(([key,v])=>`<article class="panel activity-choice"><span class="eyebrow">${kind==='single'?'ALBUM':kind==='live'?'LIVE STAGE':'ARTIST CONTENT'}</span><h2>${v.label}</h2><p>${kind==='single'?v.tracks+'곡 · 기본 제작 '+v.days+'일':kind==='live'?v.capacity.toLocaleString()+'석 · 준비 '+v.days+'일':v.desc}</p><small>${kind==='single'?'제작비 '+money(1000*v.factor)+'~'+money(7000*v.factor)+' · 제조·홍보 별도':kind==='live'?'선집행 '+money(v.cost)+' · 티켓 '+money(v.ticket)+' · 관객당 현장비 '+money(v.variable,2):'제작 '+v.days+'일 · 예산 100~600만 원'}</small>${btn('준비하기','m-activity-new',`data-kind="${kind}" data-subtype="${key}"`,'primary',!game.s.artists.length)}</article>`).join('')}</div>`;}
function albums_activity(){
  return activityHeading('앨범 준비','아티스트와 음반 종류, 방향, 예산을 정하면 제작은 자동으로 진행됩니다.')+activityChoiceCards('single',{album:ActivityData.albums.album,mini:ActivityData.albums.mini,digital:ActivityData.albums.digital})+`<div class="tip section">곡마다 따로 조작하지 않습니다. 미니앨범·정규앨범은 제작 기간과 투자비가 늘고, 발매 후 관심이 더 오래 이어집니다. 곡 수만큼 수익이 배수로 늘지는 않습니다.</div>`+panel('최근 발매한 음반',game.s.catalog.slice(-6).reverse().map(c=>releaseRow({release:c,company:game.s.company,own:true})).join('')||'<p>첫 음악을 기다리고 있습니다.</p>');
}
function concerts_activity(){return activityHeading('공연','규모보다 현재 팬층과 수익을 먼저 확인하세요. 큰 공연장은 빈 좌석과 적자의 위험도 커집니다.')+activityChoiceCards('live',ActivityData.venues)+`<div class="tip section">승인 전에 예상 관객 범위·전체 비용·손익분기 관객·예상 회사 손익을 확인할 수 있습니다. 최근 공연 반복, 신곡 발매, 팀 팬과 직원 역량이 수요에 반영됩니다. 공연 대금은 완료 후 7일 뒤 입금됩니다.</div>`;}
function content_activity(){return activityHeading('콘텐츠','작은 활동으로 팬을 만나고 다음 발매를 준비하세요.')+activityChoiceCards('cover',ActivityData.content)+`<div class="tip section">콘텐츠 자체의 직접 수입은 없습니다. 개인·팀 팬과 인지도, 다음 발매 관심을 쌓습니다. 같은 콘텐츠를 최근 30일 동안 반복하면 팬과 발매 관심의 추가 효과가 줄어듭니다. 일상·소통 콘텐츠는 신뢰와 스트레스 회복도 돕습니다.</div>`;}
function offers_activity(){
  const offers=game.s.reports.filter(r=>r.kind==='ad'||r.festivalOfferId),pending=offers.filter(r=>game.reportState(r).needsDecision),closed=offers.filter(r=>!game.reportState(r).needsDecision).slice(0,10);
  return activityHeading('외부 제안','광고와 축제·행사 섭외를 검토하세요. 수신함과 같은 제안이며 한 번만 처리됩니다.')+panel('결정할 제안 · '+pending.length,reportRows(pending))+panel('최근 처리·종료된 제안',reportRows(closed));
}
function progress_activity(){
  const jobs=game.s.jobs.filter(j=>j.kind!=='casting');
  return activityHeading('진행 중','확정한 제작·공연·촬영과 행사 일정을 함께 확인하세요.')+panel('진행 중인 활동 · '+jobs.length,jobs.map(j=>{const state=j.kind==='single'?game.productionState(j):null,progress=state?1-state.remaining/((j.baselineDue??j.due)-j.start):(game.s.day-j.start)/(j.due-j.start);return `<article class="contract-row"><div class="row between wrap"><span class="pill">${activityTypeLabel(j)}</span><strong>D-${j.due-game.s.day}</strong></div><h3>${esc(j.name)}</h3><p>${esc(j.snapshot?.name||game.entity(j.entity)?.name||'확정 아티스트')} · 완료 예정 ${date(j.due,true)}</p><div class="bar"><span style="width:${Math.max(0,Math.min(100,progress*100))}%"></span></div><p>${j.kind==='ad'?'촬영 후 잔금 '+money(j.pay):'총 승인 비용 '+money(DATA.rules.jobCost(j))}</p>${state?.paused?'<small>행사·촬영으로 제작 일시 중단 · '+date(state.resume)+' 재개</small>':''}</article>`;}).join('')||'<p>진행 중인 제작·공연·촬영이 없습니다.</p>')+panel('확정 행사',game.s.engagements.map(e=>`<article class="contract-row"><h3>${esc(e.name)}</h3><p>${esc(e.snapshot.name)} · 준비 ${date(e.start)} → 행사 ${date(e.due)}</p></article>`).join('')||'<p>예약된 행사가 없습니다. 외부 제안을 확인해 보세요.</p>');
}
function results_activity(){
  return activityHeading('활동 결과','완료한 활동의 반응과 비용, 실제 정산을 확인하세요.')+panel('최근 활동',game.s.outcomes.slice(-20).reverse().map(o=>`<details class="contract-row"><summary>${esc(o.title)} · ${activityTypeLabel(o)} · ${date(o.day)}</summary><p>완성도 ${Math.round(o.quality)} · 개인 팬 ${o.fans>=0?'+':''}${o.fans.toLocaleString()}명</p><p>선집행 제작비 ${money(o.production)}${o.capacity?' · 유료 관객 '+o.attendance.toLocaleString()+'/'+o.capacity.toLocaleString()+'명':''}</p>${o.net!==null?'<p>회사 손익 '+money(o.net)+'</p>':'<p>'+ (o.kind==='single'?'음원·음반 매출과 투자금 회수는 발매 성과에서 확인하세요.':'콘텐츠 직접 수입 없음 · 팬과 발매 관심 중심의 활동입니다.')+'</p>'}${(o.factors||[]).map(f=>'<p>'+esc(f)+'</p>').join('')}${outcomeSettlementHTML(o)}</details>`).join('')||'<p>아직 완료한 활동이 없습니다.</p>')+panel('최근 행사 결과',game.s.festivalHistory.slice(-10).reverse().map(e=>`<details class="contract-row"><summary>${esc(e.artist)} · ${esc(e.name)} · ${date(e.day)}</summary><p>신규 팬 +${e.fans.toLocaleString()}명</p>${activityStatementHTML(festivalStatement(e))}</details>`).join('')||'<p>행사 출연 기록이 없습니다.</p>');
}
function projectModal_activity(key,kind='single',subtype=''){
  const entities=game.entities;if(!entities.length)throw Error('먼저 아티스트와 계약하세요.');
  modal('새 활동 준비',`<form id="activity-form"><div class="form-grid"><div class="field"><label for="activity-entity">아티스트·팀</label><select name="entity" id="activity-entity">${entities.map(e=>`<option value="${e.key}" ${key===e.key?'selected':''}>${esc(e.name)}</option>`).join('')}</select></div><div class="field"><label for="activity-kind">활동</label><select id="activity-kind" name="kind">${[['single','앨범 준비'],['live','공연'],['cover','콘텐츠']].map(([k,n])=>`<option value="${k}" ${kind===k?'selected':''}>${n}</option>`).join('')}</select></div></div><div class="field" data-activity-field="single"><label for="activity-album">음반 종류</label><select id="activity-album" name="albumType">${Object.entries(ActivityData.albums).map(([k,v])=>`<option value="${k}" ${subtype===k?'selected':''}>${v.label} · ${v.tracks}곡 · ${v.days}일</option>`).join('')}</select></div><div class="field" data-activity-field="live"><label for="activity-venue">공연장</label><select id="activity-venue" name="venue">${Object.entries(ActivityData.venues).map(([k,v])=>`<option value="${k}" ${subtype===k?'selected':''}>${v.label} · ${v.capacity.toLocaleString()}석 · ${money(v.cost)}</option>`).join('')}</select></div><div class="field" data-activity-field="cover"><label for="activity-content">콘텐츠 종류</label><select id="activity-content" name="contentType">${Object.entries(ActivityData.content).map(([k,v])=>`<option value="${k}" ${subtype===k?'selected':''}>${v.label} · ${v.days}일</option>`).join('')}</select></div><div class="field"><label for="activity-name">작품·활동 이름</label><input id="activity-name" name="title" maxlength="30" required placeholder="우리의 다음 무대"></div><div class="form-grid"><div class="field"><label for="activity-concept">활동 방향</label><select id="activity-concept" name="concept"><option value="balanced">균형 중심</option><option value="public">대중성 중심</option><option value="creative">창작 중심</option></select></div><div class="field" id="activity-budget-field"><label for="activity-budget">제작 투자</label><select id="activity-budget" name="budget"></select><small id="activity-budget-note"></small></div></div><div data-activity-field="single" class="form-grid"><div class="field"><label for="activity-format">발매 형태</label><select id="activity-format" name="format"><option value="digital">음원 전용</option><option value="physical">실물 음반 + 음원</option></select></div><div class="field"><label for="activity-quantity">실물 초도 수량</label><select id="activity-quantity" name="quantity">${[1000,3000,10000].map(n=>`<option value="${n}">${n.toLocaleString()}장 · 제조비 ${money(n*.6)}</option>`).join('')}</select></div><div class="field"><label for="activity-promotion">사전 홍보</label><select id="activity-promotion" name="promotion">${Object.entries(DATA.promotionPlans).map(([k,v])=>`<option value="${k}">${v.name} · ${money(v.cost)} · +${v.days}일</option>`).join('')}</select></div></div><div class="tip" id="activity-preview" aria-live="polite"></div><div class="modal-actions"><button type="submit" class="primary">활동 승인</button></div></form>`,true);
  activityBudgetOptions();activityPreview();
}
function activityBudgetOptions(){
  const kind=$('#activity-kind').value,rule=DATA.rules.activity[kind],select=$('#activity-budget');select.innerHTML=rule.budgets.map(([n,l])=>`<option value="${n}">${l}</option>`).join('');
}
function activityFormValues(){
  const f=$('#activity-form'),d=new FormData(f),kind=d.get('kind'),options=kind==='single'?{albumType:d.get('albumType'),format:d.get('format'),quantity:Number(d.get('quantity')),promotion:d.get('promotion')}:kind==='live'?{venue:d.get('venue')}:{contentType:d.get('contentType')};
  return{key:d.get('entity'),kind,title:d.get('title'),budget:Number(d.get('budget')),concept:d.get('concept'),options};
}
function activityPreview(){
  const f=$('#activity-form');if(!f)return;
  const kind=$('#activity-kind').value;f.querySelectorAll('[data-activity-field]').forEach(el=>el.hidden=el.dataset.activityField!==kind);$('#activity-budget-field').hidden=kind==='live';
  const digital=$('#activity-album').value==='digital';if(digital)$('#activity-format').value='digital';$('#activity-format').disabled=digital;$('#activity-quantity').disabled=digital||$('#activity-format').value!=='physical';
  const v=activityFormValues();if(digital&&kind==='single')v.options.format='digital';
  const target=$('#activity-preview'),submit=f.querySelector('[type="submit"]');
  try{
    const p=game.activityPlan(v.key,v.kind,v.budget,v.options),q=p.quote;
    $('#activity-budget').querySelectorAll('option').forEach(o=>{const factor=kind==='single'?ActivityData.albums[v.options.albumType].factor:1;o.textContent=money(Number(o.value)*factor);});
    $('#activity-budget-note').textContent=kind==='single'?'선택한 음반 종류에 따른 제작비입니다. 제조·홍보비 별도.':'직접 수입 없이 팬·관심을 위한 투자입니다.';
    target.innerHTML=`<p>완료 예정 <strong>${date(p.due,true)}</strong> · 기본 ${p.duration}일${p.due-game.s.day>p.duration?' · 홍보·확정 행사 연장 포함':''}</p><p>제작비 ${money(q.production)}${q.discount?' (지원 할인 '+money(q.discount)+')':''} · 제조 ${money(q.manufacturing)} · 홍보 ${money(q.promo)}</p><p><strong>지금 승인할 총액 ${money(q.total)}</strong></p>`;
    if(kind==='live'){
      const c=game.concertPreview(v.key,v.options.venue),lo=c.low,hi=c.high;
      target.innerHTML+=`<p>예상 관객 <strong>${lo.attendance.toLocaleString()}~${hi.attendance.toLocaleString()} / ${c.capacity.toLocaleString()}명</strong></p><p>예상 총비용 ${money(lo.totalCost)}~${money(hi.totalCost)} · 제작·현장·아티스트 배분 포함</p><p>손익분기 관객 <strong>${c.breakEven===null?'달성 불가':c.breakEven.toLocaleString()+'명'}${c.breakEven>c.capacity?' · 수용 좌석 초과':''}</strong></p><p>예상 회사 손익 <strong>${money(lo.net)}~${money(hi.net)}</strong></p><small>현재 팬·팀·직원 기준, 완성도 40~85 가정입니다. 완료일까지의 변화로 실제 관객은 달라집니다. 일 훈련·월 고정비 별도, 입금은 완료 후 7일 뒤입니다.</small>`;
    }
    if(kind==='cover'){const e=game.contentEffect(game.entity(v.key),v.options.contentType);target.innerHTML+=`<p>직접 수입 없음 · 최근 30일 같은 콘텐츠 ${e.repeats}회 · 팬·발매 관심 추가 효과 ${Math.round(e.multiplier*100)}%</p>`;}
    if(kind==='single'&&v.options.format==='physical')target.innerHTML+='<p>음반 판매가 '+money(v.options.albumType==='album'?3.5:3,2)+' · 장당 제조비 '+money(.6,2)+'</p>';
    if(kind==='single')target.innerHTML+='<small>실물 미판매 재고의 위험이 있습니다. 제작비는 선집행되며 발매 후 매출은 매주 정산됩니다.</small>';
    if(!p.allowed)target.innerHTML+='<p class="negative">'+p.reasons.map(esc).join(' · ')+'</p>';
    if(game.s.cash<q.total)target.innerHTML+='<p class="negative">승인 자금이 부족합니다.</p>';
    submit.disabled=!p.allowed||game.s.cash<q.total;
  }catch(e){target.textContent=e.message;submit.disabled=true;}
}
function managementClick_activity(action,d){if(action==='m-activity-new')projectModal_activity(d.entity,d.kind,d.subtype);}
UIEvents.onChange('activities',ev=>{if(!ev.target.closest('#activity-form'))return;if(ev.target.id==='activity-kind')activityBudgetOptions();activityPreview();});
$('#modal-root').addEventListener('submit',ev=>{
  if(ev.target.id!=='activity-form')return;ev.preventDefault();
  try{const v=activityFormValues();if(v.kind==='single'&&v.options.albumType==='digital')v.options.format='digital';mutate(()=>game.startProject(v.key,v.kind,v.title,v.budget,v.concept,v.options),'활동을 승인했습니다.');}catch(e){$('#modal-error').textContent=e.message;}
});

;
