/* FILE src/app-dialogs.js */
'use strict';
// app-dialogs: see docs/MAINTENANCE.md for ownership and loading order.
function projectModal_app(key) {
  let entities = game.entities;
  if (!entities.length) throw Error('먼저 아티스트와 계약해 주세요.');
  modal('새로운 활동 준비', `<form id="project-form"><div class="field"><label for="entity">아티스트·팀</label><select id="entity" name="entity">${entities.map(e=>`<option value="${e.key}" ${key===e.key?'selected':''}>${esc(e.name)} · ${DATA.labels[e.type]}${game.activityAvailability(e.key).allowed?'':' ('+esc(game.activityAvailability(e.key).reasons.join(' · '))+')'}</option>`).join('')}</select></div><div class="form-grid"><div class="field"><label for="project-kind">활동 종류</label><select id="project-kind" name="kind"><option value="single">싱글 제작 · 21일</option><option value="live">라이브 공연 · 7일</option><option value="cover">커버 공개 · 5일</option></select></div><div class="field"><label for="project-concept">활동 방향</label><select id="project-concept" name="concept"><option value="balanced">아티스트의 색과 대중성의 균형</option><option value="public">대중성 중심 · 정산 수익에 강점</option><option value="creative">창작 중심 · 아티스트 신뢰에 강점</option></select></div></div><div class="field"><label for="project-name">작품·활동 이름</label><input id="project-name" name="title" maxlength="30" placeholder="예: 우리의 첫 번째 계절" required></div><div class="field"><label for="budget">총 승인 예산</label><select id="budget" name="budget">${DATA.rules.activity.single.budgets.map(([n,label])=>`<option value="${n}" ${n===DATA.rules.activity.single.defaultBudget?'selected':''}>${label} · ${money(n)}</option>`).join('')}</select></div><div class="tip" id="budget-preview"></div><div class="modal-actions"><button class="primary" type="submit">프로젝트 승인</button></div></form>`);
  budgetPreview();
}
function castingModal() {
  modal('새로운 인재 모집', `<form id="casting-form"><div class="field"><label for="method">모집 방식</label><select id="method" name="method"><option value="audition">공개 오디션 · 500만 원</option><option value="scout">인재 발굴 · 200만 원</option></select></div><div class="field"><label for="type">찾고 싶은 분야</label><select id="type" name="type"><option value="any">모든 분야</option><option value="idol">아이돌</option><option value="band">밴드 연주자·보컬</option><option value="rap">래퍼</option></select></div><div class="field"><label for="position">밴드 포지션 (지정 시 밴드 분야 선택)</label><select id="position" name="position"><option value="any">전체</option><option>보컬</option><option>기타</option><option>베이스</option><option>드럼</option><option>키보드</option></select></div><label for="experience">찾고 싶은 경력</label><select name="experience" id="experience"><option value="any">전체</option><option value="trainee">연습생 후보</option><option value="career">활동 경력자 · 바로 활동 가능</option></select><div class="tip">후보 보고가 도착하면 날짜 건너뛰기가 멈춥니다. 후보를 비교한 뒤 원하는 인원만 영입할 수 있습니다.</div><div class="modal-actions"><button class="primary">모집 승인</button></div></form>`);
}
function newModal() {
  let s = loadSaved();
  modal('나만의 기획사 설립', `<form id="new-form"><div class="eyebrow">EVERY STORY STARTS HERE</div><div class="field"><label for="company">회사 이름</label><input id="company" name="company" maxlength="30" required placeholder="블루밍 뮤직" autocomplete="off"></div><div class="field"><label for="boss">사장 이름</label><input id="boss" name="boss" maxlength="20" required placeholder="대표님의 이름" autocomplete="off"></div><div class="tip">시작 자금 3억 원 · 기본 실장 1명 · 소속 아티스트 없음<br>첫 인재를 찾는 것부터 대표님의 이야기가 시작됩니다.</div>${s?'<label class="check-row section"><input type="checkbox" required>기존 자동 저장을 새 회사로 교체합니다.</label>':''}<div class="modal-actions"><button class="primary">회사 설립하기 ${ico('arrow')}</button></div></form>`);
}
function showReport(id, asModal) {
  let r = game.s.reports.find(x => x.id === + id);
  if (!r) return;
  r.read = true;
  selectedReport = r.id;
  save();
  if (asModal) {
    render();
    modal('직원 보고', reportDetail(r));
  } else {
    page = 'inbox';
    render();
  }
}
function unitModal_app() {
  let available = game.s.artists.filter(a => !game.s.units.some(u => u.ids.includes(a.id)));
  modal('새로운 팀 결성', `<form id="unit-form"><div class="field"><label for="unit-name">팀 이름</label><input id="unit-name" name="name" required maxlength="20" placeholder="예: 오프비트"></div><small>같은 분야의 멤버 2~5명 · 팀 결성 후 프로젝트는 팀 단위로 진행</small><div style="max-height:280px;overflow:auto">${available.map(a=>`<label class="check-row"><input type="checkbox" name="members" value="${a.id}"><img src="${DATA.roster[a.id].image}" alt=""><span>${DATA.roster[a.id].name} · ${DATA.labels[DATA.roster[a.id].type]}</span></label>`).join('')}</div><div class="modal-actions"><button class="primary">팀 결성 승인</button></div></form>`);
}


;
