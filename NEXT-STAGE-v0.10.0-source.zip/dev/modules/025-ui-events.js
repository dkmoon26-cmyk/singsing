/* FILE src/ui-events.js */
'use strict';
// One listener per DOM event. A feature registers its handler once by name.
const UIEvents =(() => {
  const changes = new Map();
  document.addEventListener('change', event => {
    for (const handler of changes.values()) handler(event);
  });
  return Object.freeze({ onChange(feature, handler) {
    if (changes.has(feature)) throw new Error('Duplicate UI event owner: ' + feature);
    changes.set(feature, handler);
  }
  });
})();


;
