/* FILE src/season.js */
(function(root) {
  'use strict';
  function install(Base, D, S) {
    const {clamp, round, hash, calendar} = typeof module !== 'undefined' ? require('./season-utils.js'): root.SeasonUtils;
    const Market = (typeof module !== 'undefined' ? require('./season-market.js'): root.installSeasonMarket)(Base, D, S);
    const Schedule = (typeof module !== 'undefined' ? require('./season-schedule.js'): root.installSeasonSchedule)(Market, D, S);
    const Awards = (typeof module !== 'undefined' ? require('./season-awards.js'): root.installSeasonAwards)(Schedule, D, S);
    class SeasonGame extends Awards {
      upgrade() {
        super.upgrade();
        const s = this.s;
        if (!s) return;
        if (s.seasonVersion === 1) {
          // Repair still-running v0.8.0 productions once without touching completed releases.
          for (const j of s.jobs.filter(j => j.kind === 'single')) this.reconcileProduction(j);
          return;
        }
        s.seasonVersion = 1;
        s.seasonSince = s.day;
        s.festivalOffers = [];
        s.engagements = [];
        s.festivalHistory = [];
        s.debutYears = {};
        s.seasonYear = calendar(s.day).getUTCFullYear();
        s.yearStats = {};
        s.awardHistory = [];
        s.chartHistory = { streams: {
          day: null,
          current: {},
          previous: {},
          best: {}
        }, sales: {
          day: null,
          current: {},
          previous: {},
          best: {}
        }
        };
        s.external = [];
        for (const a of[... s.artists, ... s.departed]) s.debutYears[a.id] = D.roster[a.id].career ? 2020: calendar(a.signed).getUTCFullYear();
        for (const rival of s.rivals) for (const t of rival.talents) if (t.active && s.debutYears[t.id] === undefined) s.debutYears[t.id] = 2020;
        for (let k = 0; k < 180; k++) s.external.push(this.externalRelease('initial-' + k, s.day -(k % 75), k));
        for (const c of s.external) for (let day = s.day - 6; day <= s.day; day++) if (day >= c.startDay) c.days.push({ day, ... this.externalCounts(c, day) });
      }
      finishSeason(j) {
        super.finishCampaign(j);
        if (j.kind === 'live' && j.concert) this.addLiveStat('p:' + j.entity, j.snapshot.name, true, j.snapshot.ids, this._lastQuality || 0, j.concert.attendance);
      }
      advanceSeason() {
        const s = this.s,
        year = calendar(s.day + 1).getUTCFullYear();
        if (year !== s.seasonYear) {
          s.seasonYear = year;
          s.yearStats = {};
        }
        const reports = new Set(s.reports.map(r => r.id));
        this.advanceEvolution();
        this.tickExternal();
        this.recordYear();
        this.recordCharts();
        for (const o of s.festivalOffers) if (o.status === 'open' && o.expires < s.day) o.status = 'expired';
        if (s.day % 21 === 0) {
          const month = calendar(s.day + 14).getUTCMonth() + 1;
          for (const e of this.entities) {
            if (s.festivalOffers.some(o => o.entity === e.key && o.status === 'open')) continue;
            const eligible = Object.entries(S.festivals).filter(([k, f]) => f.months.includes(month) && e.members.reduce((n, a) => n + a.fame, 0) / e.members.length >= f.fame);
            if (eligible.length) {
              const[kind] = eligible[hash(s.day + e.key) % eligible.length];
              this.createFestivalOffer(kind, e.key, s.day + 14);
              break;
            }
          }
        }
        const date = calendar(s.day);
        if (date.getUTCMonth() === 11 && date.getUTCDate() >= 1 && !s.awardHistory.some(a => a.year === s.seasonYear)) this.nominateAwards();
        if (date.getUTCMonth() === 11 && date.getUTCDate() >= 28) this.finishAwards();
        const summary = s.daySummaries.at(- 1);
        if (summary?.day === s.day) {
          summary.newReports = s.reports.filter(r => !reports.has(r.id)).length;
          summary.festivals = s.festivalHistory.filter(e => e.day === s.day).length;
        }
        return this.pending.length;
      }
    }
    return SeasonGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installSeason = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
