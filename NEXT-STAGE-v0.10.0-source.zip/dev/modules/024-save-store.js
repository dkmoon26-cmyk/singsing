/* FILE src/save-store.js */
(function(root) {
  'use strict';
  const codec = typeof module !== 'undefined' ? require('../vendor/pako.min.js'): root.pako;
  const MAX_SAVE_BYTES = 20000000;
  function utf8Size(text) {
    let bytes = 0;
    for (let i = 0; i < text.length; i++) {
      const c = text.charCodeAt(i);
      bytes += c < 128 ? 1: c < 2048 ? 2: c >= 0xD800 && c <= 0xDBFF && i + 1 < text.length ?(i++, 4): 3;
    }
    return bytes;
  }
  function encode(value) {
    let raw = JSON.stringify(value);
    if (utf8Size(raw) > MAX_SAVE_BYTES) throw Error('저장 크기 한도를 초과했습니다. 기존 저장을 유지합니다.');
    let bytes = codec.deflate(raw, { level: 3 }),
    parts = [];
    for (let i = 0; i < bytes.length; i += 16000) parts.push(String.fromCharCode(... bytes.subarray(i, i + 16000)));
    const data = root.btoa(parts.join(''));
    if (data.length > 12000000) throw Error('압축 저장 크기 한도를 초과했습니다. 기존 저장을 유지합니다.');
    return JSON.stringify({ codec: 'deflate-base64-v1', data });
  }
  function decode(raw) {
    let item = JSON.parse(raw);
    if (item?.codec !== 'deflate-base64-v1') return item;
    if (typeof item.data !== 'string' || item.data.length > 12000000) throw Error('Invalid compressed save');
    let binary = root.atob(item.data),
    bytes = Uint8Array.from(binary, c => c.charCodeAt(0)),
    inflate = new codec.Inflate({ to: 'string' }),
    parts = [],
    length = 0;
    inflate.onData = chunk => {
      length += utf8Size(chunk);
      if (length > MAX_SAVE_BYTES) throw Error('Expanded save too large');
      parts.push(chunk);
    };
    inflate.push(bytes, true);
    if (inflate.err) throw Error('Corrupt save');
    return JSON.parse(parts.join(''));
  }
  class SaveStore {
    constructor(provider, validate) {
      this.provider = provider;
      this.validate = validate;
      // Keep the version observed by this tab. Generic reads never adopt a newer save.
      this.autoBase = undefined;
      try { this.autoBase = this.storage().getItem('next-stage-v1'); } catch {}
    }
    storage() {
      return typeof this.provider === 'function' ? this.provider(): this.provider;
    }
    read(key) {
      try {
        let raw = this.storage().getItem(key);
        if (!raw) return null;
        return decode(raw);
      } catch {
        return null;
      }
    }
    checked(state) {
      if (!this.validate(state)) throw Error('손상되거나 지원하지 않는 저장입니다.');
      return JSON.parse(JSON.stringify(state));
    }
    readAuto(adopt = false) {
      try {
        const raw = this.storage().getItem('next-stage-v1');
        if (adopt) this.autoBase = raw;
        if (raw === null) return {state:null, status:'missing', raw};
        let state;
        try { state = decode(raw); } catch { return {state:null, status:'corrupt', raw}; }
        return this.validate(state) ? {state, status:'valid', raw}: {state:null, status:'corrupt', raw};
      } catch { return {state:null, status:'unavailable'}; }
    }
    hasAutoChanged() {
      try { return this.autoBase === undefined ? this.storage().getItem('next-stage-v1') !== null: this.storage().getItem('next-stage-v1') !== this.autoBase; }
      catch { return false; }
    }
    assertAutoCurrent(expected = this.autoBase) {
      const current = this.storage().getItem('next-stage-v1');
      if (expected === undefined ? current !== null: current !== expected) {
        const error = Error('다른 탭에서 저장이 변경됐습니다. 현재 진행을 백업하거나 최신 저장을 검토해 불러와 주세요.');
        error.code = 'SAVE_CONFLICT';
        throw error;
      }
    }
    writeAuto(state, expected = this.autoBase) {
      const clean = this.checked(state), encoded = encode(clean);
      this.assertAutoCurrent(expected);
      this.storage().setItem('next-stage-v1', encoded);
      this.autoBase = encoded;
      try { this.storage().setItem('next-stage-save-meta', JSON.stringify({ at: new Date().toISOString() })); }
      catch {}
    }
    slot(index) {
      if (!Number.isInteger(index) || index < 1 || index > 3) throw Error('저장 슬롯을 확인하세요.');
      return 'next-stage-slot-' + index;
    }
    saveSlot(index, state) {
      let entry = { savedAt: new Date().toISOString(), state: this.checked(state) };
      this.storage().setItem(this.slot(index), encode(entry));
      return entry;
    }
    removeSlot(index) {
      this.storage().removeItem(this.slot(index));
    }
    clearCheckpoints() {
      this.storage().removeItem('next-stage-checkpoints');
    }
    loadSlot(index) {
      let entry = this.read(this.slot(index));
      if (!entry) throw Error('슬롯이 비어 있거나 읽을 수 없습니다.');
      return this.checked(entry.state);
    }
    checkpoints() {
      let entries = this.read('next-stage-checkpoints');
      return Array.isArray(entries) ? entries.filter(e => e && typeof e.reason === 'string' && this.validate(e.state)).slice(0, 3):[];
    }
    checkpoint(state, reason) {
      let point = { savedAt: new Date().toISOString(), reason: String(reason).slice(0, 100), state: this.checked(state) };
      let points = [point, ... this.checkpoints()].slice(0, 3);
      this.storage().setItem('next-stage-checkpoints', encode(points));
      return point;
    }
    restorePoint(index) {
      let p = this.checkpoints()[index];
      if (!p) throw Error('복구 지점이 없습니다.');
      return this.checked(p.state);
    }
  }
  if (typeof module !== 'undefined') module.exports = SaveStore;
  else root.SaveStore = SaveStore;
})(typeof window !== 'undefined' ? window: globalThis);


;
