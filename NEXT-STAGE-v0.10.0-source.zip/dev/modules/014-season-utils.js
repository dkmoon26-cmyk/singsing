/* FILE src/season-utils.js */
(function(root) {
  'use strict';
    const clamp =(v, a, b) => Math.max(a, Math.min(b, v)),
    round = v => Math.round(v * 100) / 100;
    function hash(text) {
      let h = 2166136261;
      for (const c of String(text)) {
        h ^= c.charCodeAt(0);
        h = Math.imul(h, 16777619);
      }
      return h >>> 0;
    }
    const calendar = day => new Date(Date.UTC(2027, 0, 1 + day));
  const utils = Object.freeze({clamp, round, hash, calendar});
  if (typeof module !== 'undefined') module.exports = utils;
  else root.SeasonUtils = utils;
})(typeof window !== 'undefined' ? window: globalThis);


;
