/* FILE src/app-progress.js */
'use strict';
// app-progress: see docs/MAINTENANCE.md for ownership and loading order.
function mutate_app(fn, message) {
  checkSaveSession();
  if (game.s && /계약|이적|해체|데뷔|영입|팀|직원|프로젝트|활동|사건|제조|발매/.test(message || '')) saveStore.checkpoint(game.s, message + ' 전');
  game.transaction(fn);
  let saved = save();
  close();
  render();
  if (message && saved) toast(message);
}
async function advance() {
  if (running || !game.s) return;
  const from = game.s.day;
  running = true;
  lastAdvanceNotice = {
    from,
    to: from,
    mode: 'day',
    stop: '하루 진행 중…'
  };
  render();
  try {
    await new Promise(r => setTimeout(r, 80));
    if (!running) return;
    checkSaveSession();
    game.nextDay();
    lastAdvanceNotice.to = game.s.day;
    lastAdvanceNotice.at = Date.now();
    let saved = save();
    stopReason = saved ?(game.pending.length ? '확인할 보고가 도착했습니다.': ''): '진행은 완료됐지만 저장에 실패했습니다. JSON 백업을 내보내세요.';
    lastAdvanceNotice.stop = '하루 진행 완료' +(stopReason ? ' · ' + stopReason: '');
  } catch (e) {
    stopReason = '날짜 진행 중 오류: ' + e.message;
    lastAdvanceNotice.stop = stopReason;
    toast(stopReason);
  } finally {
    running = false;
    render();
    showAdvanceNotice();
  }
}
async function skip() {
  if (running || !game.s) return;
  if (game.pending.length) {
    stopReason = '먼저 확인할 주요 보고가 ' + game.pending.length + '건 있습니다.';
    page = 'inbox';
    selectedReport = null;
    render();
    toast('주요 보고를 확인한 후 다시 진행하세요.');
    return;
  }
  const from = game.s.day;
  running = true;
  stopReason = '중요한 소식까지 진행합니다.';
  lastAdvanceNotice = {
    from,
    to: from,
    mode: 'skip',
    stop: stopReason
  };
  let count = 0;
  render();
  try {
    while (running && count < 30) {
      await new Promise(r => setTimeout(r, 110));
      if (!running) break;
      checkSaveSession();
      game.nextDay();
      count++;
      lastAdvanceNotice.to = game.s.day;
      if (!save()) {
        running = false;
        stopReason = count + '일 경과 · 저장 실패로 진행을 중지했습니다. JSON 백업이 필요합니다.';
      } else if (game.pending.length) {
        running = false;
        stopReason = count + '일 경과 · 중요한 보고가 도착해 중지했습니다.';
      }
      lastAdvanceNotice.stop = running ? count + '일 경과 · 진행 중': stopReason;
      render();
    }
    if (running) {
      stopReason = count + '일 경과 · 최대 진행 기간에 도달했습니다.';
    } else if (!stopReason.includes('경과')) stopReason = count + '일 경과 · ' +(stopReason || '사용자가 중지했습니다.');
    lastAdvanceNotice.stop = stopReason;
    lastAdvanceNotice.at = Date.now();
  } catch (e) {
    stopReason = count + '일 경과 · 진행 오류: ' + e.message;
    lastAdvanceNotice.stop = stopReason;
    toast(stopReason);
  } finally {
    running = false;
    render();
    showAdvanceNotice();
  }
}


;
