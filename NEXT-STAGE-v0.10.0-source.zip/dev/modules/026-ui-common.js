/* FILE src/ui-common.js */
'use strict';
// ui-common: see docs/MAINTENANCE.md for ownership and loading order.
const $ = s => document.querySelector(s), esc = x => String(x ?? '').replace(/[&<>"']/g, c =>({
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;'
}
[c])), KEY = 'next-stage-v1';
const icons = {
  home: 'M3 10 12 3l9 7v11h-6v-7H9v7H3z',
  mail: 'M3 5h18v14H3z M3 6l9 7 9-7',
  people: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M17 4a4 4 0 0 1 0 8 M22 21v-2a4 4 0 0 0-3-3.87',
  star: 'm12 3 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z',
  folder: 'M3 7V4h6l3 3h9v14H3z',
  staff: 'M4 7h16v14H4z M9 7V3h6v4 M4 12h16 M10 12v3h4v-3',
  chart: 'M4 21V11h4v10 M10 21V3h4v18 M16 21V7h4v14',
  calendar: 'M3 5h18v16H3z M7 3v4 M17 3v4 M3 10h18',
  music: 'M9 18V5l12-2v13 M9 5l12-2 M9 18a3 3 0 1 1-3-3c2 0 3 1 3 3 M21 16a3 3 0 1 1-3-3c2 0 3 1 3 3',
  settings: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M12 2v3 M12 19v3 M2 12h3 M19 12h3 M5 5l2 2 M17 17l2 2 M5 19l2-2 M17 7l2-2',
  arrow: 'M5 12h14 M13 6l6 6-6 6',
  wallet: 'M3 5h17v16H3z M3 5l14-3v3 M15 11h6v5h-6z',
  check: 'M5 12l4 4L19 6',
  play: 'M8 4l12 8-12 8z',
  more: 'M5 12h.01 M12 12h.01 M19 12h.01'
};
const ico =(name) => `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="${icons[name]||icons.music}"/></svg>`;
const btn =(text, action, args = '', cls = '', disabled = false) => `<button type="button" class="${cls}" data-action="${action}" ${action==='nav'&&cls.split(/\s+/).includes('active')?'aria-current="page"':''} ${args} ${disabled?'disabled':''}>${text}</button>`;
const money = (n, decimals = 0) => {
  const factor = 10 ** decimals;
  n = Math.round(n * factor) / factor;
  if (Math.abs(n) >= 10000) {
    let a = Math.trunc(n / 10000),
    b = Math.abs(n % 10000);
    return a + '억' +(b ? ' ' + b.toLocaleString('ko-KR', {maximumFractionDigits:decimals}) + '만': '') + ' 원';
  }
  return n.toLocaleString('ko-KR', {maximumFractionDigits:decimals}) + '만 원';
};
const date =(day, full = false) => {
  let d = new Date(Date.UTC(2027, 0, 1 + day));
  return full ? `${d.getUTCFullYear()}년 ${d.getUTCMonth()+1}월 ${d.getUTCDate()}일 ${['일','월','화','수','목','금','토'][d.getUTCDay()]}요일`: `${d.getUTCMonth()+1}.${d.getUTCDate()}`;
};
const focusLabel = {
  balanced: '균형 성장',
  creative: '창작 집중',
  stage: '무대 집중',
  rest: '충분한 휴식'
};
const kindLabel = {
  award: '시상식',
  single: '앨범 준비',
  live: '라이브 공연',
  cover: '콘텐츠',
  ad: '광고 촬영',
  casting: '인재 모집'
};


;
