/* FILE src/season-market.js */
(function(root) {
  'use strict';
  function install(Base, D, S) {
    const {clamp, round, hash, calendar} = typeof module !== 'undefined' ? require('./season-utils.js'): root.SeasonUtils;
    class SeasonMarket extends Base {
      releaseDay(c, owner) {
        const m = c.market,
        appeal = m.appeal,
        age = this.s.day - m.startDay,
        boost = owner === 'player' && m.fame < 20 && c.quality >= 45 && age <= 28 ? 1.15: 1;
        try {
          m.appeal = appeal * boost;
          return super.releaseDay(c, owner);
        } finally {
          m.appeal = appeal;
        }
      }
      concert(e, j, quality) {
        const result = super.concert(e, j, quality),
        fans = e.members.reduce((n, a) => n + a.fans, 0);
        if (j.budget > 300 && fans >= result.capacity * 1.5) {
          result.attendance = Math.min(result.capacity, Math.floor(result.attendance * 1.15));
          result.gross = result.attendance * result.ticket;
          const unit = j.budget <= 800 ?(e.members.length > 1 ? 1.4: 1.2):(e.members.length > 1 ? 2: 1.8);
          result.variable = round(result.attendance * unit);
          j.concert = result;
          j.factors.unshift('충분한 팬층 · 확대 공연 관객 수요 +15%');
        }
        return result;
      }
      rivalsMonth() {
        const before = new Set(this.s.rivals.flatMap(r => r.talents.filter(t => t.active).map(t => t.id)));
        super.rivalsMonth();
        if (this.s.debutYears) for (const r of this.s.rivals) for (const t of r.talents) if (t.active && !before.has(t.id) && this.s.debutYears[t.id] === undefined) this.s.debutYears[t.id] = calendar(this.s.day).getUTCFullYear();
      }
      externalRelease(uid, day, k) {
        const h = hash(uid),
        year = calendar(day).getUTCFullYear(),
        isNew = year >= 2027 && h % 7 === 0,
        artist = isNew ? 40 +(year - 2027) * 8 +(h % 8): h % S.names.length,
        level = h % 10,
        titleHash = hash(uid + ':title');
        let suffix = 0,
        name;
        do {
          name = S.titles[(titleHash + Math.floor(suffix / S.subtitles.length)) % S.titles.length] + ' — ' + S.subtitles[((titleHash >>> 8) + suffix) % S.subtitles.length];
          suffix++;
        }
        while (this.s.external.some(c => c.artist === artist && c.name === name) && suffix < 512);
        return {
          uid: 'x-' + uid,
          name,
          artist,
          artistName: isNew ?['김', '이', '박', '최', '정', '윤', '한', '서', '임', '오', '장', '신'][(year - 2027) % 12] +['민아', '지율', '도겸', '하온', '서린', '지후', '채아', '건우'][h % 8]: S.names[artist],
          debutYear: isNew ? year: 2020,
          company:['별빛뮤직', '온에어레코드', '브리즈엔터', '독립 아티스트'][artist % 4],
          startDay: day,
          base: Math.round((1800 + Math.pow(level + 1, 2) * 1450) *(0.8 +(h % 40) / 100)),
          physical: artist % 3 !== 1,
          days:[]
        };
      }
      externalCounts(c, day) {
        const age = day - c.startDay;
        if (age < 0) return { streams: 0, sales: 0 };
        const wave = .9 +(hash(c.uid + ':' + Math.floor(age / 7)) % 25) / 100,
        buzz = age >= 14 && age < 42 && hash(c.uid) % 5 === 0 ? 1.5: 1;
        return { streams: Math.floor(c.base *(Math.exp(- age / 65) * buzz + .015) * wave), sales: c.physical ? Math.floor((10 + c.base / 1800) * Math.exp(- age / 9) +(c.base / 90000) * Math.exp(- age / 65)): 0 };
      }
      tickExternal() {
        const s = this.s;
        if (s.day % 7 === 0) for (let k = 0; k < 4; k++) s.external.push(this.externalRelease(s.day + '-' + k, s.day, k));
        s.external = s.external.filter(c => s.day - c.startDay < 365).slice(- 220);
        for (const c of s.external) {
          if (c.days.at(- 1)?.day === s.day) continue;
          c.days.push({ day: s.day, ... this.externalCounts(c, s.day) });
          c.days = c.days.slice(- 14);
        }
      }
      globalReleases() {
        return [... super.allReleases().map(x =>({ ... x, external: false })), ... this.s.external.map(c =>({
          own: false,
          external: true,
          externalArtist: c.artist,
          externalDebut: c.debutYear,
          company: c.company,
          release: { name: c.name, quality: 50 +(hash(c.uid) % 40), market: {
            uid: c.uid,
            artistName: c.artistName,
            startDay: c.startDay,
            format: c.physical ? 'physical': 'digital',
            days: c.days
          }
          }
        }))];
      }
      charts(metric = 'streams', scope = 'all') {
        if (!['streams', 'sales'].includes(metric) || !['all', 'labels'].includes(scope)) throw Error('차트 종류를 확인하세요.');
        return(scope === 'labels' ? super.allReleases(): this.globalReleases()).map(row =>({ ... row, week: row.external ? row.release.market.days.filter(d => d.day > this.s.day - 7 && d.day <= this.s.day).reduce((n, d) =>({ streams: n.streams + d.streams, sales: n.sales + d.sales }), { streams: 0, sales: 0 }): this.weekStats(row.release) })).filter(row => row.week[metric] > 0).sort((a, b) => b.week[metric] - a.week[metric] || a.release.market.uid.localeCompare(b.release.market.uid));
      }
      chartPosition(uid, metric = 'streams', ranks = null) {
        const rank = ranks ? (ranks.get(uid) || 0): this.charts(metric).findIndex(r => r.release.market.uid === uid) + 1,
        h = this.s.chartHistory[metric];
        return {
          rank: rank || null,
          previous:(h.day === this.s.day ? h.previous[uid]: h.current[uid]) || null,
          best: h.best[uid] || null,
          newEntry: !!rank && !h.previous[uid]
        };
      }
      recordCharts() {
        if (this.s.day % 7 !== 0) return;
        for (const metric of['streams', 'sales']) {
          const h = this.s.chartHistory[metric];
          if (h.day === this.s.day) continue;
          h.previous = h.current;
          h.current = {};
          for (const[index, row] of this.charts(metric).entries()) {
            const uid = row.release.market.uid,
            rank = index + 1;
            h.current[uid] = rank;
            if (rank <= 100 || row.own) h.best[uid] = Math.min(h.best[uid] || Infinity, rank);
          }
          h.day = this.s.day;
          const keep = new Set([... Object.keys(h.current), ... Object.keys(h.previous), ... super.allReleases().filter(r => r.own).map(r => r.release.market.uid)]);
          for (const uid of Object.keys(h.best)) if (!keep.has(uid)) delete h.best[uid];
        }
      }

    }
    return SeasonMarket;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installSeasonMarket = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
