/* FILE src/data.js */
(function(root) {
  const names = ['서윤', '태오', '리오', '도현', '하린', '노아', '이솔', '건우', '제이', '유찬', '은재', '도크', '루아', '시온', '아샤', '민재', '해온', '카이'];
  const types = ['idol', 'band', 'rap', 'idol', 'band', 'rap', 'idol', 'band', 'rap', 'idol', 'band', 'rap', 'idol', 'band', 'rap', 'idol', 'band', 'rap'];
  const stories = ['맑은 음색과 차분한 태도. 작은 무대에서도 끝까지 눈을 맞춘다.', '빈티지 록을 사랑하는 기타리스트. 자작곡 수첩을 늘 가지고 다닌다.', '자기 이야기를 직설적인 가사로 풀어내는 래퍼.', '단정한 인상과 정확한 춤선. 팀의 중심이 되고 싶다.', '거침없는 드럼과 유쾌한 에너지로 합주실을 채운다.', '따뜻한 저음과 재즈 감각. 오래 들을 음악을 꿈꾼다.', '표정 연기와 퍼포먼스에 강한 완벽주의자.', '묵직한 베이스와 느긋한 성격. 라이브 경험이 풍부하다.', '날카로운 플로와 재치 있는 가사. 도전을 즐긴다.', '부드러운 음색의 보컬. 긴장하면 말수가 줄어든다.', '섬세한 키보드 연주와 편곡 감각을 갖췄다.', '위트 있는 랩으로 관객과 대화하는 공연형 아티스트.', '밝은 에너지와 독특한 음색. 무대를 놀이터처럼 쓴다.', '리듬 기타에 강한 성실파. 합주에서 동료를 먼저 듣는다.', '다채로운 리듬과 자신감. 음악의 경계를 넘고 싶다.', '눈에 띄는 무대 표현력. 보컬은 더 다듬어야 한다.', '감정 깊은 보컬과 작곡 감각. 밴드의 이야기를 노래한다.', '단단한 발성과 공격적인 무대. 자신만의 색이 확실하다.'];
  const labels = { idol: '아이돌', band: '밴드', rap: '힙합' };
  const specs = ['보컬', '랩', '댄스', '연주', '창작', '무대', '미디어', '협업'];
  const roster = names.map((name, i) =>({
    id: i,
    name,
    type: types[i],
    age: 20 + i % 12,
    story: stories[i],
    image: nextStagePortraitUrl(`assets/portraits/artist-${i}-anime-v1.webp`),
    style:['POP', 'ROCK', 'HIP-HOP'][i % 3],
    traits:['성실한 노력가', '자유로운 창작자', '무대 체질', '신중한 완벽주의자', '분위기 메이커', '독립적인 예술가'][i % 6],
    stats: specs.map((_, j) => Math.min(89, 36 +((i * 17 + j * 13) % 31) +(types[i] === 'idol' &&[0, 2, 5].includes(j) ? 17: types[i] === 'band' &&[3, 4, 7].includes(j) ? 17: types[i] === 'rap' &&[1, 4, 5].includes(j) ? 17: 0)))
  }));
  const extraNames = ['지안', '우진', '세나', '재하', '유리', '로건', '나린', '지호', '수아', '현우', '다온', '예린', '태린', '준서', '소민', '시우', '하온', '채린', '지유', '서진', '라온', '이든', '예온', '하율', '도윤', '유나', '서우', '다인', '태하', '시아', '윤재', '나온', '수빈', '지율', '세온', '아린', '주원', '리안', '은솔', '해준', '루진', '규리'];
  for (let i = 18; i < 60; i++) {
    let type = i < 24 ? types[i % 3]: i < 42 ? 'idol': i < 51 ? 'band': 'rap';
    roster.push({
      id: i,
      name: extraNames[i - 18],
      type,
      age: 18 + i % 8,
      story: i < 24 ? '독립 무대에서 경험을 쌓은 신인입니다.': '훈련과 데뷔 기회를 기다리는 연습생 지망생입니다.',
      image: nextStagePortraitUrl(`assets/portraits/artist-${i}-anime-v1.webp`),
      style: { idol: 'POP', band: 'ROCK', rap: 'HIP-HOP' }[type],
      traits:['창작 지향', '무대 지향', '안정 지향'][i % 3],
      stats: specs.map((_, j) => Math.min(85, (i < 24 ? 48: 32) +(i * 11 + j * 7) % 25))
    });
  }
  roster.forEach((a, i) => {
    a.image = nextStagePortraitUrl(`assets/portraits/artist-${a.id}-anime-v${[0,1,2,18].includes(a.id)?2:1}.webp`);
    a.trainee = i >= 24;
    a.position = a.type === 'band' ?['보컬', '기타', '베이스', '드럼', '키보드'][Math.floor(i / 3) % 5]: a.type === 'rap' ? '래퍼': '보컬·퍼포먼스';
    a.available = i < 54 ? 0: 365;
  });
  const personalLines = ['작은 무대라도 관객 한 사람과 눈을 맞추고 노래하고 싶어요.', '낡은 기타 소리에도 새 이야기가 숨어 있다고 믿어요.', '제 이야기를 제 언어로 쓰는 래퍼가 되고 싶어요.', '매일 같은 동작을 연습해도 어제와 다른 무대를 만들고 싶어요.', '합주가 막힐 땐 제가 먼저 분위기를 풀어 볼게요.', '늦은 밤에도 오래 듣고 싶은 음악을 만들고 싶어요.', '표정 하나까지 곡의 이야기를 담아내고 싶어요.', '튀기보다는 동료들이 편하게 연주할 수 있게 받쳐 줄게요.', '관객이 예상하지 못한 한 줄을 들려주고 싶어요.', '말은 서툴러도 노래로는 마음을 전할 수 있어요.', '멜로디 뒤에 숨은 화음을 찾아내는 게 즐거워요.', '공연장에서는 관객의 대답까지 제 음악이에요.', '무대에서만큼은 누구보다 신나게 놀고 싶어요.', '합주가 끝나면 동료들의 연주부터 다시 들어요.', '장르가 달라도 좋은 리듬은 서로 통한다고 생각해요.', '제가 설 무대의 첫 장면부터 상상하며 연습해요.', '쉽게 지나치는 감정도 곡으로 남기고 싶어요.', '첫 소절부터 제 이름을 기억하게 만들고 싶어요.', '서두르기보다 제 목소리를 알아가는 시간을 갖고 싶어요.', '기타 줄을 바꿀 때마다 새로운 곡을 시작하는 기분이에요.', '조용해 보여도 마이크를 잡으면 할 말이 많아요.', '팀의 중심에서도 동료들의 표정을 놓치고 싶지 않아요.', '베이스처럼 묵묵하게 오래 남는 사람이 되고 싶어요.', '화려한 말보다 솔직한 한 줄을 들려드릴게요.', '긴장되면 가사를 손으로 써요. 그러면 조금씩 용기가 나요.', '사람들 앞에 서는 건 아직 떨리지만 매일 나아지고 싶어요.', '친구들이 따라 부를 수 있는 노래를 들려주고 싶어요.', '연습실에 가장 먼저 와서 오늘의 목표를 적어 둬요.', '잘 안 풀린 날에도 작은 진전 하나는 꼭 찾아요.', '노래의 감정을 표정으로도 전하는 연습을 하고 있어요.', '남들이 정한 이미지보다 제가 편한 모습을 찾고 싶어요.', '오래 준비한 만큼 서두르지 않고 단단하게 데뷔하고 싶어요.', '틀려도 웃고 다시 해보는 게 제 장점이에요.', '같은 안무라도 제 리듬을 살리는 순간이 좋아요.', '조용한 연습실에서 한 소절을 완성하면 하루가 뿌듯해요.', '무대에 오르면 평소보다 솔직해지는 것 같아요.', '연습 일지에 부족했던 점보다 내일 해볼 일을 적어요.', '동료와 호흡이 맞는 순간이 가장 기분 좋아요.', '첫인상은 차가워도 함께 연습하면 꽤 수다스러워요.', '빠르게 주목받기보다 오래 믿고 듣는 가수가 되고 싶어요.', '떨릴 때는 박자를 손끝으로 세면서 마음을 다잡아요.', '오늘은 어제보다 한 번 더 자신 있게 해볼게요.', '건반 위에서는 복잡한 생각도 차분하게 정리돼요.', '빈 연습실의 잔향을 듣는 시간이 좋아요.', '마음에 드는 화음을 찾으면 잊기 전에 꼭 녹음해요.', '누군가 힘든 하루 끝에 찾아 듣는 목소리가 되고 싶어요.', '첫 음을 내기 전에 곡의 장면부터 떠올려요.', '완벽한 음정보다 살아 있는 감정을 담고 싶어요.', '좋아하는 기타 리프는 손이 기억할 때까지 반복해요.', '조금 거친 소리도 제 음악의 일부로 남기고 싶어요.', '합주에서 비어 있는 공간을 채우는 기타를 치고 싶어요.', '짧은 벌스에도 시작과 끝이 있는 이야기를 담아요.', '함께 고개를 끄덕일 수 있는 비트를 만들고 싶어요.', '작은 목소리로 해둔 메모가 무대에서 큰 말이 돼요.', '할 말이 정리될 때까지 가사를 여러 번 고쳐 써요.', '낯선 리듬을 만나면 일단 몸으로 따라가 봐요.', '제 말투 그대로 랩해도 괜찮다는 걸 보여주고 싶어요.', '친구들과 나눈 농담도 가사의 씨앗이 되곤 해요.', '실수한 무대도 다음 공연의 재료라고 생각해요.', '목소리를 키우기보다 제 생각을 분명히 전하고 싶어요.'];
  const personalities = [{
    name: '차분한 꾸준함',
    training: 'vocal',
    focus: 'balanced',
    session: 'rest',
    offer: 'balanced',
    reaction: '차분히 쌓은 연습이 오늘은 조금 들리는 것 같아요.'
  }, {
    name: '몰입하는 창작가',
    training: 'creative',
    focus: 'creative',
    session: 'creative',
    offer: 'artist',
    reaction: '제 아이디어를 끝까지 다듬어 볼 수 있어서 좋아요.'
  }, {
    name: '도전하는 표현가',
    training: 'performance',
    focus: 'stage',
    session: 'stage',
    offer: 'artist',
    reaction: '직접 부딪쳐 보니 무대에서 해보고 싶은 게 늘었어요.'
  }, {
    name: '신중한 완벽주의',
    training: 'balanced',
    focus: 'balanced',
    session: 'rest',
    offer: 'balanced',
    reaction: '하나씩 정리하고 나니 다시 집중할 수 있겠어요.'
  }, {
    name: '함께 크는 활력',
    training: 'performance',
    focus: 'stage',
    session: 'stage',
    offer: 'balanced',
    reaction: '같이 호흡을 맞추니까 혼자 할 때보다 용기가 나요.'
  }, {
    name: '독립적인 탐구가',
    training: 'creative',
    focus: 'creative',
    session: 'creative',
    offer: 'artist',
    reaction: '저만의 방법을 시험해 볼 시간을 주셔서 고마워요.'
  }];
  roster.forEach((a, i) => {
    a.personality = { ... personalities[i % 6], intro: personalLines[i] };
  });
  const stageNames = ['', '신생 레이블', '소형 기획사', '성장 기획사', '중견 기획사', '대형 엔터테인먼트사'];
  const terms = { company: {
    name: '회사 중심',
    fee: 100,
    share: .8,
    days: 365
  }, balanced: {
    name: '균형',
    fee: 200,
    share: .65,
    days: 730
  }, artist: {
    name: '아티스트 중심',
    fee: 400,
    share: .5,
    days: 1095
  }
  };
  const stageRules = [{
    level: 2,
    days: 180,
    revenue: 30000,
    profit: 0,
    runway: 3
  }, {
    level: 3,
    days: 365,
    revenue: 150000,
    profit: 10000,
    runway: 4
  }, {
    level: 4,
    days: 730,
    revenue: 700000,
    profit: 70000,
    runway: 6
  }, {
    level: 5,
    days: 1095,
    revenue: 3000000,
    profit: 300000,
    runway: 9
  }];
  const staff = [{
    id: 'manager',
    name: '윤지호',
    role: '매니저',
    salary: 250,
    fee: 150,
    level: 1,
    spec: '일정·컨디션 관리',
    stats:[76, 82, 65, 68, 84]
  }, {
    id: 'casting',
    name: '김서연',
    role: '캐스팅 담당',
    salary: 300,
    fee: 200,
    level: 1,
    spec: '후보 평가·인재 발굴',
    stats:[86, 71, 68, 84, 72]
  }, {
    id: 'trainer',
    name: '정다은',
    role: '육성 담당',
    salary: 350,
    fee: 250,
    level: 2,
    spec: '훈련·합주 성장 효율',
    stats:[88, 78, 52, 64, 82]
  }, {
    id: 'producer',
    name: '강우진',
    role: '프로듀서',
    salary: 450,
    fee: 300,
    level: 2,
    spec: '음반 완성도·제작',
    stats:[91, 74, 71, 82, 66]
  }, {
    id: 'promo',
    name: '박세린',
    role: '홍보 담당',
    salary: 400,
    fee: 250,
    level: 2,
    spec: '팬 유입·광고 발굴',
    stats:[82, 80, 86, 89, 77]
  }, {
    id: 'ads',
    name: '차민호',
    role: '광고 영업',
    salary: 500,
    fee: 350,
    level: 3,
    spec: '광고 계약금·광고 기회',
    stats:[87, 79, 93, 91, 75]
  }, {
    id: 'live',
    name: '문하준',
    role: '공연 담당',
    salary: 450,
    fee: 300,
    level: 3,
    spec: '공연 수익·섭외',
    stats:[86, 88, 81, 92, 73]
  }];
  const DATA = {
    roster,
    staff,
    labels,
    specs,
    stageNames,
    terms,
    stageRules,
    rules: typeof module !== 'undefined' ? require('./rules.js'): root.GameRules
  };
  if (typeof module !== 'undefined') module.exports = DATA;
  else root.DATA = DATA;
})(typeof window !== 'undefined' ? window: globalThis);


;
