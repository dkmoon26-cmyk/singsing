/* FILE src/app.js */
'use strict';
// app: see docs/MAINTENANCE.md for ownership and loading order.
const saveStore = new SaveStore(() => localStorage, validState);
let lastAdvanceNotice = null;
let game = new Game(), page = 'home', filter = 'all', selectedReport = null, running = false, stopReason = '', saveOK = true;


;
