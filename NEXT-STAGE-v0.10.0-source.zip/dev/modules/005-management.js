/* FILE src/management.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const clamp =(n, a, b) => Math.max(a, Math.min(b, n));
    class ManagementGame extends Base {
      constructor(state) {
        super(state ? JSON.parse(JSON.stringify(state)): null);
        if (this.s) this.upgrade();
      }
      newGame(company, boss) {
        super.newGame(company, boss);
        this.upgrade();
        return this.s;
      }
      upgrade() {
        let s = this.s;
        if (s.managementVersion === 2) return;
        s.managementVersion = 2;
        s.recordSince = s.day;
        s.companyLevel = 1;
        s.lowQuarters = 0;
        s.accounts = [];
        s.trainees = [];
        s.departed = [];
        s.teamArchive = [];
        s.goals = [];
        s.performance = [];
        s.payments = [];
        s.industryNews = [];
        s.valuations = [];
        s.rivals = [['블룸 팩토리', 'idol', 80000, [18, 21, 24]], ['루트 레코즈', 'band', 60000, [19, 22, 43]], ['모션 레이블', 'rap', 70000, [20, 23, 52]], ['오로라 뮤직', 'any', 250000, [25, 44, 53]]].map((r, i) =>({
          id: i,
          name: r[0],
          type: r[1],
          cash: r[2],
          debt: 0,
          artists: r[3],
          catalog:[],
          accounts:[],
          jobs:[],
          fans: 1000 *(i + 1),
          reputation: 20 + i * 10,
          level: i === 3 ? 3: 1,
          value: r[2],
          serial: 0
        }));
        s.artists.forEach(a => {
          a.terms = { ... D.terms.balanced, share: 1, name: '기존 계약(회사 순정산)' };
          a.signed = s.day;
          a.lastActive = s.day;
          a.star = 0;
          a.bestStar = 0;
        });
        s.units.forEach(u => {
          u.status = 'active';
          u.fame = 0;
          u.fans = 0;
          u.star = 0;
          u.bestStar = 0;
        });
        for (const c of s.catalog) {
          c.shares = [];
          c.ownerName = this.entity(c.entity)?.name || '기존 작품';
        }
        s.rivals.forEach(r => {
          r.artists = r.artists.filter(id => !this.artist(id));
        });
        for (const j of s.jobs) if (j.entity) {
          j.snapshot = this.snapshot(j.entity);
          j.shares = [];
        }
        s.candidates = s.candidates.filter(c => this.available(c.id));
      }
      get stage() {
        return this.s.companyLevel || 1;
      }
      get capacity() {
        return 6 +(this.has('manager') ? 6: 0) +(this.has('casting') ? 2: 0);
      }
      get traineeCapacity() {
        return 6 +(this.has('trainer') ? 6: 0);
      }
      get fixed() {
        return super.fixed + this.s.trainees.length * 60;
      }
      get entities() {
        return super.entities;
      }
      available(id) {
        let d = D.roster[id];
        return !!d && !this.artist(id) && !this.s.trainees.some(a => a.id === id) && !this.s.rivals.some(r => r.artists.includes(id)) && d.available <= this.s.day;
      }
      account(amount, revenue, expense, entity = null) {
        let s = this.s,
        b = s.accounts.at(- 1);
        if (!b || b.day !== s.day) {
          b = {
            day: s.day,
            revenue: 0,
            expense: 0,
            by: {}
          };
          s.accounts.push(b);
        }
        b.revenue += revenue;
        b.expense += expense;
        if (entity && revenue) b.by[entity] =(b.by[entity] || 0) + revenue;
      }
      change(amount, label, operating = true, meta = {}) {
        super.change(amount, label, operating, meta);
        if (!this.s.accounts) return;
        const financing = ['loan', 'loan_repayment', 'rescue'].includes(meta.kind);
        let interest = 0;
        if (meta.kind === 'loan_repayment') interest = meta.interest || 0;
        this.account(amount, operating && amount > 0 ? amount: 0, amount < 0 ?(financing ? interest: - amount): 0, this._earningEntity || null);
      }
      receive(amount, label, shares = [], key = null, kind = 'income') {
        this._earningEntity = key;
        this.change(amount, label, true, { kind });
        this._earningEntity = null;
        for (const x of shares) {
          let payment = Math.round(amount * x.rate * 100) / 100;
          if (payment <= 0) continue;
          this.change(- payment, '아티스트 배분: ' + D.roster[x.id].name);
          this.s.payments.unshift({
            day: this.s.day,
            id: x.id,
            amount: payment,
            label
          });
        }
        this.s.payments = this.s.payments.slice(0, 100);
      }
      metrics() {
        let s = this.s,
        bins = s.accounts.filter(b => b.day > s.day - 365);
        let revenue = bins.reduce((n, b) => n + b.revenue, 0),
        expense = bins.reduce((n, b) => n + b.expense, 0),
        by = {};
        for (const b of bins) for (const[k, v] of Object.entries(b.by)) by[k] =(by[k] || 0) + v;
        return {
          revenue,
          expense,
          profit: revenue - expense,
          runway: Math.max(0, s.cash /(this.fixed + s.artists.length * 300)),
          concentration: revenue ? Math.max(0, ... Object.values(by)) / revenue: 0,
          days: Math.min(365, s.day - s.recordSince)
        };
      }
      valuation() {
        let m = this.metrics(),
        s = this.s;
        let contractRisk = s.artists.length ? s.artists.reduce((n, a) => n + clamp((a.contract - s.day) / 365, 0, 1), 0) / s.artists.length: 0;
        let operating = Math.max(0, m.profit * 4, m.revenue * .45) *(0.65 + contractRisk * .35) *(1 - m.concentration * .25);
        let equity = Math.max(0, operating + s.cash - this.debt);
        let spread = m.days < 180 ? .35: .15;
        return {
          value: equity,
          low: Math.round(equity *(1 - spread)),
          high: Math.round(equity *(1 + spread)),
          operating: Math.round(operating),
          confidence: m.days < 180 ? '낮음': '보통',
          contractRisk
        };
      }
      hire(id) {
        let p = D.staff.find(x => x.id === id);
        if (!p || this.has(id)) throw Error('채용할 직무를 확인하세요.');
        this.spend(p.fee, '직원 채용: ' + p.name);
        this.s.staff.push(id);
        this.log(p.name + ' 채용');
      }
      startCasting(method, type, position = 'any') {
        if (!['any', '보컬', '기타', '베이스', '드럼', '키보드'].includes(position)) throw Error('포지션을 확인하세요.');
        if (!D.roster.some(d => this.available(d.id) &&(type === 'any' || d.type === type) &&(position === 'any' || d.position === position))) throw Error('현재 모집할 수 있는 후보가 없습니다.');
        super.startCasting(method, type);
        this.s.jobs.at(- 1).position = position;
      }
      sign(id, offer = 'balanced') {
        id = Number(id);
        let c = this.s.candidates.find(c => c.id === id),
        terms = D.terms[offer];
        if (!terms || !c || c.expires < this.s.day || !this.available(id)) throw Error('계약 가능한 후보와 제안서를 확인하세요.');
        const trainee = D.roster[id].trainee;
        if (trainee ? this.s.trainees.length >= this.traineeCapacity: this.s.artists.length >= this.capacity) throw Error('관리 정원이 부족합니다. 담당 직원을 채용하세요.');
        this.spend(trainee ? D.rules.traineeFee: terms.fee, trainee ? '연습생 계약 지원': '아티스트 계약금');
        let prior = this.s.departed.find(a => a.id === id);
        let a = prior ? JSON.parse(JSON.stringify(prior)): {
          id,
          stats:[... D.roster[id].stats],
          energy: 95,
          stress: 10,
          trust: 70,
          fans: 50 + Math.floor(this.rng() * 120),
          fame: 2,
          focus: 'balanced',
          star: 0,
          bestStar: 0
        };
        a.contract = this.s.day +(trainee ? 730: terms.days);
        a.signed = this.s.day;
        a.terms = { ... terms };
        a.lastActive = this.s.day;
        a.star = a.star || 0;
        a.bestStar = a.bestStar || 0;
        (trainee ? this.s.trainees: this.s.artists).push(a);
        this.s.departed = this.s.departed.filter(x => x.id !== id);
        this.s.candidates = this.s.candidates.filter(x => x.id !== id);
        this.log(D.roster[id].name + ' ' +(trainee ? '연습생 영입': '전속계약'));
        this.report('새로운 계약', D.roster[id].name + '과 함께합니다. ' +(trainee ? '훈련 후 데뷔 평가를 진행하세요.': '활동 수익은 계약 비율에 따라 배분합니다.'), 'info', false);
      }
      readiness(a) {
        return a.stats.reduce((n, v) => n + v, 0) / 8;
      }
      debut(id, offer = 'balanced') {
        let a = this.s.trainees.find(a => a.id === Number(id)),
        t = D.terms[offer];
        if (!a || !t) throw Error('연습생과 계약을 확인하세요.');
        if (this.s.day - a.signed < 90 || this.readiness(a) < 55) throw Error('훈련 90일·평균 능력 55 이상이 필요합니다.');
        if (this.s.artists.length >= this.capacity) throw Error('아티스트 관리 정원이 부족합니다.');
        this.spend(t.fee, '데뷔 계약금');
        this.s.trainees = this.s.trainees.filter(x => x !== a);
        a.terms = { ... t };
        a.contract = this.s.day + t.days;
        a.signed = this.s.day;
        a.lastActive = this.s.day;
        this.s.artists.push(a);
        this.log(D.roster[a.id].name + ' 데뷔');
        this.s.debutCount =(this.s.debutCount || 0) + 1;
      }
      releaseTrainee(id) {
        let a = this.s.trainees.find(a => a.id === Number(id));
        if (!a) throw Error('연습생이 없습니다.');
        this.s.trainees = this.s.trainees.filter(x => x !== a);
        this.s.departed.push(a);
        this.log(D.roster[a.id].name + ' 연습생 계약 합의 종료');
      }
      renewalCost(a, offer = 'balanced') {
        return Math.round((D.terms[offer].fee + a.fame * 10) *(1 +(70 - a.trust) / 200));
      }
      renew(id, offer = 'balanced') {
        let a = this.artist(id),
        t = D.terms[offer];
        if (!a || !t || a.contract - this.s.day > 90) throw Error('만료 90일 전부터 재계약할 수 있습니다.');
        if (t.share > .7 && a.fame > 60 && a.trust < 80) throw Error('아티스트가 배분 조건 개선을 요청했습니다.');
        this.spend(this.renewalCost(a, offer), '아티스트 재계약');
        a.contract = Math.max(a.contract, this.s.day) + t.days;
        a.terms = { ... t };
        a.trust = clamp(a.trust + 10, 0, 100);
        this.log(D.roster[a.id].name + ' 재계약');
        this.s.renewCount =(this.s.renewCount || 0) + 1;
      }
      snapshot(key) {
        let e = this.entity(key);
        return e ? {
          key: e.key,
          name: e.name,
          type: e.type,
          ids: e.members.map(a => a.id)
        }
        : null;
      }
      shares(snapshot) {
        return snapshot.ids.map(id =>({ id, rate:(1 -(this.artist(id)?.terms.share ?? 1)) / snapshot.ids.length }));
      }
      projectEntity(j) {
        let p = j.snapshot;
        if (!p) return this.entity(j.entity);
        let members = p.ids.map(id => this.artist(id) || this.s.departed.find(a => a.id === id)).filter(Boolean);
        return members.length ? { ... p, members }: null;
      }
      startProject(key, kind, title, budget, concept) {
        let e = this.entity(key);
        let u = this.s.units.find(u => u.key === key);
        if (u &&(u.status !== 'active' || u.ids.length < 2)) throw Error('팀을 재편하거나 활동 재개 후 진행하세요.');
        super.startProject(key, kind, title, budget, concept);
        let j = this.s.jobs.at(- 1);
        j.snapshot = this.snapshot(key);
        j.shares = this.shares(j.snapshot);
      }
      resolve(id, choice) {
        let r = this.s.reports.find(r => r.id === Number(id));
        if (r?.kind === 'ad' && choice === 'accept') {
          if (r.resolved || this.s.day > r.expires || !this.entity(r.entity) || this.busy(r.entity)) throw Error('제안을 수락할 수 없습니다.');
          let snapshot = this.snapshot(r.entity),
          shares = this.shares(snapshot);
          this.receive(r.pay * .4, '광고 계약 선금', shares, r.entity);
          this.s.jobs.push({
            id: this.id(),
            kind: 'ad',
            entity: r.entity,
            name: r.brand + ' 광고 촬영',
            pay: r.pay * .6,
            start: this.s.day,
            due: this.s.day + 5,
            snapshot,
            shares
          });
          r.resolved = true;
          r.read = true;
          return;
        }
        super.resolve(id, choice);
      }
      finishManagement(j) {
        if (j.kind === 'casting') {
          let pool = D.roster.filter(a => this.available(a.id) &&(j.type === 'any' || a.type === j.type) &&(!j.position || j.position === 'any' || a.position === j.position) &&(!j.experience || j.experience === 'any' ||(j.experience === 'career' ? !!a.career: a.trainee)));
          for (let i = pool.length - 1; i > 0; i--) {
            let k = Math.floor(this.rng() *(i + 1));
            [pool[i], pool[k]] = [pool[k], pool[i]];
          }
          let picks = pool.filter(a => !this.s.candidates.some(c => c.id === a.id)).slice(0, j.method === 'audition' ? 6: 3);
          picks.forEach(a => this.s.candidates.push({ id: a.id, evaluated: this.has('casting'), expires: this.s.day + 30 }));
          this.report('영입 후보 보고', picks.length + '명의 새 후보가 도착했습니다. 캐스팅에서 계약과 연습생 영입을 진행하세요.', 'casting', true);
          return;
        }
        let e = this.projectEntity(j);
        if (!e) return;
        let original = this.s.catalog.length;
        this.finishCore(j);
        if (['single', 'live', 'cover'].includes(j.kind)) {
          this.s.performance.push({
            day: this.s.day,
            key: j.entity,
            ids: e.members.map(a => a.id),
            kind: j.kind,
            quality: this.s.catalog[original]?.quality || this._lastQuality || 60
          });
          for (const a of e.members) a.lastActive = this.s.day;
          let u = this.s.units.find(u => u.key === j.entity);
          if (u) {
            u.fame = clamp((u.fame || 0) + 5 *(1 -(u.fame || 0) / 110), 0, 100);
            u.fans =(u.fans || 0) + Math.round((this._fanGain || 0) * .8);
          }
        }
      }
      formUnit(name, ids) {
        super.formUnit(name, ids);
        Object.assign(this.s.units.at(- 1), {
          status: 'active',
          fame: 0,
          fans: 0,
          star: 0,
          bestStar: 0
        });
      }
      leaveTeam(id) {
        let u = this.s.units.find(u => u.ids.includes(Number(id)));
        if (!u) throw Error('소속 팀이 없습니다.');
        u.ids = u.ids.filter(x => x !== Number(id));
        if (u.ids.length < 2) u.status = 'hiatus';
        if (!u.ids.length) {
          this.s.teamArchive.push({ ... u, ended: this.s.day });
          this.s.units = this.s.units.filter(x => x !== u);
        }
        this.log(D.roster[id].name + ' · ' + u.name + ' 탈퇴');
      }
      teamAction(key, action, id) {
        let u = this.s.units.find(u => u.key === key);
        if (!u) throw Error('팀이 없습니다.');
        if (action === 'dissolve') {
          this.s.teamArchive.push({ ... u, ended: this.s.day });
          this.s.units = this.s.units.filter(x => x !== u);
          this.log(u.name + ' 해체 · 개인 계약과 기존 작품 정산 유지');
          return;
        }
        if (action === 'add') {
          let a = this.artist(id);
          if (!a || D.roster[a.id].type !== u.type || u.ids.length >= 5 || this.s.units.some(x => x.ids.includes(a.id)) || this.busy(String(a.id)) || this.busy(key)) throw Error('같은 분야의 활동 가능한 미소속 멤버를 선택하세요.');
          u.ids.push(a.id);
          return;
        }
        if (action === 'resume') {
          if (u.ids.length < 2) throw Error('활동 재개에는 멤버 2명 이상이 필요합니다.');
          u.status = 'active';
        } else if (action === 'pause') u.status = 'hiatus';
        else throw Error('팀 설정을 확인하세요.');
      }
      depart(id, reason, rivalId = null) {
        let a = this.artist(id);
        if (!a) return;
        let u = this.s.units.find(u => u.ids.includes(a.id));
        if (u) this.leaveTeam(a.id);
        this.s.artists = this.s.artists.filter(x => x !== a);
        this.s.departed = this.s.departed.filter(x => x.id !== a.id);
        this.s.departed.push(a);
        const rival = rivalId === null ? this.s.rivals.filter(r => r.cash > 1000 && r.artists.length < 8 &&(r.type === 'any' || r.type === D.roster[a.id].type)).sort((x, y) => y.reputation - x.reputation)[0]: this.s.rivals.find(r => r.id === Number(rivalId));
        if (rival && !rival.artists.includes(a.id)) {
          rival.artists.push(a.id);
          this.news(D.roster[a.id].name + ' · ' + rival.name + ' 이적');
        }
        this.report('전속계약 종료', D.roster[a.id].name + ' · ' + reason + '. 기존 작품 배분과 확정 일정은 유지됩니다. ' +(rival ? rival.name + '에서 다음 활동을 이어갑니다.': '자유계약 상태입니다.'), 'info', true);
        this.log(D.roster[a.id].name + ' ' + reason);
      }
      transferQuote(id, rivalId) {
        let a = this.artist(id),
        r = this.s.rivals.find(r => r.id === Number(rivalId));
        if (!a || !r) return null;
        let fee = Math.round(200 + a.fame * 20 + Math.max(0, a.contract - this.s.day) * 2);
        return {
          fee,
          consent: a.trust < 85 &&(a.fame < 30 || r.reputation + 10 >= a.fame),
          affordable: r.cash >= fee + 1000 && r.artists.length < 8,
          fit: r.type === 'any' || r.type === D.roster[a.id].type
        };
      }
      transfer(id, rivalId) {
        let q = this.transferQuote(id, rivalId);
        if (!q || !q.consent || !q.affordable || !q.fit) throw Error('아티스트 동의·상대 자금·분야 적합 조건을 충족하지 못했습니다.');
        if (this.busy(String(id))) throw Error('진행 중인 일정을 마친 후 합의 이적할 수 있습니다.');
        let r = this.s.rivals.find(r => r.id === Number(rivalId));
        r.cash -= q.fee;
        this.change(q.fee, '합의 이적금', false);
        this.depart(id, '삼자 합의 이적', r.id);
      }
      news(text) {
        this.s.industryNews.unshift({ day: this.s.day, text });
        this.s.industryNews = this.s.industryNews.slice(0, 60);
      }
      marketFactor(type) {
        let pressure = this.s.rivals.filter(r =>(r.type === type || r.type === 'any') && r.catalog.some(c => c.age === 0)).length;
        return Math.max(.8, 1 - pressure * .06);
      }
      rivalsMonth() {
        for (const r of this.s.rivals) {
          let income = 0,
          cost = 300 + r.artists.length * 100;
          for (const c of r.catalog) {
            c.age++;
            let pay = Math.round(c.quality * 22 * Math.pow(.92, c.age));
            income += pay;
          }
          if (r.cash > 4000 && r.artists.length) {
            let budget = r.type === 'band' ? 1500: 2500;
            cost += budget;
            let quality = 45 + this.rng() * 40;
            r.catalog.push({ name: '월간 프로젝트 ' +(++ r.serial), quality, age: 0 });
            r.catalog = r.catalog.slice(- 36);
            r.fans += Math.round(quality * 8);
            r.reputation = clamp(r.reputation + quality / 30, 0, 100);
            this.news(r.name + ' · ' + r.catalog.at(- 1).name + ' 발표');
          }
          if (r.cash < cost && r.debt < 10000) {
            r.cash += 3000;
            r.debt += 3000;
          }
          if (r.cash + income < cost) {
            cost = Math.max(0, r.cash + income);
            r.reputation = Math.max(0, r.reputation - 5);
            if (r.artists.length) {
              let departed = r.artists.pop();
              this.news(r.name + ' · 재정 악화로 ' + D.roster[departed].name + '과 계약 종료');
            }
          }
          r.cash += income - cost;
          r.accounts.push({ day: this.s.day, revenue: income, expense: cost });
          r.accounts = r.accounts.filter(b => b.day > this.s.day - 365);
          let profit = r.accounts.reduce((n, b) => n + b.revenue - b.expense, 0);
          r.value = Math.max(0, r.cash - r.debt + Math.max(0, profit * 4));
          r.level = r.value >= 3000000 ? 5: r.value >= 700000 ? 4: r.value >= 150000 ? 3: r.value >= 30000 ? 2: 1;
        }
      }
      updateStars() {
        for (const a of this.s.artists) {
          if (this.s.day - a.lastActive > 90) {
            a.trust = Math.max(0, a.trust - 2);
            if (a.trust < 50 && !a.concernSent) {
              a.concernSent = true;
              this.report('활동 계획 면담 요청', D.roster[a.id].name + '이 장기 활동 공백을 걱정합니다. 활동 기회나 지원을 검토하세요.', 'event', true, { entity: String(a.id) });
            }
          } else a.concernSent = false;
          let events = this.s.performance.filter(p => p.day > this.s.day - 365 && p.ids.includes(a.id) && p.key === String(a.id)),
          hits = events.filter(p => p.quality >= 75).length;
          let fameThreshold = D.roster[a.id].type === 'band' ? 55: 70;
          let level = a.fame >= 85 && hits >= 4 && a.fans >= 20000 ? 4: a.fame >= fameThreshold && hits >= 2 && a.fans >= 5000 ? 3: a.fame >= 40 && events.length >= 2 ? 2: a.fame >= 15 ? 1: 0;
          if (level >= 3) {
            a.starSince = a.starSince ?? this.s.day;
            if (this.s.day - a.starSince < 180) level = 2;
          } else a.starSince = null;
          a.star = level;
          a.bestStar = Math.max(a.bestStar || 0, level);
          if (this.s.day - a.lastActive > 30) {
            a.fame = Math.max(0, a.fame - 1);
            a.fans = Math.max(0, Math.floor(a.fans * .99));
          }
        }
        for (const u of this.s.units) {
          let hits = this.s.performance.filter(p => p.day > this.s.day - 365 && p.key === u.key && p.quality >= 75).length;
          let level = u.fame >= 85 && hits >= 4 && u.fans >= 20000 ? 4: u.fame >= 70 && hits >= 2 && u.fans >= 5000 ? 3: u.fame >= 40 ? 2: u.fame >= 15 ? 1: 0;
          if (level >= 3) {
            u.starSince = u.starSince ?? this.s.day;
            if (this.s.day - u.starSince < 180) level = 2;
          } else u.starSince = null;
          u.star = level;
          u.bestStar = Math.max(u.bestStar || 0, level);
          if (!this.s.performance.some(p => p.key === u.key && p.day > this.s.day - 60)) {
            u.fame = Math.max(0, u.fame - 1);
            u.fans = Math.floor(u.fans * .99);
          }
        }
      }
      quarter() {
        let s = this.s,
        m = this.metrics(),
        qualified = 1;
        for (const r of D.stageRules) if (s.day >= r.days && m.days >= Math.min(r.days, 365) && m.revenue >= r.revenue && m.profit >= r.profit && m.runway >= r.runway) qualified = r.level;
        if (qualified > s.companyLevel) {
          s.companyLevel = qualified;
          s.lowQuarters = 0;
          this.report('회사 성장 단계 상승', D.stageNames[s.companyLevel] + '에 진입했습니다.', 'info', true);
        } else if (qualified < s.companyLevel) {
          s.lowQuarters++;
          if (s.lowQuarters >= 2) {
            s.companyLevel = Math.max(qualified, s.companyLevel - 1);
            s.lowQuarters = 0;
            this.report('회사 규모 재평가', D.stageNames[s.companyLevel] + '로 조정되었습니다. 직원과 기능은 유지됩니다.', 'info', true);
          }
        } else s.lowQuarters = 0;
      }
      goalList() {
        let s = this.s,
        m = this.metrics();
        return [['sign', '첫 전속계약', s.artists.length, 1], ['trainee', '첫 연습생 영입', s.trainees.length, 1], ['debut', '첫 데뷔', s.debutCount || 0, 1], ['release', '첫 싱글', s.releases, 1], ['catalog', '음원 정산', s.catalog.reduce((n, c) => n + c.revenue, 0), 1], ['profit', '흑자 기반 확보', m.days >= 30 ? Math.max(0, m.profit): 0, 1000], ['staff', '첫 전문 직원', s.staff.length, 1], ['fans', '팬 1,000명', Math.max(0, ... this.entities.map(e => e.members.reduce((n, a) => n + a.fans, 0))), 1000], ['renew', '첫 재계약', s.renewCount || 0, 1], ['star', '첫 스타 배출', Math.max(0, ... s.artists.map(a => a.bestStar || 0), ... s.units.map(u => u.bestStar || 0)), 3], ['rival', '라이벌 영업이익 추월', m.days >= 180 && m.profit > 0 && s.rivals.some(r => m.profit > r.accounts.reduce((n, b) => n + b.revenue - b.expense, 0)) ? 1: 0, 1], ['large', '대형 엔터테인먼트사', s.companyLevel, 5]].map(([id, title, value, target]) =>({
          id,
          title,
          value,
          target,
          done: s.goals.includes(id)
        }));
      }
      advanceManagement() {
        let s = this.s;
        this.advanceCore();
        this.applyScheduledExpenses();
        this._interest = 0;
        s.accounts = s.accounts.filter(b => b.day > s.day - 365);
        s.performance = s.performance.filter(p => p.day > s.day - 365);
        if (s.day % 30 === 0) {
          this.rivalsMonth();
          this.updateStars();
          let v = this.valuation();
          let prev = s.valuations.at(- 1);
          s.valuations.push({
            day: s.day,
            value: v.value,
            revenue: this.metrics().revenue,
            profit: this.metrics().profit
          });
          s.valuations = s.valuations.slice(- 24);
          this.news('우리 회사 추정 기업가치 ' + Math.round(v.low).toLocaleString() + '~' + Math.round(v.high).toLocaleString() + '만 원 · ' +(prev && v.value < prev.value ? '하락': '평가 갱신'));
        }
        if (s.day % 90 === 0) this.quarter();
        for (const g of this.goalList()) if (!g.done && g.value >= g.target) {
          s.goals.push(g.id);
          this.log('목표 달성: ' + g.title);
          this.report('목표 달성', g.title + ' · 회사 연혁에 배지를 기록했습니다.', 'info', false);
        }
        return this.pending.length;
      }
    }
    return ManagementGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installManagement = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
