/* FILE src/app-shell.js */
'use strict';
// app-shell: see docs/MAINTENANCE.md for ownership and loading order.
function toast(text) {
  $('#toast').textContent = text;
  $('#toast').classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => $('#toast').classList.remove('show'), 3300);
}
let modalReturnFocus = null;
function modal(title, body, wide = false, tapToDismiss = false) {
  if (!$('#modal-root').children.length) modalReturnFocus = document.activeElement;
  $('#modal-root').innerHTML = `<div class="modal-backdrop" ${tapToDismiss?'data-action="close"':''}><section class="modal" role="dialog" aria-modal="true" aria-label="${esc(title)}" ${wide?'style="width:820px"':''}><div class="modal-head"><h2>${esc(title)}</h2>${btn('×','close','aria-label="닫기"')}</div>${body}<div class="error" id="modal-error" role="alert"></div></section></div>`;
  setTimeout(() => $('#modal-root input, #modal-root select, #modal-root button')?.focus(), 20);
}
function close() {
  if (running) return;
  $('#modal-root').innerHTML = '';
  if (modalReturnFocus?.isConnected) modalReturnFocus.focus();
  modalReturnFocus = null;
}
function title() {
  running = false;
  lastAdvanceNotice = null;
  selectedReport = null;
  game.s = null;
  $('#modal-root').innerHTML = '';
  let s = loadSaved();
  $('#app').innerHTML = `<main class="title-screen"><section class="title-left"><div class="brand"><img src="assets/logo.svg" alt=""><div>NEXT STAGE<small>넥스트 스테이지</small></div></div><div class="eyebrow">YOUR NEXT BIG THING</div><h1>가능성을 만나,<br><span>무대를 만들다.</span></h1><p>아이돌, 밴드, 힙합.<br>당신의 안목으로 시작하는 음악 기획사.<br>첫 만남부터 다음 무대까지, 함께 성장하세요.</p><div class="title-actions">${btn('새로운 기획사 설립 '+ico('arrow'),'new','','primary')}${btn(s?`이어하기 · ${esc(s.company)} / ${date(s.day)}`:'이어하기','continue','','',!s)}${s?`<small>보유 자금 ${money(s.cash)} · 진행 일정 ${s.jobs.length+(s.engagements?.length||0)}건 · 전속 ${s.artists.length}명</small>`:''}${autoLoadStatus==='corrupt'?'<p class="negative" role="alert">자동 저장을 읽을 수 없습니다. 원본은 유지했습니다. 설정에서 슬롯·복구 지점 또는 JSON 백업을 불러오세요.</p>':autoLoadStatus==='unavailable'?'<p class="negative" role="alert">브라우저 저장소에 접근할 수 없습니다. 설정에서 백업을 확인하세요.</p>':''}${btn('설정 · 저장 백업','settings','','link')}</div><div class="version">NEXT STAGE · v${DATA.rules.version} · PC & MOBILE</div></section><section class="title-art" aria-label="개성 있는 세 아티스트"><div class="title-portraits"><img src="${DATA.roster[0].image}" alt="아이돌 서윤"><img src="${DATA.roster[1].image}" alt="밴드 아티스트 태오"><img src="${DATA.roster[2].image}" alt="래퍼 리오"></div><div class="title-art-caption">EVERY TALENT HAS A NEXT STAGE.</div></section></main>`;
}
const navs = [['home','홈','home'], ['inbox','수신함','mail'], ['artists','아티스트','people'], ['training','육성','star'], ['projects','활동','music'], ['company','회사','chart'], ['industry','업계','star']];
function primaryNavigationActive(id) {
  const selected = [...game.s.artists,...game.s.trainees].find(a=>a.id===developmentId)||game.s.artists[0]||game.s.trainees[0];
  const training = page === 'training' || page === 'development' && selected && game.s.trainees.includes(selected);
  return training ? id === 'training' : pageGroup(page) === id;
}
function navigate(p) {
  page = p;
  filter = 'all';
  stopReason = '';
  close();
  render();
  window.scrollTo(0, 0);
}
function render() {
  if (!game.s) return title();
  const archive = $('#app .studio-archive');
  if (archive) studioArchiveOpen = archive.open;
  let s = game.s;
  $('#app').innerHTML = `<aside class="sidebar"><div class="brand"><img src="assets/logo.svg" alt=""><div>NEXT STAGE<small>넥스트 스테이지</small></div></div><div class="company-label"><strong>${esc(s.company)}</strong><small>음악으로, 더 멀리.</small></div><nav class="nav" aria-label="주요 메뉴">${navs.map(([id,name,icon])=>btn(`${ico(icon)} ${name}${id==='inbox'&&s.reports.some(r=>!r.read)?`<span class="spacer"></span><span class="badge">${s.reports.filter(r=>!r.read).length}</span>`:''}`,'nav',`data-page="${id}"`,primaryNavigationActive(id)?'active':'')).join('')}</nav><div class="sidebar-foot"><div class="row"><span class="boss-icon">${ico('staff')}</span><div><strong>${esc(s.boss)} 대표</strong><small style="display:block">${DATA.stageNames[game.stage]}</small></div></div>${btn(ico('settings')+' 설정 · 저장','settings','','link section')}</div></aside><header class="topbar"><strong class="top-company">${esc(s.company)}</strong><span class="mobile-brand">${esc(s.company)}</span><span class="date">${ico('calendar')}${date(s.day,true)}</span><span class="spacer"></span><div class="row advance">${btn(running?'진행 중…':'하루 진행','day','','',running)}${btn(running?'진행 중 · 중지':'중요 일정까지 '+ico('play'),running?'stop':'skip','','primary')}</div></header>${stopReason?`<div class="stop-strip">${ico('mail')} ${esc(stopReason)}<span class="spacer"></span>${btn('소식함','nav','data-page="inbox"','link')}</div>`:''}<main class="main ${page==='home'?'is-dashboard':''}">${sectionTabs()}${progressSummaryCard()}${({home:home,inbox:inbox,artists:artists,casting:casting,projects:projects,concerts:concerts_activity,content:content_activity,offers:offers_activity,'activity-progress':progress_activity,'activity-results':results_activity,staff:staff,recruit:recruitScreen,finance:finance,training:training,teams:teams,industry:industry,company:company,goals:goals,schedule:schedule,development:developmentScreen,music:music,charts:charts}[page]||home)()}${backupReminderHTML()}<div class="footer-note">NEXT STAGE · v${DATA.rules.version} · ${saveStatusLabel()}</div></main><nav class="bottom-nav" aria-label="모바일 주요 메뉴">${[['home','홈','home'],['inbox','수신함','mail'],['artists','인재','people'],['projects','활동','music'],['company','회사','chart'],['industry','업계','star']].map(([id,name,ic])=>btn(`${ico(ic)}<span>${name}</span>${id==='inbox'&&s.reports.some(r=>!r.read)?'<i class="badge">'+s.reports.filter(r=>!r.read).length+'</i>':''}`,id==='more'?'more':'nav',`data-page="${id}"`,pageGroup(page)===id?'active':'')).join('')}</nav>`;
}


;
