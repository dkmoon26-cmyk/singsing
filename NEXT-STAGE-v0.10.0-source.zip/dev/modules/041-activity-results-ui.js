/* FILE src/activity-results-ui.js */
'use strict';
// View-only adapters. No new financial rules or duplicated saved transaction history.
function festivalStatement(record) {
  const offer = game.s.festivalOffers.find(o => o.status === 'accepted' && o.entity === record.entity && o.day === record.day && o.approval?.name === record.name);
  const gross = offer?.approval?.pay ?? null, cost = offer?.approval?.cost ?? null;
  return {name:record.name, day:record.day, kind:'festival', scope:'행사 출연', gross,
    payout:gross===null||cost===null?null:Math.round((gross-cost-record.net)*100)/100,
    cost, production:0, net:record.net, paymentDay:record.day};
}
function activityStatement(entry) {
  return {name:entry.name, day:entry.day, kind:entry.kind,
    scope:entry.kind==='ad'?'광고 잔금 구간':'공연 정산', gross:entry.gross, payout:entry.payout,
    cost:entry.variable, production:entry.budget, net:entry.net,
    paymentDay:entry.day+(entry.kind==='ad'?DATA.rules.advertisement.balanceDays:7)};
}
function activityStatementHTML(row) {
  const known = row.gross!==null && row.payout!==null && row.cost!==null;
  return `<section class="tip activity-statement"><strong>${esc(row.scope)}</strong>${known?`<p>이 정산 총액 ${money(row.gross, 2)} · 아티스트 배분 ${money(row.payout, 2)}</p><p>활동비 ${money(row.cost, 2)} · 선집행 제작비 ${money(row.production, 2)}</p>`:'<p>이전 상세 정산 자료가 없어 총액·배분·활동비는 표시하지 않습니다.</p>'}<p><strong>회사 손익 ${money(row.net, 2)}</strong> · 일 훈련·월 고정비 별도</p><p>입금 기준일 ${date(row.paymentDay,true)}${row.paymentDay>game.s.day?' · 입금 예정':''}</p>${row.kind==='ad'?'<small>잔금 구간만 표시합니다. 선금40%와 해당 배분은 계약 당시 거래 내역에서 확인하세요.</small>':row.kind==='live'?'<small>입금은 아티스트 배분 차감 후 이루어집니다. 활동비·제작비는 이미 집행한 지출입니다.</small>':''}</section>`;
}
function outcomeSettlementHTML(outcome) {
  if (!['live','ad'].includes(outcome.kind)) return '';
  const entry = game.s.settlements.find(e => e.day===outcome.day && e.kind===outcome.kind && e.name===outcome.title);
  return entry?`<details><summary>정산 금액·입금일</summary>${activityStatementHTML(activityStatement(entry))}</details>`:'';
}
function activityFinanceHTML() {
  const rows = game.s.settlements.map(activityStatement).concat(game.s.festivalHistory.map(festivalStatement)).sort((a,b)=>b.day-a.day).slice(0,15);
  return panel('활동별 회사 손익', '<p>공연·광고·행사의 실제 기록입니다. 광고는 잔금 구간만 표시하며, 손익과 입금 시점은 다릅니다.</p>'+ (rows.map(row=>`<article class="contract-row"><h3>${esc(row.name)} · ${date(row.day)}</h3>${activityStatementHTML(row)}</article>`).join('')||'<p>완료된 활동 내역 없음</p>'));
}
function festivalsOnDay(summary) {
  return game.s.festivalHistory.filter(e=>e.day===summary.day);
}
function festivalCount(summary) {
  return Math.max(festivalsOnDay(summary).length, Number.isSafeInteger(summary.festivals)?Math.max(0,summary.festivals):0);
}
function dayFestivalHTML(summary) {
  const records=festivalsOnDay(summary),count=festivalCount(summary);
  return records.map(e=>`<p>행사 완료: ${esc(e.name)} · ${esc(e.artist)} · 회사 실수령 ${money(e.net)} · 팬 +${e.fans}명</p>`).join('')+(count>records.length?`<p>행사 ${count-records.length}건 완료 · 상세 결과 보관 기간 종료</p>`:'');
}
function recentWeekHTML() {
  const s=game.s,from=Math.max(0,s.day-6),accounts=s.accounts.filter(a=>a.day>=from&&a.day<=s.day),days=s.daySummaries.filter(d=>d.day>=from&&d.day<=s.day);
  const income=accounts.reduce((n,a)=>n+a.revenue,0),expense=accounts.reduce((n,a)=>n+a.expense,0),fans=days.reduce((n,d)=>n+d.fansChange,0),teamFans=days.reduce((n,d)=>n+d.teamFansChange,0);
  return panel('최근 7일 운영 요약', `<p>${date(from)}~${date(s.day)} · 기록된 운영 수입 <strong>${money(income, 2)}</strong> · 지출 <strong>${money(expense, 2)}</strong></p><p>운영 차액 ${money(income-expense, 2)} · 개인 팬 ${fans>=0?'+':''}${fans.toLocaleString()}명 · 팀 팬 ${teamFans>=0?'+':''}${teamFans.toLocaleString()}명</p><small>대출 원금·회생·목표 지원금 제외, 이자 포함. 팬 변화는 하루 진행 기록 기준이며 계약 종료도 반영합니다.</small>`);
}


;
