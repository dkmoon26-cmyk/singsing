/* FILE src/season-ui.js */
'use strict';
let chartScope = 'all', chartLimit = 20;
function charts_season() {
  const global = game.charts(chartMetric),
  ranks = new Map(global.map((r, i) => [r.release.market.uid, i + 1])),
  rows = chartScope === 'all' ? global: global.filter(r => !r.external),
  own = global.map((r, i) =>({ ... r, rank: i + 1 })).filter(r => r.own);
  return heading('전체 음악 시장 차트', '최근 7일 집계 · 지난 확정 주 대비 등락 · 매주 최고 순위 기록 · 외부 아티스트를 포함한 가상 음악 시장입니다.', btn('연말 시상식', 'm-awards', '', 'soft')) + `<div class="tabs">${btn('주간 스트리밍','m-chart','data-metric="streams"',chartMetric==='streams'?'active':'')}${btn('주간 음반 판매','m-chart','data-metric="sales"',chartMetric==='sales'?'active':'')}</div><div class="tabs section">${[['all','전체 시장'],['labels','우리·라이벌']].map(([k,n])=>btn(n,'m-chart-scope',`data-scope="${k}"`,chartScope===k?'active':'')).join('')}</div>` + panel('우리 작품의 전체 시장 순위', own.map(r => `<p><strong>${r.rank}위${r.rank>100?' · TOP 100 밖':''}</strong> · ${esc(r.release.name)} · ${r.week[chartMetric].toLocaleString()}${chartMetric==='streams'?'회':'장'}</p>`).join('') || '<p>최근 7일 집계된 우리 작품이 없습니다.</p>') + panel('TOP 100 · ' +(chartScope === 'all' ? '전체 시장': '참여 레이블'), rows.slice(0, Math.min(100, chartLimit)).map((r, index) => {
    const h = game.chartPosition(r.release.market.uid, chartMetric, ranks),
    change = h.previous === null ? '신규': h.previous === h.rank ? '유지': h.previous > h.rank ? '▲ ' +(h.previous - h.rank): '▼ ' +(h.rank - h.previous);
    return `<article class="chart-row"><strong class="rank">${index+1}</strong><div class="spacer"><h3>${esc(r.release.name)} ${r.own?'<span class="pill">우리</span>':''}</h3><small>${esc(r.release.market.artistName)} · ${esc(r.company)}</small><p>${r.week[chartMetric].toLocaleString()}${chartMetric==='streams'?'회':'장'} · ${change}${h.best?' · 확정 주간 최고 '+h.best+'위':''}${chartScope==='labels'&&h.rank?' · 전체 '+h.rank+'위':''}</p>${btn('성과 보기','m-release',`data-uid="${r.release.market.uid}"`,'link small')}</div></article>`;
  }).join('') || '<p>최근 집계 없음</p>') +(chartLimit < 100 && rows.length > chartLimit ? btn('20위 더 보기', 'm-chart-more', '', 'soft'): '');
}
function reportDetail_season(r) {
  if (r.festivalOfferId) {
    const o = game.s.festivalOffers.find(o => o.id === r.festivalOfferId),
    p = game.festivalPlan(r.festivalOfferId),
    state = game.reportState(r);
    return `<div class="row between">${reportBadge(r)}${btn(r.read?'안 읽음으로 표시':'읽음으로 표시','m-report-unread',`data-id="${r.id}" data-read="${!r.read}"`,'soft small')}</div><h2>${esc(r.title)}</h2><p>${esc(r.body)}</p>${o?`<section class="tip"><p><strong>행사 ${date(o.day,true)}</strong> · 준비·출연 ${p.duration}일</p><p>준비 시작 ${date(p.start)} · 행사 완료일 지급<br>출연료 ${money(p.pay)} − 약정 배분·출연비 → <strong>회사 실수령 ${money(p.net)}</strong></p><p>출연비는 ${money(p.cost)}이며 행사 완료일에 차감합니다.</p>${p.productions.map(j=>`<p>${esc(j.title)} · 완료 ${date(j.oldDue)} → ${date(j.newDue)} (+${j.newDue-j.oldDue}일) · 예약 행사 반영</p>`).join('')}<small>수락일부터 준비 시작 전까지 제작은 계속됩니다. 준비·출연 구간에만 제작을 중단합니다. 출연 후 2일간 새 활동을 잡지 않습니다.</small></section>`:''}${state.needsDecision?`<p>${p.reasons.map(esc).join(' · ')}</p><div class="row wrap">${btn('출연 수락','m-festival',`data-id="${r.festivalOfferId}" data-choice="accept"`,'primary',!p.allowed)}${btn('섭외 거절','m-festival',`data-id="${r.festivalOfferId}" data-choice="decline"`)}</div>`:''}`;
  }
  if (r.festivalResultId) {
    const record = game.s.festivalHistory.find(e => e.id === r.festivalResultId);
    return reportDetail_campaign(r) + (record ? activityStatementHTML(festivalStatement(record)): '');
  }
  if (r.awardYear) return awardHTML(r.awardYear);
  return reportDetail_campaign(r);
}
function awardHTML(year) {
  const a = game.s.awardHistory.find(a => a.year === Number(year));
  if (!a) return '<p>아직 후보 발표 전입니다. 12월 1일 후보를 확정하고, 선정된 후보의 12월 28일까지 기록으로 수상자를 평가합니다.</p>';
  return `<section class="award-hero"><span class="eyebrow">NEXT MUSIC AWARDS</span><h2>${a.year}년 ${a.resultDay===null?'후보 발표':'시상 결과'}</h2><p>올해의 음악과 무대를 함께 돌아봅니다. 12월 초 후보 발표 · 12월 28일 시상.</p></section><details class="tip"><summary>집계 기간·후보 선정 기준</summary><p>후보는 ${date(a.nominationDay,true)}까지 집계한 기록으로 확정합니다. 발표 뒤 새 작품·인물은 후보에 추가하지 않습니다.</p><p>수상 평가는 확정 후보의 기록을 ${a.resultDay===null?a.year+'년 12월 28일':date(a.resultDay,true)}까지 반영합니다. 신인상은 기록된 데뷔 연도가 시상 연도인 대상입니다.</p></details>${a.categories.map(c=>`<section class="panel section"><h3>${SEASON_DATA.awards[c.key]}</h3>${c.winner?`<p class="award-winner">🏆 ${esc(c.winner.name)}${c.key==='song'?' · '+esc(c.winner.artist):''}${c.winner.own?' · 우리 회사':''}</p>${c.winner.own?'<p>인지도·회사 평판 및 수상 이력 반영. “함께해 주신 분들 덕분이에요.”</p>':''}`:'<p>'+(a.resultDay===null?'12월 28일 수상 발표':'해당 후보 없음')+'</p>'}<details ${a.resultDay===null?'open':''}><summary>후보 ${c.nominees.length}명·작품</summary>${c.nominees.map(n=>`<p>${esc(n.name)}${c.key==='song'?' · '+esc(n.artist):''}${n.own?' · 우리 회사':''}</p>`).join('')||'<p>조건을 충족한 기록 없음</p>'}<small>${c.key==='live'?'실제 관객·무대 반응':c.key==='rookie'?'데뷔 첫해 판매·재생·무대 성과':'해당 연도 판매·재생과 활동 성과'}로 후보에 선정됐습니다.</small></details></section>`).join('')}${a.summary?`<p>시상일까지 우리 회사 기록: 재생 ${a.summary.streams.toLocaleString()}회 · 음반 ${a.summary.sales.toLocaleString()}장 · 무대 ${a.summary.live}회</p>`:''}<small>집계 시작 ${date(Math.max(game.s.seasonSince,Math.round((Date.UTC(a.year,0,1)-Date.UTC(2027,0,1))/86400000)),true)}. 과거 누락 기록은 소급 생성하지 않습니다. 상금·별도 준비 과제 없음.</small>`;
}
function releaseModal_season(uid) {
  if (!uid.startsWith('x-')) {
    releaseModal_evolution(uid);
    const c = game.s.catalog.find(c => c.market.uid === uid);
    if (c) {
      const m = c.market,
      invest = m.production + m.manufacturing,
      paid = m.paid - m.payout;
      $('#modal-error').insertAdjacentHTML('beforebegin', `<section class="tip"><strong>총투자금 ${money(invest)} · 회사 누적 회수 ${money(paid)}</strong><p>${m.legacy?'이전 작품 · 과거 전체 투자금 회수 여부는 판정하지 않습니다.':paid>=invest?'투자금 회수 완료':'투자금 회수 중'}</p><small>제작·홍보·제조비 포함. 일 훈련·고정비는 별도.</small></section>`);
    }
    return;
  }
  const r = game.globalReleases().find(r => r.release.market.uid === uid);
  if (!r) throw Error('현재 집계 중인 외부 작품이 아닙니다.');
  const w = r.release.market.days.filter(d => d.day > game.s.day - 7).reduce((n, d) =>({ streams: n.streams + d.streams, sales: n.sales + d.sales }), { streams: 0, sales: 0 });
  modal(r.release.name, `<p>${esc(r.release.market.artistName)} · ${esc(r.company)}</p><p>발매 ${date(r.release.market.startDay,true)}</p><p>최근 7일 스트리밍 ${w.streams.toLocaleString()}회 · 음반 ${w.sales.toLocaleString()}장</p><small>외부 시장 아티스트입니다. 내부 원가·계약·수입은 공개하지 않습니다.</small>`);
}
function projects_season() {
  return projects_campaign() + panel('확정 행사', game.s.engagements.map(e => `<article class="contract-row"><span class="pill">${game.s.day>=e.start?'준비·출연 중':'출연 예약'}</span><h3>${esc(e.name)}</h3><p>${esc(e.snapshot.name)} · 행사 ${date(e.due)} · 준비 ${date(e.start)} 시작</p><small>준비·출연 ${e.due-e.start}일 · 확정 멤버·배분 유지</small></article>`).join('') || '<p>확정된 행사 없음 · 섭외는 수신함으로 도착합니다.</p>') + panel('최근 행사 결과', game.s.festivalHistory.slice(- 3).reverse().map(e => `<details><summary>${esc(e.artist)} · ${esc(e.name)} · 회사 ${money(e.net)}</summary><p>새로운 팬 +${e.fans}명</p>${activityStatementHTML(festivalStatement(e))}</details>`).join('') || '<p>아직 출연 기록이 없습니다.</p>');
}
function scheduleEvents_season() {
  const rows = scheduleEvents_operations();
  for (const e of game.s.engagements) rows.push({
    id: 'festival-' + e.id,
    start: e.start,
    end: e.due,
    title: e.name + ' · ' + e.snapshot.name,
    kind: 'live',
    body: `준비 ${date(e.start)}~출연 ${date(e.due)} · 출연료 ${money(e.pay)} (약정 배분·출연비 차감) · 준비 구간에만 제작 중단`,
    page: 'projects'
  });
  const year = game.s.seasonYear;
  for (const[month, day, name] of[[11, 1, '연말 시상식 후보 발표'], [11, 28, 'NEXT MUSIC AWARDS']]) {
    const dateDay = Math.round((Date.UTC(year, month, day) - Date.UTC(2027, 0, 1)) / 86400000);
    rows.push({
      id: 'awards-' + year + '-' + day,
      start: dateDay,
      end: dateDay,
      title: name,
      kind: 'award',
      body: '평소 활동 기록으로 자동 평가합니다. 별도 준비 일정은 없습니다.',
      page: 'charts'
    });
  }
  return rows;
}
function todayTasks_season() {
  return todayTasks_evolution().concat(game.s.reports.filter(r => r.festivalOfferId && game.reportState(r).needsDecision || r.awardYear && !r.read || r.festivalResultId && !r.read).map(r =>({
    priority: 2,
    label: r.title,
    action: 'report',
    args: `data-id="${r.id}"`
  }))).sort((a, b) => a.priority - b.priority);
}
function budgetPreview_season() {
  budgetPreview_campaign();
  const key = $('#entity')?.value || game.entities[0]?.key,
  e = game.entity(key);
  if (e) {
    const planned = game.s.engagements.filter(x => x.snapshot.ids.some(id => e.members.some(a => a.id === id)));
    const kind = $('#project-kind')?.value || 'single',
    availability = game.projectAvailability(key, kind),
    submit = $('#project-form button[type="submit"]');
    if (submit) submit.disabled = !availability.allowed;
    if (!availability.allowed) $('#budget-preview').innerHTML += `<p class="negative">${availability.reasons.map(esc).join(' · ')}</p>`;
    if (kind === 'single' && planned.length) {
      const due = game.productionPreview(key, $('#promotion')?.value || 'none').due;
      $('#budget-preview').innerHTML += `<p><strong>행사 반영 예상 완료 ${date(due)}</strong></p>`;
    }
    if (planned.length) $('#budget-preview').innerHTML += `<p>확정 행사: ${planned.map(x=>esc(x.name)+' '+date(x.start)+'~'+date(x.due)).join(' · ')}. 싱글은 겹치는 준비 기간만큼 완료일이 연장됩니다.</p>`;
  }
}
function managementClick_season(action, d) {
  if (action === 'm-festival') return mutate(() => game.resolveFestival(d.id, d.choice), '행사 섭외를 처리했습니다.');
  if (action === 'm-chart-scope') {
    chartScope = d.scope;
    chartLimit = 20;
  } else if (action === 'm-chart-more') chartLimit = Math.min(100, chartLimit + 20);
  else if (action === 'm-awards') {
    const years = game.s.awardHistory.slice().reverse();
    modal('연말 음악 시상식', `<div class="row wrap">${years.map(a=>btn(a.year+'년','m-award-year',`data-year="${a.year}"`,'soft')).join('')}</div>` + awardHTML(years[0]?.year));
    return;
  } else if (action === 'm-award-year') {
    modal('연말 음악 시상식', awardHTML(Number(d.year)));
    return;
  }
  render();
}


;
