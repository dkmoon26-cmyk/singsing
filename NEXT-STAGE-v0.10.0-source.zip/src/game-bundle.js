// Stable artist IDs map to individually generated studio portraits.
function nextStagePortraitUrl(path) {
  const match = /^assets\/portraits\/artist-(\d+)-anime-v\d+\.webp$/.exec(path);
  return match ? `assets/portraits/artist-${Number(match[1])}-studio-v3.webp` : path;
}

;
/* FILE src/rules.js */
(function(root) {
  'use strict';
  const activity = Object.freeze({ single: Object.freeze({
    label: '싱글',
    days: 21,
    min: 1000,
    max: 19600,
    defaultBudget: 4000,
    budgets:[[1000, '신인 제작'], [2000, '소규모'], [4000, '기본 제작'], [7000, '집중 투자']]
  }), live: Object.freeze({
    label: '공연',
    days: 7,
    min: 300,
    max: 24000,
    defaultBudget: 300,
    budgets:[[300, '소규모 클럽'], [800, '기본 공연'], [1500, '확대 공연']]
  }), cover: Object.freeze({
    label: '커버',
    days: 5,
    min: 100,
    max: 600,
    defaultBudget: 100,
    budgets:[[100, '라이브 촬영'], [300, '기본 제작'], [600, '집중 제작']]
  }) });
  const rules = Object.freeze({
    version: '0.10.0',
    advertisement: { days: 5, balanceDays: 14 },
    activity,
    traineeFee: 100,
    physicalQuantities:[1000, 3000, 10000],
    unitCost: .6,
    voucherRate: .05,
    voucherCap: 200,
    jobCost(job) {
      return Math.round(((job.actualProductionCost ?? job.budget ?? 0) +(job.manufacturing || 0) +(job.promotionCost || 0)) * 100) / 100;
    },
    quote(budget, kind, options = {}, perks = {}) {
      const base = Number(budget),
      single = kind === 'single',
      manufacturing = single && options.format === 'physical' ? Number(options.quantity) * .6: 0,
      promo = single ? Number(options.promotionCost || 0): 0,
      discount = single && perks.productionVoucher > 0 ? Math.min(200, Math.round(base * .05 * 100) / 100): 0;
      return {
        base,
        discount,
        production: base - discount,
        manufacturing,
        promo,
        total: Math.round((base - discount + manufacturing + promo) * 100) / 100
      };
    }
  });
  if (typeof module !== 'undefined') module.exports = rules;
  else root.GameRules = rules;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/data.js */
(function(root) {
  const names = ['서윤', '태오', '리오', '도현', '하린', '노아', '이솔', '건우', '제이', '유찬', '은재', '도크', '루아', '시온', '아샤', '민재', '해온', '카이'];
  const types = ['idol', 'band', 'rap', 'idol', 'band', 'rap', 'idol', 'band', 'rap', 'idol', 'band', 'rap', 'idol', 'band', 'rap', 'idol', 'band', 'rap'];
  const stories = ['맑은 음색과 차분한 태도. 작은 무대에서도 끝까지 눈을 맞춘다.', '빈티지 록을 사랑하는 기타리스트. 자작곡 수첩을 늘 가지고 다닌다.', '자기 이야기를 직설적인 가사로 풀어내는 래퍼.', '단정한 인상과 정확한 춤선. 팀의 중심이 되고 싶다.', '거침없는 드럼과 유쾌한 에너지로 합주실을 채운다.', '따뜻한 저음과 재즈 감각. 오래 들을 음악을 꿈꾼다.', '표정 연기와 퍼포먼스에 강한 완벽주의자.', '묵직한 베이스와 느긋한 성격. 라이브 경험이 풍부하다.', '날카로운 플로와 재치 있는 가사. 도전을 즐긴다.', '부드러운 음색의 보컬. 긴장하면 말수가 줄어든다.', '섬세한 키보드 연주와 편곡 감각을 갖췄다.', '위트 있는 랩으로 관객과 대화하는 공연형 아티스트.', '밝은 에너지와 독특한 음색. 무대를 놀이터처럼 쓴다.', '리듬 기타에 강한 성실파. 합주에서 동료를 먼저 듣는다.', '다채로운 리듬과 자신감. 음악의 경계를 넘고 싶다.', '눈에 띄는 무대 표현력. 보컬은 더 다듬어야 한다.', '감정 깊은 보컬과 작곡 감각. 밴드의 이야기를 노래한다.', '단단한 발성과 공격적인 무대. 자신만의 색이 확실하다.'];
  const labels = { idol: '아이돌', band: '밴드', rap: '힙합' };
  const specs = ['보컬', '랩', '댄스', '연주', '창작', '무대', '미디어', '협업'];
  const roster = names.map((name, i) =>({
    id: i,
    name,
    type: types[i],
    age: 20 + i % 12,
    story: stories[i],
    image: nextStagePortraitUrl(`assets/portraits/artist-${i}-anime-v1.webp`),
    style:['POP', 'ROCK', 'HIP-HOP'][i % 3],
    traits:['성실한 노력가', '자유로운 창작자', '무대 체질', '신중한 완벽주의자', '분위기 메이커', '독립적인 예술가'][i % 6],
    stats: specs.map((_, j) => Math.min(89, 36 +((i * 17 + j * 13) % 31) +(types[i] === 'idol' &&[0, 2, 5].includes(j) ? 17: types[i] === 'band' &&[3, 4, 7].includes(j) ? 17: types[i] === 'rap' &&[1, 4, 5].includes(j) ? 17: 0)))
  }));
  const extraNames = ['지안', '우진', '세나', '재하', '유리', '로건', '나린', '지호', '수아', '현우', '다온', '예린', '태린', '준서', '소민', '시우', '하온', '채린', '지유', '서진', '라온', '이든', '예온', '하율', '도윤', '유나', '서우', '다인', '태하', '시아', '윤재', '나온', '수빈', '지율', '세온', '아린', '주원', '리안', '은솔', '해준', '루진', '규리'];
  for (let i = 18; i < 60; i++) {
    let type = i < 24 ? types[i % 3]: i < 42 ? 'idol': i < 51 ? 'band': 'rap';
    roster.push({
      id: i,
      name: extraNames[i - 18],
      type,
      age: 18 + i % 8,
      story: i < 24 ? '독립 무대에서 경험을 쌓은 신인입니다.': '훈련과 데뷔 기회를 기다리는 연습생 지망생입니다.',
      image: nextStagePortraitUrl(`assets/portraits/artist-${i}-anime-v1.webp`),
      style: { idol: 'POP', band: 'ROCK', rap: 'HIP-HOP' }[type],
      traits:['창작 지향', '무대 지향', '안정 지향'][i % 3],
      stats: specs.map((_, j) => Math.min(85, (i < 24 ? 48: 32) +(i * 11 + j * 7) % 25))
    });
  }
  roster.forEach((a, i) => {
    a.image = nextStagePortraitUrl(`assets/portraits/artist-${a.id}-anime-v${[0,1,2,18].includes(a.id)?2:1}.webp`);
    a.trainee = i >= 24;
    a.position = a.type === 'band' ?['보컬', '기타', '베이스', '드럼', '키보드'][Math.floor(i / 3) % 5]: a.type === 'rap' ? '래퍼': '보컬·퍼포먼스';
    a.available = i < 54 ? 0: 365;
  });
  const personalLines = ['작은 무대라도 관객 한 사람과 눈을 맞추고 노래하고 싶어요.', '낡은 기타 소리에도 새 이야기가 숨어 있다고 믿어요.', '제 이야기를 제 언어로 쓰는 래퍼가 되고 싶어요.', '매일 같은 동작을 연습해도 어제와 다른 무대를 만들고 싶어요.', '합주가 막힐 땐 제가 먼저 분위기를 풀어 볼게요.', '늦은 밤에도 오래 듣고 싶은 음악을 만들고 싶어요.', '표정 하나까지 곡의 이야기를 담아내고 싶어요.', '튀기보다는 동료들이 편하게 연주할 수 있게 받쳐 줄게요.', '관객이 예상하지 못한 한 줄을 들려주고 싶어요.', '말은 서툴러도 노래로는 마음을 전할 수 있어요.', '멜로디 뒤에 숨은 화음을 찾아내는 게 즐거워요.', '공연장에서는 관객의 대답까지 제 음악이에요.', '무대에서만큼은 누구보다 신나게 놀고 싶어요.', '합주가 끝나면 동료들의 연주부터 다시 들어요.', '장르가 달라도 좋은 리듬은 서로 통한다고 생각해요.', '제가 설 무대의 첫 장면부터 상상하며 연습해요.', '쉽게 지나치는 감정도 곡으로 남기고 싶어요.', '첫 소절부터 제 이름을 기억하게 만들고 싶어요.', '서두르기보다 제 목소리를 알아가는 시간을 갖고 싶어요.', '기타 줄을 바꿀 때마다 새로운 곡을 시작하는 기분이에요.', '조용해 보여도 마이크를 잡으면 할 말이 많아요.', '팀의 중심에서도 동료들의 표정을 놓치고 싶지 않아요.', '베이스처럼 묵묵하게 오래 남는 사람이 되고 싶어요.', '화려한 말보다 솔직한 한 줄을 들려드릴게요.', '긴장되면 가사를 손으로 써요. 그러면 조금씩 용기가 나요.', '사람들 앞에 서는 건 아직 떨리지만 매일 나아지고 싶어요.', '친구들이 따라 부를 수 있는 노래를 들려주고 싶어요.', '연습실에 가장 먼저 와서 오늘의 목표를 적어 둬요.', '잘 안 풀린 날에도 작은 진전 하나는 꼭 찾아요.', '노래의 감정을 표정으로도 전하는 연습을 하고 있어요.', '남들이 정한 이미지보다 제가 편한 모습을 찾고 싶어요.', '오래 준비한 만큼 서두르지 않고 단단하게 데뷔하고 싶어요.', '틀려도 웃고 다시 해보는 게 제 장점이에요.', '같은 안무라도 제 리듬을 살리는 순간이 좋아요.', '조용한 연습실에서 한 소절을 완성하면 하루가 뿌듯해요.', '무대에 오르면 평소보다 솔직해지는 것 같아요.', '연습 일지에 부족했던 점보다 내일 해볼 일을 적어요.', '동료와 호흡이 맞는 순간이 가장 기분 좋아요.', '첫인상은 차가워도 함께 연습하면 꽤 수다스러워요.', '빠르게 주목받기보다 오래 믿고 듣는 가수가 되고 싶어요.', '떨릴 때는 박자를 손끝으로 세면서 마음을 다잡아요.', '오늘은 어제보다 한 번 더 자신 있게 해볼게요.', '건반 위에서는 복잡한 생각도 차분하게 정리돼요.', '빈 연습실의 잔향을 듣는 시간이 좋아요.', '마음에 드는 화음을 찾으면 잊기 전에 꼭 녹음해요.', '누군가 힘든 하루 끝에 찾아 듣는 목소리가 되고 싶어요.', '첫 음을 내기 전에 곡의 장면부터 떠올려요.', '완벽한 음정보다 살아 있는 감정을 담고 싶어요.', '좋아하는 기타 리프는 손이 기억할 때까지 반복해요.', '조금 거친 소리도 제 음악의 일부로 남기고 싶어요.', '합주에서 비어 있는 공간을 채우는 기타를 치고 싶어요.', '짧은 벌스에도 시작과 끝이 있는 이야기를 담아요.', '함께 고개를 끄덕일 수 있는 비트를 만들고 싶어요.', '작은 목소리로 해둔 메모가 무대에서 큰 말이 돼요.', '할 말이 정리될 때까지 가사를 여러 번 고쳐 써요.', '낯선 리듬을 만나면 일단 몸으로 따라가 봐요.', '제 말투 그대로 랩해도 괜찮다는 걸 보여주고 싶어요.', '친구들과 나눈 농담도 가사의 씨앗이 되곤 해요.', '실수한 무대도 다음 공연의 재료라고 생각해요.', '목소리를 키우기보다 제 생각을 분명히 전하고 싶어요.'];
  const personalities = [{
    name: '차분한 꾸준함',
    training: 'vocal',
    focus: 'balanced',
    session: 'rest',
    offer: 'balanced',
    reaction: '차분히 쌓은 연습이 오늘은 조금 들리는 것 같아요.'
  }, {
    name: '몰입하는 창작가',
    training: 'creative',
    focus: 'creative',
    session: 'creative',
    offer: 'artist',
    reaction: '제 아이디어를 끝까지 다듬어 볼 수 있어서 좋아요.'
  }, {
    name: '도전하는 표현가',
    training: 'performance',
    focus: 'stage',
    session: 'stage',
    offer: 'artist',
    reaction: '직접 부딪쳐 보니 무대에서 해보고 싶은 게 늘었어요.'
  }, {
    name: '신중한 완벽주의',
    training: 'balanced',
    focus: 'balanced',
    session: 'rest',
    offer: 'balanced',
    reaction: '하나씩 정리하고 나니 다시 집중할 수 있겠어요.'
  }, {
    name: '함께 크는 활력',
    training: 'performance',
    focus: 'stage',
    session: 'stage',
    offer: 'balanced',
    reaction: '같이 호흡을 맞추니까 혼자 할 때보다 용기가 나요.'
  }, {
    name: '독립적인 탐구가',
    training: 'creative',
    focus: 'creative',
    session: 'creative',
    offer: 'artist',
    reaction: '저만의 방법을 시험해 볼 시간을 주셔서 고마워요.'
  }];
  roster.forEach((a, i) => {
    a.personality = { ... personalities[i % 6], intro: personalLines[i] };
  });
  const stageNames = ['', '신생 레이블', '소형 기획사', '성장 기획사', '중견 기획사', '대형 엔터테인먼트사'];
  const terms = { company: {
    name: '회사 중심',
    fee: 100,
    share: .8,
    days: 365
  }, balanced: {
    name: '균형',
    fee: 200,
    share: .65,
    days: 730
  }, artist: {
    name: '아티스트 중심',
    fee: 400,
    share: .5,
    days: 1095
  }
  };
  const stageRules = [{
    level: 2,
    days: 180,
    revenue: 30000,
    profit: 0,
    runway: 3
  }, {
    level: 3,
    days: 365,
    revenue: 150000,
    profit: 10000,
    runway: 4
  }, {
    level: 4,
    days: 730,
    revenue: 700000,
    profit: 70000,
    runway: 6
  }, {
    level: 5,
    days: 1095,
    revenue: 3000000,
    profit: 300000,
    runway: 9
  }];
  const staff = [{
    id: 'manager',
    name: '윤지호',
    role: '매니저',
    salary: 250,
    fee: 150,
    level: 1,
    spec: '일정·컨디션 관리',
    stats:[76, 82, 65, 68, 84]
  }, {
    id: 'casting',
    name: '김서연',
    role: '캐스팅 담당',
    salary: 300,
    fee: 200,
    level: 1,
    spec: '후보 평가·인재 발굴',
    stats:[86, 71, 68, 84, 72]
  }, {
    id: 'trainer',
    name: '정다은',
    role: '육성 담당',
    salary: 350,
    fee: 250,
    level: 2,
    spec: '훈련·합주 성장 효율',
    stats:[88, 78, 52, 64, 82]
  }, {
    id: 'producer',
    name: '강우진',
    role: '프로듀서',
    salary: 450,
    fee: 300,
    level: 2,
    spec: '음반 완성도·제작',
    stats:[91, 74, 71, 82, 66]
  }, {
    id: 'promo',
    name: '박세린',
    role: '홍보 담당',
    salary: 400,
    fee: 250,
    level: 2,
    spec: '팬 유입·광고 발굴',
    stats:[82, 80, 86, 89, 77]
  }, {
    id: 'ads',
    name: '차민호',
    role: '광고 영업',
    salary: 500,
    fee: 350,
    level: 3,
    spec: '광고 계약금·광고 기회',
    stats:[87, 79, 93, 91, 75]
  }, {
    id: 'live',
    name: '문하준',
    role: '공연 담당',
    salary: 450,
    fee: 300,
    level: 3,
    spec: '공연 수익·섭외',
    stats:[86, 88, 81, 92, 73]
  }];
  const DATA = {
    roster,
    staff,
    labels,
    specs,
    stageNames,
    terms,
    stageRules,
    rules: typeof module !== 'undefined' ? require('./rules.js'): root.GameRules
  };
  if (typeof module !== 'undefined') module.exports = DATA;
  else root.DATA = DATA;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/operations-data.js */
(function(root) {
  'use strict';
  const D = typeof module !== 'undefined' ? require('./data.js'): root.DATA;
  const careers = [['한울', 'band', 28, '보컬', '인디 무대에서 8년간 노래했습니다. 음색과 라이브에는 자신 있지만 넓은 관객을 만나고 싶습니다.', [78, 35, 32, 65, 72, 80, 40, 75], 650, 9], ['도희', 'band', 26, '기타', '소규모 클럽에서 기타를 연주해 왔습니다. 해산한 밴드의 경험을 새 음악으로 이어가려 합니다.', [58, 30, 35, 83, 77, 68, 33, 72], 380, 6], ['문호', 'band', 30, '베이스', '투어 세션과 밴드 활동을 병행했습니다. 안정적인 합주와 오래가는 팀을 원합니다.', [50, 35, 28, 85, 61, 72, 38, 87], 500, 7], ['빛나', 'band', 27, '드럼', '공연 경험이 많은 드러머입니다. 작은 팬 커뮤니티가 새로운 활동을 기다리고 있습니다.', [48, 30, 46, 82, 62, 83, 45, 79], 750, 8], ['서린', 'idol', 25, '보컬·퍼포먼스', '활동을 마친 그룹의 리드보컬 출신입니다. 남은 팬들과 차분한 재출발을 준비합니다.', [80, 42, 76, 33, 50, 83, 72, 70], 1600, 18], ['태겸', 'idol', 29, '보컬·퍼포먼스', '그룹 해체 후 오랜 공백을 보냈습니다. 무대 감각은 좋지만 컨디션 회복이 필요합니다.', [67, 68, 84, 30, 52, 85, 65, 64], 900, 13], ['예원', 'idol', 28, '보컬·퍼포먼스', '짧았던 아이돌 활동 이후 보컬과 작곡을 다시 공부했습니다. 자신만의 방향을 찾고 있습니다.', [76, 40, 65, 42, 74, 72, 68, 73], 1100, 15], ['준혁', 'idol', 31, '보컬·퍼포먼스', '팀의 리더로 활동했습니다. 방송 경험과 팀 조율 능력을 새 팀에서도 살리고 싶어 합니다.', [72, 63, 78, 35, 60, 81, 80, 85], 1300, 17], ['예슬', 'idol', 32, '보컬·퍼포먼스', '두 장의 음반이 큰 성과를 내지는 못했지만 꾸준히 찾아 듣는 팬들이 있습니다.', [85, 32, 45, 50, 74, 75, 48, 66], 500, 7], ['건호', 'band', 34, '보컬', '음반 흥행은 부진했지만 공연으로 활동을 이어온 싱어송라이터입니다.', [83, 38, 30, 76, 85, 78, 40, 73], 850, 10], ['소연', 'idol', 30, '보컬·퍼포먼스', '전 소속사와 계약 종료 후 보컬 트레이닝을 하며 신곡을 준비해 왔습니다.', [82, 40, 62, 40, 66, 77, 61, 78], 400, 6], ['현준', 'rap', 27, '래퍼', '첫 음반 이후 주목도가 줄었지만 작사와 작은 공연을 멈추지 않은 래퍼입니다.', [55, 85, 50, 32, 83, 78, 55, 70], 700, 9]];
  careers.forEach((v, i) => {
    const id = 60 + i;
    D.roster.push({
      id,
      name: v[0],
      type: v[1],
      age: v[2],
      position: v[3],
      story: v[4],
      stats: v[5],
      image: nextStagePortraitUrl(`assets/portraits/artist-${id}-anime-v1.webp`),
      style: D.roster[v[1] === 'band' ? 1: v[1] === 'rap' ? 2: 0].style,
      traits:['무대 경험', '재출발', '자기 음악'][i % 3],
      trainee: false,
      available: 0,
      career: i < 4 ? '인디 출신': i < 8 ? '전직 아이돌': '솔로 재도전',
      priorFans: v[6],
      priorFame: v[7],
      personality: { ... D.roster[(i * 5) % 60].personality, intro: v[4] }
    });
  });
  const kinds = ['manager', 'casting', 'trainer', 'producer', 'promo', 'ads', 'live'];
  const extraNames = ['박도영', '이현서', '최지민', '정수현', '한도경', '문지수', '김하준', '이서하', '권민서', '백서율', '오윤서', '신도하', '조은우', '임지완', '송예진', '고서희', '남지훈', '유하늘', '장수호', '신유정', '강태윤', '차예빈', '윤세아'];
  D.staff.forEach(p => {
    p.kind = p.id;
    p.specialty = p.id === 'trainer' ? 'balanced': 'general';
    p.coaching = p.stats[0];
    p.expertise = p.stats[1];
    p.care = p.stats[4];
  });
  let serial = 0;
  for (const kind of kinds) {
    const count = kind === 'trainer' ? 6: kind === 'live' ? 2: 3;
    for (let i = 0; i < count; i++) {
      const template = D.staff.find(p => p.id === kind),
      level = i % 3,
      skill = 40 + level * 20 +(serial * 7) % 15;
      D.staff.push({
        id: kind + '-' +(i + 1),
        kind,
        name: extraNames[serial],
        role: template.role,
        level: 1,
        salary: Math.round(130 + skill * 2.6 +(kind === 'trainer' ? i * 15: 0)),
        fee: Math.round(80 + skill * 1.3),
        spec: template.spec,
        stats:[skill, 45 +(serial * 9) % 50, 40 +(serial * 11) % 50, 45 +(serial * 7) % 50, 45 +(serial * 13) % 50],
        coaching: skill,
        expertise: 50 +(serial * 11) % 50,
        care: 45 +(serial * 13) % 50,
        specialty: kind === 'trainer' ?['vocal', 'performance', 'creative', 'balanced', 'vocal', 'performance'][i]: 'general'
      });
      serial++;
    }
  }
  D.staffKinds = {
    manager: '매니저',
    casting: '캐스팅',
    trainer: '육성',
    producer: '음악 제작',
    promo: '홍보',
    ads: '광고 영업',
    live: '공연'
  };
  D.promotionPlans = { none: {
    name: '기본 발매',
    cost: 0,
    days: 0,
    boost: 0
  }, teaser: {
    name: '티저 캠페인',
    cost: 200,
    days: 2,
    boost: .08
  }, session: {
    name: '라이브 영상',
    cost: 400,
    days: 4,
    boost: .14
  }
  };
  if (typeof module !== 'undefined') module.exports = D;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/evolution-data.js */
(function(root) {
  'use strict';
  const D = typeof module !== 'undefined' ? require('./operations-data.js'): root.DATA;
  D.goalRewards = {
    sign: { cash: 100, text: '계약 기념 · 지원금 100만 원', description: '소속 아티스트 1명과 전속계약' },
    trainee: { cash: 200, text: '육성 지원금 200만 원', description: '연습생 1명 영입' },
    debut: { perk: 'debutPromo', text: '데뷔 기념 · 다음 싱글 홍보 1회 지원', description: '연습생의 정식 데뷔 1회' },
    release: { perk: 'productionVoucher', text: '다음 싱글 기본 제작비 5% 할인 · 최대200만 원', description: '싱글 1회 발매' },
    catalog: { cash: 100, text: '첫 정산 기념 · 지원금 100만 원', description: '음원 주간 정산에서 회사 몫 실제 입금 발생' },
    profit: { cash: 300, text: '운영 지원금 300만 원', description: '최소30일 기록 · 최근365일 영업이익 1,000만 원' },
    staff: { cash: 100, text: '직원 소개 · 채용 지원금 100만 원', description: '전문 직원 1명 채용' },
    fans: { offer: 'fan', text: '팬 메시지 · 소규모 팬 공연 제안', description: '개인 또는 팀 하나의 합산 팬1,000명' },
    renew: { text: '감사 대화 · 함께한 재계약 기록', description: '전속 아티스트 재계약 1회' },
    star: { offer: 'star', text: '특별 기사 · 스타 신곡 기획 제안', description: '개인 또는 팀의 스타 등급 최초 달성' },
    rival: { offer: 'collab', text: '업계 기사 · 협업 싱글 제안', description: '최소180일 기록 · 양의 최근365일 영업이익으로 라이벌 한 곳 추월' },
    large: { offer: 'large', text: '회사 성장 회고 · 대형 공연 기획 제안', description: '회사 성장5단계 도달' },
    live: { text: '첫 무대 기념 카드', description: '유료 관객이 있는 공연 완료' },
    liveprofit: { perk: 'livePromo', text: '다음 공연 홍보 1회 지원', description: '제작비·현장비·배분 차감 후 공연 손익 양수' },
    team: { text: '팀 단체 프로필 · 첫 활동 기록', description: '팀 결성 후 싱글·공연·커버 중 첫 활동 완료' },
    physical: { text: '첫 구매자 메시지 · 실물 판매 기념', description: '실물 음반 실제 판매1장 이상' },
    comeback: { text: '복귀 기사 · 아티스트의 감사 대화', description: '경력 아티스트가 자사에서 첫 음악·공연·커버 활동 완료' },
    stable: { cash: 300, text: '운영 지원금 300만 원', description: '업데이트 이후 완전한30일 정산3회 연속 영업흑자' }
  };
  D.specialOffers = {
    fan: {
      title: '팬들과 가까이 · 소규모 팬 공연',
      kind: 'live',
      budget: 300,
      days: 60,
      note: '팬1,000명 이상인 대상 · 공연비300만 원 · 준비7일 + 정산7일. 수익 보장 없음.'
    },
    star: {
      title: '우리의 다음 장 · 스타 싱글',
      kind: 'single',
      budget: 4000,
      days: 90,
      note: '스타 등급 이상 대상 · 기본 제작비4,000만 원 · 준비21일. 일반 제작·회복 조건 적용.'
    },
    collab: {
      title: '같은 무대의 다른 색 · 협업 싱글',
      kind: 'single',
      budget: 2000,
      days: 90,
      note: '현재 영업흑자 필요 · 기본 제작비2,000만 원 · 준비21일. 외부 세션과의 단발 협업이며 타사 인물·권리는 취득하지 않습니다.'
    },
    large: {
      title: 'NEXT STAGE LIVE · 대형 기획',
      kind: 'live',
      budget: 1500,
      days: 90,
      note: '현재 회사5단계 필요 · 공연비1,500만 원 · 준비7일 + 정산7일. 관객 부족 위험이 있습니다.'
    }
  };
  D.personalStories = {
    firststage: {
      title: '첫 무대 앞에서',
      body: '첫 공연을 앞두고 마음이 복잡합니다. 무대가 설레지만, 준비한 것을 잘 전할 수 있을지 걱정돼요.',
      support: '마음 정리·무대 조언 · 100만 원',
      space: '부담을 덜어 주는 대화 · 무료',
      replySupport: '제 속도에 맞춰 준비를 도와주셔서 고마워요.',
      replySpace: '실수해도 괜찮다는 말이 큰 힘이 됐어요.'
    },
    comeback: {
      title: '다시 시작하는 마음',
      body: '이전 활동의 기억이 아직 남아 있습니다. 이번에는 오래 이어 갈 수 있는 음악을 하고 싶어요.',
      support: '복귀 방향 상담 · 100만 원',
      space: '서두르지 않고 이야기 듣기 · 무료',
      replySupport: '지난 경험을 실패로만 보지 않아 주셔서 고마워요.',
      replySpace: '다시 시작할 시간을 믿고 기다려 주셨네요.'
    },
    creative: {
      title: '내 음악의 방향',
      body: '떠오르는 아이디어가 있지만 회사의 방향과 맞을지 고민입니다. 제 색을 어디까지 표현해도 될까요?',
      support: '아이디어 검토 지원 · 100만 원',
      space: '지금의 고민을 함께 듣기 · 무료',
      replySupport: '제 아이디어를 진지하게 봐주셔서 다음 곡이 기대돼요.',
      replySpace: '서둘러 답을 내지 않아도 된다는 말에 마음이 편해졌어요.'
    },
    pressure: {
      title: '조금 더 잘하고 싶은 마음',
      body: '기대에 부응하고 싶어 작은 실수도 오래 마음에 남습니다. 지금 페이스로 잘하고 있는 걸까요?',
      support: '멘토 상담 지원 · 100만 원',
      space: '휴식과 안심의 대화 · 무료',
      replySupport: '혼자 고민할 때보다 다음 목표가 선명해졌어요.',
      replySpace: '쉬어 가도 괜찮다는 말을 기억할게요.'
    },
    team: {
      title: '함께 맞추는 호흡',
      body: '같은 무대에 서지만 서로 생각하는 표현이 조금씩 다릅니다. 팀 안에서 제 목소리도 잘 전하고 싶어요.',
      support: '팀 소통 상담 · 100만 원',
      space: '각자의 생각부터 듣기 · 무료',
      replySupport: '다른 생각을 맞춰 가는 방법을 배웠어요.',
      replySpace: '제 의견도 팀의 일부라는 느낌이 들어요.'
    }
  };
  if (typeof module !== 'undefined') module.exports = D;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/management.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const clamp =(n, a, b) => Math.max(a, Math.min(b, n));
    class ManagementGame extends Base {
      constructor(state) {
        super(state ? JSON.parse(JSON.stringify(state)): null);
        if (this.s) this.upgrade();
      }
      newGame(company, boss) {
        super.newGame(company, boss);
        this.upgrade();
        return this.s;
      }
      upgrade() {
        let s = this.s;
        if (s.managementVersion === 2) return;
        s.managementVersion = 2;
        s.recordSince = s.day;
        s.companyLevel = 1;
        s.lowQuarters = 0;
        s.accounts = [];
        s.trainees = [];
        s.departed = [];
        s.teamArchive = [];
        s.goals = [];
        s.performance = [];
        s.payments = [];
        s.industryNews = [];
        s.valuations = [];
        s.rivals = [['블룸 팩토리', 'idol', 80000, [18, 21, 24]], ['루트 레코즈', 'band', 60000, [19, 22, 43]], ['모션 레이블', 'rap', 70000, [20, 23, 52]], ['오로라 뮤직', 'any', 250000, [25, 44, 53]]].map((r, i) =>({
          id: i,
          name: r[0],
          type: r[1],
          cash: r[2],
          debt: 0,
          artists: r[3],
          catalog:[],
          accounts:[],
          jobs:[],
          fans: 1000 *(i + 1),
          reputation: 20 + i * 10,
          level: i === 3 ? 3: 1,
          value: r[2],
          serial: 0
        }));
        s.artists.forEach(a => {
          a.terms = { ... D.terms.balanced, share: 1, name: '기존 계약(회사 순정산)' };
          a.signed = s.day;
          a.lastActive = s.day;
          a.star = 0;
          a.bestStar = 0;
        });
        s.units.forEach(u => {
          u.status = 'active';
          u.fame = 0;
          u.fans = 0;
          u.star = 0;
          u.bestStar = 0;
        });
        for (const c of s.catalog) {
          c.shares = [];
          c.ownerName = this.entity(c.entity)?.name || '기존 작품';
        }
        s.rivals.forEach(r => {
          r.artists = r.artists.filter(id => !this.artist(id));
        });
        for (const j of s.jobs) if (j.entity) {
          j.snapshot = this.snapshot(j.entity);
          j.shares = [];
        }
        s.candidates = s.candidates.filter(c => this.available(c.id));
      }
      get stage() {
        return this.s.companyLevel || 1;
      }
      get capacity() {
        return 6 +(this.has('manager') ? 6: 0) +(this.has('casting') ? 2: 0);
      }
      get traineeCapacity() {
        return 6 +(this.has('trainer') ? 6: 0);
      }
      get fixed() {
        return super.fixed + this.s.trainees.length * 60;
      }
      get entities() {
        return super.entities;
      }
      available(id) {
        let d = D.roster[id];
        return !!d && !this.artist(id) && !this.s.trainees.some(a => a.id === id) && !this.s.rivals.some(r => r.artists.includes(id)) && d.available <= this.s.day;
      }
      account(amount, revenue, expense, entity = null) {
        let s = this.s,
        b = s.accounts.at(- 1);
        if (!b || b.day !== s.day) {
          b = {
            day: s.day,
            revenue: 0,
            expense: 0,
            by: {}
          };
          s.accounts.push(b);
        }
        b.revenue += revenue;
        b.expense += expense;
        if (entity && revenue) b.by[entity] =(b.by[entity] || 0) + revenue;
      }
      change(amount, label, operating = true, meta = {}) {
        super.change(amount, label, operating, meta);
        if (!this.s.accounts) return;
        const financing = ['loan', 'loan_repayment', 'rescue'].includes(meta.kind);
        let interest = 0;
        if (meta.kind === 'loan_repayment') interest = meta.interest || 0;
        this.account(amount, operating && amount > 0 ? amount: 0, amount < 0 ?(financing ? interest: - amount): 0, this._earningEntity || null);
      }
      receive(amount, label, shares = [], key = null, kind = 'income') {
        this._earningEntity = key;
        this.change(amount, label, true, { kind });
        this._earningEntity = null;
        for (const x of shares) {
          let payment = Math.round(amount * x.rate * 100) / 100;
          if (payment <= 0) continue;
          this.change(- payment, '아티스트 배분: ' + D.roster[x.id].name);
          this.s.payments.unshift({
            day: this.s.day,
            id: x.id,
            amount: payment,
            label
          });
        }
        this.s.payments = this.s.payments.slice(0, 100);
      }
      metrics() {
        let s = this.s,
        bins = s.accounts.filter(b => b.day > s.day - 365);
        let revenue = bins.reduce((n, b) => n + b.revenue, 0),
        expense = bins.reduce((n, b) => n + b.expense, 0),
        by = {};
        for (const b of bins) for (const[k, v] of Object.entries(b.by)) by[k] =(by[k] || 0) + v;
        return {
          revenue,
          expense,
          profit: revenue - expense,
          runway: Math.max(0, s.cash /(this.fixed + s.artists.length * 300)),
          concentration: revenue ? Math.max(0, ... Object.values(by)) / revenue: 0,
          days: Math.min(365, s.day - s.recordSince)
        };
      }
      valuation() {
        let m = this.metrics(),
        s = this.s;
        let contractRisk = s.artists.length ? s.artists.reduce((n, a) => n + clamp((a.contract - s.day) / 365, 0, 1), 0) / s.artists.length: 0;
        let operating = Math.max(0, m.profit * 4, m.revenue * .45) *(0.65 + contractRisk * .35) *(1 - m.concentration * .25);
        let equity = Math.max(0, operating + s.cash - this.debt);
        let spread = m.days < 180 ? .35: .15;
        return {
          value: equity,
          low: Math.round(equity *(1 - spread)),
          high: Math.round(equity *(1 + spread)),
          operating: Math.round(operating),
          confidence: m.days < 180 ? '낮음': '보통',
          contractRisk
        };
      }
      hire(id) {
        let p = D.staff.find(x => x.id === id);
        if (!p || this.has(id)) throw Error('채용할 직무를 확인하세요.');
        this.spend(p.fee, '직원 채용: ' + p.name);
        this.s.staff.push(id);
        this.log(p.name + ' 채용');
      }
      startCasting(method, type, position = 'any') {
        if (!['any', '보컬', '기타', '베이스', '드럼', '키보드'].includes(position)) throw Error('포지션을 확인하세요.');
        if (!D.roster.some(d => this.available(d.id) &&(type === 'any' || d.type === type) &&(position === 'any' || d.position === position))) throw Error('현재 모집할 수 있는 후보가 없습니다.');
        super.startCasting(method, type);
        this.s.jobs.at(- 1).position = position;
      }
      sign(id, offer = 'balanced') {
        id = Number(id);
        let c = this.s.candidates.find(c => c.id === id),
        terms = D.terms[offer];
        if (!terms || !c || c.expires < this.s.day || !this.available(id)) throw Error('계약 가능한 후보와 제안서를 확인하세요.');
        const trainee = D.roster[id].trainee;
        if (trainee ? this.s.trainees.length >= this.traineeCapacity: this.s.artists.length >= this.capacity) throw Error('관리 정원이 부족합니다. 담당 직원을 채용하세요.');
        this.spend(trainee ? D.rules.traineeFee: terms.fee, trainee ? '연습생 계약 지원': '아티스트 계약금');
        let prior = this.s.departed.find(a => a.id === id);
        let a = prior ? JSON.parse(JSON.stringify(prior)): {
          id,
          stats:[... D.roster[id].stats],
          energy: 95,
          stress: 10,
          trust: 70,
          fans: 50 + Math.floor(this.rng() * 120),
          fame: 2,
          focus: 'balanced',
          star: 0,
          bestStar: 0
        };
        a.contract = this.s.day +(trainee ? 730: terms.days);
        a.signed = this.s.day;
        a.terms = { ... terms };
        a.lastActive = this.s.day;
        a.star = a.star || 0;
        a.bestStar = a.bestStar || 0;
        (trainee ? this.s.trainees: this.s.artists).push(a);
        this.s.departed = this.s.departed.filter(x => x.id !== id);
        this.s.candidates = this.s.candidates.filter(x => x.id !== id);
        this.log(D.roster[id].name + ' ' +(trainee ? '연습생 영입': '전속계약'));
        this.report('새로운 계약', D.roster[id].name + '과 함께합니다. ' +(trainee ? '훈련 후 데뷔 평가를 진행하세요.': '활동 수익은 계약 비율에 따라 배분합니다.'), 'info', false);
      }
      readiness(a) {
        return a.stats.reduce((n, v) => n + v, 0) / 8;
      }
      debut(id, offer = 'balanced') {
        let a = this.s.trainees.find(a => a.id === Number(id)),
        t = D.terms[offer];
        if (!a || !t) throw Error('연습생과 계약을 확인하세요.');
        if (this.s.day - a.signed < 90 || this.readiness(a) < 55) throw Error('훈련 90일·평균 능력 55 이상이 필요합니다.');
        if (this.s.artists.length >= this.capacity) throw Error('아티스트 관리 정원이 부족합니다.');
        this.spend(t.fee, '데뷔 계약금');
        this.s.trainees = this.s.trainees.filter(x => x !== a);
        a.terms = { ... t };
        a.contract = this.s.day + t.days;
        a.signed = this.s.day;
        a.lastActive = this.s.day;
        this.s.artists.push(a);
        this.log(D.roster[a.id].name + ' 데뷔');
        this.s.debutCount =(this.s.debutCount || 0) + 1;
      }
      releaseTrainee(id) {
        let a = this.s.trainees.find(a => a.id === Number(id));
        if (!a) throw Error('연습생이 없습니다.');
        this.s.trainees = this.s.trainees.filter(x => x !== a);
        this.s.departed.push(a);
        this.log(D.roster[a.id].name + ' 연습생 계약 합의 종료');
      }
      renewalCost(a, offer = 'balanced') {
        return Math.round((D.terms[offer].fee + a.fame * 10) *(1 +(70 - a.trust) / 200));
      }
      renew(id, offer = 'balanced') {
        let a = this.artist(id),
        t = D.terms[offer];
        if (!a || !t || a.contract - this.s.day > 90) throw Error('만료 90일 전부터 재계약할 수 있습니다.');
        if (t.share > .7 && a.fame > 60 && a.trust < 80) throw Error('아티스트가 배분 조건 개선을 요청했습니다.');
        this.spend(this.renewalCost(a, offer), '아티스트 재계약');
        a.contract = Math.max(a.contract, this.s.day) + t.days;
        a.terms = { ... t };
        a.trust = clamp(a.trust + 10, 0, 100);
        this.log(D.roster[a.id].name + ' 재계약');
        this.s.renewCount =(this.s.renewCount || 0) + 1;
      }
      snapshot(key) {
        let e = this.entity(key);
        return e ? {
          key: e.key,
          name: e.name,
          type: e.type,
          ids: e.members.map(a => a.id)
        }
        : null;
      }
      shares(snapshot) {
        return snapshot.ids.map(id =>({ id, rate:(1 -(this.artist(id)?.terms.share ?? 1)) / snapshot.ids.length }));
      }
      projectEntity(j) {
        let p = j.snapshot;
        if (!p) return this.entity(j.entity);
        let members = p.ids.map(id => this.artist(id) || this.s.departed.find(a => a.id === id)).filter(Boolean);
        return members.length ? { ... p, members }: null;
      }
      startProject(key, kind, title, budget, concept) {
        let e = this.entity(key);
        let u = this.s.units.find(u => u.key === key);
        if (u &&(u.status !== 'active' || u.ids.length < 2)) throw Error('팀을 재편하거나 활동 재개 후 진행하세요.');
        super.startProject(key, kind, title, budget, concept);
        let j = this.s.jobs.at(- 1);
        j.snapshot = this.snapshot(key);
        j.shares = this.shares(j.snapshot);
      }
      resolve(id, choice) {
        let r = this.s.reports.find(r => r.id === Number(id));
        if (r?.kind === 'ad' && choice === 'accept') {
          if (r.resolved || this.s.day > r.expires || !this.entity(r.entity) || this.busy(r.entity)) throw Error('제안을 수락할 수 없습니다.');
          let snapshot = this.snapshot(r.entity),
          shares = this.shares(snapshot);
          this.receive(r.pay * .4, '광고 계약 선금', shares, r.entity);
          this.s.jobs.push({
            id: this.id(),
            kind: 'ad',
            entity: r.entity,
            name: r.brand + ' 광고 촬영',
            pay: r.pay * .6,
            start: this.s.day,
            due: this.s.day + 5,
            snapshot,
            shares
          });
          r.resolved = true;
          r.read = true;
          return;
        }
        super.resolve(id, choice);
      }
      finishManagement(j) {
        if (j.kind === 'casting') {
          let pool = D.roster.filter(a => this.available(a.id) &&(j.type === 'any' || a.type === j.type) &&(!j.position || j.position === 'any' || a.position === j.position) &&(!j.experience || j.experience === 'any' ||(j.experience === 'career' ? !!a.career: a.trainee)));
          for (let i = pool.length - 1; i > 0; i--) {
            let k = Math.floor(this.rng() *(i + 1));
            [pool[i], pool[k]] = [pool[k], pool[i]];
          }
          let picks = pool.filter(a => !this.s.candidates.some(c => c.id === a.id)).slice(0, j.method === 'audition' ? 6: 3);
          picks.forEach(a => this.s.candidates.push({ id: a.id, evaluated: this.has('casting'), expires: this.s.day + 30 }));
          this.report('영입 후보 보고', picks.length + '명의 새 후보가 도착했습니다. 캐스팅에서 계약과 연습생 영입을 진행하세요.', 'casting', true);
          return;
        }
        let e = this.projectEntity(j);
        if (!e) return;
        let original = this.s.catalog.length;
        this.finishCore(j);
        if (['single', 'live', 'cover'].includes(j.kind)) {
          this.s.performance.push({
            day: this.s.day,
            key: j.entity,
            ids: e.members.map(a => a.id),
            kind: j.kind,
            quality: this.s.catalog[original]?.quality || this._lastQuality || 60
          });
          for (const a of e.members) a.lastActive = this.s.day;
          let u = this.s.units.find(u => u.key === j.entity);
          if (u) {
            u.fame = clamp((u.fame || 0) + 5 *(1 -(u.fame || 0) / 110), 0, 100);
            u.fans =(u.fans || 0) + Math.round((this._fanGain || 0) * .8);
          }
        }
      }
      formUnit(name, ids) {
        super.formUnit(name, ids);
        Object.assign(this.s.units.at(- 1), {
          status: 'active',
          fame: 0,
          fans: 0,
          star: 0,
          bestStar: 0
        });
      }
      leaveTeam(id) {
        let u = this.s.units.find(u => u.ids.includes(Number(id)));
        if (!u) throw Error('소속 팀이 없습니다.');
        u.ids = u.ids.filter(x => x !== Number(id));
        if (u.ids.length < 2) u.status = 'hiatus';
        if (!u.ids.length) {
          this.s.teamArchive.push({ ... u, ended: this.s.day });
          this.s.units = this.s.units.filter(x => x !== u);
        }
        this.log(D.roster[id].name + ' · ' + u.name + ' 탈퇴');
      }
      teamAction(key, action, id) {
        let u = this.s.units.find(u => u.key === key);
        if (!u) throw Error('팀이 없습니다.');
        if (action === 'dissolve') {
          this.s.teamArchive.push({ ... u, ended: this.s.day });
          this.s.units = this.s.units.filter(x => x !== u);
          this.log(u.name + ' 해체 · 개인 계약과 기존 작품 정산 유지');
          return;
        }
        if (action === 'add') {
          let a = this.artist(id);
          if (!a || D.roster[a.id].type !== u.type || u.ids.length >= 5 || this.s.units.some(x => x.ids.includes(a.id)) || this.busy(String(a.id)) || this.busy(key)) throw Error('같은 분야의 활동 가능한 미소속 멤버를 선택하세요.');
          u.ids.push(a.id);
          return;
        }
        if (action === 'resume') {
          if (u.ids.length < 2) throw Error('활동 재개에는 멤버 2명 이상이 필요합니다.');
          u.status = 'active';
        } else if (action === 'pause') u.status = 'hiatus';
        else throw Error('팀 설정을 확인하세요.');
      }
      depart(id, reason, rivalId = null) {
        let a = this.artist(id);
        if (!a) return;
        let u = this.s.units.find(u => u.ids.includes(a.id));
        if (u) this.leaveTeam(a.id);
        this.s.artists = this.s.artists.filter(x => x !== a);
        this.s.departed = this.s.departed.filter(x => x.id !== a.id);
        this.s.departed.push(a);
        const rival = rivalId === null ? this.s.rivals.filter(r => r.cash > 1000 && r.artists.length < 8 &&(r.type === 'any' || r.type === D.roster[a.id].type)).sort((x, y) => y.reputation - x.reputation)[0]: this.s.rivals.find(r => r.id === Number(rivalId));
        if (rival && !rival.artists.includes(a.id)) {
          rival.artists.push(a.id);
          this.news(D.roster[a.id].name + ' · ' + rival.name + ' 이적');
        }
        this.report('전속계약 종료', D.roster[a.id].name + ' · ' + reason + '. 기존 작품 배분과 확정 일정은 유지됩니다. ' +(rival ? rival.name + '에서 다음 활동을 이어갑니다.': '자유계약 상태입니다.'), 'info', true);
        this.log(D.roster[a.id].name + ' ' + reason);
      }
      transferQuote(id, rivalId) {
        let a = this.artist(id),
        r = this.s.rivals.find(r => r.id === Number(rivalId));
        if (!a || !r) return null;
        let fee = Math.round(200 + a.fame * 20 + Math.max(0, a.contract - this.s.day) * 2);
        return {
          fee,
          consent: a.trust < 85 &&(a.fame < 30 || r.reputation + 10 >= a.fame),
          affordable: r.cash >= fee + 1000 && r.artists.length < 8,
          fit: r.type === 'any' || r.type === D.roster[a.id].type
        };
      }
      transfer(id, rivalId) {
        let q = this.transferQuote(id, rivalId);
        if (!q || !q.consent || !q.affordable || !q.fit) throw Error('아티스트 동의·상대 자금·분야 적합 조건을 충족하지 못했습니다.');
        if (this.busy(String(id))) throw Error('진행 중인 일정을 마친 후 합의 이적할 수 있습니다.');
        let r = this.s.rivals.find(r => r.id === Number(rivalId));
        r.cash -= q.fee;
        this.change(q.fee, '합의 이적금', false);
        this.depart(id, '삼자 합의 이적', r.id);
      }
      news(text) {
        this.s.industryNews.unshift({ day: this.s.day, text });
        this.s.industryNews = this.s.industryNews.slice(0, 60);
      }
      marketFactor(type) {
        let pressure = this.s.rivals.filter(r =>(r.type === type || r.type === 'any') && r.catalog.some(c => c.age === 0)).length;
        return Math.max(.8, 1 - pressure * .06);
      }
      rivalsMonth() {
        for (const r of this.s.rivals) {
          let income = 0,
          cost = 300 + r.artists.length * 100;
          for (const c of r.catalog) {
            c.age++;
            let pay = Math.round(c.quality * 22 * Math.pow(.92, c.age));
            income += pay;
          }
          if (r.cash > 4000 && r.artists.length) {
            let budget = r.type === 'band' ? 1500: 2500;
            cost += budget;
            let quality = 45 + this.rng() * 40;
            r.catalog.push({ name: '월간 프로젝트 ' +(++ r.serial), quality, age: 0 });
            r.catalog = r.catalog.slice(- 36);
            r.fans += Math.round(quality * 8);
            r.reputation = clamp(r.reputation + quality / 30, 0, 100);
            this.news(r.name + ' · ' + r.catalog.at(- 1).name + ' 발표');
          }
          if (r.cash < cost && r.debt < 10000) {
            r.cash += 3000;
            r.debt += 3000;
          }
          if (r.cash + income < cost) {
            cost = Math.max(0, r.cash + income);
            r.reputation = Math.max(0, r.reputation - 5);
            if (r.artists.length) {
              let departed = r.artists.pop();
              this.news(r.name + ' · 재정 악화로 ' + D.roster[departed].name + '과 계약 종료');
            }
          }
          r.cash += income - cost;
          r.accounts.push({ day: this.s.day, revenue: income, expense: cost });
          r.accounts = r.accounts.filter(b => b.day > this.s.day - 365);
          let profit = r.accounts.reduce((n, b) => n + b.revenue - b.expense, 0);
          r.value = Math.max(0, r.cash - r.debt + Math.max(0, profit * 4));
          r.level = r.value >= 3000000 ? 5: r.value >= 700000 ? 4: r.value >= 150000 ? 3: r.value >= 30000 ? 2: 1;
        }
      }
      updateStars() {
        for (const a of this.s.artists) {
          if (this.s.day - a.lastActive > 90) {
            a.trust = Math.max(0, a.trust - 2);
            if (a.trust < 50 && !a.concernSent) {
              a.concernSent = true;
              this.report('활동 계획 면담 요청', D.roster[a.id].name + '이 장기 활동 공백을 걱정합니다. 활동 기회나 지원을 검토하세요.', 'event', true, { entity: String(a.id) });
            }
          } else a.concernSent = false;
          let events = this.s.performance.filter(p => p.day > this.s.day - 365 && p.ids.includes(a.id) && p.key === String(a.id)),
          hits = events.filter(p => p.quality >= 75).length;
          let fameThreshold = D.roster[a.id].type === 'band' ? 55: 70;
          let level = a.fame >= 85 && hits >= 4 && a.fans >= 20000 ? 4: a.fame >= fameThreshold && hits >= 2 && a.fans >= 5000 ? 3: a.fame >= 40 && events.length >= 2 ? 2: a.fame >= 15 ? 1: 0;
          if (level >= 3) {
            a.starSince = a.starSince ?? this.s.day;
            if (this.s.day - a.starSince < 180) level = 2;
          } else a.starSince = null;
          a.star = level;
          a.bestStar = Math.max(a.bestStar || 0, level);
          if (this.s.day - a.lastActive > 30) {
            a.fame = Math.max(0, a.fame - 1);
            a.fans = Math.max(0, Math.floor(a.fans * .99));
          }
        }
        for (const u of this.s.units) {
          let hits = this.s.performance.filter(p => p.day > this.s.day - 365 && p.key === u.key && p.quality >= 75).length;
          let level = u.fame >= 85 && hits >= 4 && u.fans >= 20000 ? 4: u.fame >= 70 && hits >= 2 && u.fans >= 5000 ? 3: u.fame >= 40 ? 2: u.fame >= 15 ? 1: 0;
          if (level >= 3) {
            u.starSince = u.starSince ?? this.s.day;
            if (this.s.day - u.starSince < 180) level = 2;
          } else u.starSince = null;
          u.star = level;
          u.bestStar = Math.max(u.bestStar || 0, level);
          if (!this.s.performance.some(p => p.key === u.key && p.day > this.s.day - 60)) {
            u.fame = Math.max(0, u.fame - 1);
            u.fans = Math.floor(u.fans * .99);
          }
        }
      }
      quarter() {
        let s = this.s,
        m = this.metrics(),
        qualified = 1;
        for (const r of D.stageRules) if (s.day >= r.days && m.days >= Math.min(r.days, 365) && m.revenue >= r.revenue && m.profit >= r.profit && m.runway >= r.runway) qualified = r.level;
        if (qualified > s.companyLevel) {
          s.companyLevel = qualified;
          s.lowQuarters = 0;
          this.report('회사 성장 단계 상승', D.stageNames[s.companyLevel] + '에 진입했습니다.', 'info', true);
        } else if (qualified < s.companyLevel) {
          s.lowQuarters++;
          if (s.lowQuarters >= 2) {
            s.companyLevel = Math.max(qualified, s.companyLevel - 1);
            s.lowQuarters = 0;
            this.report('회사 규모 재평가', D.stageNames[s.companyLevel] + '로 조정되었습니다. 직원과 기능은 유지됩니다.', 'info', true);
          }
        } else s.lowQuarters = 0;
      }
      goalList() {
        let s = this.s,
        m = this.metrics();
        return [['sign', '첫 전속계약', s.artists.length, 1], ['trainee', '첫 연습생 영입', s.trainees.length, 1], ['debut', '첫 데뷔', s.debutCount || 0, 1], ['release', '첫 싱글', s.releases, 1], ['catalog', '음원 정산', s.catalog.reduce((n, c) => n + c.revenue, 0), 1], ['profit', '흑자 기반 확보', m.days >= 30 ? Math.max(0, m.profit): 0, 1000], ['staff', '첫 전문 직원', s.staff.length, 1], ['fans', '팬 1,000명', Math.max(0, ... this.entities.map(e => e.members.reduce((n, a) => n + a.fans, 0))), 1000], ['renew', '첫 재계약', s.renewCount || 0, 1], ['star', '첫 스타 배출', Math.max(0, ... s.artists.map(a => a.bestStar || 0), ... s.units.map(u => u.bestStar || 0)), 3], ['rival', '라이벌 영업이익 추월', m.days >= 180 && m.profit > 0 && s.rivals.some(r => m.profit > r.accounts.reduce((n, b) => n + b.revenue - b.expense, 0)) ? 1: 0, 1], ['large', '대형 엔터테인먼트사', s.companyLevel, 5]].map(([id, title, value, target]) =>({
          id,
          title,
          value,
          target,
          done: s.goals.includes(id)
        }));
      }
      advanceManagement() {
        let s = this.s;
        this.advanceCore();
        this.applyScheduledExpenses();
        this._interest = 0;
        s.accounts = s.accounts.filter(b => b.day > s.day - 365);
        s.performance = s.performance.filter(p => p.day > s.day - 365);
        if (s.day % 30 === 0) {
          this.rivalsMonth();
          this.updateStars();
          let v = this.valuation();
          let prev = s.valuations.at(- 1);
          s.valuations.push({
            day: s.day,
            value: v.value,
            revenue: this.metrics().revenue,
            profit: this.metrics().profit
          });
          s.valuations = s.valuations.slice(- 24);
          this.news('우리 회사 추정 기업가치 ' + Math.round(v.low).toLocaleString() + '~' + Math.round(v.high).toLocaleString() + '만 원 · ' +(prev && v.value < prev.value ? '하락': '평가 갱신'));
        }
        if (s.day % 90 === 0) this.quarter();
        for (const g of this.goalList()) if (!g.done && g.value >= g.target) {
          s.goals.push(g.id);
          this.log('목표 달성: ' + g.title);
          this.report('목표 달성', g.title + ' · 회사 연혁에 배지를 기록했습니다.', 'info', false);
        }
        return this.pending.length;
      }
    }
    return ManagementGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installManagement = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/progression.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const clamp =(n, min, max) => Math.max(min, Math.min(max, n));
    const plans = {
      balanced: {
        name: '균형 기초',
        indexes:[0, 1, 2, 3, 4, 5, 6, 7],
        cost: 2,
        load: 1
      },
      vocal: {
        name: '보컬 집중',
        indexes:[0, 7],
        cost: 3,
        load: 2
      },
      performance: {
        name: '무대 집중',
        indexes:[2, 5, 6],
        cost: 3,
        load: 3
      },
      creative: {
        name: '창작 집중',
        indexes:[1, 3, 4],
        cost: 3,
        load: 2
      },
      rest: {
        name: '회복',
        indexes:[],
        cost: 0,
        load: 0
      }
    };
    const incidents = {
      cancel: { title: '공연 준비 차질·취소', body: '준비 차질로 예정 공연을 취소했습니다. 집행한 제작비는 회수되지 않습니다. 티켓 선판매는 없으므로 티켓 환불을 이중 차감하지 않습니다.' },
      sound: { title: '공연 음향 사고', body: '현장 음향 문제로 관객 불만이 접수됐습니다.' },
      notice: { title: '일정 공지 혼선', body: '일정 안내가 일치하지 않아 팬들이 불편을 겪었습니다.' },
      overwork: { title: '과도한 활동에 대한 우려', body: '컨디션 저하와 빡빡한 일정에 대한 우려가 제기됐습니다.' }
    };
    class ProgressionGame extends Base {
      upgrade() {
        super.upgrade();
        let s = this.s;
        if (!s || s.balanceVersion === 1) return;
        s.balanceVersion = 1;
        s.image = 60;
        s.incidents = [];
        s.lastIncidentDay = - 90;
        s.settlements = [];
        for (const a of[... s.trainees, ... s.artists, ... s.departed]) this.initTalent(a);
        for (const r of s.rivals) {
          r.image = 60;
          r.lastAction = '운영 계획 수립';
          r.talents = r.artists.map(id => this.rivalTalent(id));
        }
      }
      initTalent(a) {
        if (!a.trainingPlan) a.trainingPlan = 'balanced';
        if (!Number.isInteger(a.trainedDays)) a.trainedDays = 0;
      }
      sign(id, offer) {
        super.sign(id, offer);
        this.initTalent(this.artist(id) || this.s.trainees.find(a => a.id === Number(id)));
      }
      profile(id) {
        let d = D.roster[id],
        strengths = d.type === 'idol' ?[0, 2, 5]: d.type === 'band' ?[3, 4, 7]:[1, 4, 5];
        return {
          strength: strengths[id % 3],
          weakness:[6, 7, 0][id % 3],
          potential: 78 +(id * 7) % 20,
          learning: .8 +(id % 6) * .08,
          temperament: d.personality.name
        };
      }
      setTraining(id, plan) {
        let a = this.s.trainees.find(a => a.id === Number(id));
        if (!a || !plans[plan]) throw Error('연습생과 훈련 계획을 확인하세요.');
        a.trainingPlan = plan;
      }
      trainTrainees() {
        for (const a of[... this.s.trainees]) {
          this.initTalent(a);
          let p = plans[a.trainingPlan],
          profile = this.profile(a.id),
          rest = p === plans.rest || a.energy < 30 || a.stress > 80;
          if (rest) {
            a.energy = clamp(a.energy + 8, 0, 100);
            a.stress = clamp(a.stress - 6, 0, 100);
          } else {
            let cost = this.has('trainer') ? p.cost * .8: p.cost;
            if (this.s.cash < cost) {
              a.energy = clamp(a.energy + 5, 0, 100);
              a.stress = clamp(a.stress - 3, 0, 100);
            } else {
              this.change(- cost, '연습생 훈련: ' + D.roster[a.id].name, true, { kind: 'training' });
              a.energy = clamp(a.energy - p.load, 0, 100);
              a.stress = clamp(a.stress + p.load * .5 -(this.has('trainer') ? 1: 0), 0, 100);
              a.trainedDays++;
              for (const idx of p.indexes) {
                let gain =(this.has('trainer') ? .16: .10) * profile.learning *(p.indexes.length === 8 ? 1: 2.2) *(idx === profile.strength ? 1.35: idx === profile.weakness ? .7: 1) *(1 - a.stress * .005);
                if (a.stats[idx] < profile.potential) a.stats[idx] = Math.min(profile.potential, a.stats[idx] + gain);
              }
            }
          }
          if (a.contract <= this.s.day + 1) this.releaseTrainee(a.id);
        }
      }
      imageFactor() {
        return clamp(.6 + this.s.image / 150, .6, 1.25);
      }
      concert(e, j, quality) {
        const venue = j.budget <= 300 ? {
          name: '소규모 클럽',
          capacity: 200,
          ticket: 9,
          variable: .8
        }
        : j.budget <= 800 ? {
          name: '중형 공연장',
          capacity: 700,
          ticket: 10,
          variable: 1.2
        }
        : {
          name: '대형 공연장',
          capacity: 1800,
          ticket: 12,
          variable: 1.8
        };
        let fans = e.members.reduce((n, a) => n + a.fans, 0),
        recent = this.s.performance.filter(p => p.kind === 'live' && p.day > this.s.day - 30 && p.ids.some(id => e.members.some(a => a.id === id))).length;
        let demand =(quality * 1.5 + fans * .2) *(9 / venue.ticket) * this.imageFactor() *(1 + this.staffPower('live') * .2) /(1 + recent * .2);
        let attendance = clamp(Math.floor(demand), 0, venue.capacity),
        result = {
          ... venue,
          attendance,
          gross: attendance * venue.ticket,
          variable: Math.round(attendance * venue.variable * 100) / 100,
          recent
        };
        j.concert = result;
        return result;
      }
      newFans(e, j, quality, fan) {
        let recent = this.s.performance.filter(p => p.kind === j.kind && p.day > this.s.day - 60 && p.ids.some(id => e.members.some(a => a.id === id))).length;
        let reach = Math.max(0, quality - 25) *({ single: 11, live: 2.2, cover: 3 }[j.kind]);
        if (j.kind === 'live') reach = Math.min(reach, this.concert(e, j, quality).attendance * .35);
        let gain = Math.floor(reach * this.imageFactor() *(1 + this.staffPower('promo') * .2) * this.marketFactor(e.type) /(Math.sqrt(1 + fan / 10000) *(1 + recent * .12)));
        this._fanGain = Math.max(0, gain);
        return this._fanGain;
      }
      finishProgression(j) {
        let before = this.s.cash,
        e = j.kind === 'casting' ? null: this.projectEntity(j);
        this.finishManagement(j);
        if (!e) return;
        const quality = this._lastQuality || 0;
        if (quality >= 75 && !this.s.incidents.some(i => i.state !== 'closed')) this.s.image = clamp(this.s.image + .15, 0, 100);
        if (quality < 40 && j.kind !== 'ad') {
          for (const a of e.members) a.fans = Math.max(0, Math.floor(a.fans * .99));
          this.s.image = clamp(this.s.image - 1, 0, 100);
        }
        if (j.kind === 'live' || j.kind === 'ad') {
          let gross = j.kind === 'live' ? j.concert.gross: j.pay,
          payout = Math.round((j.shares ||[]).reduce((n, x) => n + Math.round(gross * x.rate * 100) / 100, 0) * 100) / 100,
          variable = j.concert?.variable || 0;
          let entry = {
            day: this.s.day,
            name: j.name,
            kind: j.kind,
            gross,
            payout,
            variable,
            budget: j.kind === 'live' ? j.budget: 0,
            net: Math.round((gross - payout - variable -(j.kind === 'live' ? j.budget: 0)) * 100) / 100,
            attendance: j.concert?.attendance || 0,
            capacity: j.concert?.capacity || 0
          };
          this.s.settlements.unshift(entry);
          this.s.settlements = this.s.settlements.slice(0, 80);
          let r = this.s.reports.find(r => r.day === this.s.day && r.kind === 'result');
          if (r) r.body += '\n총수입 ' + gross.toLocaleString() + '만 / 배분 ' + payout.toLocaleString() + '만 / 현장비 ' + variable.toLocaleString() + '만 / 선집행 제작비 ' + entry.budget.toLocaleString() + '만 / 회사 손익 ' + entry.net.toLocaleString() + '만 원.' +(j.kind === 'live' ? '\n유료 관객 ' + entry.attendance + ' / 수용 ' + entry.capacity + '명.': ' (광고 잔금 구간만)');
        }
      }
      valuation() {
        let v = super.valuation(),
        factor = .7 + this.s.image / 200,
        operating = v.operating * factor,
        value = Math.max(0, operating + this.s.cash - this.debt),
        spread = this.metrics().days < 180 ? .35: .15;
        return {
          ... v,
          operating: Math.round(operating),
          value,
          low: Math.round(value *(1 - spread)),
          high: Math.round(value *(1 + spread))
        };
      }
      incidentRisk(e) {
        let stress = e.members.reduce((n, a) => n + a.stress, 0) / e.members.length,
        energy = e.members.reduce((n, a) => n + a.energy, 0) / e.members.length,
        recent = this.s.performance.filter(p => p.day > this.s.day - 30 && p.ids.some(id => e.members.some(a => a.id === id))).length;
        return clamp(.04 + stress * .002 + Math.max(0, 50 - energy) * .003 + Math.max(0, recent - 3) * .02 -(this.has('manager') ? .04: 0), .02, .4);
      }
      startIncident(kind, key) {
        let e = this.entity(key),
        s = this.s;
        if (!e || !incidents[kind]) throw Error('사건 대상과 종류를 확인하세요.');
        if (s.incidents.some(i => i.state !== 'closed') || s.day - s.lastIncidentDay < 90) throw Error('진행 중인 사건 또는 재발 제한 기간입니다.');
        let cancelled = kind === 'cancel' ? s.jobs.find(j => j.kind === 'live' && j.entity === key): null;
        if (kind === 'cancel' && !cancelled) throw Error('취소할 진행 중 공연이 없습니다.');
        if (cancelled) s.jobs = s.jobs.filter(j => j !== cancelled);
        let risk = this.incidentRisk(e),
        severity = risk > .25 ? 3: risk > .12 ? 2: 1,
        rate = [0, .01, .03, .06][severity],
        imageLoss = severity * 4,
        losses = e.members.map(a =>({ id: a.id, lost: Math.floor(a.fans * rate) }));
        for (const x of losses) {
          let a = this.artist(x.id);
          a.fans -= x.lost;
        }
        const unit = s.units.find(u => u.key === key);
        let teamLost = unit ? Math.floor(unit.fans * rate): 0;
        if (unit) unit.fans -= teamLost;
        s.image = clamp(s.image - imageLoss, 0, 100);
        s.reputation = clamp(s.reputation - severity, 0, 100);
        let i = {
          id: this.id(),
          kind,
          key,
          name: e.name,
          day: s.day,
          expires: s.day + 7,
          severity,
          state: 'open',
          choice: null,
          responseDue: null,
          losses,
          teamLost,
          imageLoss,
          recovered: 0
        };
        s.incidents.unshift(i);
        s.incidents = s.incidents.slice(0, 80);
        s.lastIncidentDay = s.day;
        this.report(incidents[kind].title, e.name + ' · ' + incidents[kind].body + '\n팬 ' + losses.reduce((n, x) => n + x.lost, 0) + '명 이탈 / 회사 이미지 -' + imageLoss + '\n7일 안에 대응을 결정하세요.', 'info', true, { incidentId: i.id });
        this.log(incidents[kind].title + ' · ' + e.name);
        return i;
      }
      respondIncident(id, choice) {
        let i = this.s.incidents.find(i => i.id === Number(id));
        if (!i || i.state !== 'open') throw Error('이미 대응했거나 종료된 사건입니다.');
        if (!['explain', 'repair', 'investigate', 'ignore'].includes(choice)) throw Error('대응을 선택하세요.');
        let cost = {
          explain: 100,
          repair: 300,
          investigate: 50,
          ignore: 0
        }
        [choice] * i.severity;
        if (cost) this.spend(cost, '사건 대응: ' + incidents[i.kind].title);
        i.choice = choice;
        if (choice === 'investigate') {
          i.state = 'investigating';
          i.responseDue = this.s.day + 3;
          this.log('사건 조사 시작 · 3일 후 결과');
          return;
        }
        this.closeIncident(i, choice);
      }
      closeIncident(i, choice) {
        if (i.state === 'closed') return;
        i.choice = choice;
        i.state = 'closed';
        let ratio = choice === 'repair' ? .5: choice === 'explain' ? .2: choice === 'investigate' ? .3: 0;
        for (const x of i.losses) {
          let a = this.artist(x.id);
          if (a) {
            let gain = Math.floor(x.lost * ratio);
            a.fans += gain;
            i.recovered += gain;
          }
        }
        let u = this.s.units.find(u => u.key === i.key);
        if (u) u.fans += Math.floor(i.teamLost * ratio);
        this.s.image = clamp(this.s.image +(choice === 'repair' ? 2 * i.severity: choice === 'explain' ? i.severity: choice === 'investigate' ? i.severity: - 3 * i.severity), 0, 100);
        if (choice === 'ignore') {
          for (const x of i.losses) {
            let a = this.artist(x.id);
            if (a) a.fans = Math.floor(a.fans * .99);
          }
        }
        let r = this.s.reports.find(r => r.incidentId === i.id);
        if (r) {
          r.resolved = true;
          r.read = true;
          r.body += '\n대응 완료 · ' +({
            repair: '보완 행사',
            explain: '공식 설명',
            investigate: '조사·결과 공개',
            ignore: '미대응'
          }
          [choice]) + ' / 팬 회복 ' + i.recovered + '명';
        }
        this.log('사건 대응 종료 · ' + incidents[i.kind].title);
        this.report('사건 대응 결과', i.name + ' · ' +({
          repair: '보완 행사를 진행했습니다.',
          explain: '공식 설명과 안내를 제공했습니다.',
          investigate: '조사를 마치고 결과를 공개했습니다.',
          ignore: '기한 내 대응하지 않아 추가 불만이 발생했습니다.'
        }
        [choice]) + ' 팬 회복 ' + i.recovered + '명. 사건으로 생긴 피해가 모두 복구되지는 않습니다.', 'info', false);
      }
      tickIncidents() {
        for (const i of this.s.incidents) {
          if (i.state === 'open' && this.s.day > i.expires) this.closeIncident(i, 'ignore');
          if (i.state === 'investigating' && this.s.day >= i.responseDue) this.closeIncident(i, 'investigate');
        }
        if (this.s.day % 30 !== 0) return;
        if (!this.s.incidents.some(i => i.state !== 'closed') && this.s.day - this.s.lastIncidentDay >= 90) {
          if (this.s.image < 80) this.s.image = Math.min(80, this.s.image + 1);
          if (this.s.day >= 60) {
            let pool = this.entities.filter(e => this.s.jobs.some(j => j.entity === e.key && j.kind === 'live') || this.s.performance.some(p => p.day > this.s.day - 30 && p.ids.some(id => e.members.some(a => a.id === id))));
            if (pool.length) {
              let e = pool[Math.floor(this.rng() * pool.length)];
              if (this.rng() < this.incidentRisk(e)) {
                let stress = e.members.reduce((n, a) => n + a.stress, 0) / e.members.length;
                this.startIncident(this.s.jobs.some(j => j.kind === 'live' && j.entity === e.key) && stress > 70 ? 'cancel': stress > 65 ? 'overwork': this.rng() < .5 ? 'sound': 'notice', e.key);
              }
            }
          }
        }
      }
      depart(id, reason, rivalId = null) {
        let a = this.artist(id);
        super.depart(id, reason, rivalId);
        if (a) {
          for (const r of this.s.rivals) if (r.artists.includes(a.id) && !r.talents.some(t => t.id === a.id)) {
            let t = this.rivalTalent(a.id);
            t.active = true;
            t.skill = a.stats.reduce((n, v) => n + v, 0) / 8;
            r.talents.push(t);
          }
        }
      }
      rivalTalent(id) {
        return {
          id,
          skill: D.roster[id].stats.reduce((n, x) => n + x, 0) / 8,
          energy: 90,
          trust: 70,
          contract: this.s.day + 730,
          active: !D.roster[id].trainee
        };
      }
      rivalsMonth() {
        for (const r of this.s.rivals) {
          let income = 0,
          expense = 0,
          overhead = 250 + r.artists.length * 70;
          const spend = n => {
            if (r.cash < n) return false;
            r.cash -= n;
            expense += n;
            return true;
          };
          let take =(n) => {
            r.cash += n;
            income += n;
          };
          if (r.image < 90) r.image = clamp(r.image + 1, 0, 90);
          if (r.cash < overhead && r.debt < 10000) {
            let loan = Math.min(3000, 10000 - r.debt);
            r.cash += loan;
            r.debt += loan;
          }
          if (!spend(overhead)) {
            spend(Math.max(0, r.cash));
            r.reputation = Math.max(0, r.reputation - 3);
            if (r.artists.length) {
              let id = r.artists.pop();
              r.talents = r.talents.filter(t => t.id !== id);
              this.news(r.name + ' · 재정난으로 ' + D.roster[id].name + ' 계약 종료');
            }
          }
          if (r.debt && r.cash > overhead * 4) {
            let payment = Math.min(r.debt, 250);
            r.cash -= payment;
            r.debt -= payment;
          }
          for (const t of[... r.talents]) {
            t.energy = clamp(t.energy + 15, 0, 100);
            if (t.contract - this.s.day <= 90) {
              let fee = 200 + t.skill * 5;
              if (r.cash > fee + overhead * 2) {
                spend(fee);
                t.contract += 730;
                t.trust = clamp(t.trust + 5, 0, 100);
              } else if (t.contract <= this.s.day) {
                r.artists = r.artists.filter(id => id !== t.id);
                r.talents = r.talents.filter(x => x !== t);
                this.news(r.name + ' · ' + D.roster[t.id].name + ' 자유계약 전환');
              }
            }
          }
          let active = r.talents.filter(t => t.active),
          trainees = r.talents.filter(t => !t.active),
          action = '휴식·현금 확보',
          chance = this.rng();
          if (r.cash < overhead * 3) {
            action = '긴축 운영';
            for (const t of r.talents) t.energy = clamp(t.energy + 15, 0, 100);
          } else if (trainees.length &&(chance < .35 || !active.length)) {
            if (spend(150 * trainees.length)) {
              action = '연습생 집중 육성';
              for (const t of trainees) {
                t.skill = Math.min(90, t.skill + 1.5 + this.rng());
                if (t.skill >= 58 && spend(200)) {
                  t.active = true;
                  action = '신인 데뷔';
                  this.news(r.name + ' · ' + D.roster[t.id].name + ' 데뷔');
                }
              }
            }
          } else if (active.length &&((r.type === 'band' && chance < .75) || chance < .3)) {
            if (spend(600)) {
              let quality = active.reduce((n, t) => n + t.skill, 0) / active.length,
              attendance = Math.min(700, Math.floor(r.fans * .12 + quality * 2));
              take(attendance * 8);
              spend(Math.min(r.cash, attendance * .8));
              r.fans += Math.floor(attendance * .12 /(1 + r.fans / 30000));
              r.reputation = clamp(r.reputation + 1, 0, 100);
              active.forEach(t => t.energy = Math.max(0, t.energy - 15));
              action = '공연 중심 활동';
            }
          } else if (active.length &&(r.type === 'rap' ? chance < .9: chance < .8)) {
            let budget = r.type === 'rap' ? 1800: 2500;
            if (spend(budget)) {
              let quality = clamp(active.reduce((n, t) => n + t.skill, 0) / active.length + this.rng() * 15, 20, 95);
              r.catalog.push({ name: '신작 ' +(++ r.serial), quality, age: 0 });
              r.catalog = r.catalog.slice(- 240);
              r.fans += Math.floor(quality * 5 / Math.sqrt(1 + r.fans / 30000));
              r.reputation = clamp(r.reputation + quality / 50, 0, 100);
              action = '신작 제작·발매';
            }
          } else if (spend(200)) {
            action = '팬 소통·홍보';
            r.fans += Math.floor(100 / Math.sqrt(1 + r.fans / 10000));
            r.image = clamp(r.image + 2, 0, 100);
          }
          if (r.talents.some(t => t.energy < 35)) {
            r.talents.forEach(t => t.energy = clamp(t.energy + 20, 0, 100));
            action += '·컨디션 회복';
          }
          if (r.cash > overhead * 6 && r.artists.length < 6 && this.rng() < .18) {
            let pool = D.roster.filter(a => this.available(a.id) && !this.s.candidates.some(c => c.id === a.id) &&(r.type === 'any' || a.type === r.type));
            if (pool.length && spend(200)) {
              let a = pool[Math.floor(this.rng() * pool.length)];
              r.artists.push(a.id);
              r.talents.push(this.rivalTalent(a.id));
              this.news(r.name + ' · ' + a.name + ' 영입');
              action += '·영입';
            }
          }
          if (r.talents.length && this.rng() < .06) {
            r.fans = Math.floor(r.fans * .98);
            r.image = Math.max(0, r.image - 5);
            action += '·운영 사고';
          }
          r.lastAction = action;
          let bin = r.accounts.at(- 1);
          if (bin && bin.day === this.s.day) {
            bin.revenue += income;
            bin.expense += expense;
          } else r.accounts.push({ day: this.s.day, revenue: income, expense });
          r.accounts = r.accounts.filter(b => b.day > this.s.day - 365);
          let profit = r.accounts.reduce((n, b) => n + b.revenue - b.expense, 0);
          r.value = Math.max(0, r.cash - r.debt + Math.max(0, profit * 4) *(.7 + r.image / 200));
          r.level = r.value >= 3000000 ? 5: r.value >= 700000 ? 4: r.value >= 150000 ? 3: r.value >= 30000 ? 2: 1;
          this.news(r.name + ' · ' + action);
        }
      }
      advanceIncidents() {
        let result = this.advanceManagement();
        this.tickIncidents();
        return this.pending.length;
      }
    }
    ProgressionGame.trainingPlans = plans;
    ProgressionGame.incidentTypes = incidents;
    return ProgressionGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installProgression = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/market.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const clamp =(v, a, b) => Math.max(a, Math.min(b, v)),
    money = v => Math.round(v * 100) / 100;
    class MarketGame extends Base {
      upgrade() {
        super.upgrade();
        let s = this.s;
        if (!s || s.marketVersion === 1) return;
        s.marketVersion = 1;
        s.lastReputation = s.reputation;
        s.reputationReason = '판매·공연 성과 기록을 수집하고 있습니다.';
        for (const c of s.catalog) this.initRelease(c, { owner: 'player', legacy: true, snapshot: { name: c.ownerName || this.entity(c.entity)?.name || '이전 발매작', type: this.entity(c.entity)?.type || this.s.teamArchive.find(u => u.key === c.entity)?.type || D.roster[Number(c.entity)]?.type || 'idol', ids:(c.shares ||[]).map(x => x.id) } });
        for (const r of s.rivals) for (const[index, c] of r.catalog.entries()) this.initRelease(c, {
          owner: 'r' + r.id,
          legacy: true,
          uid: 'r' + r.id + '-old-' + index,
          snapshot: { name: r.name + ' 프로젝트팀', type: r.type === 'any' ? 'idol': r.type, ids:[] }
        });
        for (const p of s.performance) {
          p.hit = false;
          p.reach = 0;
        }
        for (const j of s.jobs) if (j.kind === 'single' && !j.releaseOptions) {
          j.releaseOptions = { format: 'digital', quantity: 0 };
          j.manufacturing = 0;
        }
      }
      initRelease(c, { owner = 'player', legacy = false, uid = null, options = {}, snapshot = null, budget = 0, fame = 0 } = {}) {
        if (c.market) return;
        c.market = {
          uid: uid || 'p-' + c.id,
          owner,
          startDay: legacy ? Math.max(0, this.s.day - Math.max(1, c.age) + 1): this.s.day,
          measuredFrom: legacy ? this.s.day + 1: this.s.day,
          lastDay: legacy ? this.s.day: this.s.day - 1,
          legacy,
          format: options.format || 'digital',
          price: 2.5,
          unitCost: .6,
          stock: options.quantity || 0,
          manufactured: options.quantity || 0,
          manufacturing: money((options.quantity || 0) * .6),
          production: budget,
          fame,
          fanBase: c.fanBase || 0,
          appeal: legacy ? 1: clamp((.4 + c.quality * .006) *(.75 + this.rng() * .5), .3, 1.5),
          discovery: legacy ? 1: this.rng() < .18 ? 1.7: 1,
          streams: 0,
          sales: 0,
          firstWeekSales: legacy ? null: 0,
          gross: 0,
          distribution: 0,
          receipts: 0,
          paid: 0,
          payout: 0,
          pending: 0,
          streamGross: 0,
          physicalGross: 0,
          streamReceipts: 0,
          physicalReceipts: 0,
          pendingStream: 0,
          pendingPhysical: 0,
          paidStream: 0,
          paidPhysical: 0,
          payoutStream: 0,
          payoutPhysical: 0,
          pendingDays: 0,
          days:[],
          weeks:[],
          hit: false,
          ids:[...(snapshot?.ids ||[])],
          type: snapshot?.type || 'idol',
          artistName: snapshot?.name || c.ownerName || '이전 발매작'
        };
      }
      startProject(key, kind, title, budget, concept, options = {}) {
        if (!options || typeof options !== 'object') throw Error('발매 설정을 확인하세요.');
        const format = options.format || 'digital',
        quantity = format === 'physical' ? Number(options.quantity): 0;
        if (!['digital', 'physical'].includes(format) || format === 'physical' &&(kind !== 'single' || ![1000, 3000, 10000].includes(quantity))) throw Error('실물 싱글은 초도 1,000/3,000/10,000장 중 선택하세요.');
        let manufacturing = quantity * .6;
        if (this.s.cash < Number(budget) + manufacturing -(this._affordabilityDiscount || 0)) throw Error('제작비와 실물 음반 제조비를 합친 자금이 부족합니다.');
        super.startProject(key, kind, title, budget, concept);
        let j = this.s.jobs.at(- 1);
        if (kind === 'single') {
          j.releaseOptions = { format, quantity };
          j.manufacturing = manufacturing;
          if (manufacturing) this.spend(manufacturing, '음반 초도 제조: ' + j.name);
        }
      }
      reprint(id, quantity) {
        let c = this.s.catalog.find(c => c.id === Number(id)),
        n = Number(quantity);
        if (!c || c.market.format !== 'physical' || ![1000, 3000, 10000].includes(n) || c.market.stock + n > 100000) throw Error('재제작할 작품과 수량을 확인하세요.');
        this.spend(n * .6, '음반 추가 제조: ' + c.name);
        c.market.stock += n;
        c.market.manufactured += n;
        c.market.manufacturing = money(c.market.manufacturing + n * .6);
      }
      newFans(e, j, quality, fan) {
        if (j.kind === 'single') {
          this._fanGain = Math.floor(Math.max(0, quality - 25) * .5 / Math.sqrt(1 + fan / 10000));
          return this._fanGain;
        }
        return super.newFans(e, j, quality, fan);
      }
      exposure(e, reach, scale) {
        let gain = Math.log10(1 + Math.max(0, reach)) * scale;
        let u = this.s.units.find(u => u.key === e.key);
        if (u) u.fame = clamp(u.fame + gain *(1 - u.fame / 110), 0, 100);
        for (const a of e.members) a.fame = clamp(a.fame + gain *(1 - a.fame / 110) *(u ? .35: 1), 0, 100);
      }
      finishMarket(j) {
        let e = j.kind === 'casting' ? null: this.projectEntity(j),
        fames = e?.members.map(a =>[a, a.fame]) ||[],
        u = e ? this.s.units.find(u => u.key === e.key): null,
        ufame = u?.fame,
        rep = this.s.reputation,
        count = this.s.catalog.length;
        this.finishProgression(j);
        if (!e) return;
        for (const[a, fame] of fames) a.fame = fame;
        if (u) u.fame = ufame;
        this.s.reputation = rep;
        if (j.kind === 'single') {
          let c = this.s.catalog[count];
          this.initRelease(c, {
            options: j.releaseOptions || {},
            snapshot: j.snapshot || this.snapshot(j.entity),
            budget: j.budget,
            fame: fames.reduce((n, x) => n + x[1], 0) / fames.length
          });
          let p = this.s.performance.at(- 1);
          if (p) {
            p.hit = false;
            p.reach = 0;
          }
        } else if (j.kind === 'live') {
          this.exposure(e, j.concert.attendance, .25);
          let p = this.s.performance.at(- 1);
          if (p) {
            p.reach = j.concert.attendance;
            p.hit = j.concert.attendance >= 500 && j.concert.attendance / j.concert.capacity >= .7 && this.s.settlements[0].net > 0;
          }
        } else if (j.kind === 'cover') {
          let reach = Math.round((this._lastQuality * 40 + e.members.reduce((n, a) => n + a.fans, 0) * .5) * this.imageFactor());
          this.exposure(e, reach, .12);
          let p = this.s.performance.at(- 1);
          if (p) {
            p.reach = reach;
            p.hit = false;
          }
        } else if (j.kind === 'ad') this.exposure(e, (j.pay || 0) * 100, .12);
      }
      releaseDay(c, owner) {
        let m = c.market;
        if (m.lastDay >= this.s.day) return null;
        let age = Math.max(0, this.s.day - m.startDay),
        tail = Math.exp(- age / (55 * (c.albumType ? root.ActivityData.albums[c.albumType].tail : 1))),
        buzz = age >= 14 && age <= 70 ? m.discovery: 1,
        base = (3000 + c.quality * 100 + Math.min(300000, m.fanBase) * 16 + m.fame * 2000) * (c.albumType ? root.ActivityData.albums[c.albumType].reach : 1);
        let image = owner === 'player' ? this.imageFactor(): clamp(.6 + owner.image / 150, .6, 1.25),
        promo = owner === 'player' && this.has('promo') ? 1 + this.staffPower('promo') * .2: 1;
        let streams = Math.max(0, Math.floor(base * m.appeal *(tail * buzz + .025 /(1 + age / 180)) * image * promo *(c.concept === 'public' ? 1.15: 1)));
        let demand = m.format === 'physical' ? Math.max(0, Math.floor((m.fanBase * .5 + m.fame * 5 + c.quality * 2) * Math.exp(- age / 4) / 4 + m.fanBase * .0002 * tail)): 0,
        sales = Math.min(m.stock, demand);
        m.stock -= sales;
        m.sales += sales;
        m.streams += streams;
        if (m.firstWeekSales !== null && age < 7) m.firstWeekSales += sales;
        let sg = money(streams * .0006),
        pg = money(sales * m.price),
        sr = money(sg - money(sg * .15)),
        pr = money(pg - money(pg * .25)),
        gross = money(sg + pg),
        receipts = money(sr + pr),
        distribution = money(gross - receipts);
        m.streamGross = money(m.streamGross + sg);
        m.physicalGross = money(m.physicalGross + pg);
        m.streamReceipts = money(m.streamReceipts + sr);
        m.physicalReceipts = money(m.physicalReceipts + pr);
        m.pendingStream = money(m.pendingStream + sr);
        m.pendingPhysical = money(m.pendingPhysical + pr);
        m.gross = money(m.gross + gross);
        m.distribution = money(m.distribution + distribution);
        m.receipts = money(m.receipts + receipts);
        m.pending = money(m.pending + receipts);
        m.pendingDays++;
        m.lastDay = this.s.day;
        c.age++;
        m.days.push({ day: this.s.day, streams, sales });
        m.days = m.days.slice(- 28);
        let week = Math.floor(age / 7),
        bin = m.weeks.at(- 1);
        if (!bin || bin.week !== week) {
          bin = { week, streams: 0, sales: 0 };
          m.weeks.push(bin);
          m.weeks = m.weeks.slice(- 104);
        }
        bin.streams += streams;
        bin.sales += sales;
        if (m.pendingDays >= 7) {
          let pay = m.pending,
          payout = 0;
          if (owner === 'player') {
            payout =(c.shares ||[]).reduce((n, x) => n + money(pay * x.rate), 0);
            this.receive(pay, '음원·음반 정산: ' + c.name, c.shares ||[], c.entity, 'stream_settlement');
          } else {
            payout = money(pay * .35);
            owner.cash = money(owner.cash + pay - payout);
            let b = owner.accounts.at(- 1);
            if (!b || b.day !== this.s.day) {
              b = { day: this.s.day, revenue: 0, expense: 0 };
              owner.accounts.push(b);
            }
            b.revenue = money(b.revenue + pay);
            b.expense = money(b.expense + payout);
            owner.accounts = owner.accounts.filter(b => b.day > this.s.day - 365);
          }
          let streamPayout = pay ? money(payout * m.pendingStream / pay): 0;
          m.paidStream = money(m.paidStream + m.pendingStream);
          m.paidPhysical = money(m.paidPhysical + m.pendingPhysical);
          m.payoutStream = money(m.payoutStream + streamPayout);
          m.payoutPhysical = money(m.payoutPhysical + money(payout - streamPayout));
          m.pendingStream = 0;
          m.pendingPhysical = 0;
          m.paid = money(m.paid + pay);
          m.payout = money(m.payout + payout);
          c.revenue = money((c.revenue || 0) + pay);
          m.pending = 0;
          m.pendingDays = 0;
        }
        return { streams, sales };
      }
      weekStats(c) {
        return c.market.days.filter(d => d.day > this.s.day - 7).reduce((a, d) =>({ streams: a.streams + d.streams, sales: a.sales + d.sales }), { streams: 0, sales: 0 });
      }
      tickCatalog() {
        let exposure = new Map();
        for (const c of this.s.catalog) {
          let result = this.releaseDay(c, 'player');
          if (!result) continue;
          let m = c.market,
          e = this.entity(c.entity);
          if (e) {
            exposure.set(c.entity, (exposure.get(c.entity) || 0) + result.streams);
            let totalFans = e.members.reduce((n, a) => n + a.fans, 0),
            fans = Math.floor(result.streams * .0002 / Math.sqrt(1 + totalFans / 5000));
            for (const a of e.members) a.fans += Math.floor(fans / e.members.length);
            let u = this.s.units.find(u => u.key === e.key);
            if (u) u.fans += fans;
          }
          let week = this.weekStats(c);
          if (!m.hit &&(week.streams >= 300000 || m.firstWeekSales >= 500)) {
            m.hit = true;
            let p = this.s.performance.find(p => p.kind === 'single' && p.key === c.entity && p.releaseId === c.id);
            if (!p) {
              p = this.s.performance.find(p => p.kind === 'single' && p.key === c.entity && p.day === m.startDay && !p.releaseId);
              if (p) p.releaseId = c.id;
            }
            if (p) {
              p.hit = true;
              p.reach = week.streams;
              p.day = this.s.day;
            } else this.s.performance.push({
              day: this.s.day,
              key: c.entity,
              ids: m.ids.length ? m.ids:(e?.members.map(a => a.id) ||[]),
              kind: 'single',
              quality: c.quality,
              hit: true,
              reach: week.streams,
              releaseId: c.id
            });
          }
        }
        for (const[key, reach] of exposure) {
          let e = this.entity(key);
          if (e) this.exposure(e, reach, .02);
        }
        for (const r of this.s.rivals) for (const c of r.catalog) {
          if (!c.market) this.initRelease(c, {
            owner: 'r' + r.id,
            uid: 'r' + r.id + '-' + r.serial,
            snapshot: { name: r.name, type: r.type === 'any' ? 'idol': r.type, ids: r.artists },
            fame: r.reputation
          });
          let result = this.releaseDay(c, r);
          if (result) r.fans += Math.floor(result.streams * .0001 / Math.sqrt(1 + r.fans / 10000));
        }
      }
      rivalsMonth() {
        let known = new Set(this.s.rivals.flatMap(r => r.catalog.map(c => c)));
        super.rivalsMonth();
        for (const r of this.s.rivals) for (const c of r.catalog) if (!known.has(c)) {
          c.fanBase = r.fans;
          c.concept = 'balanced';
          c.revenue = 0;
          let physical = r.type === 'idol' && r.cash > 3000,
          quantity = physical ? 1000: 0,
          cost = quantity * .6;
          if (cost) {
            r.cash -= cost;
            let b = r.accounts.at(- 1);
            b.expense += cost;
          }
          let active = r.talents.filter(t => t.active).map(t => t.id).slice(0, 5),
          ids = r.type === 'rap' ? active.slice(0, 1): active;
          this.initRelease(c, {
            owner: 'r' + r.id,
            uid: 'r' + r.id + '-' + r.serial,
            options: { format: physical ? 'physical': 'digital', quantity },
            snapshot: { name: ids.length === 1 ? D.roster[ids[0]].name: r.name + ' 프로젝트팀', type: r.type === 'any' ?(ids.length ? D.roster[ids[0]].type: 'idol'): r.type, ids },
            budget: r.type === 'rap' ? 1800: 2500,
            fame: r.reputation
          });
        }
      }
      entityRecord(key) {
        let e = this.entity(key);
        if (!e) return null;
        return {
          key,
          name: e.name,
          fame: this.s.units.find(u => u.key === key)?.fame ?? e.members[0].fame,
          fans: this.s.units.find(u => u.key === key)?.fans ?? e.members[0].fans,
          events: this.s.performance.filter(p => p.key === key && p.day > this.s.day - 365)
        };
      }
      grade(record) {
        let hits = record.events.filter(p => p.hit === true).length;
        return record.fame >= 85 && record.fans >= 50000 && hits >= 4 ? 4: record.fame >= 70 && record.fans >= 10000 && hits >= 2 ? 3: record.fame >= 40 && record.events.length >= 2 ? 2: record.fame >= 15 ? 1: 0;
      }
      updateStars() {
        for (const a of this.s.artists) {
          if (this.s.day - a.lastActive > 30) {
            a.fame = Math.max(0, a.fame - 1);
            a.fans = Math.floor(a.fans * .99);
          }
          if (this.s.day - a.lastActive > 90) {
            a.trust = Math.max(0, a.trust - 2);
            if (a.trust < 50 && !a.concernSent) {
              a.concernSent = true;
              this.report('활동 계획 면담 요청', D.roster[a.id].name + '이 새로운 활동 계획을 요청합니다.', 'event', true, { entity: String(a.id) });
            }
          } else a.concernSent = false;
        }
        for (const u of this.s.units) if (!this.s.performance.some(p => p.key === u.key && p.day > this.s.day - 60)) {
          u.fame = Math.max(0, u.fame - 1);
          u.fans = Math.floor(u.fans * .99);
        }
        for (const a of this.s.artists) {
          let rec = { fame: a.fame, fans: a.fans, events: this.s.performance.filter(p => p.key === String(a.id) && p.day > this.s.day - 365) },
          level = this.grade(rec);
          a.marketStarSince = level >= 3 ?(a.marketStarSince ?? this.s.day): null;
          if (level >= 3 && this.s.day - a.marketStarSince < 180) level = 2;
          a.star = level;
          a.bestStar = Math.max(a.bestStar || 0, level);
        }
        for (const u of this.s.units) {
          let level = this.grade(this.entityRecord(u.key));
          u.marketStarSince = level >= 3 ?(u.marketStarSince ?? this.s.day): null;
          if (level >= 3 && this.s.day - u.marketStarSince < 180) level = 2;
          u.star = level;
          u.bestStar = Math.max(u.bestStar || 0, level);
        }
        let streams = this.s.catalog.reduce((n, c) => n + c.market.days.filter(d => d.day > this.s.day - 28).reduce((v, d) => v + d.streams, 0), 0),
        sales = this.s.catalog.reduce((n, c) => n + c.market.days.filter(d => d.day > this.s.day - 28).reduce((v, d) => v + d.sales, 0), 0),
        hits = this.s.performance.filter(p => p.hit && p.day > this.s.day - 365).length,
        target = clamp(Math.log10(1 + streams) * 5 + Math.log10(1 + sales) * 4 + Math.sqrt(hits) * 4, 0, 100),
        old = this.s.reputation;
        this.s.reputation = clamp(old + clamp(target - old, - 2, 3), 0, 100);
        this.s.reputationReason = '최근' + ' 28일 재생 ' + streams.toLocaleString() + '회·판매 ' + sales.toLocaleString() + '장 / 최근 1년 흥행 ' + hits + '회';
        this.s.lastReputation = old;
      }
      startIncident(kind, key) {
        let incident = super.startIncident(kind, key);
        this.syncStarEligibility();
        return incident;
      }
      closeIncident(incident, choice) {
        super.closeIncident(incident, choice);
        this.syncStarEligibility();
      }
      syncStarEligibility() {
        for (const a of this.s.artists) {
          let r = { fame: a.fame, fans: a.fans, events: this.s.performance.filter(p => p.key === String(a.id) && p.day > this.s.day - 365) };
          a.marketStarSince = this.grade(r) >= 3 ?(a.marketStarSince ?? this.s.day): null;
        }
        for (const u of this.s.units) u.marketStarSince = this.grade(this.entityRecord(u.key)) >= 3 ?(u.marketStarSince ?? this.s.day): null;
      }
      advanceMarket() {
        let result = this.advanceIncidents();
        this.syncStarEligibility();
        return result;
      }
      charts(metric = 'streams') {
        if (!['streams', 'sales'].includes(metric)) throw Error('차트 종류를 확인하세요.');
        return this.allReleases().map(row =>({ ... row, week: this.weekStats(row.release) })).filter(row => row.week[metric] > 0).sort((a, b) => b.week[metric] - a.week[metric] || a.release.market.uid.localeCompare(b.release.market.uid));
      }
      allReleases() {
        return [... this.s.catalog.map(c =>({ release: c, company: this.s.company, own: true })), ... this.s.rivals.flatMap(r => r.catalog.map(c =>({ release: c, company: r.name, own: false })))];
      }
    }
    return MarketGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installMarket = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/day-feedback.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const round = n => Math.round(n * 100) / 100;
    class FeedbackGame extends Base {
      upgrade() {
        super.upgrade();
        if (!this.s || this.s.feedbackVersion === 1) return;
        this.s.feedbackVersion = 1;
        this.s.daySummaries = [];
      }
      advanceSummary() {
        let s = this.s,
        fromDay = s.day,
        cash = s.cash,
        streams = s.catalog.reduce((n, c) => n + c.market.streams, 0),
        sales = s.catalog.reduce((n, c) => n + c.market.sales, 0),
        fans = s.artists.reduce((n, a) => n + a.fans, 0),
        teamFans = s.units.reduce((n, u) => n + u.fans, 0),
        beforeIds = s.artists.map(a => a.id),
        reports = new Set(s.reports.map(r => r.id)),
        due = s.jobs.filter(j => j.due <= s.day + 1).map(j =>({ kind: j.kind, title: j.name }));
        let result = this.advanceOperations();
        let training = new Set(s.ledger.filter(l => l.day === s.day && l.kind === 'training').map(l => l.label));
        let summary = {
          fromDay,
          day: s.day,
          cashChange: round(s.cash - cash),
          streams: s.catalog.reduce((n, c) => n + c.market.streams, 0) - streams,
          sales: s.catalog.reduce((n, c) => n + c.market.sales, 0) - sales,
          fansChange: s.artists.reduce((n, a) => n + a.fans, 0) - fans,
          teamFansChange: s.units.reduce((n, u) => n + u.fans, 0) - teamFans,
          trainingCount: training.size,
          completed: due,
          newReports: s.reports.filter(r => !reports.has(r.id)).length,
          departed: beforeIds.filter(id => !s.artists.some(a => a.id === id))
        };
        s.daySummaries.push(summary);
        s.daySummaries = s.daySummaries.slice(- 30);
        return this.pending.length;
      }
    }
    return FeedbackGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installDayFeedback = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/personality.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const clamp =(x, a, b) => Math.max(a, Math.min(b, x));
    class PersonalityGame extends Base {
      personality(id) {
        return D.roster[id].personality;
      }
      talent(id) {
        return this.artist(id) || this.s.trainees.find(a => a.id === Number(id));
      }
      trainingReaction(id) {
        const a = this.talent(id),
        p = this.personality(id);
        if (!a) return p.intro;
        if (a.energy < 30 || a.stress > 80) return '오늘은 잠깐 쉬고 싶어요. 컨디션을 되찾고 다시 해볼게요.';
        const plan = D.roster[id].trainee && this.s.trainees.includes(a) ? a.trainingPlan: a.focus;
        return plan === 'rest' ? '쉬는 동안 다음 활동을 차분히 준비하고 있어요.': plan === p.training ? p.reaction: '기본기를 쌓으면서 제 색깔도 찾아가고 싶어요.';
      }
      sign(id, offer) {
        super.sign(id, offer);
        const d = D.roster[Number(id)];
        this.s.reports[0].body += '\n' + d.name + ': “' + d.personality.intro + '”';
      }
      renewalCost(a, offer = 'balanced') {
        return Math.round(super.renewalCost(a, offer) *(offer === this.personality(a.id).offer ? .95: 1));
      }
      trainTrainees() {
        const before = new Map(this.s.trainees.map(a =>[a.id, [... a.stats]]));
        super.trainTrainees();
        for (const a of this.s.trainees) {
          const p = this.personality(a.id),
          old = before.get(a.id);
          if (!old || a.trainingPlan !== p.training) continue;
          a.stats = a.stats.map((v, i) => v > old[i] ? Math.min(this.profile(a.id).potential, v +(v - old[i]) * .08): v);
        }
      }
      personalSession(id, choice) {
        id = Number(id);
        const a = this.talent(id),
        p = D.roster[id]?.personality;
        if (!a || !p || !['creative', 'stage', 'rest'].includes(choice)) throw Error('소속 인물과 상담 방식을 확인하세요.');
        if (a.lastPersonalDay !== undefined && this.s.day - a.lastPersonalDay < 30) throw Error('개인 상담은 인물별 30일에 한 번 가능합니다.');
        if (choice !== 'rest' && this.busy(String(id))) throw Error('확정 활동 중에는 추가 워크숍을 진행할 수 없습니다. 휴식 상담을 이용하세요.');
        if (choice !== 'rest') this.spend(100, '개인 상담·워크숍: ' + D.roster[id].name);
        const trust = choice === p.session ? 5: 2;
        a.trust = clamp(a.trust + trust, 0, 100);
        a.stress = clamp(a.stress -(choice === 'rest' ? 8: 3), 0, 100);
        if (choice === 'rest') a.energy = clamp(a.energy + 10, 0, 100);
        else {
          const idx = choice === 'creative' ? 4: 5,
          cap = this.s.trainees.includes(a) ? this.profile(id).potential: 99;
          if (a.stats[idx] < cap) a.stats[idx] = Math.min(cap, a.stats[idx] + .4);
        }
        a.lastPersonalDay = this.s.day;
        const reply = choice === p.session ? p.reaction: '제 이야기를 들어주셔서 고마워요. 함께 방향을 맞춰 볼게요.';
        this.report(D.roster[id].name + ' · 개인 상담', reply + '\n신뢰 +' + trust + ' · ' +(choice === 'rest' ? '체력 +10 · 스트레스 -8': '스트레스 -3 · ' +(choice === 'creative' ? '창작': '무대') + ' 능력 +0.4 (성장 한계 이내)'), 'info');
        this.log(D.roster[id].name + ' 개인 상담 완료');
        return reply;
      }
    }
    return PersonalityGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installPersonality = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/operations.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const clamp =(n, a, b) => Math.max(a, Math.min(b, n)),
    round = x => Math.round(x * 100) / 100;
    class OperationsGame extends Base {
      upgrade() {
        super.upgrade();
        const s = this.s;
        if (!s || s.operationsVersion === 1) return;
        s.operationsVersion = 1;
        s.operationsSince = s.day;
        s.staffMarketSeed =(s.seed ^ 0x51a7) >>> 0;
        s.receivables = [];
        for (const a of[... s.trainees, ... s.artists, ... s.departed]) this.initOperationsTalent(a);
      }
      initOperationsTalent(a) {
        if (!a.trainingMode) a.trainingMode = 'auto';
        if (!a.trainingGoal) a.trainingGoal = 'balanced';
        if (!a.growthHistory) a.growthHistory = [{ day: this.s.day, stats:[... a.stats], reason: '기록 시작' }];
        if (!Number.isInteger(a.recoveryUntil)) a.recoveryUntil = 0;
      }
      has(id) {
        if (D.staffKinds[id]) return this.s.staff.some(sid => D.staff.find(p => p.id === sid)?.kind === id);
        return this.s.staff.includes(id);
      }
      staffPower(kind) {
        return Math.max(0, ... this.s.staff.map(id => D.staff.find(p => p.id === id)).filter(p => p.kind === kind).map(p => p.coaching / 100));
      }
      get traineeCapacity() {
        return D.roster.length;
      }
      buildStaffBoard() {
        let seed =(this.s.staffMarketSeed + Math.imul(this.s.day + 1, 2654435761)) >>> 0;
        const pool = D.staff.filter(p => !this.s.staff.includes(p.id));
        for (let i = pool.length - 1; i > 0; i--) {
          seed =(Math.imul(seed, 1664525) + 1013904223) >>> 0;
          const j = seed %(i + 1);
          [pool[i], pool[j]] = [pool[j], pool[i]];
        }
        return { day: this.s.day, ids: pool.slice(0, 5).map(p => p.id) };
      }
      staffCandidates() {
        if (!this.s.staffBoard || this.s.staffBoard.day !== this.s.day) this.s.staffBoard = this.buildStaffBoard();
        return this.s.staffBoard.ids.filter(id => !this.s.staff.includes(id)).map(id => D.staff.find(p => p.id === id));
      }
      hire(id) {
        const p = this.staffCandidates().find(p => p.id === id);
        if (!p) throw Error('오늘의 채용 후보를 확인하세요.');
        this.spend(p.fee, '직원 채용: ' + p.name);
        this.s.staff.push(id);
        this.log(p.name + ' 채용');
      }
      fire(id) {
        if (!this.s.staff.includes(id)) throw Error('재직 중인 직원이 아닙니다.');
        super.fire(id);
      }
      coach(plan) {
        return this.s.staff.map(id => D.staff.find(p => p.id === id)).filter(p => p.kind === 'trainer').map(p =>({ staff: p, bonus: Math.min(.6, p.coaching * .004 +(p.specialty === plan ? p.expertise * .002: 0)) })).sort((a, b) => b.bonus - a.bonus)[0] || { staff: null, bonus: 0 };
      }
      startCasting(method, type, position = 'any', experience = 'any') {
        if (!['any', 'career', 'trainee'].includes(experience) || !D.roster.some(d => this.available(d.id) &&(type === 'any' || d.type === type) &&(position === 'any' || d.position === position) &&(experience === 'any' ||(experience === 'career' ? !!d.career: d.trainee)))) throw Error('조건에 맞는 모집 후보가 없습니다.');
        super.startCasting(method, type, position);
        this.s.jobs.at(- 1).experience = experience;
      }
      sign(id, offer = 'balanced') {
        const d = D.roster[Number(id)],
        prior = this.s.departed.some(a => a.id === Number(id));
        if (d?.career && offer === 'company') throw Error('경력 아티스트는 균형 또는 아티스트 중심 계약을 요청합니다.');
        const extra = d?.career ? Math.round(250 + d.priorFame * 12): 0;
        if (this.s.cash < this.contractQuote(id, offer).total) throw Error('계약금과 경력 영입 지원금이 부족합니다.');
        super.sign(id, offer);
        const a = this.talent(id);
        this.initOperationsTalent(a);
        if (d.career) {
          this.spend(extra, '경력 영입 지원금: ' + d.name);
          if (!prior) {
            a.fans = d.priorFans;
            a.fame = d.priorFame;
            a.energy = d.id === 65 ? 65: 85;
          }
          this.s.reports[0].body += '\n육성 대기 없이 제작·공연 가능. 이전 소속사 작품 권리는 취득하지 않습니다.';
        }
      }
      setTraining(id, plan) {
        super.setTraining(id, plan);
        this.s.trainees.find(a => a.id === Number(id)).trainingMode = 'manual';
      }
      setTrainingControl(id, mode, goal) {
        const a = this.s.trainees.find(a => a.id === Number(id));
        if (!a || !['auto', 'manual'].includes(mode) || !['balanced', 'debut', 'longterm', 'vocal', 'performance', 'creative'].includes(goal)) throw Error('육성 목표를 확인하세요.');
        a.trainingMode = mode;
        a.trainingGoal = goal;
      }
      trainingAdvice(a) {
        const d = D.roster[a.id],
        required = d.type === 'idol' ?[0, 2, 5]: d.type === 'band' ?(d.position === '보컬' ?[0, 4, 7]:[3, 4, 7]):[1, 4, 5];
        const sorted = [... required].sort((x, y) => a.stats[x] - a.stats[y]),
        weak = sorted[0],
        strong = [... required].sort((x, y) => a.stats[y] - a.stats[x])[0];
        const plan = weak === 0 ? 'vocal':[2, 5, 6].includes(weak) ? 'performance': 'creative';
        return {
          weak,
          strong,
          plan,
          text: DATA_NAME(d) + ' · ' + D.specs[strong] + ' 강점 / ' + D.specs[weak] + ' 보완 권장'
        };
      }
      autoPlan(a) {
        if (a.energy < 40 || a.stress > 65) return 'rest';
        if (['vocal', 'performance', 'creative'].includes(a.trainingGoal)) return a.trainingGoal;
        if (a.trainingGoal === 'longterm' && a.energy < 65) return 'rest';
        return a.trainingGoal === 'balanced' ? 'balanced': this.trainingAdvice(a).plan;
      }
      trainTrainees() {
        for (const a of[... this.s.trainees]) {
          this.initOperationsTalent(a);
          if (a.trainingMode === 'auto' && this.has('trainer')) a.trainingPlan = this.autoPlan(a);
          const p = Base.trainingPlans[a.trainingPlan],
          profile = this.profile(a.id),
          coach = this.coach(a.trainingPlan);
          let reason = '훈련';
          if (a.trainingPlan === 'rest' || a.energy < 30 || a.stress > 80) {
            a.energy = clamp(a.energy + 8, 0, 100);
            a.stress = clamp(a.stress - 6, 0, 100);
            reason = '회복';
          } else {
            const cost = p.cost *(coach.staff ? .8: 1);
            if (this.s.cash < cost) {
              a.energy = clamp(a.energy + 5, 0, 100);
              a.stress = clamp(a.stress - 3, 0, 100);
              reason = '훈련비 부족';
            } else {
              this.change(- cost, '연습생 훈련: ' + D.roster[a.id].name, true, { kind: 'training' });
              const care = coach.staff ? coach.staff.care / 100: 0;
              a.energy = clamp(a.energy - p.load *(1 - care * .25), 0, 100);
              a.stress = clamp(a.stress + p.load * .5 *(1 - care * .5), 0, 100);
              a.trainedDays++;
              for (const idx of p.indexes) {
                const preference = a.trainingPlan === this.personality(a.id).training ? 1.08: 1,
                gain = .10 *(1 + coach.bonus) * preference * profile.learning *(p.indexes.length === 8 ? 1: 2.2) *(idx === profile.strength ? 1.35: idx === profile.weakness ? .7: 1) *(1 - a.stress * .005);
                if (a.stats[idx] < profile.potential) a.stats[idx] = Math.min(profile.potential, a.stats[idx] + gain);
              }
              reason = p.indexes.every(idx => a.stats[idx] >= profile.potential - .5) ? '성장 한계 접근': '훈련';
            }
          }
          a.lastTrainingReason = reason;
          if (a.contract <= this.s.day) this.releaseTrainee(a.id);
        }
      }
      startProject(key, kind, title, budget, concept, options = {}) {
        const e = this.entity(key);
        if (e?.members.some(a => a.recoveryUntil > this.s.day)) throw Error('활동 후 회복 중입니다. 일정에서 회복 종료일을 확인하세요.');
        const promo = D.promotionPlans[options.promotion || 'none'];
        if (!promo || kind !== 'single' && options.promotion && options.promotion !== 'none') throw Error('사전 홍보는 싱글 제작에서 선택하세요.');
        const manufacture = options.format === 'physical' ? Number(options.quantity) * .6: 0;
        if (this.s.cash < Number(budget) + manufacture + promo.cost -(this._affordabilityDiscount || 0)) throw Error('제작·제조·홍보비를 합친 자금이 부족합니다.');
        super.startProject(key, kind, title, budget, concept, options);
        const j = this.s.jobs.at(- 1);
        if (kind === 'single') {
          if (promo.cost) this.spend(promo.cost, '사전 홍보: ' + j.name);
          j.promotion = options.promotion || 'none';
          j.promotionCost = promo.cost;
          j.due += promo.days;
        }
      }
      resolve(id, choice) {
        const r = this.s.reports.find(r => r.id === Number(id));
        if (r?.kind === 'ad' && choice === 'accept' && this.entity(r.entity)?.members.some(a => a.recoveryUntil > this.s.day)) throw Error('회복 중에는 광고 촬영을 추가할 수 없습니다.');
        return super.resolve(id, choice);
      }
      receive(amount, label, shares = [], key = null, kind = 'income') {
        if (this.s.receivables &&['concert_settlement', 'ad_balance'].includes(kind)) {
          this.s.receivables.push({
            id: this.id(),
            due: this.s.day +(kind === 'concert_settlement' ? 7: 14),
            amount: round(amount),
            label,
            kind,
            shares: shares.map(x =>({ ... x })),
            key
          });
          return;
        }
        super.receive(amount, label, shares, key, kind);
      }
      finishOperations(j) {
        const count = this.s.catalog.length;
        this.finishMarket(j);
        if (j.kind === 'casting') return;
        const e = this.projectEntity(j);
        if (!e) return;
        const low = e.members.some(a => a.energy < 35 || a.stress > 75);
        const recovery = j.kind === 'live' ? 3: j.kind === 'ad' ? 2: 1;
        for (const a of e.members) {
          this.initOperationsTalent(a);
          a.recoveryUntil = Math.max(a.recoveryUntil, this.s.day + recovery +(low ? 3: 0));
          a.stress = clamp(a.stress +(low ? 5: 1), 0, 100);
        }
        if (low) {
          this.s.image = clamp(this.s.image - .5, 0, 100);
          this.report('컨디션 점검 · ' + e.name, '피로 누적으로 회복 기간이 늘었습니다. 무리한 일정은 실수 위험을 높입니다. 회복 종료까지 새 활동을 잡지 않습니다.', 'info', true);
        }
        if (j.kind === 'single') {
          const c = this.s.catalog[count],
          promo = D.promotionPlans[j.promotion || 'none'];
          c.market.production = round(c.market.production +(j.promotionCost || 0));
          c.market.appeal = Math.min(1.5, c.market.appeal *(1 + promo.boost));
        }
        if (j.kind === 'ad' || j.kind === 'live') {
          const r = this.s.reports.find(r => r.day === this.s.day && r.kind === 'result');
          if (r) {
            r.body = r.body.replace('원을 받았습니다.', '원은 촬영 후 14일 뒤 지급됩니다.');
            r.body += '\n실제 입금은 ' +(j.kind === 'live' ? '7': '14') + '일 뒤이며 재정의 예정 입출금에서 확인할 수 있습니다.';
          }
        }
      }
      settleReceivables() {
        const due = this.s.receivables.filter(x => x.due <= this.s.day);
        for (const item of due) super.receive(item.amount, item.label, item.shares, item.key, item.kind);
        const ids = new Set(due.map(x => x.id));
        this.s.receivables = this.s.receivables.filter(x => !ids.has(x.id));
      }
      advanceOperations() {
        this.advanceMarket();
        this.staffCandidates();
        for (const a of[... this.s.trainees, ... this.s.artists]) {
          this.initOperationsTalent(a);
          const history = a.growthHistory;
          if (history.at(- 1)?.day !== this.s.day) history.push({ day: this.s.day, stats:[... a.stats], reason: this.s.trainees.includes(a) ? a.lastTrainingReason || '훈련': a.recoveryUntil > this.s.day ? '활동 후 회복': '활동·육성' });
          a.growthHistory = history.filter(x => x.day >= this.s.day - 90);
        }
        if (this.s.day % 7 === 0 && this.has('trainer') && this.s.trainees.length) this.report('육성 담당 주간 보고', this.s.trainees.map(a => D.roster[a.id].name + ': ' + this.trainingAdvice(a).text + ' / ' +(a.lastTrainingReason || '기록 시작') + ' / 평균 ' + this.readiness(a).toFixed(1)).join('\n'), 'info');
        return this.pending.length;
      }
      cashForecast() {
        const s = this.s,
        items = s.receivables.map(x =>({
          day: x.due,
          label: x.label,
          amount: round(x.amount - x.shares.reduce((n, a) => n + round(x.amount * a.rate), 0)),
          type: '입금 확정'
        }));
        for (const j of s.jobs) if (j.kind === 'ad') items.push({
          day: j.due + 14,
          label: j.name + ' 잔금 (촬영 완료 조건)',
          amount: round(j.pay -(j.shares ||[]).reduce((n, x) => n + round(j.pay * x.rate), 0)),
          type: '입금 예정'
        });
        for (const c of s.catalog) if (c.market.pending) items.push({
          day: s.day + 7 - c.market.pendingDays,
          label: c.name + ' 누적 미정산',
          amount: round(c.market.pending *(1 - c.shares.reduce((n, a) => n + a.rate, 0))),
          type: '입금 추정'
        });
        const month = s.day + 30 - s.day % 30;
        items.push({
          day: month,
          label: '월 고정비·연습생 지원비',
          amount: - this.fixed,
          type: '예정 지출'
        });
        for (const l of s.loans) items.push({
          day: Math.max(month, Math.ceil(l.due / 30) * 30),
          label: '대출 원금·이자',
          amount: - round(Math.min(l.remaining, l.payment) + Math.round(l.remaining * l.rate)),
          type: '예정 지출'
        });
        return items.sort((a, b) => a.day - b.day);
      }
    }
    function DATA_NAME(d) {
      return d.position;
    }
    return OperationsGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installOperations = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/evolution.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const clamp =(v, a, b) => Math.max(a, Math.min(b, v)),
    round = v => Math.round(v * 100) / 100;
    class EvolutionGame extends Base {
      upgrade() {
        super.upgrade();
        const s = this.s;
        this.upgradeReliability();
        if (!s || s.evolutionVersion === 1) return;
        s.evolutionVersion = 1;
        s.evolutionSince = s.day;
        s.rewardPaid = [];
        s.perks = { debutPromo: 0, productionVoucher: 0, livePromo: 0 };
        s.moments = [];
        s.outcomes = [];
        s.stories = [];
        s.specialOffers = [];
        s.monthProfits = [];
        s.staffImpact = {
          since: s.day,
          saved: 0,
          trainingDays: 0,
          recoveryDays: 0
        };
        s.milestoneKeys = [];
        s.pinnedEntity = null;
        s.soundEnabled = false;
        s.goalEvidence = {
          live: s.settlements.some(x => x.kind === 'live' && x.attendance > 0) ? 1: 0,
          liveprofit: s.settlements.some(x => x.kind === 'live' && x.net > 0) ? 1: 0,
          team: s.performance.some(p => p.key.startsWith('u')) ? 1: 0,
          comeback: s.performance.some(p => p.ids.some(id => D.roster[id].career)) ? 1: 0
        };
        for (const a of[... s.artists, ... s.trainees, ... s.departed]) {
          a.memories = [{ day: s.day, kind: 'start', text: ' 함께한 기록 시작 · 이전 사건과 대화는 소급 생성하지 않습니다.' }];
          a.storyKeys = [];
          a.coverAttention = 0;
          a.coverAttentionDay = s.day;
        }
        for (const u of s.units) {
          u.cohesion = 0;
          u.completedActivities = 0;
        }
        // Previously recorded achievements receive the new rewards exactly once.
        this.grantGoalRewards(true);
      }
      upgradeReliability() {
        const s = this.s;
        if (!s || s.reliabilityVersion === 1) return;
        s.reliabilityVersion = 1;
        for (const r of s.reports) if (r.kind === 'contract' && r.talentId === undefined) {
          const a = s.artists.find(a => r.body.startsWith(D.roster[a.id].name + '의 계약이 '));
          if (a) {
            r.talentId = a.id;
            const remaining = r.body.match(/계약이 (\d+)일 뒤 만료/);
            if (remaining) r.contractDue = r.day + Number(remaining[1]);
          }
        }
        // One-time conversion of old untyped records. New transactions never depend on captions.
        for (const item of s.receivables ||[]) if (!item.kind) item.kind = item.label.startsWith('공연 정산') ? 'concert_settlement': 'ad_balance';
      }
      remember(ids, kind, text) {
        for (const id of ids) {
          const a = this.talent(id) || this.s.departed.find(x => x.id === id);
          if (!a) continue;
          if (!a.memories) a.memories = [];
          a.memories.push({ day: this.s.day, kind, text });
          a.memories = a.memories.slice(- 60);
        }
      }
      moment(key, title, body, ids = []) {
        if (this.s.milestoneKeys.includes(key)) return;
        this.s.milestoneKeys.push(key);
        this.s.milestoneKeys = this.s.milestoneKeys.slice(- 1000);
        this.s.moments.push({
          id: this.id(),
          day: this.s.day,
          title,
          body,
          ids:[... ids],
          seen: false
        });
        this.s.moments = this.s.moments.slice(- 80);
      }
      goalList() {
        const s = this.s,
        rows = super.goalList(),
        e = s.goalEvidence || {};
        const paid = s.catalog.reduce((n, c) => n +(c.market ? Math.max(0, c.market.paidStream - c.market.payoutStream): 0), 0);
        rows.find(g => g.id === 'catalog').value = paid > 0 ? 1: 0;
        rows.find(g => g.id === 'catalog').target = 1;
        const full = s.monthProfits ||[],
        streak = full.slice(- 3).length === 3 && full.slice(- 3).every(x => x.profit > 0) ? 3: full.slice().reverse().findIndex(x => x.profit <= 0);
        const stable = full.length ? streak === - 1 ? Math.min(3, full.length): streak: 0;
        for (const[id, title, value, target] of[['live', '첫 공연 완료', e.live || 0, 1], ['liveprofit', '첫 공연 흑자', e.liveprofit || 0, 1], ['team', '우리 팀의 첫 활동', e.team || 0, 1], ['physical', '첫 실물 판매', s.catalog.reduce((n, c) => n +(c.market?.sales || 0), 0) > 0 ? 1: 0, 1], ['comeback', '경력자의 새 출발', e.comeback || 0, 1], ['stable', '안정적인 운영', stable, 3]]) rows.push({
          id,
          title,
          value,
          target,
          done: s.goals.includes(id)
        });
        return rows.map(g =>({ ... g, reward: D.goalRewards[g.id], paid:(s.rewardPaid ||[]).includes(g.id) }));
      }
      grantGoalRewards(migration = false) {
        const s = this.s;
        if (!s.rewardPaid) return;
        const fresh = [];
        for (const id of s.goals) {
          if (s.rewardPaid.includes(id)) continue;
          const r = D.goalRewards[id];
          if (!r) continue;
          s.rewardPaid.push(id);
          if (r.cash) this.change(r.cash, '목표 달성 지원금: ' + id, false, { kind: 'goal_grant' });
          if (r.perk) s.perks[r.perk]++;
          if (r.offer) {
            const o = D.specialOffers[r.offer];
            s.specialOffers.push({
              id: this.id(),
              kind: r.offer,
              day: s.day,
              expires: s.day + o.days,
              used: false
            });
          }
          fresh.push(id);
          if (['star', 'rival', 'large', 'comeback'].includes(id)) this.news(this.goalStory(id));
          const ids = id === 'star' ? this.starTargetIds(): id === 'debut' ? s.artists.slice(- 1).map(a => a.id): id === 'renew' ?[]: s.artists.slice(0, 5).map(a => a.id);
          this.moment('goal-' + id, this.goalList().find(g => g.id === id)?.title || id, r.text +(migration ? '\n이전에 달성한 목표의 새 보상을 지급했습니다.': '\n' + this.goalStory(id)), ids);
        }
        if (fresh.length) this.report('목표 보상 지급 · ' + fresh.length + '건', fresh.map(id =>(this.goalList().find(g => g.id === id)?.title || id) + ' · ' + D.goalRewards[id].text).join('\n'), 'info', false, { goalRewardIds: fresh });
      }
      goalStory(id) {
        const s = this.s,
        team = s.units.find(u => u.completedActivities > 0) || s.units[0],
        career = s.outcomes.slice().reverse().flatMap(o => o.ids).find(id => D.roster[id].career),
        name = career === undefined ? '경력 아티스트': D.roster[career].name;
        const lines = {
          sign: '“처음의 마음을 잊지 않고, 좋은 음악을 함께 만들고 싶어요.”',
          trainee: '“아직 부족하지만 첫 무대까지 꾸준히 준비할게요.”',
          debut: '“연습실에서 상상하던 무대를 이제 만나러 가요.” 다음 싱글에 홍보 지원이 적용됩니다.',
          release: '첫 작품이 세상에 나왔습니다. 다음 작품도 우리다운 음악으로 이어 가세요.',
          catalog: '첫 음원 정산이 실제 입금됐습니다. 작은 시작이지만 음악이 회사의 자산으로 쌓이기 시작했습니다.',
          profit: '제작·훈련·급여·배분을 감당하고 영업흑자를 기록했습니다. 다음 활동도 현금 흐름을 지켜 주세요.',
          staff: '“실무는 제가 돕겠습니다. 대표님은 다음 무대를 그려 주세요.” 직원 관리에서 실제 기여를 확인하세요.',
          fans: '팬의 편지 · “다음 무대도 기다리고 있어요. 우리 오래 만나요.” 소규모 팬 공연 제안이 도착했습니다.',
          renew: '“함께 보낸 시간을 믿어요. 다음 음악도 여기서 만들고 싶습니다.”',
          star: '업계 기사 · ' + s.company + '의 아티스트가 스타로 자리 잡았습니다. 꾸준한 실제 흥행과 팬들의 지지가 새로운 기회를 만들었습니다.',
          rival: '업계 기사 · ' + s.company + '가 라이벌 한 곳의 영업이익을 넘어섰습니다. 외부 세션과의 협업 제안이 도착했습니다.',
          large: '작은 회사에서 대형 엔터테인먼트사까지. 현재 소속 아티스트 ' + s.artists.length + '명 · 발매 ' + s.releases + '회. 첫 만남과 수많은 선택이 오늘의 회사를 만들었습니다.',
          live: '첫 무대의 기억 · “객석에서 우리 음악을 듣는 얼굴들을 봤어요. 이 순간을 기억하고 싶어요.”',
          liveprofit: '관객을 만나고 제작비·현장비·배분을 감당한 공연을 마쳤습니다. 다음 공연에 홍보 지원이 적용됩니다.',
          team:(team ? team.name: '우리 팀') + '의 첫 활동. “각자의 목소리가 하나의 무대가 됐어요.” 팀·계약 화면에서 단체 프로필을 확인하세요.',
          physical: '첫 구매자의 메시지 · “음악을 손에 간직하고 싶어서 샀어요. 다음 작품도 기대할게요.”',
          comeback: name + '의 새로운 시작 · “지난 경험을 딛고, 제 속도로 오래 음악을 하고 싶어요.”',
          stable: '완전한30일 정산3회 연속 영업흑자를 기록했습니다. 목표 지원금과 대출금은 영업실적에서 제외한 결과입니다.'
        };
        return lines[id] || '함께 만든 첫걸음을 회사의 기록에 남깁니다.';
      }
      starTargetIds() {
        let u = this.s.units.find(u => u.bestStar >= 3);
        return u ?[... u.ids]: this.s.artists.filter(a => a.bestStar >= 3).slice(0, 5).map(a => a.id);
      }
      sign(id, offer) {
        super.sign(id, offer);
        const a = this.talent(Number(id));
        if (!a.memories) a.memories = [];
        if (!a.storyKeys) a.storyKeys = [];
        a.coverAttention = a.coverAttention || 0;
        a.coverAttentionDay = this.s.day;
        this.remember([a.id], 'contract', D.roster[a.id].trainee ? '연습생으로 함께하기 시작했습니다.': '전속계약 · 새로운 음악을 함께 준비합니다.');
        if (D.roster[a.id].career) this.openStory(a.id, 'comeback');
      }
      debut(id, offer) {
        super.debut(id, offer);
        this.remember([Number(id)], 'debut', '첫 데뷔 · 기다려 온 시작을 함께했습니다.');
        this.moment('debut-' + id, D.roster[id].name + '의 데뷔', '“연습실에서 상상하던 무대를 이제 만나러 가요.”\n첫 작품과 공연을 준비할 수 있습니다.', [Number(id)]);
      }
      renew(id, offer) {
        super.renew(id, offer);
        const a = this.artist(id),
        last = a.memories?.filter(m => m.kind === 'choice').at(- 1);
        this.remember([a.id], 'renew', '재계약 · 다음 무대도 함께하기로 했습니다.');
        this.report('다음 무대도 함께 · ' + D.roster[id].name, '“' +(last ? '그때 제 이야기를 들어주신 걸 기억해요. ': '') + '다음 음악도 함께 만들고 싶어요.”', 'info', false, { talentId: a.id });
      }
      formUnit(name, ids) {
        super.formUnit(name, ids);
        const u = this.s.units.at(- 1);
        u.cohesion = 0;
        u.completedActivities = 0;
        this.remember(u.ids, 'team', u.name + ' 결성 · 서로의 호흡을 알아갑니다.');
      }
      teamProfile(e) {
        const u = this.s.units.find(u => u.key === e.key),
        needed = e.type === 'band' ?[0, 3, 4, 7]: e.type === 'rap' ?[1, 4, 5]:[0, 2, 5];
        const strength = [... needed].sort((a, b) => Math.max(... e.members.map(x => x.stats[b])) - Math.max(... e.members.map(x => x.stats[a])))[0],
        weak = [... needed].sort((a, b) => Math.max(... e.members.map(x => x.stats[a])) - Math.max(... e.members.map(x => x.stats[b])))[0];
        return {
          strength,
          weak,
          cohesion: u?.cohesion || 0,
          roles: new Set(e.members.map(a => D.roster[a.id].position)).size
        };
      }
      mean(e, index) {
        const avg = super.mean(e, index);
        if (e.members.length < 2) return avg;
        const p = this.teamProfile(e);
        return Math.min(99, avg +(Math.max(... e.members.map(a => a.stats[index])) - avg) * .30 + p.cohesion * .035);
      }
      teamAction(key, action, id) {
        super.teamAction(key, action, id);
        const u = this.s.units.find(u => u.key === key);
        if (u && action === 'add') u.cohesion = round((u.cohesion || 0) * .8);
      }
      leaveTeam(id) {
        const u = this.s.units.find(u => u.ids.includes(Number(id)));
        super.leaveTeam(id);
        if (u) u.cohesion = round((u.cohesion || 0) * .8);
      }
      get entities() {
        return [... this.s.units.filter(u => u.status === 'active' && u.ids.length >= 2).map(u => this.entity(u.key)), ... this.s.artists.map(a => this.entity(String(a.id)))];
      }
      projectQuote(key, kind, budget, options = {}) {
        return D.rules.quote(budget, kind, { ... options, promotionCost: D.promotionPlans[options.promotion || 'none']?.cost || 0 }, this.s.perks);
      }
      spend(n, label, meta = {}) {
        if (this._projectCharge && meta.kind === 'production') return super.spend(round(n - this._projectCharge.discount), label, meta);
        return super.spend(n, label, meta);
      }
      startProject(key, kind, title, budget, concept, options = {}) {
        const q = this.projectQuote(key, kind, budget, options);
        if (this.s.cash < q.total) throw Error('할인 적용 후 제작·제조·홍보비를 합친 자금이 부족합니다.');
        // Lower layers validate combined nominal costs. Quote-aware spend charges only actual cost.
        this._projectCharge = q;
        this._affordabilityDiscount = q.discount;
        try {
          super.startProject(key, kind, title, budget, concept, options);
        } finally {
          this._projectCharge = null;
          this._affordabilityDiscount = 0;
        }
        const j = this.s.jobs.at(- 1);
        j.productionDiscount = q.discount;
        j.actualProductionCost = q.production;
        if (q.discount) this.s.perks.productionVoucher--;
        if (kind === 'single' && this.s.perks.debutPromo > 0) {
          j.freePromotion = true;
          this.s.perks.debutPromo--;
        }
        if (kind === 'live' && this.s.perks.livePromo > 0) {
          j.freeLivePromotion = true;
          this.s.perks.livePromo--;
        }
        if (kind === 'single') {
          const e = this.entity(key);
          j.coverBoost = Math.min(.16, e.members.reduce((n, a) => n + this.coverAttention(a), 0) / e.members.length);
          e.members.forEach(a => {
            a.coverAttention = 0;
          });
        }
        if (kind === 'live') {
          const e = this.entity(key);
          for (const a of e.members) if (!a.storyKeys?.includes('firststage')) {
            this.openStory(a.id, 'firststage');
            break;
          }
        }
      }
      coverAttention(a) {
        return Math.max(0, (a.coverAttention || 0) *(1 - Math.max(0, this.s.day -(a.coverAttentionDay || 0)) / 60));
      }
      concert(e, j, quality) {
        let base = super.concert(e, j, quality),
        unitCost = j.budget <= 300 ? .8: j.budget <= 800 ? 1.2: 1.8,
        u = this.s.units.find(u => u.key === e.key),
        fan = e.members.reduce((n, a) => n + a.fans, 0),
        recent = this.s.performance.filter(p => p.kind === 'live' && p.day > this.s.day - 30 && p.ids.some(id => e.members.some(a => a.id === id))).length;
        if (e.members.length > 1) {
          const size = j.budget <= 300 ? {
            name: '팀 클럽 무대',
            capacity: 500,
            ticket: 10,
            variable: 1
          }
          : j.budget <= 800 ? {
            name: '팀 중형 공연장',
            capacity: 1400,
            ticket: 11,
            variable: 1.4
          }
          : {
            name: '팀 대형 공연장',
            capacity: 3200,
            ticket: 13,
            variable: 2
          };
          const demand =(quality * 2.4 + fan * .25 +(u?.fans || 0) * .30) *(10 / size.ticket) * this.imageFactor() *(1 + this.staffPower('live') * .2) *(1 +(u?.cohesion || 0) * .0015) /(1 + recent * .2);
          unitCost = size.variable;
          base = { ... size, attendance: clamp(Math.floor(demand), 0, size.capacity), recent };
        }
        const lastRelease = this.s.catalog.filter(c => c.market.ids.some(id => e.members.some(a => a.id === id))).at(- 1),
        newMusic = lastRelease && this.s.day - lastRelease.market.startDay <= 45 ? 1.08: 1,
        repeat =(1 + recent * .2) /(1 + recent * .32),
        promo = j.freeLivePromotion ? 1.08: 1;
        base.attendance = clamp(Math.floor(base.attendance * repeat * newMusic * promo), 0, base.capacity);
        base.gross = base.attendance * base.ticket;
        base.variable = round(base.attendance * unitCost);
        j.factors = j.factors ||[];
        if (base.recent > 0) j.factors.unshift('최근30일 공연 ' + base.recent + '회 · 반복 수요 조정 적용');
        if (newMusic > 1) j.factors.unshift('최근45일 신곡 · 공연 관심 +8%');
        if (promo > 1) j.factors.unshift('공연 홍보 지원 · 관객 수요 +8%');
        j.concert = base;
        return base;
      }
      newFans(e, j, quality, fan) {
        const gain = super.newFans(e, j, quality, fan);
        if (e.members.length < 2) return gain;
        this._fanGain = Math.floor(gain * 1.18);
        return this._fanGain;
      }
      finishEvolution(j) {
        const count = this.s.catalog.length,
        e = j.kind === 'casting' ? null: this.projectEntity(j),
        priorFans = e?.members.reduce((n, a) => n + a.fans, 0) || 0,
        priorSettlements = this.s.settlements[0];
        this.finishOperations(j);
        if (!e) return;
        const u = this.s.units.find(u => u.key === j.entity);
        if (j.entity?.startsWith('u') && j.snapshot?.ids.length >= 2 &&['single', 'live', 'cover'].includes(j.kind)) this.s.goalEvidence.team = 1;
        if (['single', 'live', 'cover'].includes(j.kind)) {
          if (u) {
            u.completedActivities =(u.completedActivities || 0) + 1;
            u.cohesion = clamp((u.cohesion || 0) + 3, 0, 100);
            this.s.goalEvidence.team = 1;
          }
          if (e.members.some(a => D.roster[a.id].career)) this.s.goalEvidence.comeback = 1;
          const ids = e.members.map(a => a.id);
          this.remember(ids, 'activity', j.name + ' · ' +({ single: (j.albumType ? root.ActivityData.albums[j.albumType].label : '싱글') + ' 발매', live: '공연 완료', cover: j.contentType ? root.ActivityData.content[j.contentType].label + ' 공개' : '커버 공개' }[j.kind]));
          if (j.kind === 'cover') {
            const repeats = this.s.performance.filter(p => p.kind === 'cover' && p.day > this.s.day - 60 && p.ids.some(id => ids.includes(id))).length;
            for (const a of e.members) {
              a.coverAttention = Math.min(.16, this.coverAttention(a) + .08 / Math.max(1, repeats));
              a.coverAttentionDay = this.s.day;
            }
          }
          if (j.kind === 'single') {
            const c = this.s.catalog[count];
            c.market.production = round(c.market.production -(j.productionDiscount || 0));
            c.market.appeal = clamp(c.market.appeal *(1 +(j.coverBoost || 0) +(j.freePromotion ? .08: 0)), .3, 1.5);
            if (e.members.length > 1) {
              c.market.fanBase = Math.round(priorFans * .85 +(u?.fans || 0) * .60);
              c.market.appeal = clamp(c.market.appeal *(1 + Math.min(.20, e.members.length * .025 +(u?.cohesion || 0) * .001)), .3, 1.5);
            }
            this.resurface(ids, '새 음반 발매', c.id);
          }
          if (j.kind === 'live') {
            this.s.goalEvidence.live = Math.max(this.s.goalEvidence.live, j.concert.attendance > 0 ? 1: 0);
            let entry = this.s.settlements[0];
            if (entry !== priorSettlements) {
              entry.budget = j.actualProductionCost ?? j.budget;
              entry.net = round(entry.gross - entry.payout - entry.variable - entry.budget);
              if (entry.net > 0) this.s.goalEvidence.liveprofit = 1;
            }
            if (j.concert.attendance > 0) this.resurface(ids, '공연 이후 다시 듣기');
          }
          for (const id of ids.filter(id => D.roster[id].career)) this.moment('comeback-' + id, D.roster[id].name + '의 새로운 출발', '“이번에는 제 속도로 오래 음악을 하고 싶어요.”\n우리 회사에서 첫 활동을 마쳤습니다.', [id]);
        }
        const entry = this.s.settlements[0],
        net = j.kind === 'live' && entry !== priorSettlements ? entry.net: null,
        outcome = {
          id: this.id(),
          day: this.s.day,
          kind: j.kind,
          title: j.name,
          entity: j.entity,
          ids: e.members.map(a => a.id),
          quality: round(this._lastQuality || 0),
          fans: e.members.reduce((n, a) => n + a.fans, 0) - priorFans,
          attendance: j.concert?.attendance || 0,
          capacity: j.concert?.capacity || 0,
          net,
          production: j.actualProductionCost ?? j.budget ?? 0,
          factors:(j.factors ||[]).slice(0, 3)
        };
        this.s.outcomes.push(outcome);
        this.s.outcomes = this.s.outcomes.slice(- 60);
        const r = this.s.reports.find(r => r.kind === 'result' && r.day === this.s.day && !r.outcomeId);
        if (r) r.outcomeId = outcome.id;
      }
      resurface(ids, reason, exclude = null) {
        for (const c of this.s.catalog) {
          if (c.id === exclude || this.s.day - c.market.startDay < 30 || !c.market.ids.some(id => ids.includes(id))) continue;
          if (c.market.resurfacedDay !== undefined && this.s.day - c.market.resurfacedDay < 45) continue;
          c.market.resurfacedDay = this.s.day;
          c.market.resurfaceUntil = this.s.day + 14;
          c.market.resurfaceReason = reason;
          this.log(c.name + ' · ' + reason + '로 이전 작품에 다시 관심이 모입니다.');
        }
      }
      releaseDay(c, owner) {
        const m = c.market,
        oldAppeal = m.appeal;
        if (owner === 'player' && m.resurfaceUntil > this.s.day) m.appeal = clamp(oldAppeal * 1.25, .3, 1.5);
        let result;
        try {
          result = super.releaseDay(c, owner);
        } finally {
          m.appeal = oldAppeal;
        }
        return result;
      }
      tickCatalog() {
        const hits = new Set(this.s.catalog.filter(c => c.market.hit).map(c => c.id));
        super.tickCatalog();
        for (const c of this.s.catalog) if (c.market.hit && !hits.has(c.id)) {
          this.remember(c.market.ids, 'hit', c.name + ' · 실제 흥행 기준을 달성했습니다.');
          this.moment('hit-' + c.entity, c.market.artistName + '의 첫 흥행', '「' + c.name + '」을 기다리는 사람들이 늘었습니다.\n“우리 음악이 누군가에게 닿았네요.”', c.market.ids);
          this.resurface(c.market.ids, '신곡 흥행', c.id);
        }
      }
      openStory(id, kind) {
        const a = this.talent(id);
        if (!a || !D.personalStories[kind] || a.storyKeys?.includes(kind) || this.s.stories.some(x => x.status === 'open')) return;
        const story = {
          id: this.id(),
          talentId: id,
          kind,
          day: this.s.day,
          expires: this.s.day + 14,
          status: 'open',
          choice: null
        };
        this.s.stories.push(story);
        this.s.stories = this.s.stories.slice(- 120);
        a.storyKeys.push(kind);
        const d = D.personalStories[kind];
        this.report(D.roster[id].name + ' · ' + d.title, d.body + '\n14일 안에 이야기할 수 있습니다. 기한이 지나도 별도 능력·신뢰 페널티는 없습니다.', 'info', true, { storyId: story.id, talentId: id });
      }
      resolveStory(id, choice) {
        const s = this.s,
        story = s.stories.find(x => x.id === Number(id)),
        a = story && this.talent(story.talentId);
        if (!story || story.status !== 'open' || story.expires < s.day || !a || !['support', 'space'].includes(choice)) throw Error('현재 대화할 수 있는 사건과 선택을 확인하세요.');
        const d = D.personalStories[story.kind],
        preferred = choice === 'space' ? this.personality(a.id).session === 'rest': this.personality(a.id).session !== 'rest';
        if (choice === 'support') this.spend(100, '개인 사건 상담: ' + D.roster[a.id].name);
        a.trust = clamp(a.trust +(preferred ? 5: 3), 0, 100);
        a.stress = clamp(a.stress -(choice === 'space' ? 10: 6), 0, 100);
        if (choice === 'space') a.energy = clamp(a.energy + 5, 0, 100);
        story.status = 'resolved';
        story.choice = choice;
        const reply = choice === 'support' ? d.replySupport: d.replySpace;
        this.remember([a.id], 'choice', d.title + ' · ' +(choice === 'support' ? '상담 지원': '부담을 덜어 주는 대화') + ' · “' + reply + '”');
        for (const r of s.reports) if (r.storyId === story.id) {
          r.resolved = true;
          r.read = true;
        }
        this.report(D.roster[a.id].name + '의 답장', '“' + reply + '”', 'info', false, { talentId: a.id });
      }
      trainingReaction(id) {
        const a = this.talent(id),
        memory = a?.memories?.filter(m => m.kind === 'choice').at(- 1);
        return memory && this.s.day - memory.day < 30 ? memory.text.slice(memory.text.indexOf('“') + 1, memory.text.lastIndexOf('”')): super.trainingReaction(id);
      }
      offerEligible(o, key) {
        const e = this.entity(key);
        if (!e || o.used || o.expires < this.s.day) return false;
        const u = this.s.units.find(u => u.key === key);
        return o.kind === 'fan' ? Math.max(e.members.reduce((n, a) => n + a.fans, 0), u?.fans || 0) >= 1000: o.kind === 'star' ?(u?.star ?? e.members[0].star) >= 3: o.kind === 'collab' ? this.metrics().profit > 0: this.stage >= 5;
      }
      acceptOffer(id, key) {
        const o = this.s.specialOffers.find(x => x.id === Number(id));
        if (!o || !this.offerEligible(o, key)) throw Error('제안 기한과 대상의 현재 조건을 확인하세요.');
        const spec = D.specialOffers[o.kind];
        this.startProject(key, spec.kind, spec.title, spec.budget, 'balanced');
        const j = this.s.jobs.at(- 1);
        j.specialOffer = o.kind;
        // A limited campaign advantage, never a guaranteed profit.
        if (spec.kind === 'single') j.coverBoost = Math.min(.20, (j.coverBoost || 0) + .04);
        else j.freeLivePromotion = true;
        o.used = true;
        this.log(spec.title + ' 승인 · 일반 비용·배분·일정 규칙 적용');
      }
      get pending() {
        const urgent = this.s.reports.filter(r => !r.resolved &&((r.kind === 'ad' && r.expires >= this.s.day) ||(r.kind === 'casting' && !r.read) ||(r.kind === 'crisis' && this.s.cash < 0) || r.storyId ||(r.incidentId && this.s.incidents.some(i => i.id === r.incidentId && i.state === 'open')) ||(r.kind === 'finance' && r.important && !r.read)));
        for (const r of this.s.reports) {
          const a = this.artist(r.talentId);
          if (!r.read && !r.resolved && r.kind === 'contract' && a && a.contract - this.s.day <= 30 && a.contract === r.contractDue && !urgent.includes(r)) urgent.push(r);
        }
        return urgent;
      }
      report(title, body, kind = 'info', important = false, extra = {}) {
        if (this.s.evolutionVersion === 1 && title === '목표 달성') return;
        if (this.s.evolutionVersion === 1 && title === '육성 담당 주간 보고') {
          const x = this.s.staffImpact || { saved: 0, trainingDays: 0, recoveryDays: 0 },
          ready = this.s.trainees.filter(a => this.s.day - a.signed >= 90 && this.readiness(a) >= 55).length,
          rest = this.s.trainees.filter(a => a.trainingPlan === 'rest').length;
          body = '데뷔 검토 ' + ready + '명 / 회복 계획 ' + rest + '명\n직원 지도 훈련 ' + x.trainingDays + '인일 · 직원 자동 회복 조정 ' + x.recoveryDays + '인일\n실제 연습생 훈련비 절감 ' + round(x.saved) + '만 원 (기록 ' + x.since + '일째부터)\n' + body;
        }
        return super.report(title, body, kind, important, extra);
      }
      trainTrainees() {
        const before = this.s.trainees.map(a =>({ id: a.id, trained: a.trainedDays || 0 }));
        super.trainTrainees();
        const x = this.s.staffImpact;
        if (!x) return;
        for (const b of before) {
          const a = this.talent(b.id);
          if (!a) continue;
          const trained =(a.trainedDays || 0) > b.trained;
          if (trained && this.coach(a.trainingPlan).staff) {
            x.trainingDays++;
            x.saved = round(x.saved + Base.trainingPlans[a.trainingPlan].cost * .2);
          }
          if (!trained && a.trainingMode === 'auto' && this.has('trainer') && a.trainingPlan === 'rest') x.recoveryDays++;
        }
      }
      advanceEvolution() {
        const s = this.s,
        cashBefore = s.cash,
        reportsBefore = new Set(s.reports.map(r => r.id));
        this.advanceSummary();
        for (const u of s.units) if (u.status === 'active' && u.ids.length >= 2 && u.ids.every(id => this.artist(id).energy >= 35)) u.cohesion = round(clamp((u.cohesion || 0) + .08, 0, 100));
        for (const st of s.stories) if (st.status === 'open' &&(st.expires < s.day || !this.talent(st.talentId))) {
          st.status = 'expired';
          for (const r of s.reports) if (r.storyId === st.id) {
            r.resolved = true;
            r.read = true;
          }
        }
        if (s.day % 60 === 0 && !s.stories.some(x => x.status === 'open')) {
          const pool = [... s.artists, ... s.trainees];
          for (const a of pool) {
            const kind = s.units.some(u => u.ids.includes(a.id)) ? 'team': this.personality(a.id).session === 'creative' ? 'creative': 'pressure';
            if (!a.storyKeys.includes(kind)) {
              this.openStory(a.id, kind);
              break;
            }
          }
        }
        if (s.day % 30 === 0 && s.day - 30 >= s.evolutionSince) {
          const bins = s.accounts.filter(b => b.day > s.day - 30 && b.day <= s.day),
          profit = round(bins.reduce((n, b) => n + b.revenue - b.expense, 0));
          s.monthProfits.push({ day: s.day, profit });
          s.monthProfits = s.monthProfits.slice(- 12);
        }
        // Management checks run before this complete day's receipts; settle goals once more now.
        for (const g of this.goalList()) if (!g.done && g.value >= g.target) {
          s.goals.push(g.id);
          this.log('목표 달성: ' + g.title);
        }
        this.grantGoalRewards();
        if (s.day % 7 === 0) {
          this.report('주간 운영 요약', '최근 7일 운영 요약은 홈에서, 작품·공연 성과는 활동 결과에서 확인하세요.\n확정 정산 예정 ' + s.receivables.length + '건 · 현재 소속 ' + s.artists.length + '명 · 연습생 ' + s.trainees.length + '명\n훈련 성장과 회복은 연습생 상세, 실제 입출금은 재정에서 확인하세요.', 'info', false, { weeklySummary: true });
        }
        this.closeFinancialDay();
        // Include post-settlement grants in the daily cash record, without making them operating revenue.
        const summary = s.daySummaries.at(- 1);
        if (summary?.day === s.day) {
          summary.cashChange = round(s.cash - cashBefore);
          summary.newReports = s.reports.filter(r => !reportsBefore.has(r.id)).length;
        }
        return this.pending.length;
      }
    }
    return EvolutionGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installEvolution = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/campaign.js */
(function(root) {
  'use strict';
  function install(Base, D) {
    const round = n => Math.round(n * 100) / 100;
    class CampaignGame extends Base {
      upgrade() {
        super.upgrade();
        const s = this.s;
        if (!s || s.campaignVersion === 1) return;
        s.campaignVersion = 1;
        for (const j of s.jobs) if (j.kind === 'single') {
          j.baselineDue = j.due;
          j.delayDays = 0;
          j.pauses = [];
        }
      }
      participantIds(job) {
        return job.snapshot?.ids || this.entity(job.entity)?.members.map(a => a.id) ||[];
      }
      productionState(job) {
        const active =(job.pauses ||[]).find(p => p.start <= this.s.day && p.end > this.s.day);
        return {
          paused: !!active,
          resume: active?.end ?? null,
          remaining: Math.max(0, job.due - this.s.day -(active ? active.end - this.s.day: 0)),
          delay: job.delayDays || 0
        };
      }
      adPlan(id) {
        const r = this.s.reports.find(r => r.id === Number(id)),
        e = r && this.entity(r.entity),
        reasons = [],
        days = D.rules.advertisement.days;
        if (!r || r.kind !== 'ad' || r.resolved || r.expires < this.s.day) reasons.push('이미 처리됐거나 기한이 끝난 제안입니다.');
        if (!e || e.key.startsWith('u') &&(e.status !== 'active' || e.members.length < 2)) reasons.push('현재 활동 가능한 대상이 아닙니다.');
        if (e?.members.some(a => a.recoveryUntil > this.s.day)) reasons.push('활동 후 회복 중입니다.');
        if (e?.members.some(a => a.energy < 25)) reasons.push('촬영을 준비할 체력이 부족합니다.');
        const ids = e?.members.map(a => a.id) ||[],
        linked = this.s.jobs.filter(j => this.participantIds(j).some(id => ids.includes(id))),
        productions = linked.filter(j => j.kind === 'single');
        if (linked.some(j => j.kind !== 'single')) reasons.push('공연·커버·다른 광고와 일정이 겹칩니다.');
        const family = new Set(ids);
        for (const u of this.s.units) if (u.ids.some(id => ids.includes(id))) u.ids.forEach(id => family.add(id));
        for (const j of productions) this.participantIds(j).forEach(id => family.add(id));
        if (this.s.jobs.some(j => j.kind === 'ad' && this.participantIds(j).some(id => family.has(id)))) reasons.push('같은 팀 또는 제작 참여자의 광고가 진행 중입니다.');
        if (productions.some(j => this.productionState(j).paused)) reasons.push('해당 제작은 이미 광고로 중단돼 있습니다.');
        return {
          allowed: reasons.length === 0,
          reasons:[... new Set(reasons)],
          days,
          name: e?.name || '종료된 대상',
          pay: r?.pay || 0,
          advance: round((r?.pay || 0) * .4),
          balance: round((r?.pay || 0) * .6),
          shootingDay: this.s.day + days,
          paymentDay: this.s.day + days + D.rules.advertisement.balanceDays,
          productions: productions.map(j =>({
            id: j.id,
            title: j.name,
            artist: j.snapshot?.name || e?.name || '',
            oldDue: j.due,
            newDue: j.due + days,
            remaining: this.productionState(j).remaining
          }))
        };
      }
      // One extension path for approval and previews; Season adds future reservations.
      pauseProduction(j, pause) {
        if ((j.pauses || []).some(p => p.adId === pause.adId)) return j;
        if (j.baselineDue === undefined) j.baselineDue = j.due;
        const days = pause.end - pause.start;
        j.delayDays = (j.delayDays || 0) + days;
        j.due += days;
        const pauses = (j.pauses || []).concat(pause).sort((a, b) => a.start - b.start);
        if (pauses.slice(0, -60).some(p => p.end > this.s.day)) throw Error('예약된 제작 중단 일정이 너무 많습니다.');
        j.pauses = pauses.slice(-60);
        return j;
      }
      reconcileProduction(j, events = []) { return j; }
      resolve(id, choice) {
        const r = this.s.reports.find(r => r.id === Number(id));
        if (r?.kind !== 'ad') return super.resolve(id, choice);
        return this.transaction(() => {
          if (!r || r.resolved || r.expires < this.s.day) throw Error('현재 처리할 수 있는 광고 제안이 아닙니다.');
          if (choice === 'decline') {
            r.resolved = true;
            r.read = true;
            r.decision = 'decline';
            return;
          }
          if (choice !== 'accept') throw Error('광고 응답을 확인하세요.');
          const plan = this.adPlan(id);
          if (!plan.allowed) throw Error(plan.reasons.join(' '));
          const snapshot = this.snapshot(r.entity),
          shares = this.shares(snapshot),
          adId = this.id();
          this.receive(plan.advance, '광고 계약 선금', shares, r.entity, 'ad_advance');
          this.s.jobs.push({
            id: adId,
            kind: 'ad',
            entity: r.entity,
            name: r.brand + ' 광고 촬영',
            pay: plan.balance,
            start: this.s.day,
            due: plan.shootingDay,
            snapshot,
            shares,
            reportId: r.id,
            interrupts: plan.productions.map(p => p.id)
          });
          for (const p of plan.productions) {
            const j = this.s.jobs.find(j => j.id === p.id);
            this.pauseProduction(j, { adId, start: this.s.day, end: plan.shootingDay });
            this.reconcileProduction(j);
            this.log(j.name + ' · 광고로 제작 중단 ' + plan.days + '일 · 예약 행사 반영 완료일 ' + j.due + '일째');
          }
          r.resolved = true;
          r.read = true;
          r.decision = 'accept';
          this.report('광고 일정 확정', plan.name + ' · 촬영 완료 ' + plan.shootingDay + '일째 / 잔금 ' + plan.paymentDay + '일째.\n' +(plan.productions.length ? plan.productions.map(p => p.title + ': ' + p.oldDue + ' → ' + p.newDue + '일째').join('\n'): '진행 중인 음반 제작의 변경은 없습니다.'), 'info', false, { entity: r.entity });
        });
      }
      finishCampaign(j) {
        super.finishEvolution(j);
        if (j.kind === 'ad' && j.interrupts?.length) {
          const jobs = this.s.jobs.filter(x => j.interrupts.includes(x.id));
          if (jobs.length) this.report('광고 촬영 종료 · 제작 재개', jobs.map(x => x.name + ' · 제작 잔여 ' + this.productionState(x).remaining + '일 / 완료 ' + x.due + '일째').join('\n'), 'info', false);
        }
      }
      reportState(r) {
        if (r.closedReason === 'expired') return { status: 'expired', label: '기한 종료', needsDecision: false };
        if (r.incidentId) {
          const i = this.s.incidents.find(i => i.id === r.incidentId);
          if (i?.state === 'open') return {
            status: 'decision',
            label: '결정 필요',
            needsDecision: true,
            expires: i.expires
          };
          if (i?.state === 'investigating') return { status: 'working', label: '조사 중', needsDecision: false };
          return { status: 'done', label: '처리 완료', needsDecision: false };
        }
        if (r.storyId) {
          const s = this.s.stories.find(s => s.id === r.storyId);
          if (s?.status === 'open') return {
            status: 'decision',
            label: '결정 필요',
            needsDecision: true,
            expires: s.expires
          };
          return { status: s?.status === 'resolved' ? 'done': 'expired', label: s?.status === 'resolved' ? '처리 완료': '기한 종료', needsDecision: false };
        }
        if (r.kind === 'ad') {
          if (r.resolved) return { status: 'done', label: r.decision === 'decline' ? '거절 완료': '처리 완료', needsDecision: false };
          if (r.expires < this.s.day || !this.entity(r.entity)) return { status: 'expired', label: '기한 종료', needsDecision: false };
          return {
            status: 'decision',
            label: '결정 필요',
            needsDecision: true,
            expires: r.expires
          };
        }
        if (r.kind === 'contract') {
          const a = this.artist(r.talentId),
          active = a && a.contract === r.contractDue && a.contract - this.s.day <= 90;
          return active ? {
            status: 'decision',
            label: '재계약 검토',
            needsDecision: true,
            expires: a.contract
          }
          : { status: 'done', label: '확인 종료', needsDecision: false };
        }
        if (r.resolved) return { status: 'done', label: '처리 완료', needsDecision: false };
        if (r.kind === 'event' && this.entity(r.entity) || r.kind === 'crisis' && this.s.cash < 0) return { status: 'decision', label: '결정 필요', needsDecision: true };
        return { status: 'info', label: r.read ? '읽음': '안 읽음', needsDecision: false };
      }
      setReportRead(id, read) {
        const r = this.s.reports.find(r => r.id === Number(id));
        if (!r) throw Error('보고가 없습니다.');
        r.read = !!read;
      }
      markGeneralRead() {
        for (const r of this.s.reports) if (!this.reportState(r).needsDecision) r.read = true;
      }
      inboxCounts() {
        return { unread: this.s.reports.filter(r => !r.read).length, decision: this.s.reports.filter(r => this.reportState(r).needsDecision).length };
      }
      reportCategory(r) {
        return r.storyId || r.kind === 'event' || r.title === '육성 담당 주간 보고' ? 'training': r.kind === 'result' || r.kind === 'ad' ? 'activity':['finance', 'crisis'].includes(r.kind) || r.goalRewardIds ? 'finance': 'general';
      }
      get pending() {
        const base = super.pending.filter(r => !['done', 'expired', 'working'].includes(this.reportState(r).status));
        for (const r of this.s.reports) if (this.reportState(r).needsDecision && r.kind !== 'contract' && !base.includes(r)) base.push(r);
        return base;
      }
      activityAvailability(key) {
        const e = this.entity(key);
        if (!e) return { allowed: false, reasons:['활동 대상 없음'] };
        const reasons = [];
        if (e.key.startsWith('u') &&(e.status !== 'active' || e.members.length < 2)) reasons.push('팀 활동 중단·멤버 부족');
        const jobs = this.s.jobs.filter(j => this.participantIds(j).some(id => e.members.some(a => a.id === id)));
        for (const j of jobs) reasons.push((j.kind === 'single' ? '음반 제작': j.kind === 'ad' ? '광고 촬영': j.kind === 'live' ? '공연': '커버') + ' 일정 ' + Math.max(0, j.due - this.s.day) + '일 남음');
        const recovery = Math.max(0, ... e.members.map(a => a.recoveryUntil - this.s.day));
        if (recovery) reasons.push('회복 ' + recovery + '일 남음');
        if (e.members.some(a => a.energy < 25)) reasons.push('체력 부족');
        return { allowed: reasons.length === 0, reasons };
      }
      cashPlan(days = 30) {
        const end = this.s.day + days,
        entries = this.cashForecast().filter(x => x.day <= end),
        confirmed = entries.filter(x => x.amount > 0 && x.type === '입금 확정').reduce((n, x) => n + x.amount, 0),
        conditional = entries.filter(x => x.amount > 0 && x.type !== '입금 확정').reduce((n, x) => n + x.amount, 0),
        scheduled = - entries.filter(x => x.amount < 0).reduce((n, x) => n + x.amount, 0);
        let daily = 0;
        for (const a of this.s.artists) if (a.focus !== 'rest') daily += this.has('trainer') ? 7: 10;
        for (const a of this.s.trainees) {
          const plan = Base.trainingPlans[a.trainingPlan];
          daily += plan.cost *(this.coach(a.trainingPlan).staff ? .8: 1);
        }
        const maintenance = round(daily * days);
        return {
          days,
          entries,
          confirmed: round(confirmed),
          conditional: round(conditional),
          scheduled: round(scheduled),
          maintenance,
          balance: round(this.s.cash + confirmed - scheduled - maintenance)
        };
      }
      staffComparison(id) {
        const p = D.staff.find(p => p.id === id);
        if (!p) throw Error('직원이 없습니다.');
        const current = this.s.staff.map(id => D.staff.find(p => p.id === id)).filter(x => x.kind === p.kind && x.id !== id).sort((a, b) => b.coaching - a.coaching)[0] || null;
        return { candidate: p, current };
      }
      teamImpact(key) {
        const u = this.s.units.find(u => u.key === key);
        if (!u) throw Error('팀이 없습니다.');
        return {
          name: u.name,
          jobs: this.s.jobs.filter(j => j.entity === key).map(j =>({ name: j.name, due: j.due })),
          catalog: this.s.catalog.filter(c => c.entity === key).length,
          cohesion: u.cohesion || 0
        };
      }
    }
    return CampaignGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installCampaign = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/season-data.js */
(function(root) {
  'use strict';
  const S = {
    festivals: { campus: {
      name: '청춘 캠퍼스 페스티벌',
      duration: 3,
      fee: 700,
      cost: 80,
      fame: 0,
      months:[3, 4, 5, 9, 10, 11]
    }, summer: {
      name: '블루웨이브 워터 페스티벌',
      duration: 4,
      fee: 1600,
      cost: 180,
      fame: 15,
      months:[6, 7, 8]
    }, genre: {
      name: '사운드크로스 장르 페스티벌',
      duration: 3,
      fee: 1000,
      cost: 100,
      fame: 5,
      months:[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    }
    },
    awards: {
      rookie: '신인상',
      song: '올해의 곡',
      live: '올해의 라이브',
      artist: '올해의 아티스트'
    },
    names:['루미아', '노스윈드', '오브제', '하린', '마일드블루', '라온', '네온비트', '제이든', '이든', '별하', '모노데이', '소울웨이', '레브', '유하', '블랭크', '로우키', '미온', '프리즘', '도유', '파도선', '에코룸', '나린', '루프라인', '리븐', '채온', '그루브온', '오월밤', '로아', '엔플로', '정오', '누아', '유월', '온새', '리프', '하이노트', '시온', '웨이브릿', '유니온', '레인폴', '달빛정원'],
    subtitles:['첫빛', '저녁 편지', '새로운 길', '먼 여행', '작은 약속', '파란 기억', '한낮의 꿈', '별의 시간', '너의 이야기', '다음 계절', '오래된 사진', '낯선 설렘', '고요한 순간', '첫 번째 봄', '느린 걸음', '오늘의 우리', '밤의 조각', '그날의 바람', '다시 만난 날', '마지막 페이지', '붉은 노을', '창가의 노래', '눈을 감으면', '여름의 끝', '하얀 새벽', '빛나는 마음', '비 온 뒤', '우리의 내일', '다정한 안부', '새벽 산책', '초록의 날', '너에게 가는 길'],
    titles:['빛이 머무는 곳', '너의 계절', '여름의 조각', '한 걸음', '푸른 밤', '작은 우주', '다시 시작', '도시의 온도', '눈부신 순간', '우리의 거리', '늦은 편지', '아침이 오면', '파란 약속', '숨결', '별의 궤도', '멀리서 들리는 노래']
  };
  if (typeof module !== 'undefined') module.exports = S;
  else root.SEASON_DATA = S;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/season-utils.js */
(function(root) {
  'use strict';
    const clamp =(v, a, b) => Math.max(a, Math.min(b, v)),
    round = v => Math.round(v * 100) / 100;
    function hash(text) {
      let h = 2166136261;
      for (const c of String(text)) {
        h ^= c.charCodeAt(0);
        h = Math.imul(h, 16777619);
      }
      return h >>> 0;
    }
    const calendar = day => new Date(Date.UTC(2027, 0, 1 + day));
  const utils = Object.freeze({clamp, round, hash, calendar});
  if (typeof module !== 'undefined') module.exports = utils;
  else root.SeasonUtils = utils;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/season-market.js */
(function(root) {
  'use strict';
  function install(Base, D, S) {
    const {clamp, round, hash, calendar} = typeof module !== 'undefined' ? require('./season-utils.js'): root.SeasonUtils;
    class SeasonMarket extends Base {
      releaseDay(c, owner) {
        const m = c.market,
        appeal = m.appeal,
        age = this.s.day - m.startDay,
        boost = owner === 'player' && m.fame < 20 && c.quality >= 45 && age <= 28 ? 1.15: 1;
        try {
          m.appeal = appeal * boost;
          return super.releaseDay(c, owner);
        } finally {
          m.appeal = appeal;
        }
      }
      concert(e, j, quality) {
        const result = super.concert(e, j, quality),
        fans = e.members.reduce((n, a) => n + a.fans, 0);
        if (j.budget > 300 && fans >= result.capacity * 1.5) {
          result.attendance = Math.min(result.capacity, Math.floor(result.attendance * 1.15));
          result.gross = result.attendance * result.ticket;
          const unit = j.budget <= 800 ?(e.members.length > 1 ? 1.4: 1.2):(e.members.length > 1 ? 2: 1.8);
          result.variable = round(result.attendance * unit);
          j.concert = result;
          j.factors.unshift('충분한 팬층 · 확대 공연 관객 수요 +15%');
        }
        return result;
      }
      rivalsMonth() {
        const before = new Set(this.s.rivals.flatMap(r => r.talents.filter(t => t.active).map(t => t.id)));
        super.rivalsMonth();
        if (this.s.debutYears) for (const r of this.s.rivals) for (const t of r.talents) if (t.active && !before.has(t.id) && this.s.debutYears[t.id] === undefined) this.s.debutYears[t.id] = calendar(this.s.day).getUTCFullYear();
      }
      externalRelease(uid, day, k) {
        const h = hash(uid),
        year = calendar(day).getUTCFullYear(),
        isNew = year >= 2027 && h % 7 === 0,
        artist = isNew ? 40 +(year - 2027) * 8 +(h % 8): h % S.names.length,
        level = h % 10,
        titleHash = hash(uid + ':title');
        let suffix = 0,
        name;
        do {
          name = S.titles[(titleHash + Math.floor(suffix / S.subtitles.length)) % S.titles.length] + ' — ' + S.subtitles[((titleHash >>> 8) + suffix) % S.subtitles.length];
          suffix++;
        }
        while (this.s.external.some(c => c.artist === artist && c.name === name) && suffix < 512);
        return {
          uid: 'x-' + uid,
          name,
          artist,
          artistName: isNew ?['김', '이', '박', '최', '정', '윤', '한', '서', '임', '오', '장', '신'][(year - 2027) % 12] +['민아', '지율', '도겸', '하온', '서린', '지후', '채아', '건우'][h % 8]: S.names[artist],
          debutYear: isNew ? year: 2020,
          company:['별빛뮤직', '온에어레코드', '브리즈엔터', '독립 아티스트'][artist % 4],
          startDay: day,
          base: Math.round((1800 + Math.pow(level + 1, 2) * 1450) *(0.8 +(h % 40) / 100)),
          physical: artist % 3 !== 1,
          days:[]
        };
      }
      externalCounts(c, day) {
        const age = day - c.startDay;
        if (age < 0) return { streams: 0, sales: 0 };
        const wave = .9 +(hash(c.uid + ':' + Math.floor(age / 7)) % 25) / 100,
        buzz = age >= 14 && age < 42 && hash(c.uid) % 5 === 0 ? 1.5: 1;
        return { streams: Math.floor(c.base *(Math.exp(- age / 65) * buzz + .015) * wave), sales: c.physical ? Math.floor((10 + c.base / 1800) * Math.exp(- age / 9) +(c.base / 90000) * Math.exp(- age / 65)): 0 };
      }
      tickExternal() {
        const s = this.s;
        if (s.day % 7 === 0) for (let k = 0; k < 4; k++) s.external.push(this.externalRelease(s.day + '-' + k, s.day, k));
        s.external = s.external.filter(c => s.day - c.startDay < 365).slice(- 220);
        for (const c of s.external) {
          if (c.days.at(- 1)?.day === s.day) continue;
          c.days.push({ day: s.day, ... this.externalCounts(c, s.day) });
          c.days = c.days.slice(- 14);
        }
      }
      globalReleases() {
        return [... super.allReleases().map(x =>({ ... x, external: false })), ... this.s.external.map(c =>({
          own: false,
          external: true,
          externalArtist: c.artist,
          externalDebut: c.debutYear,
          company: c.company,
          release: { name: c.name, quality: 50 +(hash(c.uid) % 40), market: {
            uid: c.uid,
            artistName: c.artistName,
            startDay: c.startDay,
            format: c.physical ? 'physical': 'digital',
            days: c.days
          }
          }
        }))];
      }
      charts(metric = 'streams', scope = 'all') {
        if (!['streams', 'sales'].includes(metric) || !['all', 'labels'].includes(scope)) throw Error('차트 종류를 확인하세요.');
        return(scope === 'labels' ? super.allReleases(): this.globalReleases()).map(row =>({ ... row, week: row.external ? row.release.market.days.filter(d => d.day > this.s.day - 7 && d.day <= this.s.day).reduce((n, d) =>({ streams: n.streams + d.streams, sales: n.sales + d.sales }), { streams: 0, sales: 0 }): this.weekStats(row.release) })).filter(row => row.week[metric] > 0).sort((a, b) => b.week[metric] - a.week[metric] || a.release.market.uid.localeCompare(b.release.market.uid));
      }
      chartPosition(uid, metric = 'streams', ranks = null) {
        const rank = ranks ? (ranks.get(uid) || 0): this.charts(metric).findIndex(r => r.release.market.uid === uid) + 1,
        h = this.s.chartHistory[metric];
        return {
          rank: rank || null,
          previous:(h.day === this.s.day ? h.previous[uid]: h.current[uid]) || null,
          best: h.best[uid] || null,
          newEntry: !!rank && !h.previous[uid]
        };
      }
      recordCharts() {
        if (this.s.day % 7 !== 0) return;
        for (const metric of['streams', 'sales']) {
          const h = this.s.chartHistory[metric];
          if (h.day === this.s.day) continue;
          h.previous = h.current;
          h.current = {};
          for (const[index, row] of this.charts(metric).entries()) {
            const uid = row.release.market.uid,
            rank = index + 1;
            h.current[uid] = rank;
            if (rank <= 100 || row.own) h.best[uid] = Math.min(h.best[uid] || Infinity, rank);
          }
          h.day = this.s.day;
          const keep = new Set([... Object.keys(h.current), ... Object.keys(h.previous), ... super.allReleases().filter(r => r.own).map(r => r.release.market.uid)]);
          for (const uid of Object.keys(h.best)) if (!keep.has(uid)) delete h.best[uid];
        }
      }

    }
    return SeasonMarket;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installSeasonMarket = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/season-schedule.js */
(function(root) {
  'use strict';
  function install(Base, D, S) {
    const {clamp, round, hash, calendar} = typeof module !== 'undefined' ? require('./season-utils.js'): root.SeasonUtils;
    class SeasonSchedule extends Base {
      reservationOverlaps(ids, start, end) {
        return this.s.engagements.some(e => e.start < end && e.due + 2 > start && e.snapshot.ids.some(id => ids.includes(id)));
      }
      busy(key) {
        const e = this.entity(key);
        return super.busy(key) || !!e && this.s.engagements.some(x => x.start <= this.s.day && x.due > this.s.day && x.snapshot.ids.some(id => e.members.some(a => a.id === id)));
      }
      productionState(j) {
        const active =(j.pauses ||[]).find(p => p.start <= this.s.day && p.end > this.s.day),
        reserved =(j.pauses ||[]).reduce((n, p) => n + Math.max(0, p.end - Math.max(this.s.day, p.start)), 0);
        return {
          paused: !!active,
          resume: active?.end ?? null,
          remaining: Math.max(0, j.due - this.s.day - reserved),
          delay: j.delayDays || 0,
          reason: active?.kind === 'festival' ? '행사 준비·출연': '광고 촬영'
        };
      }
      delayProduction(j, e) {
        if (j.due <= e.start || e.due <= j.start || !this.participantIds(j).some(id => e.snapshot.ids.includes(id))) return;
        this.pauseProduction(j, { adId: e.id, start: e.start, end: e.due, kind: 'festival' });
      }
      reconcileProduction(j, events = this.s.engagements) {
        // Dates only extend. Revisit reservations until no newly crossed pause remains.
        // delayDays retains earlier pauses even when the 60-entry display history rolls off.
        const ordered = [...events].sort((a, b) => a.start - b.start);
        const recorded = new Set((j.pauses || []).map(p => p.adId));
        let due;
        do {
          due = j.due;
          for (const e of ordered) {
            if (recorded.has(e.id)) continue;
            this.delayProduction(j, e);
            if ((j.pauses || []).some(p => p.adId === e.id)) recorded.add(e.id);
          }
        } while (j.due !== due);
        return j;
      }
      previewProduction(j, event) {
        const copy = { ...j, pauses: (j.pauses || []).map(p => ({ ...p })) };
        return this.reconcileProduction(copy, this.s.engagements.concat(event));
      }
      productionPreview(key, promotion = 'none') {
        const e = this.entity(key), plan = D.promotionPlans[promotion];
        if (!e || !plan) throw Error('제작 대상과 홍보 계획을 확인하세요.');
        const job = {kind:'single', entity:key, start:this.s.day,
          due:this.s.day + D.rules.activity.single.days + plan.days, snapshot:this.snapshot(key)};
        return this.reconcileProduction(job);
      }
      festivalPlan(id) {
        const approved = this.s.festivalOffers.find(o => o.id === Number(id));
        if (approved?.status === 'accepted' && approved.approval) return { ... approved.approval, allowed: false, reasons:['이미 출연을 확정했습니다.'] };
        const o = this.s.festivalOffers.find(x => x.id === Number(id)),
        e = o && this.entity(o.entity),
        f = o && S.festivals[o.kind],
        reasons = [];
        if (!o || o.status !== 'open' || o.expires < this.s.day) reasons.push('처리했거나 기한이 끝난 섭외입니다.');
        if (!e || e.key.startsWith('u') &&(e.status !== 'active' || e.members.length < 2)) reasons.push('활동 가능한 대상이 없습니다.');
        const ids = e?.members.map(a => a.id) ||[],
        start = o ? o.day - f.duration: 0,
        end = o?.day || 0;
        if (start < this.s.day) reasons.push('준비 기간이 부족합니다.');
        if (e?.members.some(a => a.energy < 25 || a.recoveryUntil > start)) reasons.push('체력·회복 상태를 확인하세요.');
        const jobs = this.s.jobs.filter(j => this.participantIds(j).some(id => ids.includes(id)));
        if (jobs.some(j => j.kind !== 'single' && j.due + 3 > start)) reasons.push('공연·커버·광고 일정과 겹칩니다.');
        if (this.reservationOverlaps(ids, start, end)) reasons.push('다른 행사 준비·회복 기간과 겹칩니다.');
        const productions = jobs.filter(j => j.kind === 'single' && j.due > start);
        if (productions.some(j =>(j.pauses ||[]).some(p => p.start < end && p.end > start))) reasons.push('제작 중단 일정이 겹칩니다.');
        const snapshot = e && this.snapshot(e.key),
        shares = snapshot ? this.shares(snapshot):[],
        pay = o?.pay || 0,
        payout = round(shares.reduce((n, x) => n + round(pay * x.rate), 0));
        return {
          allowed: reasons.length === 0,
          reasons:[... new Set(reasons)],
          name: f?.name || '',
          start,
          day: end,
          duration: f?.duration || 0,
          pay,
          cost: o?.cost || 0,
          net: round(pay - payout -(o?.cost || 0)),
          productions: productions.map(j =>({
            id: j.id,
            title: j.name,
            oldDue: j.due,
            newDue: this.previewProduction(j, { id: -1, start, due: end, snapshot }).due
          })),
          snapshot,
          shares
        };
      }
      createFestivalOffer(kind, key, day) {
        const f = S.festivals[kind],
        e = this.entity(key),
        month = calendar(day).getUTCMonth() + 1;
        if (!f || !e || !Number.isInteger(day) || day < this.s.day + f.duration || !f.months.includes(month)) throw Error('행사 종류·계절·날짜를 확인하세요.');
        if (e.members.reduce((n, a) => n + a.fame, 0) / e.members.length < f.fame) throw Error('행사 인지도 조건 미달입니다.');
        if (this.s.festivalOffers.some(o => o.entity === key && o.status === 'open')) throw Error('대기 중인 행사 섭외가 있습니다.');
        const id = this.id(),
        fame = e.members.reduce((n, a) => n + a.fame, 0) / e.members.length,
        pay = Math.round(f.fee + fame * 12 + Math.sqrt(e.members.reduce((n, a) => n + a.fans, 0)) * 5);
        this.s.festivalOffers.unshift({
          id,
          kind,
          entity: key,
          day,
          pay,
          cost: f.cost,
          expires: Math.min(this.s.day + 7, day - f.duration),
          status: 'open'
        });
        this.s.festivalOffers = this.s.festivalOffers.slice(0, 60);
        this.report(f.name + ' 출연 섭외', e.name + '에게 출연 요청이 왔습니다. 출연료와 준비 일정을 검토하세요.', 'info', true, { festivalOfferId: id });
        return id;
      }
      resolveFestival(id, choice) {
        return this.transaction(() => {
          const o = this.s.festivalOffers.find(x => x.id === Number(id));
          if (!o || o.status !== 'open' || o.expires < this.s.day) throw Error('현재 처리할 수 없는 섭외입니다.');
          if (!['accept', 'decline'].includes(choice)) throw Error('응답을 확인하세요.');
          if (choice === 'accept') {
            const p = this.festivalPlan(id);
            if (!p.allowed) throw Error(p.reasons.join(' '));
            const e = {
              id: this.id(),
              offerId: o.id,
              kind: o.kind,
              entity: o.entity,
              name: p.name,
              start: p.start,
              due: p.day,
              pay: p.pay,
              cost: p.cost,
              snapshot: p.snapshot,
              shares: p.shares
            };
            o.approval = {
              name: p.name,
              start: p.start,
              day: p.day,
              duration: p.duration,
              pay: p.pay,
              cost: p.cost,
              net: p.net,
              productions: p.productions
            };
            this.s.engagements.push(e);
            for (const j of this.s.jobs.filter(j => j.kind === 'single')) this.reconcileProduction(j);
            o.status = 'accepted';
            this.report('행사 출연 확정', p.name + ' · ' + p.duration + '일 준비·출연. 출연료는 행사 완료일 입금하며 약정 배분과 출연비를 차감합니다.', 'info', false);
          } else o.status = 'declined';
          for (const r of this.s.reports) if (r.festivalOfferId === o.id) {
            r.resolved = true;
            r.read = true;
            r.decision = choice;
          }
        });
      }
      adPlan(id) {
        const p = super.adPlan(id),
        r = this.s.reports.find(r => r.id === Number(id)),
        e = r && this.entity(r.entity);
        if (e && this.reservationOverlaps([... new Set(e.members.map(a => a.id).concat(p.productions.flatMap(p => this.participantIds(this.s.jobs.find(j => j.id === p.id)))))], this.s.day, p.shootingDay + 2)) {
          p.allowed = false;
          p.reasons.push('확정 행사 준비·출연 일정과 겹칩니다.');
        }
        for (const production of p.productions) {
          const j = this.s.jobs.find(j => j.id === production.id);
          const copy = { ...j, pauses: (j.pauses || []).map(p => ({ ...p })) };
          this.pauseProduction(copy, { adId: -1, start: this.s.day, end: p.shootingDay });
          production.newDue = this.reconcileProduction(copy).due;
        }
        return p;
      }
      startProject(key, kind, ... args) {
        const e = this.entity(key),
        ids = e?.members.map(a => a.id) ||[];
        if (kind !== 'single' && this.reservationOverlaps(ids, this.s.day, this.s.day +(D.rules.activity[kind]?.days || 0) + 3)) throw Error('확정 행사 일정과 겹칩니다.');
        super.startProject(key, kind, ... args);
        if (kind === 'single') {
          const j = this.s.jobs.at(- 1);
          this.reconcileProduction(j);
        }
      }
      activityAvailability(key) {
        const p = super.activityAvailability(key),
        e = this.entity(key);
        if (e && this.s.engagements.some(x => x.start <= this.s.day && x.due > this.s.day && x.snapshot.ids.some(id => e.members.some(a => a.id === id)))) p.reasons.push('행사 준비·출연 중');
        p.allowed = p.reasons.length === 0;
        return p;
      }
      projectAvailability(key, kind) {
        const p = this.activityAvailability(key),
        e = this.entity(key);
        if (e && kind !== 'single' && this.reservationOverlaps(e.members.map(a => a.id), this.s.day, this.s.day +(D.rules.activity[kind]?.days || 0) + 3)) p.reasons.push('확정 행사 준비·출연·회복 기간과 겹칩니다.');
        p.allowed = p.reasons.length === 0;
        return p;
      }
      settleReceivables() {
        super.settleReceivables();
        if (!this.s.engagements) return;
        const due = this.s.engagements.filter(e => e.due <= this.s.day);
        this.s.engagements = this.s.engagements.filter(e => e.due > this.s.day);
        for (const e of due) this.finishFestival(e);
      }
      finishFestival(e) {
        const entity = this.projectEntity({ entity: e.entity, snapshot: e.snapshot }),
        members = entity?.members ||[];
        const skill = members.length ? members.reduce((n, a) => n +(a.stats[5] + a.stats[6]) / 2, 0) / members.length: 40,
        energy = members.length ? members.reduce((n, a) => n + a.energy, 0) / members.length: 50,
        quality = clamp(Math.round(skill * .7 + energy * .2 +(hash(e.id + ':festival') % 11)), 15, 99),
        fans = Math.round((80 + quality * 3) *(e.kind === 'summer' ? 1.6: 1)),
        share = round(e.shares.reduce((n, x) => n + round(e.pay * x.rate), 0));
        this.receive(e.pay, '행사 출연료: ' + e.name, e.shares, e.entity, 'festival_fee');
        this.change(- e.cost, '행사 출연비: ' + e.name, true, { kind: 'festival_cost' });
        for (const a of members) {
          a.fans += Math.floor(fans / Math.max(1, members.length));
          a.fame = clamp(a.fame + quality / 40, 0, 100);
          a.energy = Math.max(0, a.energy - 12);
          a.recoveryUntil = Math.max(a.recoveryUntil, this.s.day + 2);
        }
        const u = this.s.units.find(u => u.key === e.entity);
        if (u) {
          u.fans += Math.round(fans * .6);
          u.fame = clamp(u.fame + quality / 40, 0, 100);
        }
        this.s.reputation = clamp(this.s.reputation + quality / 100, 0, 100);
        const record = {
          id: e.id,
          day: this.s.day,
          entity: e.entity,
          name: e.name,
          artist: e.snapshot.name,
          ids: e.snapshot.ids,
          quality,
          fans,
          attendance: Math.floor((e.kind === 'summer' ? 12000: e.kind === 'campus' ? 4000: 6000) *(.35 + quality / 200)),
          net: round(e.pay - share - e.cost)
        };
        this.s.festivalHistory.push(record);
        this.s.festivalHistory = this.s.festivalHistory.slice(- 100);
        this.addLiveStat('p:' + e.entity, e.snapshot.name, true, e.snapshot.ids, quality, record.attendance);
        this.report('행사 출연 완료 · ' + e.name, e.snapshot.name + ' · 무대 반응 ' + quality + ' / 새로운 팬 ' + fans + '명 / 회사 실수령 ' + record.net + '만 원. 중단한 제작은 재개합니다.', 'result', false, { festivalResultId: e.id });
      }
      cashForecast() {
        const rows = super.cashForecast();
        if (this.s.engagements) for (const e of this.s.engagements) rows.push({
          day: e.due,
          label: e.name + ' (출연 완료 조건·비용 차감)',
          amount: round(e.pay - e.shares.reduce((n, x) => n + round(e.pay * x.rate), 0) - e.cost),
          type: '입금 예정'
        });
        return rows.sort((a, b) => a.day - b.day);
      }
      reportState(r) {
        if (r.festivalOfferId) {
          const o = this.s.festivalOffers.find(o => o.id === r.festivalOfferId);
          if (!o || o.status === 'expired' || o.expires < this.s.day && o.status === 'open') return { status: 'expired', label: '기한 종료', needsDecision: false };
          return o.status === 'open' ? {
            status: 'decision',
            label: '결정 필요',
            needsDecision: true,
            expires: o.expires
          }
          : { status: 'done', label: o.status === 'declined' ? '거절 완료': '출연 확정', needsDecision: false };
        }
        return super.reportState(r);
      }
      get pending() {
        const rows = super.pending;
        if (this.s.seasonVersion) for (const r of this.s.reports) if (!r.read &&(r.awardYear || r.festivalResultId) && !rows.includes(r)) rows.push(r);
        return rows;
      }
      reportCategory(r) {
        return r.festivalOfferId || r.festivalResultId ? 'activity': super.reportCategory(r);
      }

    }
    return SeasonSchedule;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installSeasonSchedule = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/season-awards.js */
(function(root) {
  'use strict';
  function install(Base, D, S) {
    const {clamp, round, hash, calendar} = typeof module !== 'undefined' ? require('./season-utils.js'): root.SeasonUtils;
    class SeasonAwards extends Base {
      sign(id, ... args) {
        super.sign(id, ... args);
        if (this.artist(id) && this.s.debutYears && this.s.debutYears[id] === undefined) this.s.debutYears[id] = D.roster[id].career ? 2020: calendar(this.s.day).getUTCFullYear();
      }
      debut(id, ... args) {
        super.debut(id, ... args);
        if (this.s.debutYears[id] === undefined) this.s.debutYears[id] = calendar(this.s.day).getUTCFullYear();
      }
      stat(key, name, own, ids = [], debut = 2020) {
        const stats = this.s.yearStats;
        if (!stats[key]) stats[key] = {
          key,
          name,
          own,
          ids:[... ids],
          debut,
          streams: 0,
          sales: 0,
          live: 0,
          liveCount: 0,
          quality: 0,
          releaseId: null
        };
        return stats[key];
      }
      addLiveStat(key, name, own, ids, quality, attendance) {
        const stat = this.stat(key, name, own, ids, ids.length ? Math.min(... ids.map(id => this.s.debutYears[id] ?? 2020)): 2020);
        stat.live += Math.round(attendance * Math.max(0, quality) / 100);
        stat.liveCount++;
        stat.quality += quality;
      }
      recordYear() {
        for (const row of this.globalReleases()) {
          const c = row.release,
          m = c.market,
          day = m.days.at(- 1);
          if (!day || day.day !== this.s.day) continue;
          const actor = row.external ? 'x:' + row.externalArtist: row.own ? 'p:' + c.entity: 'r:' + m.owner + ':' + m.ids.join('-'),
          ids = m.ids ||[],
          debut = row.own ?(ids.length ? Math.min(... ids.map(id => this.s.debutYears[id] ?? 2020)): 2020): row.external ? row.externalDebut:(ids.length ? Math.min(... ids.map(id => this.s.debutYears[id] ?? 2020)): 2020);
          const person = this.stat(actor, m.artistName, row.own, ids, debut),
          song = this.stat('song:' + m.uid, c.name, row.own, ids, debut);
          song.artist = m.artistName;
          song.releaseId = m.uid;
          song.streams += day.streams;
          song.sales += day.sales;
          person.streams += day.streams;
          person.sales += day.sales;
        }
        // External/rival live activity is an inexpensive monthly model, independent of player growth.
        if (this.s.day % 30 === 0) {
          for (const r of this.s.rivals) {
            if (r.lastAction?.includes('공연')) {
              const active = r.talents.filter(t => t.active),
              ids =(r.type === 'rap' ? active.slice(0, 1): active.slice(0, 5)).map(t => t.id),
              name = ids.length === 1 ? D.roster[ids[0]].name: r.name + ' 프로젝트팀',
              quality = active.reduce((n, t) => n + t.skill, 0) / Math.max(1, active.length);
              this.addLiveStat('r:r' + r.id + ':' + ids.join('-'), name, false, ids, quality, Math.min(700, Math.floor(r.fans * .12 + quality * 2)));
            }
          }
          for (let a = 0; a < S.names.length; a++) {
            const quality = 55 + hash('live' + a) % 35;
            this.addLiveStat('x:' + a, S.names[a], false, [], quality, 100 + hash('attendance' + a) % 3000);
          }
        }
      }
      awardScore(stat, key) {
        if (key === 'song') return stat.streams + stat.sales * 120;
        if (key === 'live') return stat.live;
        if (key === 'rookie') return stat.streams + stat.sales * 120 + stat.live * 30;
        return stat.streams + stat.sales * 120 + stat.live * 80;
      }
      nominateAwards() {
        const year = this.s.seasonYear;
        if (this.s.awardHistory.some(a => a.year === year)) return;
        const categories = Object.keys(S.awards).map(key => {
          const nominees = Object.values(this.s.yearStats).filter(x =>(key === 'song' ? x.key.startsWith('song:'): !x.key.startsWith('song:')) &&(key !== 'rookie' || x.debut === year) &&(key !== 'live' || x.liveCount > 0) && this.awardScore(x, key) > 0).sort((a, b) => this.awardScore(b, key) - this.awardScore(a, key) || a.key.localeCompare(b.key)).slice(0, 5).map(x =>({
            key: x.key,
            name: x.name,
            artist: x.artist || x.name,
            own: x.own,
            ids:[... x.ids],
            releaseId: x.releaseId
          }));
          return { key, nominees, winner: null };
        });
        this.s.awardHistory.push({
          year,
          since: this.s.seasonSince,
          nominationDay: this.s.day,
          resultDay: null,
          categories
        });
        this.s.awardHistory = this.s.awardHistory.slice(- 10);
        this.report(year + ' NEXT MUSIC AWARDS 후보 발표', '올해 기록된 판매·재생과 무대 성과로 후보를 선정했습니다. 12월 28일 결과를 발표합니다. 이전 저장에서 기록되지 않은 과거 성과는 소급하지 않습니다.', 'info', true, { awardYear: year });
      }
      finishAwards() {
        this.nominateAwards();
        const award = this.s.awardHistory.find(a => a.year === this.s.seasonYear);
        if (award.resultDay !== null) return;
        for (const category of award.categories) {
          const ranked = category.nominees.map(n =>({ ... n, score: this.awardScore(this.s.yearStats[n.key] || { streams: 0, sales: 0, live: 0 }, category.key) *(0.97 +(hash(award.year + ':' + category.key + ':' + n.key) % 7) / 100) })).sort((a, b) => b.score - a.score || a.key.localeCompare(b.key));
          if (!ranked.length) continue;
          const { score, ... winner } = ranked[0];
          category.winner = winner;
          if (winner.own) {
            this.s.reputation = clamp(this.s.reputation + 2, 0, 100);
            for (const id of winner.ids) {
              const a = this.artist(id);
              if (a) a.fame = clamp(a.fame + 3, 0, 100);
            }
            this.remember(winner.ids, 'award', award.year + ' ' + S.awards[category.key] + ' 수상');
            this.moment('award-' + award.year + '-' + category.key, S.awards[category.key] + ' 수상', winner.name + ' · 한 해의 활동이 인정받았습니다.\n“함께해 주신 분들 덕분이에요. 다음 무대도 기대해 주세요.”', winner.ids);
          } else if (winner.key.startsWith('r:')) {
            const rid = Number(winner.key.split(':')[1].slice(1)),
            r = this.s.rivals.find(r => r.id === rid);
            if (r) r.reputation = clamp(r.reputation + 2, 0, 100);
          }
        }
        award.resultDay = this.s.day;
        const own = Object.values(this.s.yearStats).filter(x => x.own && !x.key.startsWith('song:'));
        award.summary = { streams: own.reduce((n, x) => n + x.streams, 0), sales: own.reduce((n, x) => n + x.sales, 0), live: own.reduce((n, x) => n + x.liveCount, 0) };
        this.report(award.year + ' NEXT MUSIC AWARDS 결과', award.categories.map(c => S.awards[c.key] + ' · ' +(c.winner ? c.winner.name + ' / ' + c.winner.artist: '해당 후보 없음')).join('\n') + '\n인지도·평판 및 수상 이력 반영. 상금은 없습니다.', 'info', true, { awardYear: award.year });
      }

    }
    return SeasonAwards;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installSeasonAwards = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/season.js */
(function(root) {
  'use strict';
  function install(Base, D, S) {
    const {clamp, round, hash, calendar} = typeof module !== 'undefined' ? require('./season-utils.js'): root.SeasonUtils;
    const Market = (typeof module !== 'undefined' ? require('./season-market.js'): root.installSeasonMarket)(Base, D, S);
    const Schedule = (typeof module !== 'undefined' ? require('./season-schedule.js'): root.installSeasonSchedule)(Market, D, S);
    const Awards = (typeof module !== 'undefined' ? require('./season-awards.js'): root.installSeasonAwards)(Schedule, D, S);
    class SeasonGame extends Awards {
      upgrade() {
        super.upgrade();
        const s = this.s;
        if (!s) return;
        if (s.seasonVersion === 1) {
          // Repair still-running v0.8.0 productions once without touching completed releases.
          for (const j of s.jobs.filter(j => j.kind === 'single')) this.reconcileProduction(j);
          return;
        }
        s.seasonVersion = 1;
        s.seasonSince = s.day;
        s.festivalOffers = [];
        s.engagements = [];
        s.festivalHistory = [];
        s.debutYears = {};
        s.seasonYear = calendar(s.day).getUTCFullYear();
        s.yearStats = {};
        s.awardHistory = [];
        s.chartHistory = { streams: {
          day: null,
          current: {},
          previous: {},
          best: {}
        }, sales: {
          day: null,
          current: {},
          previous: {},
          best: {}
        }
        };
        s.external = [];
        for (const a of[... s.artists, ... s.departed]) s.debutYears[a.id] = D.roster[a.id].career ? 2020: calendar(a.signed).getUTCFullYear();
        for (const rival of s.rivals) for (const t of rival.talents) if (t.active && s.debutYears[t.id] === undefined) s.debutYears[t.id] = 2020;
        for (let k = 0; k < 180; k++) s.external.push(this.externalRelease('initial-' + k, s.day -(k % 75), k));
        for (const c of s.external) for (let day = s.day - 6; day <= s.day; day++) if (day >= c.startDay) c.days.push({ day, ... this.externalCounts(c, day) });
      }
      finishSeason(j) {
        super.finishCampaign(j);
        if (j.kind === 'live' && j.concert) this.addLiveStat('p:' + j.entity, j.snapshot.name, true, j.snapshot.ids, this._lastQuality || 0, j.concert.attendance);
      }
      advanceSeason() {
        const s = this.s,
        year = calendar(s.day + 1).getUTCFullYear();
        if (year !== s.seasonYear) {
          s.seasonYear = year;
          s.yearStats = {};
        }
        const reports = new Set(s.reports.map(r => r.id));
        this.advanceEvolution();
        this.tickExternal();
        this.recordYear();
        this.recordCharts();
        for (const o of s.festivalOffers) if (o.status === 'open' && o.expires < s.day) o.status = 'expired';
        if (s.day % 21 === 0) {
          const month = calendar(s.day + 14).getUTCMonth() + 1;
          for (const e of this.entities) {
            if (s.festivalOffers.some(o => o.entity === e.key && o.status === 'open')) continue;
            const eligible = Object.entries(S.festivals).filter(([k, f]) => f.months.includes(month) && e.members.reduce((n, a) => n + a.fame, 0) / e.members.length >= f.fame);
            if (eligible.length) {
              const[kind] = eligible[hash(s.day + e.key) % eligible.length];
              this.createFestivalOffer(kind, e.key, s.day + 14);
              break;
            }
          }
        }
        const date = calendar(s.day);
        if (date.getUTCMonth() === 11 && date.getUTCDate() >= 1 && !s.awardHistory.some(a => a.year === s.seasonYear)) this.nominateAwards();
        if (date.getUTCMonth() === 11 && date.getUTCDate() >= 28) this.finishAwards();
        const summary = s.daySummaries.at(- 1);
        if (summary?.day === s.day) {
          summary.newReports = s.reports.filter(r => !reports.has(r.id)).length;
          summary.festivals = s.festivalHistory.filter(e => e.day === s.day).length;
        }
        return this.pending.length;
      }
    }
    return SeasonGame;
  }
  if (typeof module !== 'undefined') module.exports = install;
  else root.installSeason = install;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/game.js */
(function(root) {
  const D = typeof module !== 'undefined' ? require('./evolution-data.js'): root.DATA;
  class Game {
    constructor(state) {
      this.s = state || null;
    }
    newGame(company, boss) {
      this.s = {
        version: 1,
        company,
        boss,
        day: 0,
        cash: 30000,
        seed: Math.floor(Math.random() * 999999) + 1,
        artists:[],
        units:[],
        staff:[],
        jobs:[],
        candidates:[],
        reports:[],
        ledger:[],
        history:[],
        catalog:[],
        loans:[],
        reputation: 0,
        releases: 0,
        totalRevenue: 0,
        monthIn: 0,
        monthOut: 0,
        lastMonth: null,
        policy: 'balanced',
        serial: 0
      };
      this.report('회사 설립을 축하드립니다', `${boss} 대표님, ${company}의 첫날입니다. 캐스팅에서 오디션이나 발굴을 지시해 주세요. 초기 자금은 3억 원입니다. 기본 실장이 실무를 맡으며, 전문 직원과 외주를 활용할 수 있습니다.`, 'welcome', true);
      this.log('회사를 설립했습니다.');
      return this.s;
    }
    // Every user action and day has one commit boundary. Failed work cannot be saved.
    transaction(action) {
      if (this._transactionDepth) return action();
      const state = JSON.parse(JSON.stringify(this.s)),
      own = Object.fromEntries(Object.entries(this).filter(([key]) => key !== 's'));
      this._transactionDepth = 1;
      try {
        const result = action();
        const validate = typeof module !== 'undefined' ? require('./state.js'): root.validState;
        if (validate && !validate(this.s)) throw Error('처리 결과의 저장 검증에 실패했습니다. 변경 전 상태로 복원했습니다.');
        return result;
      } catch (error) {
        for (const key of Object.keys(this)) if (key !== 's' && !Object.hasOwn(own, key)) delete this[key];
        Object.assign(this, own);
        this.s = state;
        throw error;
      } finally {
        this._transactionDepth = 0;
      }
    }
    nextDay(options = {}) {
      return options.transactional === false ? this.advanceSeason(): this.transaction(() => this.advanceSeason());
    }
    finish(job) {
      return this.finishSeason(job);
    }
    contractQuote(id, offer = 'balanced') {
      const d = D.roster[Number(id)],
      terms = D.terms[offer];
      if (!d || !terms) throw Error('계약 후보와 제안서를 확인하세요.');
      const base = d.trainee ? D.rules.traineeFee: terms.fee,
      extra = d.career ? Math.round(250 + d.priorFame * 12): 0;
      return { base, extra, total: base + extra };
    }
    rng() {
      let s = this.s;
      s.seed =(s.seed * 1664525 + 1013904223) >>> 0;
      return s.seed / 4294967296;
    }
    id() {
      return++ this.s.serial;
    }
    report(title, body, kind = 'info', important = false, extra = {}) {
      this.s.reports.unshift({
        id: this.id(),
        day: this.s.day,
        title,
        body,
        kind,
        important,
        read: false,
        resolved: false,
        ... extra
      });
      this.s.reports = this.s.reports.slice(0, 120);
    }
    log(text) {
      this.s.history.unshift({ day: this.s.day, text });
      this.s.history = this.s.history.slice(0, 200);
    }
    change(amount, label, operating = true, meta = {}) {
      if (!Number.isFinite(amount)) throw Error('거래 금액이 올바르지 않습니다.');
      let s = this.s;
      s.cash = Math.round((s.cash + amount) * 100) / 100;
      s.ledger.unshift({
        day: s.day,
        amount: Math.round(amount * 100) / 100,
        label,
        kind: meta.kind ||(amount < 0 ? 'expense': 'income')
      });
      s.ledger = s.ledger.slice(0, 350);
      if (amount > 0) {
        s.monthIn += amount;
        if (operating) s.totalRevenue += amount;
      } else s.monthOut -= amount;
    }
    spend(n, label, meta = {}) {
      if (!Number.isFinite(n) || n < 0) throw Error('지출 금액이 올바르지 않습니다.');
      if (this.s.cash < n) throw Error('자금이 부족합니다. 재정에서 지출과 대출을 확인하세요.');
      this.change(- n, label, true, meta);
    }
    get stage() {
      return this.s.releases >= 6 && this.s.reputation >= 45 ? 3: this.s.releases >= 2 ? 2: 1;
    }
    get capacity() {
      return 6 + this.s.staff.length * 2;
    }
    get fixed() {
      return 800 + this.s.staff.reduce((n, id) => n + D.staff.find(x => x.id === id).salary, 0);
    }
    has(id) {
      return this.s.staff.includes(id);
    }
    get pending() {
      return this.s.reports.filter(r => r.important && !r.read && !r.resolved);
    }
    get loanLimit() {
      return Math.min(20000, 5000 + Math.floor(this.s.totalRevenue * .3) + this.s.releases * 500);
    }
    get debt() {
      return this.s.loans.reduce((n, x) => n + x.remaining, 0);
    }
    artist(id) {
      return this.s.artists.find(x => x.id === + id);
    }
    entity(key) {
      if (typeof key !== 'string') return null;
      if (key.startsWith('u')) {
        let u = this.s.units.find(u => u.key === key);
        if (!u) return null;
        return { ... u, members: u.ids.map(id => this.artist(id)) };
      }
      let a = this.artist(Number(key));
      return a ? {
        key: String(a.id),
        name: D.roster[a.id].name,
        type: D.roster[a.id].type,
        members:[a]
      }
      : null;
    }
    get entities() {
      let grouped = this.s.units.flatMap(u => u.ids);
      return [... this.s.units.map(u => this.entity(u.key)), ... this.s.artists.filter(a => !grouped.includes(a.id)).map(a => this.entity(String(a.id)))];
    }
    busy(key) {
      let e = this.entity(key);
      if (!e) return false;
      return this.s.jobs.some(j => {
        let ids = j.snapshot?.ids || this.entity(j.entity)?.members.map(a => a.id) ||[];
        return ids.some(id => e.members.some(a => a.id === id));
      });
    }
    mean(e, index) {
      return e.members.reduce((n, a) => n + a.stats[index], 0) / e.members.length;
    }
    startCasting(method, type) {
      if (!['audition', 'scout'].includes(method) || !['any', 'idol', 'band', 'rap'].includes(type)) throw Error('모집 설정을 확인하세요.');
      if (this.s.jobs.some(j => j.kind === 'casting')) throw Error('현재 인재를 모집 중입니다. 보고를 기다려 주세요.');
      if (!D.roster.some(a => !this.artist(a.id) &&(type === 'any' || a.type === type))) throw Error('이 분야의 모든 후보와 계약했습니다. 다른 분야를 찾아보세요.');
      let days = method === 'audition' ? 7: 10;
      if (this.has('casting')) days -= Math.max(1, Math.round(this.staffPower('casting') * 3));
      this.spend(method === 'audition' ? 500: 200, method === 'audition' ? '오디션 개최': '인재 발굴');
      this.s.jobs.push({
        id: this.id(),
        kind: 'casting',
        name: method === 'audition' ? '공개 오디션': '인재 발굴',
        type,
        method,
        start: this.s.day,
        due: this.s.day + days
      });
      this.log('첫 만남을 위한 인재 모집을 시작했습니다.');
    }
    sign(id) {
      let c = this.s.candidates.find(x => x.id === + id);
      if (!c || c.expires < this.s.day || this.artist(id)) throw Error('현재 계약 가능한 후보가 아닙니다.');
      if (this.s.artists.length >= this.capacity) throw Error('담당 인력이 부족합니다. 직원을 채용해 관리 인원을 늘려 주세요.');
      this.spend(200, '아티스트 계약 준비비');
      this.s.artists.push({
        id: + id,
        stats:[... D.roster[id].stats],
        energy: 95,
        stress: 10,
        trust: 70,
        fans: 50 + Math.floor(this.rng() * 120),
        fame: 2,
        focus: 'balanced',
        contract: this.s.day + 365
      });
      this.s.candidates = this.s.candidates.filter(c => c.id !== + id);
      this.report(`${D.roster[id].name}, 첫 인사를 전합니다`, `${this.s.boss} 대표님, 함께 좋은 음악을 만들고 싶습니다. 아티스트 화면에서 육성 방향을 정하고 프로젝트를 시작해 주세요.`, 'info', true);
      this.log(`${D.roster[id].name} 영입`);
    }
    evaluate(id) {
      let c = this.s.candidates.find(x => x.id === + id);
      if (!c || c.evaluated) throw Error('평가할 후보가 없습니다.');
      this.spend(50, '후보 추가 평가');
      c.evaluated = true;
    }
    formUnit(name, ids) {
      if (!name.trim() || ids.length < 2 || ids.length > 5) throw Error('팀 이름과 멤버 2~5명을 선택하세요.');
      ids = [... new Set(ids.map(Number))];
      if (ids.length < 2 || ids.length > 5) throw Error('서로 다른 멤버 2~5명을 선택하세요.');
      let members = ids.map(id => this.artist(id));
      if (members.some(a => !a) || new Set(ids.map(id => D.roster[id].type)).size > 1) throw Error('같은 분야의 소속 아티스트로 구성하세요.');
      if (ids.some(id => this.s.units.some(u => u.ids.includes(id)) || this.busy(String(id)))) throw Error('팀에 소속되었거나 활동 중인 멤버가 있습니다.');
      this.s.units.push({
        key: 'u' + this.id(),
        name: name.trim().slice(0, 20),
        ids,
        type: D.roster[ids[0]].type
      });
      this.log(`${name.trim()} 결성`);
    }
    setFocus(id, focus) {
      let a = this.artist(id);
      if (!a || !['balanced', 'creative', 'stage', 'rest'].includes(focus)) throw Error('육성 방향을 확인하세요.');
      a.focus = focus;
    }
    hire(id) {
      let p = D.staff.find(x => x.id === id);
      if (!p || p.level > this.stage || this.has(id)) throw Error('아직 채용할 수 없는 직무입니다.');
      this.spend(p.fee, '직원 채용: ' + p.name);
      this.s.staff.push(id);
      this.log(`${p.name} ${p.role} 채용`);
    }
    fire(id) {
      if (!this.has(id)) throw Error('재직 중이 아닙니다.');
      let p = D.staff.find(x => x.id === id);
      this.spend(p.salary, '퇴직 정산: ' + p.name);
      this.s.staff = this.s.staff.filter(x => x !== id);
      this.log(`${p.name} 퇴사`);
    }
    startProject(key, kind, title, budget, concept) {
      let e = this.entity(key);
      if (!e) throw Error('아티스트를 선택하세요.');
      if (this.busy(key)) throw Error('이미 프로젝트나 광고 일정이 진행 중입니다.');
      if (!['single', 'live', 'cover'].includes(kind)) throw Error('프로젝트를 선택하세요.');
      if (e.members.some(a => a.energy < 25)) throw Error('컨디션 회복이 먼저입니다. 육성 방향을 휴식으로 바꾸세요.');
      let b = Number(budget);
      if (!Number.isFinite(b) || b < D.rules.activity[kind].min || b > D.rules.activity[kind].max) throw Error('예산 범위를 확인하세요.');
      this.spend(b, `${e.name} ${title||'새 프로젝트'} 제작비`, { kind: 'production' });
      let days = D.rules.activity[kind].days;
      this.s.jobs.push({
        id: this.id(),
        kind,
        entity: key,
        name:(title ||({ single: '첫 번째 싱글', live: '라이브 공연', cover: '커버 영상' }[kind])).trim().slice(0, 30),
        budget: b,
        concept:['balanced', 'public', 'creative'].includes(concept) ? concept: 'balanced',
        start: this.s.day,
        due: this.s.day + days
      });
      this.log(`${e.name} · ${kind==='single'?'싱글':kind==='live'?'공연':'커버'} 준비 시작`);
    }
    borrow(amount) {
      let n = Number(amount);
      if (![1000, 3000, 5000].includes(n) || this.debt + n > this.loanLimit) throw Error('대출 가능 한도를 확인하세요.');
      this.s.loans.push({
        id: this.id(),
        remaining: n,
        principal: n,
        payment: n / 12,
        rate: .006,
        due: this.s.day + 30,
        missed: 0
      });
      this.change(n, '운영자금 대출 실행', false, { kind: 'loan' });
      this.log(`${n}만 원 대출 실행`);
    }
    repay(id) {
      let l = this.s.loans.find(x => x.id === + id);
      if (!l) throw Error('대출이 없습니다.');
      this.spend(l.remaining, '대출 조기 상환', { kind: 'loan_repayment' });
      this.s.loans = this.s.loans.filter(x => x !== l);
    }
    renewalCost(a) {
      return Math.round((300 + Math.floor(a.fame * 10)) *(1 +(70 - a.trust) / 200));
    }
    renew(id) {
      let a = this.artist(id);
      if (!a || a.contract - this.s.day > 60) throw Error('계약 만료 60일 전부터 재계약할 수 있습니다.');
      this.spend(this.renewalCost(a), '아티스트 재계약');
      a.contract = Math.max(this.s.day, a.contract) + 365;
      a.trust = Math.min(100, a.trust + 10);
      this.log(`${D.roster[id].name} 재계약`);
    }
    resolve(id, choice) {
      let r = this.s.reports.find(x => x.id === + id);
      if (!r || r.resolved) throw Error('이미 처리된 안건입니다.');
      if (r.kind === 'ad') {
        if (choice === 'accept') {
          let e = this.entity(r.entity);
          if (!e || this.busy(r.entity)) throw Error('진행 중인 활동을 마친 후 수락할 수 있습니다.');
          if (this.s.day > r.expires) throw Error('제안 기한이 지났습니다.');
          this.change(r.pay * .4, '광고 계약 선금');
          this.s.jobs.push({
            id: this.id(),
            kind: 'ad',
            entity: r.entity,
            name: r.brand + ' 광고 촬영',
            pay: r.pay * .6,
            start: this.s.day,
            due: this.s.day + 5
          });
        } else if (choice !== 'decline') throw Error('선택을 확인하세요.');
      } else if (r.kind === 'event') {
        let e = this.entity(r.entity);
        if (choice === 'invest') {
          this.spend(150, '아티스트 지원');
          e?.members.forEach(a => {
            a.trust = Math.min(100, a.trust + 8);
            a.stress = Math.max(0, a.stress - 15);
          });
        } else if (choice === 'rest') {
          e?.members.forEach(a => {
            a.energy = Math.min(100, a.energy + 15);
            a.stress = Math.max(0, a.stress - 8);
          });
        } else throw Error('선택을 확인하세요.');
      }
      r.resolved = true;
      r.read = true;
    }
    finishCore(j) {
      let s = this.s;
      if (j.kind === 'casting') {
        let pool = D.roster.filter(a => !this.artist(a.id) &&(j.type === 'any' || a.type === j.type));
        for (let i = pool.length - 1; i > 0; i--) {
          let k = Math.floor(this.rng() *(i + 1));
          [pool[i], pool[k]] = [pool[k], pool[i]];
        }
        let picks = pool.slice(0, j.method === 'audition' ? 6: 3);
        s.candidates = s.candidates.filter(c => c.expires >= s.day);
        picks.forEach(a => {
          if (!s.candidates.some(c => c.id === a.id)) s.candidates.push({ id: a.id, evaluated: this.has('casting'), expires: s.day + 30 });
        });
        this.report('새로운 영입 후보가 도착했습니다', `${picks.length}명의 후보를 찾았습니다. 캐스팅에서 평가와 계약을 진행하세요. 제안은 30일간 유효합니다. 한 명당 계약 준비비는 200만 원입니다.`, 'casting', true);
        return;
      }
      let e = this.projectEntity ? this.projectEntity(j): this.entity(j.entity);
      if (!e) return;
      let fan = e.members.reduce((n, a) => n + a.fans, 0),
      fame = e.members.reduce((n, a) => n + a.fame, 0) / e.members.length;
      let score = e.type === 'idol' ?(this.mean(e, 0) + this.mean(e, 2) + this.mean(e, 5)) / 3: e.type === 'band' ?(this.mean(e, 3) + this.mean(e, 4) + this.mean(e, 7)) / 3:(this.mean(e, 1) + this.mean(e, 4) + this.mean(e, 5)) / 3;
      let energy = e.members.reduce((n, a) => n + a.energy, 0) / e.members.length;
      let stress = e.members.reduce((n, a) => n + a.stress, 0) / e.members.length,
      trust = e.members.reduce((n, a) => n + a.trust, 0) / e.members.length;
      let synergy = e.members.length > 1 ? this.mean(e, 7) / 100 * Math.min(10, (e.members.length - 1) * 3): 0;
      let investment = { single: 18, live: 12, cover: 10 }[j.kind] || 0;
      let cap = j.albumType ? 7000 * root.ActivityData.albums[j.albumType].factor : j.venue ? root.ActivityData.venues[j.venue].cost : ({ single: 7000, live: 1500, cover: 600 }[j.kind] || 1);
      let quality = Math.max(15, Math.min(99, score * .63 + energy * .17 +(this.has('producer') ? 3 + this.staffPower('producer') * 6: 0) +((j.budget || 0) / cap) * investment + synergy +(trust - 70) * .08 - stress * .10 + this.rng() * 15));
      j.factors = [];
      if (stress > 20) j.factors.push('스트레스 ' + Math.round(stress) + ' · 완성도 기여 -' +(stress * .10).toFixed(1));
      if (energy < 50) j.factors.push('완료 당시 평균 체력 ' + Math.round(energy) + ' · 체력 기여 ' +(energy * .17).toFixed(1));
      if (synergy > 0) j.factors.push('팀 협업 · 완성도 기여 +' + synergy.toFixed(1));
      j.factors.push('제작 투자 · 완성도 기여 +' +(((j.budget || 0) / cap) * investment).toFixed(1));
      this._lastQuality = quality;
      if (j.kind === 'ad') {
        this.receive(j.pay, '광고 잔금: ' + e.name, j.shares ||[], e.key, 'ad_balance');
        e.members.forEach(a => {
          a.fame = Math.min(100, a.fame + 2);
          a.energy = Math.max(0, a.energy - 12);
        });
        this.report('광고 촬영을 마쳤습니다', `${e.name}의 ${j.name}이 완료되어 잔금 ${Math.round(j.pay).toLocaleString()}만 원을 받았습니다.`, 'result', false);
        this.log(e.name + ' 광고 촬영 완료');
        return;
      }
      let fans = this.newFans(e, j, quality, fan);
      let income = 0;
      if (j.kind === 'single') {
        s.catalog.push({
          id: this.id(),
          entity: e.key,
          name: j.name,
          quality,
          age: 0,
          revenue: 0,
          fanBase: fan,
          concept: j.concept,
          shares: j.shares ||[],
          ownerName: e.name
        });
        s.releases++;
        if (j.concept === 'creative') e.members.forEach(a => a.trust = Math.min(100, a.trust + 5));
        s.reputation = Math.min(100, s.reputation + quality / 12);
      } else if (j.kind === 'live') {
        let live = this.concert(e, j, quality);
        income = live.gross;
        this.receive(income, '공연 정산: ' + j.name, j.shares ||[], e.key, 'concert_settlement');
        this.change(- live.variable, '공연 현장비: ' + j.name);
      } else {
        s.reputation = Math.min(100, s.reputation + 1);
      }
      e.members.forEach(a => {
        a.fans += Math.floor(fans / e.members.length);
        a.fame = Math.min(100, a.fame +({ single: 5, live: 2, cover: 1 }[j.kind]) *(1 - a.fame / 110) *(j.entity.startsWith('u') ? .35: 1));
        a.energy = Math.max(0, a.energy -({ single: 18, live: 20, cover: 8 }[j.kind]));
      });
      this.report(j.kind === 'single' ? '새로운 음악이 세상에 나왔습니다': '활동 결과가 도착했습니다', `${e.name} · 「${j.name}」\n완성도 ${Math.round(quality)} / 신규 팬 ${fans.toLocaleString()}명${income?' / 정산 '+income.toLocaleString()+'만 원':''}.\n${j.kind==='single'?'음원·음반 수익은 발매 후 매주 정산됩니다. ':''}${quality>=75?'실력과 준비가 좋은 반응으로 이어졌습니다. 후속 활동으로 관심을 이어가세요.':'아직 넓은 대중에게 닿지는 못했습니다. 육성과 소규모 활동으로 기반을 다져 보세요.'}`, 'result', false);
      this.log(`${e.name} · ${j.name} ${j.kind==='single'?'발매':'완료'}`);
    }
    applyScheduledExpenses() {
      const s = this.s;
      if (s.day % 30 === 0) {
        this.change(- this.fixed, '월 고정비·직원 급여');
        for (let l of[... s.loans]) {
          if (l.due > s.day) continue;
          let interest = Math.round(l.remaining * l.rate),
          principal = Math.min(l.remaining, l.payment),
          bill = principal + interest;
          if (s.cash >= bill) {
            this._interest = interest;
            this.change(- bill, '대출 원금·이자 상환', true, { kind: 'loan_repayment', interest });
            this._interest = 0;
            l.remaining -= principal;
            l.missed = 0;
          } else {
            l.remaining += interest;
            l.missed++;
            this.report('대출 상환이 연체되었습니다', '상환 자금이 부족해 이자가 원금에 가산되었습니다. 지출을 줄이고 재정에서 조기 상환을 검토하세요.', 'finance', true);
          }
          l.due = s.day + 30;
        }
        s.loans = s.loans.filter(l => l.remaining > .01);
      }
    }
    closeFinancialDay() {
      const s = this.s;
      if (s.day % 30 === 0) {
        s.lastMonth = { in: Math.round(s.monthIn * 100) / 100, out: Math.round(s.monthOut * 100) / 100, day: s.day };
        this.report('월간 정산 보고', `이번 기간 유입 ${Math.round(s.monthIn).toLocaleString()}만 원 / 지출 ${Math.round(s.monthOut).toLocaleString()}만 원. 대출 실행·상환을 포함한 현금 흐름입니다. 상세 항목은 재정에서 확인하세요.`, 'finance', false);
        s.monthIn = 0;
        s.monthOut = 0;
      }
      if (s.cash < 0 && !s.reports.some(r => r.kind === 'crisis' && !r.resolved)) {
        this.report('운영 자금이 부족합니다', '제작을 줄이고 광고·공연 수입 또는 대출로 자금을 확보하세요. 회생 지원을 받으면 3,000만 원을 받는 대신 평판이 10 감소합니다.', 'crisis', true);
      }
      if (s.cash >= 0) for (const r of s.reports) if (r.kind === 'crisis' && !r.resolved) {
        r.resolved = true;
        r.closedReason = 'funded';
      }
    }
    advanceCore() {
      let s = this.s;
      s.day++;
      this.settleReceivables();
      this.trainTrainees();
      for (let a of[... s.artists]) {
        let meta = D.roster[a.id],
        busy = this.busy(String(a.id));
        let rest = a.focus === 'rest' || a.energy < 30 || a.recoveryUntil > s.day;
        let load = busy ? 1.5: 0;
        let gain = rest ? 8: 2 -(s.policy === 'growth' ? 2: 0) - load +(this.has('manager') ? this.staffPower('manager') * 1.5: 0);
        a.energy = Math.max(0, Math.min(100, a.energy + gain));
        a.stress = Math.max(0, Math.min(100, a.stress +(rest ? - 5: busy ? 1: 0) -(this.has('manager') ? this.staffPower('manager') * 1.5: 0)));
        if (!rest) {
          this.change(-(this.has('trainer') ? 7: 10), '훈련·외주: ' + meta.name, true, { kind: 'training' });
          let indexes = this.weeklyTrainingIndexes?.(a) || (a.focus === 'creative' ?[4]: a.focus === 'stage' ?[5, 6]: meta.type === 'idol' ?[0, 2, 5]: meta.type === 'band' ?[3, 4, 7]:[1, 4, 5]);
          let idx = indexes[Math.floor(this.rng() * indexes.length)];
          a.stats[idx] = Math.min(99, a.stats[idx] +(.12 *(1 +(this.coach ? this.coach([1, 3, 4].includes(idx) ? 'creative':[2, 5, 6].includes(idx) ? 'performance': 'vocal').bonus: 0))) *(a.energy < 30 ? .3: 1) *(s.policy === 'growth' ? 1.35: 1) *(1 - a.stress * .005) *(.8 + a.trust * .004) *(a.focus === meta.personality.focus ? 1.08: 1));
        }
        if ([180, 90, 30].includes(a.contract - s.day)) this.report('재계약을 준비할 시기입니다', `${meta.name}의 계약이 ${a.contract-s.day}일 뒤 만료됩니다. 아티스트 상세에서 재계약을 결정하세요.`, 'contract', true, { talentId: a.id, contractDue: a.contract });
        if (a.contract <= s.day) {
          this.depart(a.id, '계약 만료');
        }
      }
      let finished = s.jobs.filter(j => j.due <= s.day);
      s.jobs = s.jobs.filter(j => j.due > s.day);
      finished.forEach(j => this.finish(j));
      this.tickCatalog();
      for (let r of s.reports) if (r.kind === 'ad' && !r.resolved && s.day > r.expires) {
        r.resolved = true;
        r.closedReason = 'expired';
        r.body += '\n제안 기한이 지나 자동 종료되었습니다.';
      }
      if (s.day %(14 - Math.round(this.staffPower('ads') * 5)) === 0 && s.artists.length) {
        let entities = this.entities,
        e = entities[Math.floor(this.rng() * entities.length)];
        if (!s.reports.some(r => r.kind === 'ad' && !r.resolved && r.entity === e.key)) {
          let fame = e.members.reduce((n, a) => n + a.fame, 0) / e.members.length;
          let pay = Math.round((200 + fame * 18 + s.reputation * 6 + Math.sqrt(e.members.reduce((n, a) => n + a.fans, 0)) * 8) *(1 + this.staffPower('ads') * .3) * this.imageFactor());
          let brand = e.type === 'band' ? '루트 사운드': e.type === 'rap' ? '모션 스트리트': '데일리 블룸';
          this.report(e.name + ' 광고 출연 제안', `${brand}에서 연락이 왔습니다.\n계약금 ${pay.toLocaleString()}만 원 / 계약 즉시 40%, 촬영 후 60% 지급\n촬영 준비 5일 / 단발 광고·독점 없음\n싱글 제작 중 수락하면 제작을 5일 중단하고 완료일을 늦춥니다. 연장된 제작이 예약 행사와 겹치면 해당 준비·출연 기간도 추가 반영합니다. 공연·커버·다른 광고 중에는 수락할 수 없습니다. 잔금은 촬영 종료 14일 뒤 입금됩니다.`, 'ad', true, {
            entity: e.key,
            pay,
            brand,
            expires: s.day + 10
          });
        }
      }
      if (s.day % 23 === 0 && s.artists.length) {
        let e = this.entities[Math.floor(this.rng() * this.entities.length)];
        this.report('새로운 곡을 위한 작은 고민', `${e.name}이 창작 방향에 대해 상담을 요청했습니다. 외부 멘토와 만남을 지원하거나, 잠시 쉬며 생각을 정리하도록 할 수 있습니다.`, 'event', true, { entity: e.key });
      }
      if (s.day % 17 === 0) this.report('음악계 소식', ['새로운 라이브 페스티벌이 발표되었습니다. 공연 활동으로 팬을 만나 보세요.', '짧은 라이브 영상이 주목받고 있습니다. 꾸준한 공개 활동이 인지도에 도움이 됩니다.', '신인들의 다양한 음악이 차트를 채우고 있습니다. 우리만의 색을 찾아보세요.'][Math.floor(this.rng() * 3)]);
      s.candidates = s.candidates.filter(c => c.expires >= s.day);
      return this.pending.length;
    }
    rescue(id) {
      let r = this.s.reports.find(x => x.id === + id && x.kind === 'crisis' && !x.resolved);
      if (!r || this.s.cash >= 0) throw Error('현재 회생 지원이 필요하지 않습니다.');
      this.change(3000, '회생 지원금', false, { kind: 'rescue' });
      this.s.reputation = Math.max(0, this.s.reputation - 10);
      r.resolved = true;
      r.read = true;
      this.log('회생 지원으로 운영을 재개했습니다.');
    }
  }
  const FinalGame = typeof module !== 'undefined' ? require('./day-feedback.js')(require('./operations.js')(require('./personality.js')(require('./market.js')(require('./progression.js')(require('./management.js')(Game, D), D), D), D), D), D): root.installDayFeedback(root.installOperations(root.installPersonality(root.installMarket(root.installProgression(root.installManagement(Game, D), D), D), D), D), D);
  if (typeof module !== 'undefined') module.exports = require('./season.js')(require('./campaign.js')(require('./evolution.js')(FinalGame, D), D), D, require('./season-data.js'));
  else root.Game = root.installSeason(root.installCampaign(root.installEvolution(FinalGame, D), D), D, root.SEASON_DATA);
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/development.js */
(function(root) {
  'use strict';
  const Base = root.Game, plans = ['balanced','vocal','performance','creative','rest'];
  const weekday = day => (new Date(Date.UTC(2027,0,1+day)).getUTCDay()+6)%7;
  class DevelopmentGame extends Base {
    upgrade() {
      super.upgrade();
      if (!this.s) return;
      if (this.s.developmentVersion === undefined) this.s.developmentVersion = 1;
      for (const a of [...this.s.artists,...this.s.trainees,...this.s.departed]) this.initDevelopmentTalent(a);
    }
    initDevelopmentTalent(a) {
      for (const key of ['weeklyPlan','weeklyBase','growthTarget','milestone']) if (a[key] === undefined) a[key] = null;
    }
    initOperationsTalent(a) { super.initOperationsTalent(a); this.initDevelopmentTalent(a); }
    sign(id, offer = 'balanced') {
      return this.transaction(() => { super.sign(id,offer); this.initDevelopmentTalent(this.talent(Number(id))); });
    }
    ownedTalent(id) {
      const a = [...this.s.artists,...this.s.trainees].find(a=>a.id===Number(id));
      if (!a) throw Error('현재 소속된 인물을 선택하세요.');
      return a;
    }
    setWeeklyPlan(id, days) {
      return this.transaction(() => {
        const a = this.ownedTalent(id);
        if (!Array.isArray(days) || days.length!==7 || !days.every(p=>plans.includes(p))) throw Error('월요일부터 일요일까지 훈련을 지정하세요.');
        if (!a.weeklyPlan) a.weeklyBase = {focus:a.focus, plan:a.trainingPlan, mode:a.trainingMode};
        a.weeklyPlan = [...days];
      });
    }
    clearWeeklyPlan(id) {
      const a = this.ownedTalent(id);
      if (a.weeklyBase) { a.focus=a.weeklyBase.focus; a.trainingPlan=a.weeklyBase.plan; a.trainingMode=a.weeklyBase.mode; }
      a.weeklyPlan = null; a.weeklyBase = null;
    }
    setTraining(id, plan) { return this.transaction(()=>{ this.clearWeeklyPlan(id); return super.setTraining(id,plan); }); }
    setTrainingControl(id, mode, goal) {
      // Validate before touching the existing weekly schedule.
      if (!['auto','manual'].includes(mode) || !['balanced','debut','longterm','vocal','performance','creative'].includes(goal)) throw Error('육성 목표를 확인하세요.');
      return this.transaction(()=>{ this.clearWeeklyPlan(id); return super.setTrainingControl(id,mode,goal); });
    }
    setFocus(id, focus) {
      if (!['balanced','creative','stage','rest'].includes(focus)) throw Error('육성 방향을 확인하세요.');
      return this.transaction(()=>{ this.clearWeeklyPlan(id); return super.setFocus(id,focus); });
    }
    trainTrainees() {
      for (const a of [...this.s.artists,...this.s.trainees]) {
        this.initDevelopmentTalent(a);
        if (!a.weeklyPlan) continue;
        const plan = a.weeklyPlan[weekday(this.s.day)];
        a.trainingPlan = plan;
        a.focus = {balanced:'balanced',vocal:'balanced',performance:'stage',creative:'creative',rest:'rest'}[plan];
        if (this.s.trainees.includes(a)) a.trainingMode = 'manual';
      }
      return super.trainTrainees();
    }
    weeklyTrainingIndexes(a) { return a.weeklyPlan ? Base.trainingPlans[a.weeklyPlan[weekday(this.s.day)]].indexes : null; }
    setGrowthTarget(id, metric, target) {
      return this.transaction(()=>{
        const a=this.ownedTalent(id); metric=Number(metric);target=Number(target);
        if (!Number.isInteger(metric)||metric<0||metric>7||!Number.isInteger(target)||target<1||target>99) throw Error('능력과 목표값(1~99)을 확인하세요.');
        a.growthTarget={metric,target,setDay:this.s.day,achievedDay:a.stats[metric]>=target?this.s.day:null};
      });
    }
    setMilestone(id, kind, day) {
      return this.transaction(()=>{
        const a=this.ownedTalent(id), trainee=this.s.trainees.includes(a);day=Number(day);
        if (!(trainee?['debut']:['live','single']).includes(kind)||!Number.isInteger(day)||day<this.s.day||day>this.s.day+365) throw Error('오늘부터 365일 이내의 목표 날짜를 선택하세요.');
        if (kind==='debut' && day<a.signed+90) throw Error('데뷔 목표일은 입소 후 90일 이후로 지정하세요.');
        a.milestone={kind,day,completedDay:null};
      });
    }
    debut(id, offer) {
      return this.transaction(()=>{ super.debut(id,offer);const a=this.ownedTalent(id);if(a.milestone?.kind==='debut')a.milestone.completedDay=this.s.day; });
    }
    developmentCountdown(a) {
      const job=[...this.s.jobs.filter(j=>['single','live'].includes(j.kind)),...(this.s.engagements||[]).map(e=>({...e,kind:'live'}))].filter(j=>(j.snapshot?.ids||[]).includes(a.id)).sort((x,y)=>x.due-y.due)[0];
      if(job)return {kind:job.kind,day:job.due,confirmed:true,completedDay:null};
      return a.milestone ? {...a.milestone,confirmed:false} : null;
    }
    advanceSeason() {
      const result=super.advanceSeason();
      let developmentReports=0;
      for(const a of [...this.s.artists,...this.s.trainees]) {
        const target=a.growthTarget;
        if(target && target.achievedDay===null && a.stats[target.metric]>=target.target) {
          target.achievedDay=this.s.day;
          this.report('개인 육성 목표 달성',root.DATA.roster[a.id].name+' · '+root.DATA.specs[target.metric]+' '+target.target+' 달성','info',false);
          developmentReports++;
        }
        const mark=a.milestone;
        if(mark && mark.completedDay===null && ['live','single'].includes(mark.kind) && (this.s.performance.some(p=>p.day===this.s.day&&p.kind===mark.kind&&p.ids.includes(a.id))||mark.kind==='live'&&(this.s.festivalHistory||[]).some(e=>e.day===this.s.day&&e.ids.includes(a.id))))mark.completedDay=this.s.day;
      }
      const summary=this.s.daySummaries.at(-1);
      if(summary?.day===this.s.day)summary.newReports+=developmentReports;
      return result;
    }
    monthlyOperatingForecast() {
      const signature=JSON.stringify(this.s);
      if(this._developmentForecast?.signature===signature)return this._developmentForecast.value;
      const sim=new DevelopmentGame(JSON.parse(signature));
      let revenue=0,expense=0;
      const change=sim.change.bind(sim);
      sim.change=(amount,label,operating=true,meta={})=>{
        if(operating&&!['loan','loan_repayment','rescue'].includes(meta.kind)) {
          if(amount>0)revenue+=amount;else expense-=amount;
        }
        return change(amount,label,operating,meta);
      };
      for(let day=0;day<30;day++)sim.nextDay({transactional:false});
      const round=x=>Math.round(x*100)/100;
      const value={revenue:round(revenue),expense:round(expense),profit:round(revenue-expense),cashChange:round(sim.s.cash-this.s.cash),from:this.s.day+1,to:this.s.day+30};
      this._developmentForecast={signature,value};return value;
    }
  }
  root.DevelopmentWeekday=weekday;
  root.Game=DevelopmentGame;
})(typeof window!=='undefined'?window:globalThis);

;
/* Album packages, ticketed venues and artist content. Legacy job kinds stay compatible. */
(function(root){
  'use strict';
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,n)),round=n=>Math.round(n*100)/100;
  const albums={digital:{label:'디지털 싱글',tracks:1,days:21,factor:1,reach:1,tail:1},mini:{label:'미니앨범',tracks:5,days:35,factor:1.8,reach:1.15,tail:1.3},album:{label:'정규앨범',tracks:10,days:49,factor:2.8,reach:1.3,tail:1.6}};
  const venues={small:{label:'소공연장',capacity:300,cost:300,ticket:6,variable:.8,days:7},hall:{label:'콘서트홀',capacity:1500,cost:1500,ticket:8,variable:1.2,days:14},large:{label:'대형 콘서트장',capacity:5000,cost:6000,ticket:10,variable:1.8,days:21},arena:{label:'아레나',capacity:20000,cost:24000,ticket:12,variable:2.5,days:35}};
  const content={cover:{label:'커버 영상',days:5,fans:1,attention:1,desc:'새로운 팬 유입과 다음 발매에 대한 관심을 모읍니다.'},practice:{label:'연습 영상',days:4,fans:.7,attention:.7,desc:'댄스·합주·랩 연습을 공개해 실력과 준비 과정을 전합니다.'},daily:{label:'일상·소통 콘텐츠',days:3,fans:.5,attention:.4,desc:'팬과 소통하고 아티스트의 신뢰와 긴장을 돌봅니다.'}};
  for(const group of [albums,venues,content]){Object.values(group).forEach(Object.freeze);Object.freeze(group);}
  root.ActivityData=Object.freeze({albums,venues,content});
  class ActivityGame extends root.Game{
    activityPlan(key,kind,budget,options={}){
      if(!options||typeof options!=='object')throw Error('활동 설정을 확인하세요.');
      const album=Object.hasOwn(albums,options.albumType)?albums[options.albumType]:null,venue=Object.hasOwn(venues,options.venue)?venues[options.venue]:null,clip=Object.hasOwn(content,options.contentType)?content[options.contentType]:null;
      if(!['single','live','cover'].includes(kind)||options.albumType&&!album||options.venue&&!venue||options.contentType&&!clip||album&&kind!=='single'||venue&&kind!=='live'||clip&&kind!=='cover')throw Error('활동 종류와 세부 설정을 확인하세요.');
      if(album===albums.digital&&options.format==='physical')throw Error('디지털 싱글은 음원 전용입니다.');
      const b=Number(budget),factor=album?.factor||1;
      if(!Number.isFinite(b)||kind==='single'&&(b<1000||b>7000)||kind==='cover'&&(b<100||b>600)||kind==='live'&&!venue&&(b<300||b>1500))throw Error('예산 범위를 확인하세요.');
      const production=venue?venue.cost:round(b*factor),q=this.projectQuote(key,kind,production,options),e=this.entity(key);
      if(!e)throw Error('활동할 아티스트·팀을 선택하세요.');
      const duration=album?.days||venue?.days||clip?.days||({single:21,live:7,cover:5}[kind]),promotion=kind==='single'?root.DATA.promotionPlans[options.promotion||'none']:null;
      const days=duration+(promotion?.days||0),availability=this.projectAvailability(key,kind),reasons=[...availability.reasons];
      if(kind!=='single'&&this.reservationOverlaps(e.members.map(a=>a.id),this.s.day,this.s.day+duration+3)&&!reasons.some(x=>x.includes('행사')))reasons.push('확정 행사 준비·출연·회복 기간과 겹칩니다.');
      let due=this.s.day+days;
      if(kind==='single')due=this.reconcileProduction({kind,entity:key,start:this.s.day,due,snapshot:this.snapshot(key)}).due;
      return{kind,production,quote:q,duration,days,due,allowed:reasons.length===0,reasons};
    }
    startProject(key,kind,title,budget,concept,options={}){
      return this.transaction(()=>{
        const p=this.activityPlan(key,kind,budget,options);
        if(!p.allowed)throw Error(p.reasons.join(' · '));
        super.startProject(key,kind,title,p.production,concept,options);
        const j=this.s.jobs.at(-1);
        if(options.albumType){
          j.albumType=options.albumType;j.trackCount=albums[j.albumType].tracks;
          // Rebuild reservation delays for the full package, including reservations crossed by an extension.
          const promoDays=j.due-j.start-21-(j.delayDays||0);
          j.due=j.start+albums[j.albumType].days+promoDays;
          delete j.baselineDue;delete j.delayDays;delete j.pauses;this.reconcileProduction(j);
        }
        if(options.venue){j.venue=options.venue;j.due=j.start+venues[j.venue].days;}
        if(options.contentType){j.contentType=options.contentType;j.due=j.start+content[j.contentType].days;}
        return j;
      });
    }
    contentEffect(e,type){
      const ids=e.members.map(a=>a.id),repeats=this.s.outcomes.filter(o=>o.kind==='cover'&&(o.contentType||'cover')===type&&o.day>this.s.day-30&&o.ids.some(id=>ids.includes(id))).length;
      return{repeats,multiplier:1/(1+repeats*.45)};
    }
    newFans(e,j,quality,fan){
      const n=super.newFans(e,j,quality,fan);
      if(!j.contentType)return n;
      const effect=this.contentEffect(e,j.contentType);j.contentRepeat=effect.repeats;
      this._fanGain=Math.floor(n*content[j.contentType].fans*effect.multiplier);
      return this._fanGain;
    }
    venueResult(e,j,quality){
      const v=venues[j.venue],ids=e.members.map(a=>a.id),u=this.s.units.find(u=>u.key===e.key),fans=e.members.reduce((n,a)=>n+a.fans,0),recent=this.s.performance.filter(p=>p.kind==='live'&&p.day>this.s.day-30&&p.ids.some(id=>ids.includes(id))).length;
      const release=this.s.catalog.filter(c=>c.market.ids.some(id=>ids.includes(id))).at(-1),fresh=release&&this.s.day-release.market.startDay<=45?1.08:1;
      const demand=(quality*(e.members.length>1?2.4:1.5)+fans*.22+(u?.fans||0)*.30)*(8/v.ticket)*this.imageFactor()*(1+this.staffPower('live')*.2)*(1+(u?.cohesion||0)*.0015)*fresh*(j.freeLivePromotion?1.08:1)/(1+recent*.32);
      const attendance=clamp(Math.floor(demand),0,v.capacity);
      return{name:v.label,capacity:v.capacity,ticket:v.ticket,attendance,gross:round(attendance*v.ticket),variable:round(attendance*v.variable),recent};
    }
    concert(e,j,quality){
      if(!j.venue)return super.concert(e,j,quality);
      const result=this.venueResult(e,j,quality);j.concert=result;
      j.factors=j.factors||[];
      const factor=result.name+' · '+result.attendance.toLocaleString()+'/'+result.capacity.toLocaleString()+'석 · 최근 30일 공연 '+result.recent+'회';
      if(!j.factors.includes(factor))j.factors.unshift(factor);
      return result;
    }
    concertPreview(key,venue){
      if(!venues[venue])throw Error('공연장을 선택하세요.');
      const e=this.entity(key);if(!e)throw Error('공연할 아티스트·팀을 선택하세요.');
      const v=venues[venue],j={venue,freeLivePromotion:this.s.perks.livePromo>0},low=this.venueResult(e,j,40),high=this.venueResult(e,j,85),share=this.shares(this.snapshot(key)).reduce((n,x)=>n+x.rate,0),q=this.projectQuote(key,'live',v.cost),margin=v.ticket*(1-share)-v.variable;
      const estimate=r=>({attendance:r.attendance,gross:r.gross,payout:round(r.gross*share),variable:r.variable,totalCost:round(q.total+r.gross*share+r.variable),net:round(r.gross*(1-share)-r.variable-q.total)});
      return{venue,capacity:v.capacity,days:v.days,cost:q.total,ticket:v.ticket,low:estimate(low),high:estimate(high),breakEven:margin>0?Math.ceil(q.total/margin):null};
    }
    finish(j){
      const e=j.kind==='casting'?null:this.projectEntity(j),count=this.s.catalog.length,attention=e?.members.map(a=>this.coverAttention(a))||[],effect=e&&j.contentType?this.contentEffect(e,j.contentType):null;
      super.finish(j);
      const outcome=this.s.outcomes.find(o=>o.day===this.s.day&&o.title===j.name&&o.entity===j.entity);
      if(j.albumType&&this.s.catalog.length>count){const c=this.s.catalog[count];c.albumType=j.albumType;c.trackCount=j.trackCount;if(c.market.format==='physical')c.market.price=j.albumType==='album'?3.5:j.albumType==='mini'?3:2.5;}
      for(const field of ['albumType','trackCount','venue','contentType'])if(j[field]!==undefined&&outcome)outcome[field]=j[field];
      if(effect){
        e.members.forEach((a,i)=>{const gain=Math.max(0,this.coverAttention(a)-attention[i]);a.coverAttention=clamp(attention[i]+gain*content[j.contentType].attention*effect.multiplier,0,.16);a.coverAttentionDay=this.s.day;if(j.contentType==='daily'){a.trust=clamp(a.trust+2*effect.multiplier,0,100);a.stress=clamp(a.stress-3*effect.multiplier,0,100);}});
        if(outcome)outcome.factors=['최근 30일 같은 콘텐츠 '+effect.repeats+'회 · 추가 효과 '+Math.round(effect.multiplier*100)+'%',...(outcome.factors||[])].slice(0,3);
      }
    }
  }
  root.Game=ActivityGame;
})(typeof window!=='undefined'?window:globalThis);

;
/* FILE src/legacy-state.js */
(function(root) {
  'use strict';
  function validLegacyState(s) {
    try {
      const D = typeof module !== 'undefined' ? require('./data.js'): root.DATA;
      const num =(v, min = - 1e12, max = 1e12) => Number.isFinite(v) && v >= min && v <= max;
      const int =(v, min = 0, max = 1e9) => Number.isInteger(v) && v >= min && v <= max;
      const str =(v, max = 300) => typeof v === 'string' && v.length <= max;
      const ids = xs => new Set(xs).size === xs.length;
      const choice =(v, xs) => xs.includes(v);
      if (!s || s.version !== 1 || !str(s.company, 30) || !str(s.boss, 20) || !int(s.day, 0, 1000000) || !int(s.seed, 0, 4294967295) || !int(s.serial) || !int(s.releases) || !num(s.reputation, 0, 100) || !choice(s.policy, ['balanced', 'growth'])) return false;
      if (s.guideHidden !== undefined && typeof s.guideHidden !== 'boolean') return false;
      if (s.guideStep !== undefined && !int(s.guideStep, 0, 6)) return false;
      for (const k of['cash', 'totalRevenue', 'monthIn', 'monthOut']) if (!num(s[k])) return false;
      for (const k of['artists', 'units', 'staff', 'jobs', 'candidates', 'reports', 'ledger', 'history', 'catalog', 'loans']) if (!Array.isArray(s[k]) || s[k].length > 10000 || s[k].some(x => x == null)) return false;
      if (!s.artists.every(a => int(a.id, 0, D.roster.length - 1) && Array.isArray(a.stats) && a.stats.length === 8 && a.stats.every(v => num(v, 0, 99)) &&['energy', 'stress', 'trust', 'fame'].every(k => num(a[k], 0, 100)) && int(a.fans) && int(a.contract) && choice(a.focus, ['balanced', 'creative', 'stage', 'rest']))) return false;
      if (!ids(s.artists.map(a => a.id)) || !ids(s.staff) || !s.staff.every(id => D.staff.some(p => p.id === id))) return false;
      const artist = id => s.artists.some(a => a.id === id);
      if (!s.units.every(u => /^u[1-9]\d*$/.test(u.key) && str(u.name, 20) && Array.isArray(u.ids) && u.ids.length >= 1 && u.ids.length <= 5 && ids(u.ids) && u.ids.every(artist) && choice(u.type, ['idol', 'band', 'rap']) && u.ids.every(id => D.roster[id].type === u.type)) || !ids(s.units.map(u => u.key)) || !ids(s.units.flatMap(u => u.ids))) return false;
      const entity = k => typeof k === 'string' &&(s.units.some(u => u.key === k) || s.artists.some(a => String(a.id) === k) ||(s.managementVersion === 2 && s.jobs.some(j => j.entity === k && j.snapshot)));
      const key = k => typeof k === 'string' &&(/^(0|[1-9]\d*)$/.test(k) || /^u[1-9]\d*$/.test(k));
      if (!s.jobs.every(j => int(j.id, 1, s.serial) && int(j.start, 0, s.day) && int(j.due, j.start + 1) && str(j.name, 60) && choice(j.kind, ['casting', 'single', 'live', 'cover', 'ad']) &&(j.kind === 'casting' ? choice(j.method, ['audition', 'scout']) && choice(j.type, ['any', 'idol', 'band', 'rap']): entity(j.entity) &&(j.kind === 'ad' ? num(j.pay, 0): num(j.budget, D.rules.activity[j.kind]?.min, D.rules.activity[j.kind]?.max) && choice(j.concept, ['balanced', 'creative', 'public']))))) return false;
      if (!s.candidates.every(c => int(c.id, 0, D.roster.length - 1) && !artist(c.id) && int(c.expires) && typeof c.evaluated === 'boolean') || !ids(s.candidates.map(c => c.id))) return false;
      if (!s.loans.every(l => int(l.id, 1, s.serial) && num(l.remaining, 0) && num(l.principal, 0) && num(l.payment, Number.EPSILON) && num(l.rate, 0, 1) && int(l.due) && int(l.missed))) return false;
      if (!s.reports.every(r => int(r.id, 1, s.serial) && int(r.day, 0, s.day) && str(r.title, 500) && str(r.body, 10000) && choice(r.kind, ['info', 'welcome', 'casting', 'ad', 'event', 'result', 'contract', 'finance', 'crisis']) &&['read', 'resolved', 'important'].every(k => typeof r[k] === 'boolean') &&(r.kind !== 'ad' || key(r.entity) && str(r.brand) && num(r.pay, 0) && int(r.expires)) &&(r.kind !== 'event' || key(r.entity)))) return false;
      if (!s.catalog.every(c => int(c.id, 1, s.serial) && key(c.entity) && str(c.name, 30) && num(c.quality, 0, 99) && int(c.age) && num(c.revenue, 0) && num(c.fanBase, 0) && choice(c.concept, ['balanced', 'creative', 'public'])) || !s.ledger.every(l => int(l.day, 0, s.day) && num(l.amount) && str(l.label, 500)) || !s.history.every(h => int(h.day, 0, s.day) && str(h.text, 500))) return false;
      if (s.lastMonth !== null &&(!s.lastMonth || !num(s.lastMonth.in, 0) || !num(s.lastMonth.out, 0) || !int(s.lastMonth.day, 0, s.day))) return false;
      const serials = [... s.jobs, ... s.reports, ... s.catalog, ... s.loans].map(x => x.id).concat(s.units.map(u => Number(u.key.slice(1))));
      return ids(serials);
    } catch {
      return false;
    }
  }
  if (typeof module !== 'undefined') module.exports = validLegacyState;
  else root.validLegacyState = validLegacyState;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/season-state.js */
(function(root) {
  'use strict';
  function valid(s, D) {
    try {
      const int =(v, a = 0, b = 1e12) => Number.isSafeInteger(v) && v >= a && v <= b,
      num =(v, a = 0, b = 1e14) => Number.isFinite(v) && v >= a && v <= b,
      text =(v, n = 120) => typeof v === 'string' && v.length <= n,
      arr =(v, n) => Array.isArray(v) && v.length <= n,
      unique = a => new Set(a).size === a.length,
      obj = x => x && typeof x === 'object' && !Array.isArray(x),
      ids = x => arr(x, 5) && unique(x) && x.every(v => int(v, 0, D.roster.length - 1)),
      key = x => typeof x === 'string' && /^(u[1-9]\d*|0|[1-9]\d*)$/.test(x),
      kinds = ['campus', 'summer', 'genre'];
      if (s.seasonVersion !== 1 || !int(s.seasonSince, 0, s.day) || s.seasonYear !== new Date(Date.UTC(2027, 0, 1 + s.day)).getUTCFullYear() || !obj(s.debutYears) || !Object.entries(s.debutYears).every(([k, v]) => /^\d+$/.test(k) && int(+ k, 0, D.roster.length - 1) && int(v, 1900, 10000))) return false;
      if (!arr(s.festivalOffers, 60) || !arr(s.engagements, 72) || !arr(s.festivalHistory, 100) || !arr(s.external, 220) || !arr(s.awardHistory, 10) || !obj(s.yearStats) || Object.keys(s.yearStats).length > 6000) return false;
      const people = [... s.artists, ... s.departed],
      snapshot = x => obj(x) && key(x.key) && text(x.name, 30) &&['idol', 'band', 'rap'].includes(x.type) && ids(x.ids) && x.ids.length > 0 && x.ids.every(id => people.some(a => a.id === id)),
      shares = x => arr(x, 5) && unique(x.map(v => v.id)) && x.every(v => int(v.id, 0, D.roster.length - 1) && num(v.rate, 0, 1)) && x.reduce((n, v) => n + v.rate, 0) <= 1.000001;
      if (!s.festivalOffers.every(o => int(o.id, 1, s.serial) && kinds.includes(o.kind) && key(o.entity) && int(o.day, 0, s.day + 365) && num(o.pay) && num(o.cost) && int(o.expires, 0, o.day) &&['open', 'accepted', 'declined', 'expired'].includes(o.status))) return false;
      if (!s.festivalOffers.every(o => o.approval === undefined || obj(o.approval) && text(o.approval.name) && int(o.approval.start, 0, o.day) && o.approval.day === o.day && o.approval.duration ===(o.kind === 'summer' ? 4: 3) && num(o.approval.pay) && num(o.approval.cost) && num(o.approval.net, - 1e12) && arr(o.approval.productions, 72) && o.approval.productions.every(p => int(p.id, 1, s.serial) && text(p.title, 60) && int(p.oldDue) && int(p.newDue, p.oldDue + o.approval.duration)))) return false;
      if (!s.engagements.every(e => int(e.id, 1, s.serial) && int(e.offerId, 1, s.serial) && kinds.includes(e.kind) && key(e.entity) && text(e.name) && int(e.start, 0, s.day + 365) && int(e.due, e.start + 1, s.day + 365) && e.due - e.start ===(e.kind === 'summer' ? 4: 3) && e.due > s.day && snapshot(e.snapshot) && e.snapshot.key === e.entity && shares(e.shares) && num(e.pay) && num(e.cost))) return false;
      if (s.engagements.some((e, i) => s.engagements.slice(i + 1).some(f => e.start < f.due + 2 && e.due + 2 > f.start && e.snapshot.ids.some(id => f.snapshot.ids.includes(id))))) return false;
      if (!s.festivalHistory.every(e => int(e.id, 1, s.serial) && int(e.day, 0, s.day) && key(e.entity) && text(e.name) && text(e.artist, 30) && ids(e.ids) && num(e.quality, 0, 99) && int(e.fans) && int(e.attendance) && num(e.net, - 1e12))) return false;
      const all = [... s.festivalOffers, ... s.engagements, ... s.festivalHistory].map(x => x.id).concat([... s.jobs, ... s.reports, ... s.catalog, ... s.loans, ... s.outcomes, ... s.moments, ... s.stories, ... s.specialOffers].map(x => x.id), s.units.map(u => + u.key.slice(1)));
      if (!unique(all)) return false;
      if (!unique(s.external.map(c => c.uid)) || !s.external.every(c => text(c.uid, 80) && c.uid.startsWith('x-') && text(c.name) && int(c.artist, 0, 100000) && int(c.debutYear, 1900, s.seasonYear) && text(c.artistName) && text(c.company) && int(c.startDay, - 365, s.day) && int(c.base, 0, 1e7) && typeof c.physical === 'boolean' && arr(c.days, 14) && unique(c.days.map(d => d.day)) && c.days.every(d => int(d.day, - 365, s.day) && int(d.streams) && int(d.sales)))) return false;
      if (!Object.entries(s.yearStats).every(([k, v]) => text(k, 160) && obj(v) && v.key === k && text(v.name) && typeof v.own === 'boolean' && ids(v.ids) && int(v.debut, 1900, 10000) &&['streams', 'sales', 'live', 'liveCount', 'quality'].every(k => num(v[k])) &&(v.releaseId === null || text(v.releaseId, 100)))) return false;
      const nominee = n => obj(n) && text(n.key, 160) && text(n.name) && text(n.artist) && typeof n.own === 'boolean' && ids(n.ids) &&(n.releaseId === null || text(n.releaseId, 100));
      if (!unique(s.awardHistory.map(a => a.year)) || !s.awardHistory.every(a => int(a.year, 2027, s.seasonYear) && int(a.since, 0, s.day) && int(a.nominationDay, 0, s.day) &&(a.resultDay === null || int(a.resultDay, a.nominationDay, s.day)) && arr(a.categories, 4) && a.categories.length === 4 && unique(a.categories.map(c => c.key)) && a.categories.every(c =>['rookie', 'song', 'live', 'artist'].includes(c.key) && arr(c.nominees, 5) && unique(c.nominees.map(n => n.key)) && c.nominees.every(nominee) &&(c.winner === null || nominee(c.winner) && c.nominees.some(n => n.key === c.winner.key))))) return false;
      for (const metric of['streams', 'sales']) {
        const h = s.chartHistory?.[metric];
        if (!obj(h) || !(h.day === null || int(h.day, 0, s.day))) return false;
        for (const k of['current', 'previous', 'best']) if (!obj(h[k]) || Object.keys(h[k]).length > 10000 || !Object.entries(h[k]).every(([id, rank]) => text(id, 100) && int(rank, 1, 100000))) return false;
      }
      if (!s.reports.every(r =>(r.festivalOfferId === undefined || int(r.festivalOfferId, 1, s.serial)) &&(r.festivalResultId === undefined || int(r.festivalResultId, 1, s.serial)) &&(r.awardYear === undefined || int(r.awardYear, 2027, s.seasonYear)))) return false;
      return true;
    } catch {
      return false;
    }
  }
  if (typeof module !== 'undefined') module.exports = valid;
  else root.validSeasonState = valid;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/state.js */
(function(root) {
  'use strict';
  const legacy = typeof module !== 'undefined' ? require('./legacy-state.js'): root.validLegacyState;
  const D = typeof module !== 'undefined' ? require('./evolution-data.js'): root.DATA;
  function validState(s) {
    try {
      if (!legacy(s)) return false;
      if (s.managementVersion === undefined) return true;
      if (s.managementVersion !== 2) return false;
      const n =(x, min = 0, max = 1e12) => Number.isFinite(x) && x >= min && x <= max;
      const i =(x, min = 0, max = 1e9) => Number.isInteger(x) && x >= min && x <= max;
      const arr =(x, max = 10000) => Array.isArray(x) && x.length <= max && x.every(v => v !== null);
      const round2 = x => Math.round(x * 100) / 100;
      const unique = x => new Set(x).size === x.length;
      const text =(x, max = 500) => typeof x === 'string' && x.length <= max;
      const person = a => a && i(a.id, 0, D.roster.length - 1) && arr(a.stats, 8) && a.stats.length === 8 && a.stats.every(v => n(v, 0, 99)) &&['energy', 'stress', 'trust', 'fame'].every(k => n(a[k], 0, 100)) && i(a.fans) && i(a.contract) && i(a.signed, 0, s.day) && i(a.lastActive, 0, s.day) && a.terms && n(a.terms.share, 0, 1) && n(a.terms.fee) && i(a.terms.days, 1, 3650) && text(a.terms.name) &&['balanced', 'creative', 'stage', 'rest'].includes(a.focus) && i(a.star, 0, 4) && i(a.bestStar, 0, 4) &&(a.starSince == null || i(a.starSince, 0, s.day));
      if (!i(s.recordSince, 0, s.day) || !i(s.companyLevel, 1, 5) || !i(s.lowQuarters, 0, 1)) return false;
      for (const k of['accounts', 'trainees', 'departed', 'teamArchive', 'goals', 'performance', 'payments', 'industryNews', 'valuations', 'rivals']) if (!arr(s[k])) return false;
      if (![... s.artists, ... s.trainees, ... s.departed].every(a => person(a) &&(a.lastPersonalDay === undefined || i(a.lastPersonalDay, 0, s.day)))) return false;
      if (!unique(s.artists.concat(s.trainees).map(a => a.id)) || !unique(s.departed.map(a => a.id)) || s.departed.some(a => s.artists.concat(s.trainees).some(b => a.id === b.id))) return false;
      const key = x => typeof x === 'string' && /^(u[1-9]\d*|0|[1-9]\d*)$/.test(x);
      const bins = xs => arr(xs, 366) && xs.every(b => i(b.day, 0, s.day) && n(b.revenue) && n(b.expense));
      if (!bins(s.accounts) || !unique(s.accounts.map(b => b.day)) || !s.accounts.every(b => b.by && typeof b.by === 'object' && !Array.isArray(b.by) && Object.entries(b.by).every(([k, v]) => key(k) && n(v)))) return false;
      if (!s.units.every(u =>['active', 'hiatus'].includes(u.status) && n(u.fame, 0, 100) && i(u.fans) && i(u.star, 0, 4) && i(u.bestStar, 0, 4))) return false;
      const allPeople = [... s.artists, ... s.departed];
      const shares = x => arr(x, 5) && unique(x.map(v => v.id)) && x.every(v => i(v.id, 0, D.roster.length - 1) && n(v.rate, 0, 1)) && x.reduce((n, v) => n + v.rate, 0) <= 1.000001;
      if (!s.catalog.every(c => shares(c.shares) && text(c.ownerName))) return false;
      if (!s.jobs.every(j => j.kind === 'casting' || j.snapshot && key(j.snapshot.key) && j.entity === j.snapshot.key && text(j.snapshot.name, 30) &&['idol', 'band', 'rap'].includes(j.snapshot.type) && arr(j.snapshot.ids, 5) && j.snapshot.ids.length > 0 && unique(j.snapshot.ids) && j.snapshot.ids.every(id => allPeople.some(a => a.id === id)) && shares(j.shares))) return false;
      if (s.rivals.length !== 4 || !unique(s.rivals.map(r => r.id)) || !s.rivals.every(r => i(r.id, 0, 3) && text(r.name, 30) &&['idol', 'band', 'rap', 'any'].includes(r.type) && n(r.cash, - 1e12) && n(r.debt) && arr(r.artists, D.roster.length) && unique(r.artists) && r.artists.every(id => i(id, 0, D.roster.length - 1)) && arr(r.catalog, 240) && r.catalog.every(c => text(c.name) && n(c.quality, 0, 100) && i(c.age)) && bins(r.accounts) && i(r.serial) && i(r.fans) && n(r.reputation, 0, 100) && i(r.level, 1, 5) && n(r.value))) return false;
      const owners = s.artists.concat(s.trainees).map(a => a.id).concat(s.rivals.flatMap(r => r.artists));
      if (!unique(owners) || s.candidates.some(c => owners.includes(c.id))) return false;
      if (!s.goals.every(g =>['sign', 'trainee', 'debut', 'release', 'catalog', 'profit', 'staff', 'fans', 'renew', 'star', 'rival', 'large', 'live', 'liveprofit', 'team', 'physical', 'comeback', 'stable'].includes(g)) || !unique(s.goals)) return false;
      if (!s.performance.every(p => i(p.day, 0, s.day) && key(p.key) && arr(p.ids, 5) && p.ids.every(id => i(id, 0, D.roster.length - 1)) &&['single', 'live', 'cover'].includes(p.kind) && n(p.quality, 0, 99))) return false;
      if (!s.payments.every(p => i(p.day, 0, s.day) && i(p.id, 0, D.roster.length - 1) && n(p.amount) && text(p.label))) return false;
      if (!s.industryNews.every(p => i(p.day, 0, s.day) && text(p.text, 2000)) || !s.valuations.every(v => i(v.day, 0, s.day) && n(v.value) && n(v.revenue) && n(v.profit, - 1e12))) return false;
      if (!s.teamArchive.every(u => key(u.key) && text(u.name, 20) && arr(u.ids, 5) && u.ids.every(id => i(id, 0, D.roster.length - 1)) && i(u.ended, 0, s.day))) return false;
      for (const k of['debutCount', 'renewCount']) if (s[k] !== undefined && !i(s[k])) return false;
      if (s.balanceVersion !== undefined) {
        if (s.balanceVersion !== 1 || !n(s.image, 0, 100) || !i(s.lastIncidentDay, - 90, s.day) || !arr(s.incidents, 80) || !arr(s.settlements, 80)) return false;
        if (![... s.trainees, ... s.artists, ... s.departed].every(a =>['balanced', 'vocal', 'performance', 'creative', 'rest'].includes(a.trainingPlan) && i(a.trainedDays))) return false;
        if (!s.rivals.every(r => n(r.image, 0, 100) && text(r.lastAction, 100) && arr(r.talents, D.roster.length) && unique(r.talents.map(t => t.id)) && r.talents.length === r.artists.length && r.talents.every(t => r.artists.includes(t.id) && n(t.skill, 0, 99) && n(t.energy, 0, 100) && n(t.trust, 0, 100) && i(t.contract) && typeof t.active === 'boolean'))) return false;
        if (!unique(s.incidents.map(x => x.id)) || !s.incidents.every(x => i(x.id, 1, s.serial) &&['cancel', 'sound', 'notice', 'overwork'].includes(x.kind) && key(x.key) && text(x.name, 30) && i(x.day, 0, s.day) && i(x.expires, x.day) && i(x.severity, 1, 3) &&['open', 'investigating', 'closed'].includes(x.state) &&(x.choice === null ||['explain', 'repair', 'investigate', 'ignore'].includes(x.choice)) &&(x.responseDue === null || i(x.responseDue, x.day)) && arr(x.losses, 5) && unique(x.losses.map(l => l.id)) && x.losses.every(l => i(l.id, 0, D.roster.length - 1) && i(l.lost)) && i(x.teamLost) && n(x.imageLoss, 0, 100) && i(x.recovered))) return false;
        if (s.incidents.filter(x => x.state !== 'closed').length > 1) return false;
        if (!s.settlements.every(x => i(x.day, 0, s.day) && text(x.name, 60) &&['live', 'ad'].includes(x.kind) &&['gross', 'payout', 'variable', 'budget'].every(k => n(x[k])) && n(x.net, - 1e12) && i(x.attendance) && i(x.capacity) && x.attendance <= x.capacity)) return false;
      }
      if (s.marketVersion !== undefined) {
        if (s.marketVersion !== 1 || !n(s.lastReputation, 0, 100) || !text(s.reputationReason, 1000)) return false;
        const release =(c) => {
          let m = c.market;
          return m && typeof m.uid === 'string' && /^(p-\d+|r[0-3]-(?:old-)?\d+)$/.test(m.uid) &&(m.owner === 'player' || /^r[0-3]$/.test(m.owner)) && i(m.startDay, 0, s.day) && i(m.measuredFrom, 0, s.day + 1) && i(m.lastDay, - 1, s.day) && typeof m.legacy === 'boolean' &&['digital', 'physical'].includes(m.format) && m.price === (m.format === 'physical' && c.albumType === 'album' ? 3.5 : m.format === 'physical' && c.albumType === 'mini' ? 3 : 2.5) && m.unitCost === .6 && i(m.stock, 0, 100000) && i(m.manufactured) && m.sales + m.stock === m.manufactured &&['manufacturing', 'production', 'fanBase', 'gross', 'distribution', 'receipts', 'paid', 'payout', 'pending', 'streamGross', 'physicalGross', 'streamReceipts', 'physicalReceipts', 'pendingStream', 'pendingPhysical', 'paidStream', 'paidPhysical', 'payoutStream', 'payoutPhysical'].every(k => n(m[k])) && n(m.fame, 0, 100) && n(m.appeal, .3, 1.5) && n(m.discovery, 1, 1.7) && i(m.streams, 0, Number.MAX_SAFE_INTEGER) && i(m.sales) &&(m.firstWeekSales === null && m.legacy || i(m.firstWeekSales, 0, m.sales)) && i(m.pendingDays, 0, 6) && typeof m.hit === 'boolean' && arr(m.ids, D.roster.length) && m.ids.every(id => i(id, 0, D.roster.length - 1)) &&['idol', 'band', 'rap'].includes(m.type) && text(m.artistName, 60) && Math.abs(m.receipts - m.paid - m.pending) < .03 && Math.abs(m.gross - m.distribution - m.receipts) < .03 && Math.abs(m.paid - m.paidStream - m.paidPhysical) < .03 && Math.abs(m.payout - m.payoutStream - m.payoutPhysical) < .03 && Math.abs(m.pending - m.pendingStream - m.pendingPhysical) < .03 && Math.abs(m.receipts - m.streamReceipts - m.physicalReceipts) < .03 && arr(m.days, 28) && unique(m.days.map(d => d.day)) && m.days.every(d => i(d.day, 0, s.day) && i(d.streams, 0, Number.MAX_SAFE_INTEGER) && i(d.sales)) && arr(m.weeks, 104) && unique(m.weeks.map(w => w.week)) && m.weeks.every(w => i(w.week) && i(w.streams, 0, Number.MAX_SAFE_INTEGER) && i(w.sales));
        };
        const releases = [... s.catalog, ... s.rivals.flatMap(r => r.catalog)];
        if (!releases.every(release) || !unique(releases.map(c => c.market.uid))) return false;
        if (!s.jobs.every(j => j.kind !== 'single' || j.releaseOptions &&['digital', 'physical'].includes(j.releaseOptions.format) && n(j.manufacturing) && j.manufacturing === j.releaseOptions.quantity * .6 &&(j.releaseOptions.format === 'digital' ? j.releaseOptions.quantity === 0:[1000, 3000, 10000].includes(j.releaseOptions.quantity)))) return false;
        for (const a of[... s.artists, ... s.units]) if (a.marketStarSince !== undefined && a.marketStarSince !== null && !i(a.marketStarSince, 0, s.day)) return false;
      }
      if (s.feedbackVersion !== undefined) {
        if (s.feedbackVersion !== 1 || !arr(s.daySummaries, 30) || !unique(s.daySummaries.map(d => d.day)) || !s.daySummaries.every(d => i(d.day, 1, s.day) && d.fromDay === d.day - 1 && n(d.cashChange, - 1e12) && i(d.streams, 0, Number.MAX_SAFE_INTEGER) && i(d.sales) && i(d.fansChange, - 1e9) && i(d.teamFansChange, - 1e9) && i(d.trainingCount, 0, 100) && arr(d.completed, 100) && d.completed.every(j =>['casting', 'single', 'live', 'cover', 'ad'].includes(j.kind) && text(j.title, 60)) && i(d.newReports, 0, 1000) && arr(d.departed, D.roster.length) && d.departed.every(id => i(id, 0, D.roster.length - 1)))) return false;
      }
      if (s.operationsVersion !== undefined) {
        if (s.operationsVersion !== 1 || !i(s.operationsSince, 0, s.day) || !i(s.staffMarketSeed, 0, 4294967295) || !arr(s.receivables, 300) || !unique(s.receivables.map(x => x.id))) return false;
        if (s.staffBoard !== undefined &&(!s.staffBoard || !i(s.staffBoard.day, 0, s.day) || !arr(s.staffBoard.ids, 5) || !unique(s.staffBoard.ids) || !s.staffBoard.ids.every(id => D.staff.some(p => p.id === id)))) return false;
        if (!s.receivables.every(x => i(x.id, 1, s.serial) && i(x.due, s.day + 1, s.day + 30) && n(x.amount) && text(x.label, 200) && key(x.key) && shares(x.shares))) return false;
        if (![... s.trainees, ... s.artists, ... s.departed].every(a =>['auto', 'manual'].includes(a.trainingMode) &&['balanced', 'debut', 'longterm', 'vocal', 'performance', 'creative'].includes(a.trainingGoal) && i(a.recoveryUntil, 0, s.day + 30) && arr(a.growthHistory, 91) && a.growthHistory.length > 0 && unique(a.growthHistory.map(x => x.day)) && a.growthHistory.every((x, j) => i(x.day, 0, s.day) &&(!j || x.day > a.growthHistory[j - 1].day) && arr(x.stats, 8) && x.stats.length === 8 && x.stats.every(v => n(v, 0, 99)) && text(x.reason, 100)))) return false;
        if (!s.jobs.every(j =>(j.experience === undefined ||['any', 'career', 'trainee'].includes(j.experience)) &&(j.promotion === undefined || D.promotionPlans[j.promotion] && n(j.promotionCost) && j.promotionCost === D.promotionPlans[j.promotion].cost))) return false;
      }
      if (s.evolutionVersion !== undefined) {
        if (s.evolutionVersion !== 1 || !i(s.evolutionSince, 0, s.day) || typeof s.soundEnabled !== 'boolean') return false;
        const goalIds = Object.keys(D.goalRewards),
        people = [... s.artists, ... s.trainees, ... s.departed];
        if (!arr(s.rewardPaid, 18) || !unique(s.rewardPaid) || !s.rewardPaid.every(id => goalIds.includes(id) && s.goals.includes(id))) return false;
        if (!s.perks || !['debutPromo', 'productionVoucher', 'livePromo'].every(k => i(s.perks[k], 0, 1))) return false;
        if (!s.goalEvidence || !['live', 'liveprofit', 'team', 'comeback'].every(k => i(s.goalEvidence[k], 0, 1))) return false;
        if (!arr(s.monthProfits, 12) || !unique(s.monthProfits.map(x => x.day)) || !s.monthProfits.every((x, j) => i(x.day, 0, s.day) && x.day % 30 === 0 && x.day - 30 >= s.evolutionSince && n(x.profit, - 1e12) &&(!j || x.day > s.monthProfits[j - 1].day))) return false;
        if (!s.staffImpact || !i(s.staffImpact.since, 0, s.day) || !n(s.staffImpact.saved) || !i(s.staffImpact.trainingDays) || !i(s.staffImpact.recoveryDays)) return false;
        if (!(s.pinnedEntity === null || key(s.pinnedEntity)) || !arr(s.milestoneKeys, 1000) || !unique(s.milestoneKeys) || !s.milestoneKeys.every(k => text(k, 100))) return false;
        if (!people.every(a => arr(a.memories, 60) && a.memories.every(m => i(m.day, 0, s.day) &&['start', 'contract', 'debut', 'renew', 'team', 'activity', 'hit', 'choice', 'award'].includes(m.kind) && text(m.text, 500)) && arr(a.storyKeys, 5) && unique(a.storyKeys) && a.storyKeys.every(k => Object.hasOwn(D.personalStories, k)) && n(a.coverAttention, 0, .16) && i(a.coverAttentionDay, 0, s.day))) return false;
        if (!s.units.every(u => n(u.cohesion, 0, 100) && i(u.completedActivities))) return false;
        const talentIds = xs => arr(xs, 5) && unique(xs) && xs.every(id => i(id, 0, D.roster.length - 1));
        if (!arr(s.moments, 80) || !s.moments.every(m => i(m.id, 1, s.serial) && i(m.day, 0, s.day) && text(m.title, 200) && text(m.body, 2000) && talentIds(m.ids) && typeof m.seen === 'boolean')) return false;
        if (!arr(s.outcomes, 60) || !s.outcomes.every(o => i(o.id, 1, s.serial) && i(o.day, 0, s.day) &&['single', 'live', 'cover', 'ad'].includes(o.kind) && text(o.title, 60) && key(o.entity) && talentIds(o.ids) && n(o.quality, 0, 99) && i(o.fans, - 1e9) && i(o.attendance) && i(o.capacity) && o.attendance <= o.capacity &&(o.net === null || n(o.net, - 1e12)) && n(o.production))) return false;
        if (!arr(s.stories, 120) || !s.stories.every(st => i(st.id, 1, s.serial) && i(st.talentId, 0, D.roster.length - 1) && Object.hasOwn(D.personalStories, st.kind) && i(st.day, 0, s.day) && st.expires === st.day + 14 &&['open', 'resolved', 'expired'].includes(st.status) &&(st.choice === null ||['support', 'space'].includes(st.choice)))) return false;
        if (s.stories.filter(st => st.status === 'open').length > 1) return false;
        if (!arr(s.specialOffers, 4) || !unique(s.specialOffers.map(o => o.kind)) || !s.specialOffers.every(o => i(o.id, 1, s.serial) && Object.hasOwn(D.specialOffers, o.kind) && i(o.day, 0, s.day) && o.expires === o.day + D.specialOffers[o.kind].days && typeof o.used === 'boolean')) return false;
        const extraIds = [... s.moments, ... s.outcomes, ... s.stories, ... s.specialOffers].map(x => x.id),
        existingIds = [... s.jobs, ... s.reports, ... s.catalog, ... s.loans].map(x => x.id).concat(s.units.map(u => Number(u.key.slice(1))));
        if (!unique([... extraIds, ... existingIds])) return false;
        if (!s.jobs.every(j =>(j.productionDiscount === undefined || n(j.productionDiscount, 0, 200) && n(j.actualProductionCost) && j.actualProductionCost === round2(j.budget - j.productionDiscount)) &&(j.coverBoost === undefined || n(j.coverBoost, 0, .20)) &&(j.freePromotion === undefined || typeof j.freePromotion === 'boolean') &&(j.freeLivePromotion === undefined || typeof j.freeLivePromotion === 'boolean'))) return false;
        for (const c of s.catalog) {
          const m = c.market;
          if (m.resurfaceUntil !== undefined &&(!i(m.resurfacedDay, 0, s.day) || m.resurfaceUntil !== m.resurfacedDay + 14 || !text(m.resurfaceReason, 100))) return false;
        }
      }
      if (s.reliabilityVersion !== undefined) {
        if (s.reliabilityVersion !== 1) return false;
        if (!s.receivables.every(x =>['concert_settlement', 'ad_balance'].includes(x.kind))) return false;
      }
      if (s.campaignVersion !== undefined) {
        if (s.campaignVersion !== 1) return false;
        for (const j of s.jobs) {
          if (j.baselineDue !== undefined) {
            if (j.kind !== 'single' || !i(j.baselineDue, j.start + 1) || !i(j.delayDays, 0, 100000) ||(!s.seasonVersion && j.delayDays % 5 !== 0) || j.due !== j.baselineDue + j.delayDays || !arr(j.pauses, 60) || !unique(j.pauses.map(p => p.adId))) return false;
            if (!j.pauses.every((p, index) => i(p.adId, 1, s.serial) &&(p.kind === undefined || p.kind === 'festival') && i(p.start, j.start, s.day +(s.seasonVersion ? 365: 0)) &&(p.kind === 'festival' && s.seasonVersion ?[3, 4].includes(p.end - p.start): p.end === p.start + 5) &&(!index || j.pauses[index - 1].end <= p.start)) || j.pauses.reduce((n, p) => n + p.end - p.start, 0) > j.delayDays) return false;
          } else if (j.pauses !== undefined || j.delayDays !== undefined) return false;
          if (j.interrupts !== undefined &&(j.kind !== 'ad' || !arr(j.interrupts, 72) || !unique(j.interrupts) || !j.interrupts.every(id => i(id, 1, s.serial)))) return false;
        }
        if (!s.reports.every(r =>(r.decision === undefined ||['accept', 'decline'].includes(r.decision)) &&(r.closedReason === undefined ||['expired', 'funded'].includes(r.closedReason)))) return false;
        if (!s.outcomes.every(o => o.factors === undefined || arr(o.factors, 3) && o.factors.every(x => text(x, 200)))) return false;
      }
      if (s.seasonVersion !== undefined) {
        const check = typeof module !== 'undefined' ? require('./season-state.js'): root.validSeasonState;
        if (!check(s, D)) return false;
      }
      return true;
    } catch {
      return false;
    }
  }
  if (typeof module !== 'undefined') module.exports = validState;
  else root.validState = validState;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/development-state.js */
(function(root){
  'use strict';
  const base=root.validState,plans=['balanced','vocal','performance','creative','rest'];
  root.validState=function(s){
    if(!base(s))return false;
    try{
      const people=[...s.artists,...(s.trainees||[]),...(s.departed||[])];
      const fields=['weeklyPlan','weeklyBase','growthTarget','milestone'];
      if(s.developmentVersion===undefined)return people.every(a=>fields.every(k=>a[k]===undefined));
      if(s.developmentVersion!==1)return false;
      const day=v=>Number.isInteger(v)&&v>=0&&v<=1e9;
      return people.every(a=>{
        if(a.weeklyPlan!==null && (!Array.isArray(a.weeklyPlan)||a.weeklyPlan.length!==7||!a.weeklyPlan.every(p=>plans.includes(p))))return false;
        if((a.weeklyPlan===null)!==(a.weeklyBase===null))return false;
        if(a.weeklyBase && (!['balanced','creative','stage','rest'].includes(a.weeklyBase.focus)||!plans.includes(a.weeklyBase.plan)||!['auto','manual'].includes(a.weeklyBase.mode)))return false;
        const g=a.growthTarget;
        if(g!==null && (!g||!Number.isInteger(g.metric)||g.metric<0||g.metric>7||!Number.isInteger(g.target)||g.target<1||g.target>99||!day(g.setDay)||g.setDay>s.day||!(g.achievedDay===null||day(g.achievedDay)&&g.achievedDay>=g.setDay&&g.achievedDay<=s.day)))return false;
        const m=a.milestone;
        return m===null||!!m&&['debut','live','single'].includes(m.kind)&&day(m.day)&&(m.completedDay===null||day(m.completedDay)&&m.completedDay<=s.day);
      });
    }catch{return false;}
  };
})(typeof window!=='undefined'?window:globalThis);

;
/* Validate optional activity metadata without rejecting old saves. */
(function(root){
  'use strict';
  const base=root.validState,D=root.ActivityData,has=(map,key)=>Object.hasOwn(map,key);
  root.validState=function(s){
    if(!base(s))return false;
    try{
      const metadata=(x,kind)=>{
        if(x.albumType!==undefined&&(!has(D.albums,x.albumType)||kind!=='single'||x.trackCount!==D.albums[x.albumType].tracks))return false;
        if(x.trackCount!==undefined&&x.albumType===undefined)return false;
        if(x.venue!==undefined&&(!has(D.venues,x.venue)||kind!=='live'))return false;
        if(x.contentType!==undefined&&(!has(D.content,x.contentType)||kind!=='cover'))return false;
        return true;
      };
      return s.jobs.every(j=>metadata(j,j.kind)&&(j.kind!=='single'||j.albumType||j.budget<=7000)&&(j.kind!=='live'||j.venue||j.budget<=1500)&&(!j.albumType||j.budget>=1000*D.albums[j.albumType].factor&&j.budget<=7000*D.albums[j.albumType].factor)&&(!j.venue||j.budget===D.venues[j.venue].cost))&&s.catalog.every(c=>metadata(c,'single'))&&s.outcomes.every(o=>metadata(o,o.kind));
    }catch{return false;}
  };
})(typeof window!=='undefined'?window:globalThis);

;
/* FILE src/guide.js */
(function(root) {
  'use strict';
  function guideStep(s) {
    const previous = Number.isInteger(s.guideStep) ? s.guideStep: 0;
    let step = 0;
    if (s.jobs.some(j => j.kind === 'casting')) step = 1;
    if (s.candidates.length) step = 2;
    if (s.artists.length || s.trainees?.length) step = 3;
    if (s.jobs.some(j => j.kind === 'single')) step = 4;
    if (s.releases > 0) step = 5;
    if (s.catalog.some(c => c.revenue > 0)) step = 6;
    return Math.max(previous, step);
  }
  const steps = [['첫 인재 찾기', '오디션은 500만 원·7일, 발굴은 200만 원·10일입니다. 원하는 분야의 모집을 시작하세요.', '캐스팅으로', 'casting'], ['후보 보고 기다리기', '날짜를 진행하면 후보 보고가 도착합니다. 주요 보고를 확인하면 날짜 건너뛰기를 사용할 수 있습니다.', '소식함으로', 'inbox'], ['첫 계약 맺기', '후보를 비교하고 계약하세요. 연습생 영입은100만 원, 전속계약은 제안서별 금액이며 경력자는 영입 지원금이 추가됩니다.', '후보 확인', 'casting'], ['첫 싱글 준비하기', '아티스트에서 육성 방향과 컨디션을 확인하세요. 싱글은 최소 1,000만 원이며 운영비는 별도입니다.', '아티스트 확인', 'artists'], ['첫 발매 기다리기', '싱글 제작은 21일입니다. 기다리는 동안 현금과 컨디션을 확인하세요.', '진행 중 확인', 'activity-progress'], ['첫 음원 정산 확인하기', '발매 후 매주 수익이 들어옵니다. 날짜를 진행한 뒤 재정에서 수입과 지출을 비교하세요.', '재정 확인', 'finance']];
  const api = { guideStep, steps };
  if (typeof module !== 'undefined') module.exports = api;
  else root.Guide = api;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/save-store.js */
(function(root) {
  'use strict';
  const codec = typeof module !== 'undefined' ? require('../vendor/pako.min.js'): root.pako;
  const MAX_SAVE_BYTES = 20000000;
  function utf8Size(text) {
    let bytes = 0;
    for (let i = 0; i < text.length; i++) {
      const c = text.charCodeAt(i);
      bytes += c < 128 ? 1: c < 2048 ? 2: c >= 0xD800 && c <= 0xDBFF && i + 1 < text.length ?(i++, 4): 3;
    }
    return bytes;
  }
  function encode(value) {
    let raw = JSON.stringify(value);
    if (utf8Size(raw) > MAX_SAVE_BYTES) throw Error('저장 크기 한도를 초과했습니다. 기존 저장을 유지합니다.');
    let bytes = codec.deflate(raw, { level: 3 }),
    parts = [];
    for (let i = 0; i < bytes.length; i += 16000) parts.push(String.fromCharCode(... bytes.subarray(i, i + 16000)));
    const data = root.btoa(parts.join(''));
    if (data.length > 12000000) throw Error('압축 저장 크기 한도를 초과했습니다. 기존 저장을 유지합니다.');
    return JSON.stringify({ codec: 'deflate-base64-v1', data });
  }
  function decode(raw) {
    let item = JSON.parse(raw);
    if (item?.codec !== 'deflate-base64-v1') return item;
    if (typeof item.data !== 'string' || item.data.length > 12000000) throw Error('Invalid compressed save');
    let binary = root.atob(item.data),
    bytes = Uint8Array.from(binary, c => c.charCodeAt(0)),
    inflate = new codec.Inflate({ to: 'string' }),
    parts = [],
    length = 0;
    inflate.onData = chunk => {
      length += utf8Size(chunk);
      if (length > MAX_SAVE_BYTES) throw Error('Expanded save too large');
      parts.push(chunk);
    };
    inflate.push(bytes, true);
    if (inflate.err) throw Error('Corrupt save');
    return JSON.parse(parts.join(''));
  }
  class SaveStore {
    constructor(provider, validate) {
      this.provider = provider;
      this.validate = validate;
      // Keep the version observed by this tab. Generic reads never adopt a newer save.
      this.autoBase = undefined;
      try { this.autoBase = this.storage().getItem('next-stage-v1'); } catch {}
    }
    storage() {
      return typeof this.provider === 'function' ? this.provider(): this.provider;
    }
    read(key) {
      try {
        let raw = this.storage().getItem(key);
        if (!raw) return null;
        return decode(raw);
      } catch {
        return null;
      }
    }
    checked(state) {
      if (!this.validate(state)) throw Error('손상되거나 지원하지 않는 저장입니다.');
      return JSON.parse(JSON.stringify(state));
    }
    readAuto(adopt = false) {
      try {
        const raw = this.storage().getItem('next-stage-v1');
        if (adopt) this.autoBase = raw;
        if (raw === null) return {state:null, status:'missing', raw};
        let state;
        try { state = decode(raw); } catch { return {state:null, status:'corrupt', raw}; }
        return this.validate(state) ? {state, status:'valid', raw}: {state:null, status:'corrupt', raw};
      } catch { return {state:null, status:'unavailable'}; }
    }
    hasAutoChanged() {
      try { return this.autoBase === undefined ? this.storage().getItem('next-stage-v1') !== null: this.storage().getItem('next-stage-v1') !== this.autoBase; }
      catch { return false; }
    }
    assertAutoCurrent(expected = this.autoBase) {
      const current = this.storage().getItem('next-stage-v1');
      if (expected === undefined ? current !== null: current !== expected) {
        const error = Error('다른 탭에서 저장이 변경됐습니다. 현재 진행을 백업하거나 최신 저장을 검토해 불러와 주세요.');
        error.code = 'SAVE_CONFLICT';
        throw error;
      }
    }
    writeAuto(state, expected = this.autoBase) {
      const clean = this.checked(state), encoded = encode(clean);
      this.assertAutoCurrent(expected);
      this.storage().setItem('next-stage-v1', encoded);
      this.autoBase = encoded;
      try { this.storage().setItem('next-stage-save-meta', JSON.stringify({ at: new Date().toISOString() })); }
      catch {}
    }
    slot(index) {
      if (!Number.isInteger(index) || index < 1 || index > 3) throw Error('저장 슬롯을 확인하세요.');
      return 'next-stage-slot-' + index;
    }
    saveSlot(index, state) {
      let entry = { savedAt: new Date().toISOString(), state: this.checked(state) };
      this.storage().setItem(this.slot(index), encode(entry));
      return entry;
    }
    removeSlot(index) {
      this.storage().removeItem(this.slot(index));
    }
    clearCheckpoints() {
      this.storage().removeItem('next-stage-checkpoints');
    }
    loadSlot(index) {
      let entry = this.read(this.slot(index));
      if (!entry) throw Error('슬롯이 비어 있거나 읽을 수 없습니다.');
      return this.checked(entry.state);
    }
    checkpoints() {
      let entries = this.read('next-stage-checkpoints');
      return Array.isArray(entries) ? entries.filter(e => e && typeof e.reason === 'string' && this.validate(e.state)).slice(0, 3):[];
    }
    checkpoint(state, reason) {
      let point = { savedAt: new Date().toISOString(), reason: String(reason).slice(0, 100), state: this.checked(state) };
      let points = [point, ... this.checkpoints()].slice(0, 3);
      this.storage().setItem('next-stage-checkpoints', encode(points));
      return point;
    }
    restorePoint(index) {
      let p = this.checkpoints()[index];
      if (!p) throw Error('복구 지점이 없습니다.');
      return this.checked(p.state);
    }
  }
  if (typeof module !== 'undefined') module.exports = SaveStore;
  else root.SaveStore = SaveStore;
})(typeof window !== 'undefined' ? window: globalThis);


;
/* FILE src/ui-events.js */
'use strict';
// One listener per DOM event. A feature registers its handler once by name.
const UIEvents =(() => {
  const changes = new Map();
  document.addEventListener('change', event => {
    for (const handler of changes.values()) handler(event);
  });
  return Object.freeze({ onChange(feature, handler) {
    if (changes.has(feature)) throw new Error('Duplicate UI event owner: ' + feature);
    changes.set(feature, handler);
  }
  });
})();


;
/* FILE src/ui-common.js */
'use strict';
// ui-common: see docs/MAINTENANCE.md for ownership and loading order.
const $ = s => document.querySelector(s), esc = x => String(x ?? '').replace(/[&<>"']/g, c =>({
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;'
}
[c])), KEY = 'next-stage-v1';
const icons = {
  home: 'M3 10 12 3l9 7v11h-6v-7H9v7H3z',
  mail: 'M3 5h18v14H3z M3 6l9 7 9-7',
  people: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M17 4a4 4 0 0 1 0 8 M22 21v-2a4 4 0 0 0-3-3.87',
  star: 'm12 3 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z',
  folder: 'M3 7V4h6l3 3h9v14H3z',
  staff: 'M4 7h16v14H4z M9 7V3h6v4 M4 12h16 M10 12v3h4v-3',
  chart: 'M4 21V11h4v10 M10 21V3h4v18 M16 21V7h4v14',
  calendar: 'M3 5h18v16H3z M7 3v4 M17 3v4 M3 10h18',
  music: 'M9 18V5l12-2v13 M9 5l12-2 M9 18a3 3 0 1 1-3-3c2 0 3 1 3 3 M21 16a3 3 0 1 1-3-3c2 0 3 1 3 3',
  settings: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M12 2v3 M12 19v3 M2 12h3 M19 12h3 M5 5l2 2 M17 17l2 2 M5 19l2-2 M17 7l2-2',
  arrow: 'M5 12h14 M13 6l6 6-6 6',
  wallet: 'M3 5h17v16H3z M3 5l14-3v3 M15 11h6v5h-6z',
  check: 'M5 12l4 4L19 6',
  play: 'M8 4l12 8-12 8z',
  more: 'M5 12h.01 M12 12h.01 M19 12h.01'
};
const ico =(name) => `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="${icons[name]||icons.music}"/></svg>`;
const btn =(text, action, args = '', cls = '', disabled = false) => `<button type="button" class="${cls}" data-action="${action}" ${action==='nav'&&cls.split(/\s+/).includes('active')?'aria-current="page"':''} ${args} ${disabled?'disabled':''}>${text}</button>`;
const money = (n, decimals = 0) => {
  const factor = 10 ** decimals;
  n = Math.round(n * factor) / factor;
  if (Math.abs(n) >= 10000) {
    let a = Math.trunc(n / 10000),
    b = Math.abs(n % 10000);
    return a + '억' +(b ? ' ' + b.toLocaleString('ko-KR', {maximumFractionDigits:decimals}) + '만': '') + ' 원';
  }
  return n.toLocaleString('ko-KR', {maximumFractionDigits:decimals}) + '만 원';
};
const date =(day, full = false) => {
  let d = new Date(Date.UTC(2027, 0, 1 + day));
  return full ? `${d.getUTCFullYear()}년 ${d.getUTCMonth()+1}월 ${d.getUTCDate()}일 ${['일','월','화','수','목','금','토'][d.getUTCDay()]}요일`: `${d.getUTCMonth()+1}.${d.getUTCDate()}`;
};
const focusLabel = {
  balanced: '균형 성장',
  creative: '창작 집중',
  stage: '무대 집중',
  rest: '충분한 휴식'
};
const kindLabel = {
  award: '시상식',
  single: '앨범 준비',
  live: '라이브 공연',
  cover: '콘텐츠',
  ad: '광고 촬영',
  casting: '인재 모집'
};


;
/* FILE src/app.js */
'use strict';
// app: see docs/MAINTENANCE.md for ownership and loading order.
const saveStore = new SaveStore(() => localStorage, validState);
let lastAdvanceNotice = null;
let game = new Game(), page = 'home', filter = 'all', selectedReport = null, running = false, stopReason = '', saveOK = true;


;
/* FILE src/app-storage.js */
'use strict';
// app-storage: see docs/MAINTENANCE.md for ownership and loading order.
let autoLoadStatus = 'missing';
function save() {
  if (!game.s) return false;
  game.s.guideStep = Guide.guideStep(game.s);
  try {
    saveStore.writeAuto(game.s);
    saveOK = true;
    return true;
  } catch (error) {
    saveOK = false;
    if (error.code === 'SAVE_CONFLICT') {
      running = false;
      stopReason = error.message;
      toast(error.message);
      return false;
    }
    toast('자동 저장이 제한되어 있습니다. 설정에서 백업을 내보내 주세요.');
    return false;
  }
}
function loadSaved(adopt = false) {
  const loaded = saveStore.readAuto(adopt);
  autoLoadStatus = loaded.status;
  return loaded.state;
}
window.addEventListener('storage', event => {
  if (event.key !== KEY || !game.s || !saveStore.hasAutoChanged()) return;
  saveOK = false;
  running = false;
  stopReason = '다른 탭에서 저장이 변경됐습니다. 현재 진행을 백업한 뒤 설정에서 최신 저장을 검토해 주세요.';
  render();
  toast(stopReason);
});
window.addEventListener('pagehide', () => {
  if (game.s) save();
});

const BACKUP_META_KEY = 'next-stage-backup-meta-v1';
function backupMeta(state) {
  try {
    const meta = JSON.parse(localStorage.getItem(BACKUP_META_KEY));
    return meta && meta.company === state.company && meta.boss === state.boss &&
      Number.isFinite(meta.at) && meta.at > 0 && meta.at <= Date.now() &&
      Number.isInteger(meta.day) && meta.day >= 0 && meta.day <= state.day ? meta : null;
  } catch { return null; }
}
function backupDue(state) {
  const meta = backupMeta(state);
  return meta ? state.day - meta.day >= 30 || Date.now() - meta.at >= 7 * 86400000 : state.day >= 30;
}
function backupStatusHTML(state) {
  if (!state) return '';
  const meta = backupMeta(state);
  return `<p class="muted">${meta ? '마지막 백업 내보내기 요청: ' + esc(new Date(meta.at).toLocaleString('ko-KR')) + ' · ' + date(meta.day, true) : '이 회사의 백업 내보내기 기록이 없습니다.'}</p><p class="muted">내보낸 파일이 다운로드 폴더에 있는지 확인하세요. 백업 기록은 이 브라우저에만 보관됩니다.</p>`;
}
function backupReminderHTML() {
  if (!game.s || !backupDue(game.s)) return '';
  return `<section class="panel section backup-reminder" aria-label="저장 백업 안내"><strong>진행 내용을 파일로 보관해 주세요.</strong><p>백업은 게임 내 30일 또는 실제 7일마다 권장합니다. 브라우저 데이터가 삭제되면 자동 저장과 슬롯도 사라집니다.</p>${btn('백업·저장 관리', 'settings', '', 'soft')}</section>`;
}

function settings_app() {
  modal('설정 · 저장 관리', `<div class="tip">이 브라우저에 자동 저장됩니다. 다른 기기·주소로 이동할 때는 백업 파일을 내보낸 뒤 불러와 주세요.</div>${backupStatusHTML(game.s || loadSaved())}<div class="list section">${btn('현재 진행 저장','manual-save','','primary',!game.s)}${btn('저장 백업 내보내기','export','','soft',!game.s&&!loadSaved())}<label class="check-row" style="justify-content:center;cursor:pointer">백업 파일 불러오기<input type="file" id="import-save" accept="application/json,.json" style="max-width:180px;font-size:11px"></label>${saveStore.hasAutoChanged()?btn('최신 저장 검토','latest-save','','soft'):''}${btn('저장 슬롯·복구 지점','m-saves','','soft')}${game.s?btn(game.s.guideHidden?'가이드 다시 켜기':'가이드 숨기기','guide-toggle','','soft')+btn('타이틀로 돌아가기','to-title'):''}</div><p class="muted" style="font-size:12px;margin-top:18px">v${DATA.rules.version} · 초반부터 후속 활동까지 계속 운영할 수 있습니다. 오프라인 파일 실행도 지원하며 PC·모바일 저장은 자동 동기화되지 않습니다.</p>`);
}

function reviewLatestSave() {
  const latest = saveStore.readAuto();
  if (!latest.state) throw Error('최신 자동 저장을 읽을 수 없습니다. 슬롯·복구 지점 또는 JSON 백업을 선택하세요.');
  previewRestore(latest.state, '다른 탭의 최신 자동 저장', latest.raw);
}

function checkSaveSession() {
  try { if (saveStore.hasAutoChanged()) saveStore.assertAutoCurrent(); }
  catch (error) {
    if (error.code === 'SAVE_CONFLICT') {
      saveOK = false;
      running = false;
      stopReason = error.message;
    }
    throw error;
  }
}


;
/* FILE src/app-shell.js */
'use strict';
// app-shell: see docs/MAINTENANCE.md for ownership and loading order.
function toast(text) {
  $('#toast').textContent = text;
  $('#toast').classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => $('#toast').classList.remove('show'), 3300);
}
let modalReturnFocus = null;
function modal(title, body, wide = false, tapToDismiss = false) {
  if (!$('#modal-root').children.length) modalReturnFocus = document.activeElement;
  $('#modal-root').innerHTML = `<div class="modal-backdrop" ${tapToDismiss?'data-action="close"':''}><section class="modal" role="dialog" aria-modal="true" aria-label="${esc(title)}" ${wide?'style="width:820px"':''}><div class="modal-head"><h2>${esc(title)}</h2>${btn('×','close','aria-label="닫기"')}</div>${body}<div class="error" id="modal-error" role="alert"></div></section></div>`;
  setTimeout(() => $('#modal-root input, #modal-root select, #modal-root button')?.focus(), 20);
}
function close() {
  if (running) return;
  $('#modal-root').innerHTML = '';
  if (modalReturnFocus?.isConnected) modalReturnFocus.focus();
  modalReturnFocus = null;
}
function title() {
  running = false;
  lastAdvanceNotice = null;
  selectedReport = null;
  game.s = null;
  $('#modal-root').innerHTML = '';
  let s = loadSaved();
  $('#app').innerHTML = `<main class="title-screen"><section class="title-left"><div class="brand"><img src="assets/logo.svg" alt=""><div>NEXT STAGE<small>넥스트 스테이지</small></div></div><div class="eyebrow">YOUR NEXT BIG THING</div><h1>가능성을 만나,<br><span>무대를 만들다.</span></h1><p>아이돌, 밴드, 힙합.<br>당신의 안목으로 시작하는 음악 기획사.<br>첫 만남부터 다음 무대까지, 함께 성장하세요.</p><div class="title-actions">${btn('새로운 기획사 설립 '+ico('arrow'),'new','','primary')}${btn(s?`이어하기 · ${esc(s.company)} / ${date(s.day)}`:'이어하기','continue','','',!s)}${s?`<small>보유 자금 ${money(s.cash)} · 진행 일정 ${s.jobs.length+(s.engagements?.length||0)}건 · 전속 ${s.artists.length}명</small>`:''}${autoLoadStatus==='corrupt'?'<p class="negative" role="alert">자동 저장을 읽을 수 없습니다. 원본은 유지했습니다. 설정에서 슬롯·복구 지점 또는 JSON 백업을 불러오세요.</p>':autoLoadStatus==='unavailable'?'<p class="negative" role="alert">브라우저 저장소에 접근할 수 없습니다. 설정에서 백업을 확인하세요.</p>':''}${btn('설정 · 저장 백업','settings','','link')}</div><div class="version">NEXT STAGE · v${DATA.rules.version} · PC & MOBILE</div></section><section class="title-art" aria-label="개성 있는 세 아티스트"><div class="title-portraits"><img src="${DATA.roster[0].image}" alt="아이돌 서윤"><img src="${DATA.roster[1].image}" alt="밴드 아티스트 태오"><img src="${DATA.roster[2].image}" alt="래퍼 리오"></div><div class="title-art-caption">EVERY TALENT HAS A NEXT STAGE.</div></section></main>`;
}
const navs = [['home','홈','home'], ['inbox','수신함','mail'], ['artists','아티스트','people'], ['training','육성','star'], ['projects','활동','music'], ['company','회사','chart'], ['industry','업계','star']];
function primaryNavigationActive(id) {
  const selected = [...game.s.artists,...game.s.trainees].find(a=>a.id===developmentId)||game.s.artists[0]||game.s.trainees[0];
  const training = page === 'training' || page === 'development' && selected && game.s.trainees.includes(selected);
  return training ? id === 'training' : pageGroup(page) === id;
}
function navigate(p) {
  page = p;
  filter = 'all';
  stopReason = '';
  close();
  render();
  window.scrollTo(0, 0);
}
function render() {
  if (!game.s) return title();
  const archive = $('#app .studio-archive');
  if (archive) studioArchiveOpen = archive.open;
  let s = game.s;
  $('#app').innerHTML = `<aside class="sidebar"><div class="brand"><img src="assets/logo.svg" alt=""><div>NEXT STAGE<small>넥스트 스테이지</small></div></div><div class="company-label"><strong>${esc(s.company)}</strong><small>음악으로, 더 멀리.</small></div><nav class="nav" aria-label="주요 메뉴">${navs.map(([id,name,icon])=>btn(`${ico(icon)} ${name}${id==='inbox'&&s.reports.some(r=>!r.read)?`<span class="spacer"></span><span class="badge">${s.reports.filter(r=>!r.read).length}</span>`:''}`,'nav',`data-page="${id}"`,primaryNavigationActive(id)?'active':'')).join('')}</nav><div class="sidebar-foot"><div class="row"><span class="boss-icon">${ico('staff')}</span><div><strong>${esc(s.boss)} 대표</strong><small style="display:block">${DATA.stageNames[game.stage]}</small></div></div>${btn(ico('settings')+' 설정 · 저장','settings','','link section')}</div></aside><header class="topbar"><strong class="top-company">${esc(s.company)}</strong><span class="mobile-brand">${esc(s.company)}</span><span class="date">${ico('calendar')}${date(s.day,true)}</span><span class="spacer"></span><div class="row advance">${btn(running?'진행 중…':'하루 진행','day','','',running)}${btn(running?'진행 중 · 중지':'중요 일정까지 '+ico('play'),running?'stop':'skip','','primary')}</div></header>${stopReason?`<div class="stop-strip">${ico('mail')} ${esc(stopReason)}<span class="spacer"></span>${btn('소식함','nav','data-page="inbox"','link')}</div>`:''}<main class="main ${page==='home'?'is-dashboard':''}">${sectionTabs()}${progressSummaryCard()}${({home:home,inbox:inbox,artists:artists,casting:casting,projects:projects,concerts:concerts_activity,content:content_activity,offers:offers_activity,'activity-progress':progress_activity,'activity-results':results_activity,staff:staff,recruit:recruitScreen,finance:finance,training:training,teams:teams,industry:industry,company:company,goals:goals,schedule:schedule,development:developmentScreen,music:music,charts:charts}[page]||home)()}${backupReminderHTML()}<div class="footer-note">NEXT STAGE · v${DATA.rules.version} · ${saveStatusLabel()}</div></main><nav class="bottom-nav" aria-label="모바일 주요 메뉴">${[['home','홈','home'],['inbox','수신함','mail'],['artists','인재','people'],['projects','활동','music'],['company','회사','chart'],['industry','업계','star']].map(([id,name,ic])=>btn(`${ico(ic)}<span>${name}</span>${id==='inbox'&&s.reports.some(r=>!r.read)?'<i class="badge">'+s.reports.filter(r=>!r.read).length+'</i>':''}`,id==='more'?'more':'nav',`data-page="${id}"`,pageGroup(page)===id?'active':'')).join('')}</nav>`;
}


;
/* FILE src/app-screens.js */
'use strict';
// app-screens: see docs/MAINTENANCE.md for ownership and loading order.
function heading(title, desc, action = '') {
  return `<div class="page-head row between wrap"><div><h1>${title}</h1><p>${desc}</p></div>${action}</div>`;
}
function portraitCard(a) {
  let d = DATA.roster[a.id],
  e = game.entities.find(e => e.members.some(m => m.id === a.id)),
  busy = game.s.jobs.find(j => j.entity === e?.key);
  return btn(`<img loading="lazy" decoding="async" class="portrait" src="${d.image}" alt="${d.name}" loading="lazy"><div class="artist-caption"><strong>${d.name}</strong><small>${e?.members.length>1?esc(e.name):'솔로'} · ${d.style}</small><small>팬 ${a.fans.toLocaleString()}명 · 인지도 ${Math.round(a.fame)}</small><span class="pill">${busy?kindLabel[busy.kind]+' D-'+(busy.due-game.s.day):focusLabel[a.focus]}</span></div>`, 'artist', `data-id="${a.id}"`, 'artist-card');
}
function reportRows(reports) {
  return reports.length ? reports.map(r => `<div class="report-row"><span class="avatar">${ico(r.kind==='casting'?'star':r.kind==='ad'?'chart':'mail')}</span><div class="report-body"><div class="row between"><small>운영 실장 · ${date(r.day)}</small>${r.important&&!r.read?'<span class="pill coral">확인 필요</span>':''}</div><strong>${esc(r.title)}</strong>${btn(r.kind==='casting'?'후보 확인':r.kind==='ad'?'제안 보기':'보고서 확인','report',`data-id="${r.id}"`,'link small')}</div></div>`).join(''): '<p class="muted">모든 보고를 확인했습니다.</p>';
}
function guideCard() {
  let s = game.s;
  if (s.guideHidden) return '';
  s.guideStep = Guide.guideStep(s);
  if (s.guideStep >= Guide.steps.length) return '<section class="panel section"><strong>첫 운영 가이드 완료</strong><p>첫 작품의 정산까지 경험했습니다. 직원·회사에서 다음 성장 조건을 확인하세요.</p></section>';
  let[title, body, label, target] = Guide.steps[s.guideStep];
  if (s.guideStep === 3 && !s.artists.length && s.trainees.length) {
    title = '연습생을 데뷔시키세요';
    body = '훈련 90일·평균 능력 55 이상부터 데뷔 계약을 맺고 첫 작품을 준비할 수 있습니다.';
    label = '연습생 확인';
    target = 'training';
  }
  return '<section class="panel section" aria-label="첫 운영 가이드"><div class="row between wrap"><strong>첫 운영 가이드 · ' +(s.guideStep + 1) + ' / ' + Guide.steps.length + '</strong>' + btn('가이드 건너뛰기', 'guide-hide', '', 'link small') + '</div><h2>' + title + '</h2><p>' + body + '</p>' + btn(label, 'nav', 'data-page="' + target + '"', 'soft small') + '</section>';
}
function casting() {
  let s = game.s;
  let j = s.jobs.find(j => j.kind === 'casting');
  return heading('캐스팅', '아직 발견되지 않은 가능성, 회사의 다음 시작.', btn('모집 지시', 'casting-modal', '', 'primary', !!j)) + `<div class="two-col"><div class="panel"><span class="pill">공개 오디션</span><h2 style="margin:12px 0">여러 재능을 한자리에서</h2><p class="muted">개최비 500만 원 · ${game.has('casting')?5:7}일 · 최대 6명 보고<br>아이돌·밴드·힙합 분야를 지정할 수 있습니다.</p></div><div class="panel"><span class="pill coral">인재 발굴</span><h2 style="margin:12px 0">작은 무대에서 찾은 가능성</h2><p class="muted">활동비 200만 원 · ${game.has('casting')?8:10}일 · 최대 3명 보고<br>공연장과 온라인에서 활동 중인 인재를 찾습니다.</p></div></div>${j?`<div class="tip section">${ico('calendar')} ${esc(j.name)} 진행 중 · 결과 보고까지 ${j.due-s.day}일. ${btn('중요 일정까지 진행','skip','','link')}</div>`:''}<div class="panel-head section"><h2>영입 후보 <small>${s.candidates.length}명</small></h2><small>연습생 영입 100만 원 · 신인 계약금은 제안서별 적용 · 후보 유효기간 30일</small></div>${s.candidates.length?`<div class="candidate-grid">${s.candidates.map(c=>{let d=DATA.roster[c.id];return `<article class="panel candidate"><img loading="lazy" decoding="async" class="portrait" src="${d.image}" alt="${d.name}" loading="lazy"><div class="candidate-info"><div class="row between"><h2>${d.name}</h2><span class="pill">${DATA.labels[d.type]}</span></div><small>${d.age}세 · ${d.trainee?'연습생 후보':'신인 아티스트'} · ${d.position} · ${d.traits}</small><p>${d.story}</p><div class="row between wrap"><small>계약 제안 D-${c.expires-s.day}</small>${btn('프로필·계약','candidate',`data-id="${d.id}"`,'soft small')}</div></div></article>`;}).join('')}</div>`:`<div class="empty section"><h3>${j?'어떤 인재를 만나게 될까요?':'첫 만남을 준비하세요'}</h3><p>${j?'직원이 후보를 평가하고 있습니다. 날짜를 진행해 주세요.':'오디션이나 발굴을 지시하면 후보 보고가 도착합니다.'}</p></div>`}`;
}
function artists() {
  let list = game.s.artists.filter(a => filter === 'all' || DATA.roster[a.id].type === filter);
  return heading('아티스트', '같은 목표, 각자의 빛. 음악과 사람을 함께 키우세요.', btn('팀 결성', 'unit-modal', '', 'primary', game.s.artists.length < 2)) + `<div class="tabs">${[['all','전체'],['idol','아이돌'],['band','밴드'],['rap','힙합']].map(([id,l])=>btn(l,'filter',`data-filter="${id}"`,filter===id?'active':'')).join('')}</div>${game.s.units.length?`<div class="tip" style="margin-bottom:20px">소속 팀 · ${game.s.units.map(u=>esc(u.name)+' ('+u.ids.map(id=>DATA.roster[id].name).join(' · ')+')').join(' / ')}</div>`:''}${list.length?`<div class="candidate-grid">${list.map(portraitCard).join('')}</div>`:`<div class="empty">${ico('people')}<h3>아직 소속 아티스트가 없습니다</h3><p>캐스팅에서 새로운 인재와 만나세요.</p>${btn('캐스팅으로','nav','data-page="casting"','primary')}</div>`}`;
}
function statsHTML(stats, known = true, id = 0) {
  return DATA.specs.map((name, i) => {
    let v = Math.round(stats[i]),
    lo = Math.max(0, Math.floor(v / 10) * 10 - 5),
    hi = Math.min(100, lo + 20);
    return `<div class="statline"><span>${name}</span><div class="bar"><span style="width:${known?v:(lo+hi)/2}%"></span></div><b>${known?v:lo+'~'+hi}</b></div>`;
  }).join('');
}
function artistModal_app(id, candidate = false) {
  if (candidate) return talentModal(id);
  let d = DATA.roster[id],
  a = game.artist(id),
  c = game.s.candidates.find(c => c.id === id);
  if (!d ||(!a && !c)) throw Error('현재 확인 가능한 아티스트가 아닙니다.');
  let known = !candidate || c.evaluated;
  modal(d.name + ' · ' + DATA.labels[d.type], `<div class="detail-grid"><div class="detail-photo-wrap"><img class="detail-photo" src="${d.image}" alt="${d.name}"><p>${d.age}세 · ${d.traits}<br>${d.story}</p></div><div><span class="pill">${d.style}</span>${statsHTML(a?a.stats:d.stats,known,id)}${candidate?`<small>${known?'추가 평가 완료 · 현재 실력 확인':'현재 실력 추정치 · 평가 신뢰도 보통'}</small><p class="muted" style="font-size:12px;margin-top:12px">${c.evaluated?'직원 의견: '+(d.type==='band'?'합주 경험을 쌓으면 팀 활동에서 강점을 보일 후보입니다.':d.type==='rap'?'작사와 라이브에 투자하면 자신만의 색을 만들 후보입니다.':'기초 훈련과 무대 경험을 함께 쌓는 편이 좋겠습니다.'):'잠재력은 확정 수치가 아닙니다. 실제 육성 결과는 훈련과 활동에 따라 달라집니다.'}</p>`:''}</div></div>${personalityCard(id)}${a?`<div class="detail-state">${[['체력',Math.round(a.energy)],['스트레스',Math.round(a.stress)],['회사 신뢰',Math.round(a.trust)],['충성 팬',a.fans.toLocaleString()+'명'],['대중 인지도',Math.round(a.fame)],['계약 만료',date(a.contract)]].map(([n,v])=>`<div><small>${n}</small><b>${v}</b></div>`).join('')}</div><label for="focus">육성 방향</label><select id="focus" data-focus="${id}">${Object.entries(focusLabel).map(([k,v])=>`<option value="${k}" ${a.focus===k?'selected':''}>${v}</option>`).join('')}</select><small>세부 일정은 실장이 조율합니다. 체력이 낮으면 자동으로 휴식합니다.</small><div class="modal-actions">${a.contract-game.s.day<=90?btn('재계약 협상','m-renew',`data-id="${id}"`,'soft'):''}${btn('활동 준비','project-modal',`data-entity="${game.entities.find(e=>e.members.some(m=>m.id===id)).key}"`,'primary')}</div>`:`<div class="modal-actions">${!c.evaluated?btn('추가 평가 · 50만 원','evaluate',`data-id="${id}"`,'soft'):''}${btn('계약 승인 · 200만 원','sign',`data-id="${id}"`,'primary',game.s.artists.length>=game.capacity)}</div><small>제안서별 기간 적용 · 활동 수익의 아티스트 배분은 게임 정산액에 반영된 것으로 처리합니다.</small>`}`, true);
}
function projects_app() {
  let s = game.s;
  return heading('프로젝트', '방향과 예산을 승인하면, 실무는 직원이 맡습니다.', btn('새 프로젝트', 'project-modal', '', 'primary', !s.artists.length)) + `<div class="tip">${ico('music')} 승인한 예산 안에서 제작이 자동 진행됩니다. 동일 아티스트는 한 번에 하나의 프로젝트·광고를 진행할 수 있습니다.</div><h2 class="section" style="margin-bottom:15px">진행 중인 활동</h2>${s.jobs.filter(j=>j.kind!=='casting').length?`<div class="two-col">${s.jobs.filter(j=>j.kind!=='casting').map(j=>`<article class="project-row"><div class="row between"><span class="pill">${kindLabel[j.kind]}</span><small>D-${j.due-s.day}</small></div><h3 style="margin-top:12px">${esc(j.name)}</h3><small>${esc(j.snapshot?.name||game.entity(j.entity)?.name||'확정 일정')} · ${date(j.due)} 예정</small><div class="bar"><span style="width:${j.kind==='single'?Math.max(0,Math.min(100,(1-game.productionState(j).remaining/((j.baselineDue??j.due)-j.start))*100)):(s.day-j.start)/(j.due-j.start)*100}%"></span></div><small>${j.budget?'승인 예산 '+money(j.budget):'촬영 후 잔금 '+money(j.pay)}</small></article>`).join('')}</div>`:`<div class="empty"><h3>다음 무대를 준비하세요</h3><p>싱글 제작·공연·커버 공개 중 회사에 맞는 활동을 선택하세요.</p></div>`}<h2 class="section" style="margin-bottom:15px">발매 작품 · ${s.catalog.length}곡</h2><div class="list">${s.catalog.map(c=>`<div class="project-row row"><span class="avatar">${ico('music')}</span><div class="spacer"><h3>${esc(c.name)}</h3>${btn('성과 보기','m-release',`data-uid="${c.market.uid}"`,'link small')}<small>${esc(c.ownerName||game.entity(c.entity)?.name||'전속 종료 아티스트')} · 발매 ${c.age}일 · 완성도 ${Math.round(c.quality)}</small></div><div style="text-align:right"><small>누적 총수입</small><br><strong>${money(c.revenue)}</strong></div></div>`).join('')||'<p class="muted">첫 음악을 기다리고 있습니다.</p>'}</div>`;
}
function staff() {
  return staffScreen();
}
function inbox_app() {
  let s = game.s,
  r = s.reports.find(r => r.id === selectedReport);
  return heading('소식함', '중요한 판단은 대표에게, 일상의 실무는 직원에게.', btn('정보 보고 모두 읽음', 'read-info', '', 'soft')) + `<div class="inbox"><section class="panel inbox-list" style="padding:0">${s.reports.map(r=>btn(`<small>${date(r.day)} · ${r.resolved?'처리 완료':r.important?'주요 보고':'일반 보고'}</small><strong>${esc(r.title)}</strong>`,'open-report',`data-id="${r.id}"`,(r.id===selectedReport?'selected ':'')+(!r.read?'unread':''))).join('')}</section><section class="panel inbox-detail">${r?reportDetail(r):'<div class="report-placeholder">'+ico('mail')+'<p>왼쪽 목록에서 보고를 선택하세요.</p></div>'}</section></div>`;
}
function reportDetail_app(r) {
  if (r.incidentId) return incidentReport(r);
  let action = '';
  if (r.kind === 'casting') action = btn('후보 확인', 'nav', 'data-page="casting"', 'primary');
  if (r.kind === 'ad' && !r.resolved) action = `<div class="row wrap">${btn('광고 수락','resolve',`data-id="${r.id}" data-choice="accept"`,'primary',game.busy(r.entity))}${btn('제안 거절','resolve',`data-id="${r.id}" data-choice="decline"`)}<small>${game.busy(r.entity)?'현재 활동 중 · 일정 종료 후 수락 가능':'승인 시 촬영 일정 확정'} · 기한 ${date(r.expires)}</small></div>`;
  if (r.kind === 'event' && !r.resolved) action = `<div class="row wrap">${btn('외부 멘토 지원 · 150만','resolve',`data-id="${r.id}" data-choice="invest"`,'primary')}${btn('휴식 권유','resolve',`data-id="${r.id}" data-choice="rest"`,'soft')}</div>`;
  if (r.kind === 'contract') action = btn('아티스트 관리', 'nav', 'data-page="artists"', 'primary');
  if (r.kind === 'crisis' && !r.resolved) action = `<div class="row wrap">${btn('운영자금 대출','loan-modal','','primary')}${btn('재정 확인','nav','data-page="finance"','soft')}${btn('회생 지원 · 평판 -10','rescue',`data-id="${r.id}"`,'soft',game.s.cash>=0)}</div>`;
  return `<div class="row between"><span class="pill ${r.resolved?'green':''}">${r.resolved?'처리 완료':'운영 실장 보고'}</span><small>${date(r.day,true)}</small></div><h2 style="margin-top:18px">${esc(r.title)}</h2><div class="report-content">${esc(r.body)}</div>${action}`;
}
function finance_app() {
  let s = game.s,
  avail = Math.max(0, game.loanLimit - game.debt);
  return heading('재정·기록', '현금 흐름을 지키고, 다음 가능성에 투자하세요.', btn('운영자금 대출', 'loan-modal', '', 'primary')) + `<div class="metrics"><div class="panel metric"><div><small>현재 현금</small><strong>${money(s.cash)}</strong></div></div><div class="panel metric"><div><small>대출 잔액</small><strong>${money(game.debt)}</strong></div></div><div class="panel metric"><div><small>월 고정비</small><strong>${money(game.fixed)}</strong></div></div></div><div class="two-col section"><section class="panel"><div class="panel-head"><h2>대출 관리</h2><small>추가 한도 ${money(avail)}</small></div>${s.loans.map(l=>`<div class="project-row"><div class="row between"><strong>${money(l.remaining)}</strong>${btn('전액 조기 상환','repay-confirm',`data-id="${l.id}"`,'small')}</div><small>월 원금 ${money(l.payment)} + 잔액의 0.6% 이자<br>다음 납부 ${date(l.due)} · 연체 ${l.missed}회</small></div>`).join('')||'<p class="muted">이용 중인 대출이 없습니다.</p>'}<div class="tip section">대출금은 수익이 아닌 현금 유입입니다. 월 고정비와 훈련비 외에 매월 대출 상환액이 발생합니다.</div></section><section class="panel"><h2>이번 기간 현금 흐름</h2><div class="finance-mini"><div><small>유입 · 대출 포함</small><strong class="positive">${money(s.monthIn)}</strong></div><div><small>지출 · 상환 포함</small><strong>${money(s.monthOut)}</strong></div></div><small style="display:block;margin-top:15px">매 30일 정산 · 다음 정산 ${30-s.day%30}일 후<br>음원·음반은 각 작품 발매 후 매주 정산합니다.</small>${s.lastMonth?`<p class="muted" style="margin-top:15px;font-size:12px">지난 기간 · 유입 ${money(s.lastMonth.in)} / 지출 ${money(s.lastMonth.out)}</p>`:''}</section></div><div class="two-col section"><section class="panel"><h2 style="margin-bottom:15px">최근 거래</h2><div style="max-height:500px;overflow:auto"><table class="ledger"><thead><tr><th>날짜</th><th>내용</th><th>금액</th></tr></thead><tbody>${s.ledger.slice(0,100).map(t=>`<tr><td>${date(t.day)}</td><td>${esc(t.label)}</td><td class="${t.amount>0?'positive':'negative'}">${t.amount>0?'+':''}${money(t.amount)}</td></tr>`).join('')}</tbody></table>${!s.ledger.length?'<p class="muted">아직 거래가 없습니다.</p>':''}</div></section><section class="panel"><h2 style="margin-bottom:15px">회사의 발자취</h2><div class="list" style="max-height:500px;overflow:auto">${s.history.map(h=>`<div style="border-bottom:1px solid var(--line);padding-bottom:12px"><small>${date(h.day)}</small><p>${esc(h.text)}</p></div>`).join('')}</div></section></div>`;
}


;
/* FILE src/app-dialogs.js */
'use strict';
// app-dialogs: see docs/MAINTENANCE.md for ownership and loading order.
function projectModal_app(key) {
  let entities = game.entities;
  if (!entities.length) throw Error('먼저 아티스트와 계약해 주세요.');
  modal('새로운 활동 준비', `<form id="project-form"><div class="field"><label for="entity">아티스트·팀</label><select id="entity" name="entity">${entities.map(e=>`<option value="${e.key}" ${key===e.key?'selected':''}>${esc(e.name)} · ${DATA.labels[e.type]}${game.activityAvailability(e.key).allowed?'':' ('+esc(game.activityAvailability(e.key).reasons.join(' · '))+')'}</option>`).join('')}</select></div><div class="form-grid"><div class="field"><label for="project-kind">활동 종류</label><select id="project-kind" name="kind"><option value="single">싱글 제작 · 21일</option><option value="live">라이브 공연 · 7일</option><option value="cover">커버 공개 · 5일</option></select></div><div class="field"><label for="project-concept">활동 방향</label><select id="project-concept" name="concept"><option value="balanced">아티스트의 색과 대중성의 균형</option><option value="public">대중성 중심 · 정산 수익에 강점</option><option value="creative">창작 중심 · 아티스트 신뢰에 강점</option></select></div></div><div class="field"><label for="project-name">작품·활동 이름</label><input id="project-name" name="title" maxlength="30" placeholder="예: 우리의 첫 번째 계절" required></div><div class="field"><label for="budget">총 승인 예산</label><select id="budget" name="budget">${DATA.rules.activity.single.budgets.map(([n,label])=>`<option value="${n}" ${n===DATA.rules.activity.single.defaultBudget?'selected':''}>${label} · ${money(n)}</option>`).join('')}</select></div><div class="tip" id="budget-preview"></div><div class="modal-actions"><button class="primary" type="submit">프로젝트 승인</button></div></form>`);
  budgetPreview();
}
function castingModal() {
  modal('새로운 인재 모집', `<form id="casting-form"><div class="field"><label for="method">모집 방식</label><select id="method" name="method"><option value="audition">공개 오디션 · 500만 원</option><option value="scout">인재 발굴 · 200만 원</option></select></div><div class="field"><label for="type">찾고 싶은 분야</label><select id="type" name="type"><option value="any">모든 분야</option><option value="idol">아이돌</option><option value="band">밴드 연주자·보컬</option><option value="rap">래퍼</option></select></div><div class="field"><label for="position">밴드 포지션 (지정 시 밴드 분야 선택)</label><select id="position" name="position"><option value="any">전체</option><option>보컬</option><option>기타</option><option>베이스</option><option>드럼</option><option>키보드</option></select></div><label for="experience">찾고 싶은 경력</label><select name="experience" id="experience"><option value="any">전체</option><option value="trainee">연습생 후보</option><option value="career">활동 경력자 · 바로 활동 가능</option></select><div class="tip">후보 보고가 도착하면 날짜 건너뛰기가 멈춥니다. 후보를 비교한 뒤 원하는 인원만 영입할 수 있습니다.</div><div class="modal-actions"><button class="primary">모집 승인</button></div></form>`);
}
function newModal() {
  let s = loadSaved();
  modal('나만의 기획사 설립', `<form id="new-form"><div class="eyebrow">EVERY STORY STARTS HERE</div><div class="field"><label for="company">회사 이름</label><input id="company" name="company" maxlength="30" required placeholder="블루밍 뮤직" autocomplete="off"></div><div class="field"><label for="boss">사장 이름</label><input id="boss" name="boss" maxlength="20" required placeholder="대표님의 이름" autocomplete="off"></div><div class="tip">시작 자금 3억 원 · 기본 실장 1명 · 소속 아티스트 없음<br>첫 인재를 찾는 것부터 대표님의 이야기가 시작됩니다.</div>${s?'<label class="check-row section"><input type="checkbox" required>기존 자동 저장을 새 회사로 교체합니다.</label>':''}<div class="modal-actions"><button class="primary">회사 설립하기 ${ico('arrow')}</button></div></form>`);
}
function showReport(id, asModal) {
  let r = game.s.reports.find(x => x.id === + id);
  if (!r) return;
  r.read = true;
  selectedReport = r.id;
  save();
  if (asModal) {
    render();
    modal('직원 보고', reportDetail(r));
  } else {
    page = 'inbox';
    render();
  }
}
function unitModal_app() {
  let available = game.s.artists.filter(a => !game.s.units.some(u => u.ids.includes(a.id)));
  modal('새로운 팀 결성', `<form id="unit-form"><div class="field"><label for="unit-name">팀 이름</label><input id="unit-name" name="name" required maxlength="20" placeholder="예: 오프비트"></div><small>같은 분야의 멤버 2~5명 · 팀 결성 후 프로젝트는 팀 단위로 진행</small><div style="max-height:280px;overflow:auto">${available.map(a=>`<label class="check-row"><input type="checkbox" name="members" value="${a.id}"><img src="${DATA.roster[a.id].image}" alt=""><span>${DATA.roster[a.id].name} · ${DATA.labels[DATA.roster[a.id].type]}</span></label>`).join('')}</div><div class="modal-actions"><button class="primary">팀 결성 승인</button></div></form>`);
}


;
/* FILE src/app-progress.js */
'use strict';
// app-progress: see docs/MAINTENANCE.md for ownership and loading order.
function mutate_app(fn, message) {
  checkSaveSession();
  if (game.s && /계약|이적|해체|데뷔|영입|팀|직원|프로젝트|활동|사건|제조|발매/.test(message || '')) saveStore.checkpoint(game.s, message + ' 전');
  game.transaction(fn);
  let saved = save();
  close();
  render();
  if (message && saved) toast(message);
}
async function advance() {
  if (running || !game.s) return;
  const from = game.s.day;
  running = true;
  lastAdvanceNotice = {
    from,
    to: from,
    mode: 'day',
    stop: '하루 진행 중…'
  };
  render();
  try {
    await new Promise(r => setTimeout(r, 80));
    if (!running) return;
    checkSaveSession();
    game.nextDay();
    lastAdvanceNotice.to = game.s.day;
    lastAdvanceNotice.at = Date.now();
    let saved = save();
    stopReason = saved ?(game.pending.length ? '확인할 보고가 도착했습니다.': ''): '진행은 완료됐지만 저장에 실패했습니다. JSON 백업을 내보내세요.';
    lastAdvanceNotice.stop = '하루 진행 완료' +(stopReason ? ' · ' + stopReason: '');
  } catch (e) {
    stopReason = '날짜 진행 중 오류: ' + e.message;
    lastAdvanceNotice.stop = stopReason;
    toast(stopReason);
  } finally {
    running = false;
    render();
    showAdvanceNotice();
  }
}
async function skip() {
  if (running || !game.s) return;
  if (game.pending.length) {
    stopReason = '먼저 확인할 주요 보고가 ' + game.pending.length + '건 있습니다.';
    page = 'inbox';
    selectedReport = null;
    render();
    toast('주요 보고를 확인한 후 다시 진행하세요.');
    return;
  }
  const from = game.s.day;
  running = true;
  stopReason = '중요한 소식까지 진행합니다.';
  lastAdvanceNotice = {
    from,
    to: from,
    mode: 'skip',
    stop: stopReason
  };
  let count = 0;
  render();
  try {
    while (running && count < 30) {
      await new Promise(r => setTimeout(r, 110));
      if (!running) break;
      checkSaveSession();
      game.nextDay();
      count++;
      lastAdvanceNotice.to = game.s.day;
      if (!save()) {
        running = false;
        stopReason = count + '일 경과 · 저장 실패로 진행을 중지했습니다. JSON 백업이 필요합니다.';
      } else if (game.pending.length) {
        running = false;
        stopReason = count + '일 경과 · 중요한 보고가 도착해 중지했습니다.';
      }
      lastAdvanceNotice.stop = running ? count + '일 경과 · 진행 중': stopReason;
      render();
    }
    if (running) {
      stopReason = count + '일 경과 · 최대 진행 기간에 도달했습니다.';
    } else if (!stopReason.includes('경과')) stopReason = count + '일 경과 · ' +(stopReason || '사용자가 중지했습니다.');
    lastAdvanceNotice.stop = stopReason;
    lastAdvanceNotice.at = Date.now();
  } catch (e) {
    stopReason = count + '일 경과 · 진행 오류: ' + e.message;
    lastAdvanceNotice.stop = stopReason;
    toast(stopReason);
  } finally {
    running = false;
    render();
    showAdvanceNotice();
  }
}


;
/* FILE src/app-clicks.js */
'use strict';
// app-clicks: see docs/MAINTENANCE.md for ownership and loading order.
$('#app').addEventListener('click', handleClick);
$('#modal-root').addEventListener('click', handleClick);
function handleClick(ev) {
  let b = ev.target.closest('[data-action]');
  if (!b) return;
  let action = b.dataset.action,
  id = b.dataset.id;
  if (running && action !== 'stop') return;
  try {
    if (action.startsWith('m-')) return managementClick(action, b.dataset);
    switch (action) {
      case 'close': close();
      break;
      case 'new': newModal();
      break;
      case 'continue': {
        let s = loadSaved(true);
        if (!validState(s)) throw Error('저장 정보를 읽을 수 없습니다. 백업을 불러와 주세요.');
        game = new Game(s);
        $('#app').insertAdjacentHTML('beforeend', '<div class="loading-progress"><div><div class="brand" style="justify-content:center">NEXT STAGE</div><h2 style="margin-top:16px">우리의 다음 무대를 준비하고 있어요.</h2><div class="bar"><span></span></div><small>당신의 아티스트들이 기다리고 있습니다.</small></div></div>');
        setTimeout(() => {
          page = 'home';
          render();
        }, 850);
        break;
      }
      case 'nav': navigate(b.dataset.page);
      break;
      case 'more': modal('회사 업무', `<div class="list">${[['casting','캐스팅 · 인재 발굴'],['staff','직원·회사'],['finance','재정·기록'],['training','연습생·데뷔'],['teams','팀·계약'],['company','회사·가치'],['industry','업계·라이벌'],['goals','목표'],['schedule','통합 일정']].map(([p,n])=>btn(n,'nav',`data-page="${p}"`,'soft')).join('')}${btn('설정 · 저장','settings')}</div>`);
      break;
      case 'latest-save': reviewLatestSave();
      break;
      case 'settings': settings();
      break;
      case 'guide-hide': mutate(() => {
        game.s.guideHidden = true;
      }, '가이드를 건너뛰었습니다. 설정에서 다시 켤 수 있습니다.');
      break;
      case 'guide-toggle': game.s.guideHidden = !game.s.guideHidden;
      save();
      render();
      settings();
      break;
      case 'day': advance();
      break;
      case 'skip': close();
      skip();
      break;
      case 'stop': running = false;
      stopReason = '사용자가 진행을 중지했습니다.';
      if (lastAdvanceNotice) lastAdvanceNotice.stop = stopReason;
      save();
      render();
      break;
      case 'casting-modal': castingModal();
      break;
      case 'candidate': artistModal(+ id, true);
      break;
      case 'artist': artistModal(+ id);
      break;
      case 'evaluate': game.evaluate(+ id);
      save();
      artistModal(+ id, true);
      break;
      case 'sign': mutate(() => game.sign(+ id), '새로운 아티스트와 함께하게 되었습니다.');
      break;
      case 'filter': filter = b.dataset.filter;
      render();
      break;
      case 'unit-modal': unitModal();
      break;
      case 'project-modal': projectModal(b.dataset.entity);
      break;
      case 'report': showReport(id, true);
      break;
      case 'open-report': showReport(id, false);
      break;
      case 'resolve': mutate(() => game.resolve(+ id, b.dataset.choice), '안건을 처리했습니다.');
      break;
      case 'rescue': mutate(() => game.rescue(+ id), '회생 지원금을 받았습니다.');
      break;
      case 'read-info': mutate(() => game.markGeneralRead(), '일반 보고를 읽음 처리했습니다.');
      break;
      case 'staff-confirm': {
        let p = DATA.staff.find(x => x.id === id),
        h = game.has(id);
        modal(h ? '직원 퇴직 협의': '직원 채용 승인', `<h3>${p.name} · ${p.role}</h3><p class="report-content">${h?'퇴직 정산금 '+money(p.salary)+'을 지출합니다. 남은 직원과 실장이 업무를 분담합니다.':'채용비 '+money(p.fee)+' / 월 급여 '+money(p.salary)+'\n'+p.spec+' 업무를 담당합니다. 직무별 정원 효과는 직원 화면에서 확인하세요.'}</p><div class="modal-actions">${btn(h?'퇴직 승인':'채용 승인',h?'fire':'hire',`data-id="${id}"`,'primary')}</div>`);
        break;
      }
      case 'hire': mutate(() => game.hire(id), '직원을 채용했습니다.');
      break;
      case 'fire': mutate(() => game.fire(id), '퇴직 정산을 완료했습니다.');
      break;
      case 'loan-modal': modal('운영자금 대출', `<form id="loan-form"><div class="tip">현재 추가 가능 한도 ${money(Math.max(0,game.loanLimit-game.debt))}<br>12개월 원금 분할 상환 · 월 이자 잔액의 0.6% · 조기 상환 수수료 없음</div><div class="field section"><label for="amount">대출 금액</label><select name="amount" id="amount"><option value="1000">1,000만 원 · 월 원금 약 83만 + 이자</option><option value="3000">3,000만 원 · 월 원금 250만 + 이자</option><option value="5000">5,000만 원 · 월 원금 약 417만 + 이자</option></select></div><small>첫 납부는 실행 후 최소 30일이 지난 월 정산일입니다. 연체 시 이자가 원금에 가산됩니다.</small><div class="modal-actions"><button class="primary">대출 실행 승인</button></div></form>`);
      break;
      case 'repay-confirm': {
        let l = game.s.loans.find(l => l.id === + id);
        modal('대출 조기 상환', `<p>잔액 ${money(l.remaining)}을 전액 상환합니다.</p><div class="modal-actions">${btn('상환 승인','repay',`data-id="${id}"`,'primary')}</div>`);
        break;
      }
      case 'repay': mutate(() => game.repay(+ id), '상환을 완료했습니다.');
      break;
      case 'renew': mutate(() => game.renew(+ id), '재계약을 완료했습니다.');
      break;
      case 'manual-save': if (save()) toast('현재 진행을 저장했습니다.');
      break;
      case 'export': {
        let s = game.s || loadSaved();
        if (!s) throw Error('백업할 진행이 없습니다.');
        let blob = new Blob([JSON.stringify(s, null, 2)], { type: 'application/json' }),
        url = URL.createObjectURL(blob),
        a = document.createElement('a');
        a.href = url;
        a.download = 'next-stage-save-day-' + s.day + '.json';
        document.body.appendChild(a);
        a.click();
        a.remove();
        try { localStorage.setItem(BACKUP_META_KEY, JSON.stringify({company:s.company, boss:s.boss, day:s.day, at:Date.now()})); } catch {}
        if (game.s) render();
        if ($('#modal-root').children.length) settings();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        toast('백업 다운로드를 요청했습니다. 다운로드 폴더를 확인해 주세요.');
        break;
      }
      case 'to-title':
      if (game.s && !save()) {
        if ($('#modal-error')) $('#modal-error').textContent = '저장하지 못해 현재 게임을 유지했습니다. 백업 내보내기로 진행을 보관해 주세요.';
        break;
      }
      close();
      title();
      break;
    }
  } catch (e) {
    if ($('#modal-error')) $('#modal-error').textContent = e.message;
    else toast(e.message);
  }
}


;
/* FILE src/app-input.js */
'use strict';
// Form submission, field changes, backup import and keyboard accessibility.
$('#modal-root').addEventListener('submit', ev => {
  ev.preventDefault();
  let f = ev.target,
  data = new FormData(f);
  try {
    switch (f.getAttribute('id')) {
      case 'new-form': {
        let company = data.get('company').trim(),
        boss = data.get('boss').trim();
        if (!company || !boss) throw Error('회사 이름과 사장 이름을 입력하세요.');
        checkSaveSession();
        let previous = game.s || loadSaved();
        if (previous && validState(previous)) saveStore.checkpoint(previous, '새 회사 설립 전');
        game = new Game();
        game.newGame(company, boss);
        page = 'home';
        mutate(() => {
        }, '새로운 이야기가 시작됩니다.');
        showReport(game.s.reports[0].id, true);
        break;
      }
      case 'casting-form': mutate(() => game.startCasting(data.get('method'), data.get('type'), data.get('position'), data.get('experience') || 'any'), '모집을 시작했습니다. 날짜를 진행해 주세요.');
      break;
      case 'project-form': mutate(() => game.startProject(data.get('entity'), data.get('kind'), data.get('title'), data.get('budget'), data.get('concept'), { format: data.get('kind') === 'single' ?(data.get('format') || 'digital'): 'digital', quantity: Number(data.get('quantity') || 0), promotion: data.get('kind') === 'single' ?(data.get('promotion') || 'none'): 'none' }), '프로젝트를 승인했습니다.');
      break;
      case 'unit-form': mutate(() => game.formUnit(data.get('name'), data.getAll('members')), '새로운 팀을 결성했습니다.');
      break;
      case 'loan-form': mutate(() => game.borrow(data.get('amount')), '운영자금 대출이 실행되었습니다.');
      break;
    }
  } catch (e) {
    $('#modal-error').textContent = e.message;
  }
});

UIEvents.onChange('app', ev => {
  try {
    if (ev.target.dataset.focus) {
      game.setFocus(+ ev.target.dataset.focus, ev.target.value);
      save();
      render();
      toast('육성 방향을 변경했습니다.');
    }
    if (ev.target.id === 'policy') {
      game.s.policy = ev.target.value;
      save();
      toast('회사 운영 방침을 변경했습니다.');
    }
    if (ev.target.id === 'project-kind') {
      let k = ev.target.value,
      options = Object.fromEntries(Object.entries(DATA.rules.activity).map(([key, rule]) =>[key, rule.budgets]));
      $('#budget').innerHTML = options[k].map(([n, l]) => `<option value="${n}">${l} · ${money(n)}</option>`).join('');
      budgetPreview();
    }
    if (ev.target.id === 'budget') budgetPreview();
    if (ev.target.id === 'import-save') {
      let file = ev.target.files[0];
      if (!file) return;
      if (file.size > 20000000) throw Error('백업 파일이 너무 큽니다.');
      file.text().then(raw => {
        try {
          let s = JSON.parse(raw);
          if (!validState(s)) throw Error('지원하지 않거나 손상된 저장 파일입니다.');
          modal('백업 불러오기 확인', `<p><strong>${esc(s.company)}</strong> · ${date(s.day,true)}<br>현재 자동 저장을 이 백업으로 교체합니다.</p><div class="modal-actions">${btn('불러오기','confirm-import','','primary')}</div>`);
          let b = $('[data-action="confirm-import"]');
          b.addEventListener('click', () => {
            try {
              let previous = game.s || loadSaved();
              if (previous && validState(previous)) saveStore.checkpoint(previous, '백업 불러오기 전');
              s = new Game(s).s;
              saveStore.writeAuto(s);
            } catch {
              toast('백업을 저장할 수 없습니다. 기존 진행을 유지합니다.');
              return;
            }
            game = new Game(s);
            saveOK = true;
            page = 'home';
            close();
            render();
            toast('백업을 불러왔습니다.');
          });
        } catch (e) {
          toast(e.message);
        }
      }).catch(() => toast('백업 파일을 읽지 못했습니다. 기존 진행을 유지합니다.'));
    }
  } catch (e) {
    toast(e.message);
  }
});

document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && !running) close();
  if (e.key === 'Tab' && $('#modal-root').children.length) {
    let items = [... $('#modal-root').querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled)')].filter(x => x.getClientRects().length);
    if (!items.length) return;
    let first = items[0],
    last = items[items.length - 1];
    if (e.shiftKey &&(document.activeElement === first || !$('#modal-root').contains(document.activeElement))) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey &&(document.activeElement === last || !$('#modal-root').contains(document.activeElement))) {
      e.preventDefault();
      first.focus();
    }
  }
});


;
/* FILE src/management-ui.js */
'use strict';
const starNames = ['신인', '주목받는 신예', '인기 아티스트', '스타', '톱스타'];
const panel =(title, body) => `<section class="panel section"><h2>${title}</h2>${body}</section>`;
function offerOptions() {
  return Object.entries(DATA.terms).map(([k, t]) => `<option value="${k}" ${k==='balanced'?'selected':''}>${t.name} · ${t.days/365}년 · 회사 ${Math.round(t.share*100)}% · 기본 계약금 ${money(t.fee)}</option>`).join('');
}
function talentModal_management(id) {
  let d = DATA.roster[id],
  c = game.s.candidates.find(c => c.id === id);
  if (!c) throw Error('유효한 후보가 없습니다.');
  modal(d.name + ' · ' +(d.trainee ? '연습생': '신인 계약'), `<div class="detail-grid"><img class="detail-photo" src="${d.image}" alt="${d.name}"><div><p>${d.position} · ${d.traits}</p>${statsHTML(d.stats,c.evaluated)}<p>${d.story}</p></div></div>${personalityCard(id)}<form id="m-contract"><input type="hidden" name="id" value="${id}"><label for="offer">${d.trainee?'데뷔 시 적용할 기본 제안서 (현재 영입비 100만 원·육성계약 2년)':'전속계약 제안서'}</label><select id="offer" name="offer">${offerOptions()}</select><p class="muted">${d.trainee?'월 지원비 60만 원과 일 훈련비 2만 원. 90일 훈련·평균 능력 55부터 데뷔 평가가 가능합니다.':'기간·배분은 계약 이후 작품에 적용됩니다. 기존 작품의 약정 배분은 계약 종료 후에도 유지됩니다.'}</p><div class="modal-actions">${!c.evaluated?btn('추가 평가 · 50만','evaluate',`data-id="${id}"`):''}<button class="primary">${d.trainee?'연습생 영입':'전속계약 승인'}</button></div></form>`, true);
}
function termsText(a) {
  return `${a.terms.name} · 회사 ${Math.round(a.terms.share*100)}% / 아티스트 ${Math.round((1-a.terms.share)*100)}% · 만료 ${date(a.contract,true)}`;
}
function teams_management() {
  let s = game.s;
  return heading('팀·계약', '팀 활동·개인 전속계약·작품 권리는 별도로 유지됩니다.', btn('팀 결성', 'unit-modal', '', 'primary', s.artists.length < 2)) + `<div class="two-col section">${s.units.map(u=>`<article class="panel"><h2>${esc(u.name)}</h2><p>${u.ids.map(id=>DATA.roster[id].name).join(' · ')} · ${u.status==='active'?'활동':'휴지·재편'}</p><p>팀 인지도 ${u.fame.toFixed(1)} · 팀 팬 ${u.fans.toLocaleString()} · ${starNames[u.star]}</p><div class="row wrap">${btn('팀 관리','m-team',`data-key="${u.key}"`,'soft')}${btn(u.status==='active'?'활동 중단':'활동 재개','m-team-confirm',`data-key="${u.key}" data-op="${u.status==='active'?'pause':'resume'}"`)}${btn('해체 검토','m-team-confirm',`data-key="${u.key}" data-op="dissolve"`,'danger')}</div></article>`).join('')}</div>` + panel('개인 전속계약', s.artists.map(a => `<article class="contract-row"><h3>${DATA.roster[a.id].name} · ${starNames[a.star]} <small>최고 ${starNames[a.bestStar]}</small></h3><p>${termsText(a)}</p><p>개인 인지도 ${a.fame.toFixed(1)} · 개인 팬 ${a.fans.toLocaleString()} · 회사 신뢰 ${Math.round(a.trust)}</p><div class="row wrap">${btn('상세·육성','artist',`data-id="${a.id}"`)}${a.contract-s.day<=90?btn('재계약 협상','m-renew',`data-id="${a.id}"`,'primary'):''}${btn('합의 이적 검토','m-transfer',`data-id="${a.id}"`)}${s.units.some(u=>u.ids.includes(a.id))?btn('팀 탈퇴 검토','m-leave-confirm',`data-id="${a.id}"`):''}</div></article>`).join('') || '<p>전속 아티스트가 없습니다.</p>') + panel('최근 작품 배분 내역', `<p>회사가 보유한 기존 작품은 계약 종료·해체 후에도 약정 비율로 정산합니다.</p>${s.payments.slice(0,12).map(p=>`<p>${date(p.day)} · ${DATA.roster[p.id].name} · ${money(p.amount)} · ${esc(p.label)}</p>`).join('')||'<p>배분 내역 없음</p>'}`);
}
function company_management() {
  let m = game.metrics(),
  v = game.valuation(),
  s = game.s,
  previous = s.valuations.length > 1 ? s.valuations.at(- 2): null;
  return heading('회사·기업가치', '규모·수익·상장 여부를 구분해 평가합니다.') + `<div class="metrics"><div class="panel"><small>회사 규모</small><h2>${DATA.stageNames[game.stage]}</h2><p>비상장 · 대표 지분 100%</p></div><div class="panel"><small>추정 지분가치</small><h2>${money(v.low)} ~ ${money(v.high)}</h2><p>평가 신뢰도 ${v.confidence}</p></div><div class="panel"><small>운영 여유</small><h2>${m.runway.toFixed(1)}개월</h2><p>훈련·월 고정비 기준 / 새 제작·대출상환 제외</p></div></div>` + panel('최근 1년 운영 손익 (현금 기준)', `<p>기록 ${m.days}일 / 365일 · 기존 저장은 업데이트 이후부터 집계합니다.</p><div class="finance-mini"><div>총매출 <strong>${money(m.revenue)}</strong></div><div>영업비용 <strong>${money(m.expense)}</strong></div><div>영업이익 <strong>${money(m.profit)}</strong></div></div><p>아티스트 배분·제작비·급여·훈련·이자 포함. 대출 원금·회생금·이적금은 영업 실적에서 제외합니다.</p>`) + panel('평가 근거', `<p>영업가치 ${money(v.operating)} + 현금 ${money(s.cash)} − 부채 ${money(game.debt)}</p><p>주력 활동 매출 의존도 ${Math.round(m.concentration*100)}% · 계약 안정성 ${Math.round(v.contractRisk*100)}%</p><p>관측된 영업이익·매출과 계약 안정성으로 계산합니다. 음원 자산을 별도로 더하지 않아 중복 평가를 방지합니다.</p><p>${previous?'지난 평가 대비 '+money(v.value-previous.value)+' · 영업 실적, 현금·부채와 잔여 계약 기간 변화 반영':'비교할 평가 이력이 아직 없습니다.'}</p>`) + panel('5단계 승급 조건', `<p>분기 말 평가 · 2개 분기 연속 미달 시 한 단계 재평가 · 직원·기능 유지</p><div class="table-scroll"><table class="ledger"><thead><tr><th>단계</th><th>운영기간</th><th>연매출</th><th>영업이익</th><th>운영 여유</th></tr></thead><tbody><tr><td>신생 레이블</td><td>설립</td><td>—</td><td>—</td><td>—</td></tr>${DATA.stageRules.map(r=>`<tr><td>${DATA.stageNames[r.level]}</td><td>${r.days}일</td><td>${money(r.revenue)}</td><td>${money(r.profit)}</td><td>${r.runway}개월</td></tr>`).join('')}</tbody></table></div><p>규모 기준은 게임용 초기 밸런스입니다. 고수익 솔로 회사도 승급할 수 있습니다.</p>`);
}
function industry_management() {
  let s = game.s,
  v = game.valuation();
  return heading('업계·라이벌', '가상 회사 4곳의 활동과 추정치를 비교하세요.') + `<div class="two-col section">${s.rivals.map(r=>`<article class="panel"><h2>${esc(r.name)}</h2><p>${DATA.stageNames[r.level]} · ${r.type==='any'?'종합':DATA.labels[r.type]} · 소속 ${r.artists.length}명</p><h3>추정 기업가치 ${money(r.value*.8)} ~ ${money(r.value*1.2)}</h3><p>${r.artists.map(id=>DATA.roster[id].name).join(' · ')||'소속 없음'}</p><p>최근 공개 프로젝트 ${r.catalog.length}건 · 평판 ${Math.round(r.reputation)}</p><p>우리 회사와 추정 중앙값 차이 ${money(v.value-r.value)}</p></article>`).join('')}</div>` + panel('업계 소식', s.industryNews.map(n => `<p>${date(n.day)} · ${esc(n.text)}</p>`).join('') || '<p>첫 월간 업데이트를 기다리고 있습니다.</p>');
}
function managementClick_management(action, d) {
  let id = Number(d.id),
  a = game.artist(id);
  switch (action) {
    case 'm-renew': case 'm-debut': modal(action === 'm-renew' ? '재계약 제안서': '데뷔 계약 제안서', `<form id="${action}" class="list"><input type="hidden" name="id" value="${id}"><label for="offer">계약 제안</label><select name="offer" id="offer">${offerOptions()}</select><p>${a?'기존 작품 배분은 유지하며 새 활동부터 변경됩니다. 최종 계약금은 인지도·신뢰에 따라 조정됩니다. 아래에서 확인하세요.':'90일 훈련·평균 능력 55 이상 필요'}</p>${a?Object.entries(DATA.terms).map(([k,t])=>`<p>${t.name}: 실제 계약금 ${money(game.renewalCost(a,k))}</p>`).join(''):''}<button class="primary">계약 승인</button></form>`);
    break;
    case 'm-release-trainee': case 'm-leave-confirm': modal('계약·소속 변경 확인', `<p>${action==='m-release-trainee'?'연습생 계약을 합의 종료합니다.':'팀에서 탈퇴합니다. 개인 계약과 기존 작품 배분·확정 일정은 유지됩니다. 1명만 남으면 팀은 휴지 상태가 됩니다.'}</p><div class="modal-actions">${btn('변경 승인',action==='m-release-trainee'?'m-trainee-release':'m-leave',`data-id="${id}"`,'danger')}</div>`);
    break;
    case 'm-trainee-release': mutate(() => game.releaseTrainee(id), '연습생 계약을 종료했습니다.');
    break;
    case 'm-leave': mutate(() => game.leaveTeam(id), '팀에서 탈퇴했습니다.');
    break;
    case 'm-team-confirm': {
      const impact = game.teamImpact(d.key);
      modal('팀 운영 변경', `<p>확정 일정 ${impact.jobs.length}건 · 기존 작품 ${impact.catalog}개 유지. 현재 협업 호흡 ${Math.round(impact.cohesion)}.</p>${impact.jobs.map(j=>`<p>${esc(j.name)} · ${date(j.due)}</p>`).join('')}<p>${d.op==='dissolve'?'팀을 해체합니다. 이름과 활동 이력은 보존되며, 개인 계약·기존 작품 배분·확정 일정은 유지됩니다.':d.op==='pause'?'새 팀 활동을 중단합니다. 이미 확정된 일정은 완료합니다.':'멤버 2명 이상이면 활동을 재개합니다.'}</p><div class="modal-actions">${btn('승인','m-team-apply',`data-key="${d.key}" data-op="${d.op}"`,'primary')}</div>`);
      break;
    }
    case 'm-team-apply': mutate(() => game.teamAction(d.key, d.op), '팀 설정을 변경했습니다.');
    break;
    case 'm-team': {
      let u = game.s.units.find(u => u.key === d.key);
      let list = game.s.artists.filter(a => DATA.roster[a.id].type === u.type && !game.s.units.some(u => u.ids.includes(a.id)));
      modal(esc(u.name) + ' 멤버 관리', `<p>새 멤버는 활동 중인 일정이 없어야 합니다. 기존 작품의 배분은 변경되지 않습니다.</p><form id="m-team-add"><input type="hidden" name="key" value="${u.key}"><label for="member">합류할 멤버</label><select name="id" id="member">${list.map(a=>`<option value="${a.id}">${DATA.roster[a.id].name}</option>`).join('')}</select><div class="modal-actions"><button class="primary" ${list.length?'':'disabled'}>팀 합류 승인</button></div></form>`);
      break;
    }
    case 'm-transfer': modal('삼자 합의 이적 검토', `<p>${DATA.roster[id].name} · 활동 중이면 일정 종료 후 진행하세요. 기존 작품 권리와 배분은 유지됩니다.</p>${game.s.rivals.map(r=>{let q=game.transferQuote(id,r.id);return `<div class="contract-row"><h3>${esc(r.name)}</h3><p>합의금 ${money(q.fee)} · 본인 ${q.consent?'동의':'거절'} · 상대 자금 ${q.affordable?'충족':'부족'} · 분야 ${q.fit?'적합':'불일치'}</p>${btn('이적 최종 검토','m-transfer-confirm',`data-id="${id}" data-rival="${r.id}"`,'soft',!q.consent||!q.affordable||!q.fit||game.busy(String(id)))}</div>`;}).join('')}`);
    break;
    case 'm-transfer-confirm': {
      let q = game.transferQuote(id, d.rival),
      r = game.s.rivals.find(r => r.id === Number(d.rival));
      modal('합의 이적 승인', `<p>${DATA.roster[id].name} → ${esc(r.name)}</p><p>회사는 ${money(q.fee)}을 받습니다. 전속계약과 팀 소속은 종료되고 작품 배분은 유지됩니다.</p>${btn('삼자 합의 승인','m-transfer-apply',`data-id="${id}" data-rival="${r.id}"`,'primary')}`);
      break;
    }
    case 'm-transfer-apply': mutate(() => game.transfer(id, d.rival), '합의 이적을 완료했습니다.');
    break;
  }
}
$('#modal-root').addEventListener('submit', ev => {
  let f = ev.target;
  if (!f.getAttribute('id')?.startsWith('m-')) return;
  ev.preventDefault();
  let data = new FormData(f);
  try {
    switch (f.getAttribute('id')) {
      case 'm-contract': mutate(() => game.sign(data.get('id'), data.get('offer')), '계약을 체결했습니다.');
      break;
      case 'm-renew': mutate(() => game.renew(data.get('id'), data.get('offer')), '재계약했습니다.');
      break;
      case 'm-debut': mutate(() => game.debut(data.get('id'), data.get('offer')), '정식 아티스트로 데뷔했습니다.');
      break;
      case 'm-team-add': mutate(() => game.teamAction(data.get('key'), 'add', Number(data.get('id'))), '팀 멤버가 합류했습니다.');
      break;
    }
  } catch (e) {
    $('#modal-error').textContent = e.message;
  }
});


;
/* FILE src/progression-ui.js */
'use strict';
const originalCompany = company_management, originalFinance = finance_app, originalIndustry = industry_management, originalManagementClick = managementClick_management;
let pendingRestore = null;
;
function company_progression() {
  return originalCompany() + panel('회사 이미지', `<h2>${game.s.image.toFixed(1)} / 100</h2><p>평판은 활동 성과, 이미지는 운영 신뢰를 뜻합니다. 사건·대응과 안정적인 활동에 따라 변합니다.</p><p>이미지는 관객 수요·신규 팬·광고 대가·기업가치에 영향을 줍니다. 이미 발생한 사건 피해를 즉시 모두 되돌릴 수는 없습니다.</p><h3>최근 사건</h3>${game.s.incidents.slice(0,8).map(i=>`<div class="contract-row"><strong>${Game.incidentTypes[i.kind].title} · ${esc(i.name)}</strong><p>${date(i.day)} · ${i.state==='closed'?'처리 완료':i.state==='investigating'?'조사 중':'대응 필요'} · 최초 팬 이탈 ${i.losses.reduce((n,x)=>n+x.lost,0)}명 · 회복 ${i.recovered}명</p>${i.state==='open'?btn('사건 보고','m-incident-open',`data-id="${i.id}"`,'soft'):''}</div>`).join('')||'<p>사건 이력 없음</p>'}`);
};
function finance_progression() {
  return originalFinance() + activityFinanceHTML();
};
function industry_progression() {
  return originalIndustry() + panel('라이벌 운영 상태', game.s.rivals.map(r => `<div class="contract-row"><h3>${esc(r.name)}</h3><p>최근 행동: ${esc(r.lastAction)} · 활동 인원 ${r.talents.filter(t=>t.active).length} / 연습생 ${r.talents.filter(t=>!t.active).length}</p><p>회사 이미지 추정 ${Math.round(r.image/10)*10} · 신작·공연·육성·홍보·긴축·재계약·영입을 자금과 인재 상태에 따라 결정합니다.</p></div>`).join(''));
};
function incidentReport(r) {
  let i = game.s.incidents.find(i => i.id === r.incidentId);
  if (!i) return `<h2>${esc(r.title)}</h2><p>${esc(r.body)}</p>`;
  return `<h2>${esc(r.title)}</h2><div class="report-content">${esc(r.body)}</div><p>회사 이미지 ${game.s.image.toFixed(1)} / 100 · ${i.state==='closed'?'처리 완료':i.state==='investigating'?'조사 중 · 완료 '+date(i.responseDue):'대응 기한 '+date(i.expires)}</p>${i.state==='open'?`<div class="list">${btn('공식 설명 · '+money(100*i.severity)+' · 팬 20% 회복','m-incident-respond',`data-id="${i.id}" data-choice="explain"`,'soft')}${btn('보완 행사 · '+money(300*i.severity)+' · 팬 50% 회복','m-incident-respond',`data-id="${i.id}" data-choice="repair"`,'primary')}${btn('3일 조사·결과 공개 · '+money(50*i.severity)+' · 팬 30% 회복','m-incident-respond',`data-id="${i.id}" data-choice="investigate"`)}${btn('미대응 · 추가 이미지 하락·팬 이탈','m-incident-respond',`data-id="${i.id}" data-choice="ignore"`,'danger')}</div><p>회복 비율은 이번 사건으로 이탈한 팬 기준입니다. 회사에 남은 대상만 회복합니다. 자금 부족 시 유료 대응은 실행되지 않습니다.</p>`:''}`;
}
function savePanel() {
  let points = saveStore.checkpoints();
  modal('저장 슬롯·복구 지점', `<p>자동 저장 외에 수동 슬롯 3개와 복구 지점 3개를 보관합니다. 브라우저별로 분리되므로 JSON 백업도 권장합니다.</p><div class="list">${[1,2,3].map(index=>{let entry=saveStore.read(saveStore.slot(index)),valid=entry&&validState(entry.state);return `<section class="panel"><h3>슬롯 ${index}</h3><p>${valid?esc(entry.state.company)+' · '+date(entry.state.day,true):entry?'저장 손상·불러오기 불가':'비어 있음'}</p><div class="row wrap">${btn('현재 진행 저장','m-slot-save-confirm',`data-index="${index}"`,'soft',!game.s)}${btn('불러오기','m-slot-load',`data-index="${index}"`,'',!valid)}${btn('슬롯 비우기','m-slot-delete-confirm',`data-index="${index}"`,'link',!entry)}</div></section>`;}).join('')}<h3>자동 복구 지점</h3>${btn('복구 지점 비우기','m-points-clear-confirm','','link',!points.length)}<p>저장 공간이 부족하면 JSON 백업 후 사용하지 않는 슬롯이나 복구 지점을 비워주세요.</p>${points.map((p,index)=>`<section class="panel"><strong>${esc(p.reason)}</strong><p>${esc(p.state.company)} · ${date(p.state.day,true)}</p>${btn('복원 검토','m-point-load',`data-index="${index}"`,'soft')}</section>`).join('')||'<p>아직 복구 지점이 없습니다.</p>'}</div>`, true);
}
function previewRestore(state, label, expectedAuto) {
  pendingRestore = { state: JSON.parse(JSON.stringify(state)), label, expectedAuto };
  modal('저장 복원 확인', `<h3>${esc(state.company)}</h3><p>${date(state.day,true)} · 현금 ${money(state.cash)}</p><p>${esc(label)}의 상태로 자동 저장과 현재 진행을 교체합니다. 진행 중인 게임이 있으면 복구 지점으로 보관합니다.</p>${btn('이 저장으로 복원','m-restore-apply','','primary')}`);
}
function applyRestore_progression() {
  if (!pendingRestore) throw Error('복원할 저장을 다시 선택하세요.');
  let restored = new Game(pendingRestore.state);
  if (!validState(restored.s)) throw Error('저장을 변환하지 못했습니다.');
  let previous = game.s || loadSaved();
  if (previous && validState(previous)) saveStore.checkpoint(previous, '저장 복원 전');
  saveStore.writeAuto(restored.s, pendingRestore.expectedAuto);
  game = restored;
  pendingRestore = null;
  page = 'home';
  running = false;
  stopReason = '';
  saveOK = true;
  close();
  render();
  toast('저장을 복원했습니다.');
}
function managementClick_progression(action, d) {
  switch (action) {
    case 'm-saves': return savePanel();
    case 'm-slot-save-confirm': {
      let index = Number(d.index);
      saveStore.slot(index);
      let old = saveStore.read(saveStore.slot(index));
      if (!old) return managementClick('m-slot-save', d);
      modal('슬롯 덮어쓰기 확인', `<p>슬롯 ${index}를 현재 회사 진행으로 교체합니다. 정상인 기존 슬롯은 복구 지점으로 보관합니다.</p>${btn('슬롯 교체 승인','m-slot-save',`data-index="${index}"`,'primary')}`);
      return;
    }
    case 'm-slot-save': {
      if (!game.s) throw Error('진행 중인 회사가 없습니다.');
      let index = Number(d.index),
      old = saveStore.read(saveStore.slot(index));
      if (old && validState(old.state)) saveStore.checkpoint(old.state, '슬롯 ' + index + ' 덮어쓰기 전');
      saveStore.saveSlot(index, game.s);
      savePanel();
      toast('슬롯에 저장했습니다.');
      return;
    }
    case 'm-slot-load': return previewRestore(saveStore.loadSlot(Number(d.index)), '슬롯 ' + d.index);
    case 'm-point-load': return previewRestore(saveStore.restorePoint(Number(d.index)), '복구 지점');
    case 'm-restore-apply': return applyRestore();
    case 'm-incident-open': {
      let r = game.s.reports.find(r => r.incidentId === Number(d.id));
      if (r) return showReport(r.id, true);
      throw Error('사건 보고가 없습니다.');
    }
    case 'm-incident-respond': return mutate(() => game.respondIncident(d.id, d.choice), '사건 대응을 진행했습니다.');
    default: throw Error("처리할 수 없는 동작입니다.");
  }
};
UIEvents.onChange('progression', ev => {
  if (ev.target.id === 'entity') budgetPreview();
});
;


;
/* FILE src/market-ui.js */
'use strict';
let releaseScope = 'own', chartMetric = 'streams', compareReleases = [], traineeView = 'all';
const menuGroups = {
  home:[['home', '홈'], ['goals', '목표']],
  inbox:[['inbox', '수신함']],
  artists:[['artists', '아티스트'], ['development', '개인 육성'], ['training', '연습생'], ['casting', '캐스팅'], ['teams', '팀·계약']],
  projects:[['projects', '앨범 준비'], ['concerts', '공연'], ['content', '콘텐츠'], ['offers', '외부 제안'], ['activity-progress', '진행 중'], ['activity-results', '활동 결과'], ['music', '발매 성과'], ['schedule', '통합 일정']],
  company:[['company', '회사·가치'], ['staff', '직원 관리'], ['recruit', '직원 고용'], ['finance', '재정']],
  industry:[['industry', '라이벌'], ['charts', '음악 차트']]
};
function pageGroup(p) {
  return Object.keys(menuGroups).find(group => menuGroups[group].some(([id]) => id === p)) || 'home';
}
function sectionTabs() {
  return `<nav class="section-tabs" aria-label="영역 내 메뉴">${menuGroups[pageGroup(page)].map(([id,label])=>btn(label,'nav',`data-page="${id}"`,page===id?'active':'')).join('')}${btn('저장·복구','m-saves','','link')}</nav>`;
}
function saveStatusLabel() {
  let meta = saveStore.read('next-stage-save-meta'),
  date = meta?.at ? new Date(meta.at): null;
  if (!saveOK && saveStore.hasAutoChanged()) return '다른 탭 저장 감지 · 현재 진행 백업 필요';
  return saveOK ? '저장됨' +(date && Number.isFinite(date.getTime()) ? ' · ' + date.toLocaleTimeString('ko-KR', { timeZone: 'Asia/Seoul', hour: '2-digit', minute: '2-digit' }): ''): '저장 실패 · JSON 백업 필요';
}
function todayTasks_market() {
  let s = game.s,
  tasks = [];
  for (const i of s.incidents) if (i.state === 'open') tasks.push({
    priority: 0,
    label: '사건 대응 · ' + i.name + ' · ' +(i.expires - s.day) + '일 남음',
    action: 'm-incident-open',
    args: `data-id="${i.id}"`
  });
  if (s.cash < game.fixed * 2) tasks.push({
    priority: 0,
    label: '운영 자금 확인 · ' + money(s.cash),
    action: 'nav',
    args: 'data-page="finance"'
  });
  for (const a of s.artists) if (a.contract - s.day <= 90) tasks.push({
    priority: 1,
    label: DATA.roster[a.id].name + ' 재계약 · ' +(a.contract - s.day) + '일 남음',
    action: 'm-renew',
    args: `data-id="${a.id}"`
  });
  for (const a of s.trainees) if (s.day - a.signed >= 90 && game.readiness(a) >= 55) tasks.push({
    priority: 2,
    label: DATA.roster[a.id].name + ' 데뷔 조건 충족',
    action: 'm-debut',
    args: `data-id="${a.id}"`
  });
  if (!s.artists.length && !s.trainees.length) tasks.push({
    priority: 2,
    label: '첫 인재 모집 시작',
    action: 'casting-modal',
    args: ''
  });
  return tasks.sort((a, b) => a.priority - b.priority);
};
function releaseRow(row) {
  let c = row.release,
  m = c.market,
  w = game.weekStats(c);
  return `<article class="contract-row"><div class="row between wrap"><div><h3>${esc(c.name)}</h3><small>${esc(m.artistName)} · ${esc(row.company)} · ${date(m.startDay)} · ${c.albumType?ActivityData.albums[c.albumType].label+' · '+ActivityData.albums[c.albumType].tracks+'곡':(m.format==='physical'?'실물 싱글':'음원 싱글')}</small></div>${btn('작품 성과','m-release',`data-uid="${m.uid}"`,'soft small')}</div><p>최근 7일 ${w.streams.toLocaleString()}회 재생 · ${m.format==='physical'?w.sales.toLocaleString()+'장 판매':'실물 미제작'} / 누적 ${m.streams.toLocaleString()}회${m.format==='physical'?' · '+m.sales.toLocaleString()+'장':''}</p>${btn(compareReleases.includes(m.uid)?'비교 선택됨':'비교에 추가','m-compare-select',`data-uid="${m.uid}"`,'link small')}</article>`;
}
function music() {
  let rows = game.allReleases().filter(row => releaseScope === 'all' || releaseScope === 'own' && row.own || releaseScope === 'rival' && !row.own).sort((a, b) => b.release.market.startDay - a.release.market.startDay);
  return heading('발매 성과', '판매·재생·정산을 작품별로 확인하세요.', btn('선택 작품 비교 (' + compareReleases.length + '/3)', 'm-compare', '', 'primary', compareReleases.length < 2)) + `<div class="tabs">${[['own','우리 회사'],['rival','라이벌'],['all','전체']].map(([id,label])=>btn(label,'m-release-scope',`data-scope="${id}"`,releaseScope===id?'active':'')).join('')}</div>` + panel('최근 발매작', rows.slice(0, 60).map(releaseRow).join('') || '<p>아직 집계할 작품이 없습니다.</p>') + `<p class="muted">최근 60개 작품 표시. 이전 작품은 프로젝트의 발매 목록에서도 열 수 있습니다.</p>`;
}
function charts_market() {
  let rows = game.charts(chartMetric);
  return heading('참여 레이블 차트', '우리 회사와 라이벌 4곳만 포함합니다. 전체 음악 시장 순위가 아닙니다.', btn('선택 작품 비교', 'm-compare', '', 'soft', compareReleases.length < 2)) + `<div class="tabs">${btn('주간 스트리밍','m-chart','data-metric="streams"',chartMetric==='streams'?'active':'')}${btn('주간 음반 판매','m-chart','data-metric="sales"',chartMetric==='sales'?'active':'')}</div>` + panel('최근 7일 순위', rows.slice(0, 30).map((row, index) => `<div class="chart-row"><strong class="rank">${index+1}</strong><div class="spacer"><h3>${esc(row.release.name)}</h3><small>${esc(row.company)} · ${esc(row.release.market.artistName)}</small><p>${row.week[chartMetric].toLocaleString()}${chartMetric==='streams'?'회':'장'}</p>${btn('성과 보기','m-release',`data-uid="${row.release.market.uid}"`,'link small')}${btn('비교 선택','m-compare-select',`data-uid="${row.release.market.uid}"`,'link small')}</div></div>`).join('') || '<p>최근 7일 집계가 없습니다.</p>');
}
function releaseGraph(c, metric) {
  let bins = c.market.weeks.slice(- 12);
  if (!bins.length) return '<p>아직 주간 기록이 없습니다.</p>';
  let max = Math.max(1, ... bins.map(w => w[metric]));
  return `<svg viewBox="0 0 520 170" class="release-graph" role="img" aria-label="최근 12주 ${metric==='streams'?'스트리밍':'판매'} 추이"><title>${metric==='streams'?'스트리밍':'음반 판매'} · 최고 ${max.toLocaleString()}</title><line x1="12" y1="135" x2="508" y2="135" stroke="#cbd5e1"/>${bins.map((w,i)=>{let width=480/bins.length-6,x=20+i*480/bins.length,h=w[metric]/max*110;return `<rect x="${x}" y="${135-h}" width="${Math.max(4,width)}" height="${h}" rx="3" fill="#1265ef"><title>${w.week+1}주차 ${w[metric].toLocaleString()}</title></rect><text x="${x}" y="154" font-size="10" fill="#52627c">${w.week+1}주</text>`;}).join('')}</svg><small>최근 ${bins.length}개 주간 · 현재 주는 집계 중 · 최고 ${max.toLocaleString()}${metric==='streams'?'회':'장'}</small>`;
}
function releaseModal_market(uid) {
  let row = game.allReleases().find(row => row.release.market.uid === uid);
  if (!row) throw Error('작품을 찾을 수 없습니다.');
  let c = row.release,
  m = c.market,
  w = game.weekStats(c),
  today = m.days.find(d => d.day === game.s.day),
  first = m.firstWeekSales === null ? '과거 기록 없음': m.firstWeekSales.toLocaleString() + '장' +(game.s.day - m.startDay < 6 ? ' · 집계 중': '');
  modal(c.name + ' · 발매 성과', `<p>${esc(m.artistName)} · ${esc(row.company)} · ${DATA.labels[m.type]} · 완성도 ${Math.round(c.quality)}</p><p>${m.legacy?'이전 작품: 업데이트 이후 측정분만 표시합니다.':'발매 '+date(m.startDay,true)} · 측정 시작 ${date(m.measuredFrom)}</p><div class="detail-state"><div><small>오늘 스트리밍</small><b>${(today?.streams||0).toLocaleString()}회</b></div><div><small>최근 7일 스트리밍</small><b>${w.streams.toLocaleString()}회</b></div><div><small>누적 스트리밍</small><b>${m.streams.toLocaleString()}회</b></div><div><small>초동 7일 판매</small><b>${m.format==='physical'?first:'음원 전용'}</b></div><div><small>최근 7일 판매</small><b>${m.format==='physical'?w.sales.toLocaleString()+'장':'음원 전용'}</b></div><div><small>누적 판매</small><b>${m.format==='physical'?m.sales.toLocaleString()+'장':'음원 전용'}</b></div></div><h3>주간 스트리밍 추이</h3>${releaseGraph(c,'streams')}${m.format==='physical'?'<h3>주간 판매 추이</h3>'+releaseGraph(c,'sales'):''}${row.own?`<section class="panel section"><h3>업데이트 이후 정산</h3><p>스트리밍: 발생 ${money(m.streamReceipts)} / 지급 ${money(m.paidStream)} / 배분 ${money(m.payoutStream)} / 회사 ${money(m.paidStream-m.payoutStream)}</p><p>음반: 발생 ${money(m.physicalReceipts)} / 지급 ${money(m.paidPhysical)} / 배분 ${money(m.payoutPhysical)} / 회사 ${money(m.paidPhysical-m.payoutPhysical)}</p><p>매출 합계 ${money(m.gross)} − 유통 공제 ${money(m.distribution)} = 정산 발생액 ${money(m.receipts)}</p><p>지급 완료 ${money(m.paid)} − 아티스트 배분 ${money(m.payout)} = 회사 입금 ${money(m.paid-m.payout)}</p><p>미정산 ${money(m.pending)} · 다음 정산까지 ${7-m.pendingDays}일</p><p>음악 제작비 ${money(m.production)} · 음반 제조비 ${money(m.manufacturing)}</p><strong>입금 기준 누적 손익 ${money(m.paid-m.payout-m.production-m.manufacturing)}</strong><p>일 훈련·월 고정비 별도. 이전 작품의 과거 비용·판매량은 소급 복원하지 않습니다.</p>${m.format==='physical'?`<p>재고 ${m.stock.toLocaleString()}장 / 누적 제조 ${m.manufactured.toLocaleString()}장 · 제조원가 장당 ${money(m.unitCost)}</p>${btn('1,000장 추가 제조 검토','m-reprint',`data-id="${c.id}"`,'soft')}`:''}</section>`:`<p>타사 내부 원가·배분은 비공개입니다. 공개 지표 기반 수입 추정 ${money(m.receipts*.8)}~${money(m.receipts*1.2)}이며 실제 회사 이익이 아닙니다.</p>`}<p>${m.hit?'이 작품은 실제 성과 기준 흥행으로 기록됐습니다.':'흥행 기준: 최근 7일 30만 회 재생 또는 초동 500장. 완성도만으로 판정하지 않습니다.'}</p>${btn(compareReleases.includes(uid)?'비교 선택 해제':'비교에 추가','m-compare-select',`data-uid="${uid}"`,'soft')}`, true);
}
function compareModal() {
  let rows = game.allReleases().filter(row => compareReleases.includes(row.release.market.uid));
  if (rows.length < 2) throw Error('비교할 작품 2~3개를 선택하세요.');
  modal('작품 비교', `<p>최근 7일은 같은 날짜 구간입니다. 누적 성과는 발매 후 경과 기간도 함께 비교하세요.</p><div class="compare-grid">${rows.map(row=>{let c=row.release,m=c.market,w=game.weekStats(c);return `<article class="panel"><h3>${esc(c.name)}</h3><p>${esc(row.company)} · 발매 ${Math.max(0,game.s.day-m.startDay)}일</p><p>최근 7일 재생 ${w.streams.toLocaleString()}회</p><p>누적 재생 ${m.streams.toLocaleString()}회</p><p>최근 7일 판매 ${m.format==='physical'?w.sales.toLocaleString()+'장':'음원 전용'}</p><p>누적 판매 ${m.format==='physical'?m.sales.toLocaleString()+'장':'음원 전용'}</p>${releaseGraph(c,'streams')}</article>`;}).join('')}</div>`, true);
}
const marketProjectModal = projectModal_app, marketArtistModal = artistModal_app, marketManagementClick = managementClick_progression, marketCompany = company_progression;
function projectModal_market(key) {
  marketProjectModal(key);
  $('#budget-preview').insertAdjacentHTML('afterend', `<div id="release-options" class="field"><label for="release-format">싱글 발매 형태</label><select id="release-format" name="format"><option value="digital">음원 전용</option><option value="physical">실물 음반 + 음원</option></select><label for="release-quantity">실물 초도 수량 (실물 선택 시 적용)</label><select id="release-quantity" name="quantity"><option value="1000">1,000장 · 제조비 600만 원</option><option value="3000">3,000장 · 제조비 1,800만 원</option><option value="10000">10,000장 · 제조비 6,000만 원</option></select><small>음반 가격 2.5만 원 · 장당 제조원가 0.6만 원. 제조비는 음악 제작비와 별도이며 미판매 재고 위험이 있습니다.</small></div>`);
  budgetPreview();
};
;
function gradeSummary(key) {
  let rec = game.entityRecord(key);
  if (!rec) return '';
  let star = key.startsWith('u') ? game.s.units.find(u => u.key === key): game.artist(Number(key)),
  hits = rec.events.filter(p => p.hit).length,
  next = Math.min(4, star.star + 1),
  targets = [{}, { fame: 15, fans: 0, hits: 0 }, { fame: 40, fans: 0, hits: 0 }, { fame: 70, fans: 10000, hits: 2 }, { fame: 85, fans: 50000, hits: 4 }],
  t = targets[next];
  return `<section class="panel section"><h3>${starNames[star.star]} → ${star.star===4?'최고 등급 유지':starNames[next]}</h3><p>개인/팀 인지도 ${rec.fame.toFixed(1)} / ${t.fame} · 충성 팬 ${rec.fans.toLocaleString()} / ${t.fans.toLocaleString()} · 최근 1년 실제 흥행 ${hits} / ${t.hits}</p><p>${next===2?'인기 등급에는 최근 1년 활동 2회도 필요합니다.':next>=3?'스타 이상은 인지도·팬·흥행 조건을 180일 유지해야 합니다. 현재 유지 '+(star.marketStarSince==null?0:game.s.day-star.marketStarSince)+'일.':''}</p><small>음원: 최근 7일 30만 회 또는 초동 500장. 공연: 관객500명 이상·점유70% 이상·회사 손익 양수. 충성 팬은 구매·관람 가능성이 높은 팬층이며 인지도는 대중 노출 정도입니다.</small></section>`;
}
function artistModal_market(id, candidate = false) {
  marketArtistModal(id, candidate);
  if (!candidate && game.artist(id)) $('#modal-error').insertAdjacentHTML('beforebegin', gradeSummary(String(id)));
};
function company_market() {
  return marketCompany() + panel('평판 변동 근거', `<h3>${game.s.reputation.toFixed(1)} / 100 · 최근 월간 조정 ${(game.s.reputation-game.s.lastReputation).toFixed(1)}</h3><p>${esc(game.s.reputationReason)}</p><p>최근 판매·스트리밍·흥행으로 월간 목표 평판을 계산해 최대 +3 / −2씩 조정합니다. 사건·회생 지원의 별도 감소는 유지합니다.</p>`);
};
;
function managementClick_market(action, d) {
  switch (action) {
    case 'm-slot-delete-confirm': modal('슬롯 삭제 확인', `<p>슬롯 ${Number(d.index)}의 저장을 삭제합니다. 자동 저장은 유지됩니다. 필요한 진행은 먼저 JSON으로 백업하세요.</p>${btn('이 슬롯 삭제','m-slot-delete',`data-index="${Number(d.index)}"`,'danger')}`);
    return;
    case 'm-slot-delete': saveStore.removeSlot(Number(d.index));
    savePanel();
    return;
    case 'm-points-clear-confirm': modal('복구 지점 삭제 확인', `<p>자동 복구 지점3개를 비웁니다. 현재 자동 저장과 수동 슬롯은 유지됩니다.</p>${btn('복구 지점 비우기','m-points-clear','','danger')}`);
    return;
    case 'm-points-clear': saveStore.clearCheckpoints();
    savePanel();
    return;
    case 'm-release': return releaseModal(d.uid);
    case 'm-release-scope': releaseScope = d.scope;
    render();
    return;
    case 'm-chart': chartMetric = d.metric;
    render();
    return;
    case 'm-compare-select': if (compareReleases.includes(d.uid)) compareReleases = compareReleases.filter(uid => uid !== d.uid);
    else {
      if (compareReleases.length >= 3) throw Error('작품은 최대3개까지 비교할 수 있습니다.');
      compareReleases.push(d.uid);
    }
    render();
    if ($('#modal-root').children.length) releaseModal(d.uid);
    toast('비교 작품 ' + compareReleases.length + '/3개 선택');
    return;
    case 'm-compare': return compareModal();
    case 'm-reprint': modal('추가 제조 확인', `<p>1,000장 추가 제조에 600만 원을 지출합니다. 기존 재고와 판매 추이를 확인한 뒤 결정하세요.</p>${btn('추가 제조 승인','m-reprint-apply',`data-id="${d.id}"`,'primary')}`);
    return;
    case 'm-reprint-apply': return mutate(() => game.reprint(d.id, 1000), '음반 추가 제조를 승인했습니다.');
    case 'm-trainee-filter': traineeView = d.filter;
    render();
    return;
    default: throw Error("처리할 수 없는 동작입니다.");
  }
};
UIEvents.onChange('market', ev => {
  if (['release-format', 'release-quantity'].includes(ev.target.id)) budgetPreview();
});


;
/* FILE src/day-feedback-ui.js */
'use strict';
function progressSummaryContent() {
  const s = game.s;
  if (!s) return '';
  const notice = lastAdvanceNotice;
  let rows = notice ? s.daySummaries.filter(d => d.day > notice.from && d.day <= notice.to): s.daySummaries.slice(- 1);
  if (!rows.length && !running) return '';
  const from = notice?.from ?? rows[0]?.fromDay ?? s.day,
  to = notice?.to ?? rows.at(- 1)?.day ?? s.day,
  elapsed = to - from;
  const sum = rows.reduce((a, d) =>({
    cash: a.cash + d.cashChange,
    streams: a.streams + d.streams,
    sales: a.sales + d.sales,
    training: a.training + d.trainingCount,
    fans: a.fans + d.fansChange,
    teamFans: a.teamFans + d.teamFansChange,
    completed: a.completed + d.completed.length + festivalCount(d),
    reports: a.reports + d.newReports
  }), {
    cash: 0,
    streams: 0,
    sales: 0,
    training: 0,
    fans: 0,
    teamFans: 0,
    completed: 0,
    reports: 0
  });
  const fresh = notice?.at && Date.now() - notice.at < 1800;
  const label = running ?(notice?.mode === 'skip' ? '중요 일정까지 진행 중…': '하루 진행 중…'): notice?.stop ||(elapsed === 1 ? '최근 하루 진행 기록': '최근 진행 기록');
  return `<section class="panel progress-summary ${running?'is-running':fresh?'is-new':''}" role="status" aria-live="polite"><div class="row between wrap"><div><strong>${esc(label)}</strong><p><span class="progress-date">${date(from)} → ${date(to)}</span> · ${elapsed}일 경과</p></div></div>${rows.length?`<p>훈련 ${sum.training}건 · 스트리밍 ${sum.streams.toLocaleString()}회 · 음반 ${sum.sales.toLocaleString()}장 · 일정 완료 ${sum.completed}건</p><p>현금 ${sum.cash>=0?'+':''}${money(sum.cash)} · 개인 팬 ${sum.fans>=0?'+':''}${sum.fans.toLocaleString()}명 · 팀 팬 ${sum.teamFans>=0?'+':''}${sum.teamFans.toLocaleString()}명</p>${!sum.completed&&!sum.reports?'<small>훈련과 성과 집계를 마쳤습니다. 새로운 주요 일정·보고는 없습니다.</small>':''}${sum.reports?`<small>새 보고 ${sum.reports}건 · </small>${btn('소식함 확인','nav','data-page="inbox"','link small')}`:''}`:'<p>날짜와 훈련·정산 결과를 계산하고 있습니다.</p>'}</section>`;
}
function progressSummaryCard() {
  return running ? progressSummaryContent(): '';
}
const feedbackManagementClick = managementClick_market, feedbackApplyRestore = applyRestore_progression;
function managementClick_dayfeedback(action, d) {
  return feedbackManagementClick(action, d);
};
function applyRestore_dayfeedback() {
  feedbackApplyRestore();
  lastAdvanceNotice = null;
  selectedReport = null;
  render();
};


;
/* FILE src/personality-ui.js */
'use strict';
function personalityCard(id) {
  const p = game.personality(id),
  a = game.talent(id),
  d = DATA.roster[id];
  const trainee = a && game.s.trainees.includes(a);
  const plan = trainee ? Game.trainingPlans[p.training].name: focusLabel[p.focus];
  const remaining = a && a.lastPersonalDay !== undefined ? Math.max(0, 30 - game.s.day + a.lastPersonalDay): 0;
  return `<section class="personality-card" aria-label="${esc(d.name)}의 성격과 상담"><strong>${esc(p.name)}</strong><p>“${esc(p.intro)}”</p><p class="muted">선호 육성: ${esc(a?plan:Game.trainingPlans[p.training].name+' / '+focusLabel[p.focus])} · 해당 방향의 실제 훈련 성장량 +8%<br>선호 재계약: ${DATA.terms[p.offer].name} · 재계약금 5% 절감</p>${a?`<p class="personal-reaction">${esc(game.trainingReaction(id))}</p><p>개인 상담 · ${remaining?'다음 상담까지 '+remaining+'일':'지금 가능'}<br><small>선호 상담: ${{creative:'창작',stage:'무대',rest:'휴식'}[p.session]} · 신뢰 +5, 다른 상담 +2 (상한 100)</small></p><div class="personal-actions">${[['creative','창작 워크숍 · 100만'],['stage','무대 리허설 · 100만'],['rest','휴식 상담 · 무료']].map(([choice,label])=>btn(label,'m-personal',`data-id="${id}" data-choice="${choice}"`,'soft small',remaining>0||(choice!=='rest'&&game.busy(String(id))))).join('')}</div><small>워크숍: 해당 능력 +0.4·스트레스 -3. 휴식: 체력 +10·스트레스 -8. 효과는 각 상한 이내이며 확정 활동 중에는 워크숍을 진행할 수 없습니다.</small>`:''}</section>`;
}
const personalityManagementClick = managementClick_dayfeedback;
function managementClick_personality(action, data) {
  mutate(() => game.personalSession(data.id, data.choice), '상담을 마쳤습니다. 소식함에서 반응을 확인하세요.');
};


;
/* FILE src/operations-ui.js */
'use strict';
let recruitFilter = 'all', calendarMonth = null, calendarDay = null, traineeGraphDays = 30, traineeGraphMetric = - 1;
function staffCard(p, hired = false) {
  return `<article class="panel staff-card"><span class="pill">${DATA.staffKinds[p.kind]}</span><h2>${esc(p.name)}</h2><p>${esc(p.specialty==='general'?p.spec:Game.trainingPlans[p.specialty].name+' 전문')} · 지도/직무 ${p.coaching} · 전문 ${p.expertise} · 관리 ${p.care}</p><strong>월급 ${money(p.salary)}</strong><p>${hired?'재직 중':'채용비 '+money(p.fee)}</p>${btn('상세정보','m-staff-detail',`data-id="${p.id}"`,'soft')}</article>`;
}
function staffScreen_operations() {
  const people = game.s.staff.map(id => DATA.staff.find(p => p.id === id));
  return heading('직원 관리', '고용한 직원 전원을 한 화면에서 확인하세요.', btn('직원 고용', 'nav', 'data-page="recruit"', 'primary')) + panel('전체 직원 ' + people.length + '명', `<h2>월급 합계 ${money(people.reduce((n,p)=>n+p.salary,0))}</h2><p>육성 직원은 인원 제한 없이 전체 연습생을 관리합니다. 분야별 가장 적합한 직원의 효과가 적용됩니다.</p><label for="policy">활동 운영 방침</label><select id="policy"><option value="balanced" ${game.s.policy==='balanced'?'selected':''}>균형</option><option value="growth" ${game.s.policy==='growth'?'selected':''}>집중 성장</option></select>`) + `<div class="three-col section">${people.map(p=>staffCard(p,true)).join('')||'<p class="panel">고용한 직원이 없습니다.</p>'}</div>`;
};
function recruitScreen() {
  const candidates = game.staffCandidates().filter(p => recruitFilter === 'all' || p.kind === recruitFilter);
  return heading('직원 고용', '미고용 후보 30명 중 매일 최대5명이 지원합니다. 고용한 후보는 목록에서 빠지며 당일 추가 충원은 없습니다.', btn('직원 관리', 'nav', 'data-page="staff"', 'soft')) + `<p>${date(game.s.day,true)} · 내일 지원자 갱신 · 같은 날 불러와도 유지</p><div class="tabs">${[['all','전체'],...Object.entries(DATA.staffKinds)].map(([key,label])=>btn(label,'m-recruit-filter',`data-filter="${key}"`,recruitFilter===key?'active':'')).join('')}</div><div class="three-col section">${candidates.map(p=>staffCard(p)).join('')||'<p class="panel">현재 조건에 맞는 지원자가 없습니다. 다른 직무를 확인하거나 다음 날 다시 찾아주세요.</p>'}</div>`;
}
function staffDetail_operations(id) {
  const p = DATA.staff.find(p => p.id === id);
  if (!p) throw Error('직원을 찾을 수 없습니다.');
  const hired = game.s.staff.includes(id),
  bonus = Math.min(.6, p.coaching * .004 + p.expertise * .002);
  modal(p.name + ' · ' + p.role, `<p>${esc(p.spec)}</p><div class="detail-state"><div>지도·직무 <b>${p.coaching}</b></div><div>전문성 <b>${p.expertise}</b></div><div>컨디션 관리 <b>${p.care}</b></div></div><p>월급 ${money(p.salary)} · 채용비 ${money(p.fee)}</p>${p.kind==='trainer'?`<p>기본 성장량 +${(p.coaching*.4).toFixed(1)}% · 전문 분야 ${Game.trainingPlans[p.specialty].name} +${(bonus*100).toFixed(1)}% (총 보너스 최대60%)</p><p>담당 인원 제한 없음. 분야마다 성장 효과가 가장 높은 직원이 지도하며, 보너스는 합산하지 않습니다. 훈련비20% 절감·피로 최대25%/스트레스 최대50% 완화는 해당 직원의 관리 능력에 비례합니다.</p>`:`<p>직무 능력에 따라 ${esc(p.spec)} 효과가 달라집니다. 같은 직무는 가장 능숙한 직원 효과를 적용합니다.</p>`}<div class="modal-actions">${hired?btn('퇴직 협의','staff-confirm',`data-id="${id}"`,'danger'):btn('채용 승인','hire',`data-id="${id}"`,'primary',!game.staffCandidates().some(x=>x.id===id))}</div>`);
}
function growthSummary(a, days = 30) {
  const points = a.growthHistory.filter(x => x.day >= game.s.day - days),
  first = points[0],
  last = points.at(- 1);
  return first && last ? { days: last.day - first.day, gain:(last.stats.reduce((n, v) => n + v, 0) - first.stats.reduce((n, v) => n + v, 0)) / 8 }: { days: 0, gain: 0 };
}
function training_operations() {
  const list = game.s.trainees.filter(a => traineeView === 'ready' ? game.s.day - a.signed >= 90 && game.readiness(a) >= 55: traineeView === 'rest' ? a.energy < 30 || a.stress > 80: true);
  return heading('연습생 관리', '연습생을 누르면 개인 성장 리포트와 훈련·계약 정보를 확인할 수 있습니다.', btn('인재 모집', 'casting-modal', '', 'primary')) + `<div class="tabs">${[['all','전체'],['ready','데뷔 가능'],['rest','회복 필요']].map(([key,label])=>btn(label,'m-trainee-filter',`data-filter="${key}"`,traineeView===key?'active':'')).join('')}</div><div class="two-col section">${list.map(a=>{const d=DATA.roster[a.id],growth=growthSummary(a),ready=game.s.day-a.signed>=90&&game.readiness(a)>=55;return `<button type="button" class="panel trainee-summary" data-action="m-trainee-detail" data-id="${a.id}"><img class="talent-thumb" src="${d.image}" alt="${d.name}" loading="lazy"><div><h2>${d.name}</h2><p>${game.has('trainer')&&a.trainingMode==='auto'?'직원 자동 관리':'직접 훈련'} · ${Game.trainingPlans[a.trainingPlan].name}</p><p>체력 ${Math.round(a.energy)} · 스트레스 ${Math.round(a.stress)} · ${ready?'데뷔 조건 충족':'데뷔 준비 중'}</p><small>${growth.days}일 기록 · 평균 ${growth.gain>=0?'+':''}${growth.gain.toFixed(2)} · ${DATA.specs[game.trainingAdvice(a).weak]} 보완</small></div></button>`;}).join('')||'<p class="panel">해당하는 연습생이 없습니다.</p>'}</div>`;
};
function growthGraph(a) {
  const points = a.growthHistory.filter(x => x.day >= game.s.day - traineeGraphDays),
  metric = traineeGraphMetric,
  label = metric < 0 ? '평균 능력': DATA.specs[metric];
  if (points.length < 2) return '<p>성장 기록을 쌓고 있습니다. 날짜를 진행하면 그래프가 표시됩니다. 과거 기록은 소급 생성하지 않습니다.</p>';
  const value = p => metric < 0 ? p.stats.reduce((n, v) => n + v, 0) / 8: p.stats[metric],
  first = points[0],
  last = points.at(- 1),
  span = Math.max(1, last.day - first.day),
  coords = points.map(p => `${40+(p.day-first.day)/span*460},${155-value(p)/100*125}`).join(' ');
  return `<svg class="growth-graph" viewBox="0 0 540 190" role="img" aria-label="${label} 성장 추이"><title>${label} · ${value(first).toFixed(2)} → ${value(last).toFixed(2)}</title>${[0,25,50,75,100].map(v=>`<line x1="40" x2="500" y1="${155-v*1.25}" y2="${155-v*1.25}" stroke="#dce4ef"/><text x="5" y="${159-v*1.25}" font-size="11" fill="#667085">${v}</text>`).join('')}<polyline fill="none" stroke="#2563eb" stroke-width="3" points="${coords}"/><text x="40" y="178" font-size="12">${date(first.day)}</text><text x="455" y="178" font-size="12">${date(last.day)}</text></svg><p>${points.length}개 실제 기록 · ${label} ${value(first).toFixed(2)} → ${value(last).toFixed(2)}</p>`;
}
function traineeDetail_operations(id) {
  const a = game.s.trainees.find(a => a.id === Number(id));
  if (!a) throw Error('소속 연습생이 아닙니다.');
  const d = DATA.roster[a.id],
  advice = game.trainingAdvice(a),
  profile = game.profile(a.id),
  coach = game.coach(a.trainingPlan);
  modal(d.name + ' · 개인 육성', `<div class="detail-grid"><img class="detail-photo" src="${d.image}" alt="${d.name}"><div><p>${d.age}세 · ${d.position}</p><p>${d.story}</p><p>평균 ${game.readiness(a).toFixed(1)} · 체력 ${Math.round(a.energy)} · 스트레스 ${Math.round(a.stress)}</p><p>입소 ${game.s.day-a.signed}일 / 최소90일 · 데뷔 기준 평균55</p></div></div><h3>육성 목표</h3><label for="training-mode-${id}">관리 방식</label><select id="training-mode-${id}" data-control-id="${id}">${[['auto','직원 자동 관리'],['manual','직접 계획 지정']].map(([key,label])=>`<option value="${key}" ${a.trainingMode===key?'selected':''}>${label}</option>`).join('')}</select><label for="training-goal-${id}">목표</label><select id="training-goal-${id}" data-goal-id="${id}">${[['balanced','균형 성장'],['debut','빠른 데뷔 · 부족한 분야 보완'],['longterm','장기 성장 · 회복 우선'],['vocal','보컬 강화'],['performance','무대 강화'],['creative','창작 강화']].map(([key,label])=>`<option value="${key}" ${a.trainingGoal===key?'selected':''}>${label}</option>`).join('')}</select><p>${coach.staff?coach.staff.name+' 지도 · 성장 +'+(coach.bonus*100).toFixed(1)+'%':'육성 직원 없음 · 기본 훈련 유지'}${a.trainingMode==='auto'&&!game.has('trainer')?' · 채용 후 자동 조율 시작':''}</p><label for="training-${id}">직접 훈련 계획 · 변경 시 수동 관리</label><select id="training-${id}" data-training-id="${id}">${Object.entries(Game.trainingPlans).map(([key,p])=>`<option value="${key}" ${a.trainingPlan===key?'selected':''}>${p.name} · 일 ${p.cost}만 원${coach.staff?' (직원20% 절감)':''}</option>`).join('')}</select><h3>성장 리포트</h3><div class="row wrap">${btn('최근30일','m-growth-range',`data-id="${id}" data-days="30"`,traineeGraphDays===30?'primary small':'small')}${btn('최근90일','m-growth-range',`data-id="${id}" data-days="90"`,traineeGraphDays===90?'primary small':'small')}</div><label for="growth-metric-${id}">표시 능력</label><select id="growth-metric-${id}" data-growth-id="${id}">${['평균',...DATA.specs].map((label,i)=>`<option value="${i-1}" ${traineeGraphMetric===i-1?'selected':''}>${label}</option>`).join('')}</select>${growthGraph(a)}<p><strong>${DATA.specs[advice.strong]} 강점 / ${DATA.specs[advice.weak]} 보완 권장</strong></p><p>장르·포지션 기준 추천: ${Game.trainingPlans[advice.plan].name}. 최근 상태: ${esc(a.lastTrainingReason||'기록 시작')}.</p><details><summary>능력·계약·성격 상세</summary>${statsHTML(a.stats)}<p>성장 한계 ${profile.potential} · 학습 계수 ${profile.learning.toFixed(2)} · 실제 훈련 ${a.trainedDays}일</p><p>계약 만료 ${date(a.contract,true)} · 월 지원비60만 원 + 실제 훈련비</p>${personalityCard(a.id)}</details><p>최소 데뷔 조건과 무대 준비 수준은 다릅니다. 부족한 분야를 보완하면 활동 완성도에 도움이 됩니다.</p><div class="modal-actions">${btn('데뷔 계약 검토','m-debut',`data-id="${id}"`,'primary')}${btn('합의 종료 검토','m-release-trainee',`data-id="${id}"`,'link')}</div>`, true);
}
function scheduleEvents_operations() {
  const s = game.s,
  events = [];
  for (const j of s.jobs) events.push({
    id: 'job-' + j.id,
    start: j.start,
    end: j.due,
    title: activityTypeLabel(j) +(j.kind === 'single' && game.productionState(j).paused ?(game.productionState(j).reason === '광고 촬영' ? ' (광고로 중단)': ' (행사로 중단)'): '') + ' · ' + j.name,
    kind: j.kind,
    body: `${j.snapshot?.name||'인재 모집'} · ${date(j.start)}~${date(j.due)} · 예산 ${money(DATA.rules.jobCost(j))}${j.kind==='single'?` · ${game.productionState(j).paused?game.productionState(j).reason+' 중 / '+date(game.productionState(j).resume)+' 재개':'제작 중'} · 제작 잔여 ${game.productionState(j).remaining}일 · 연장 ${game.productionState(j).delay}일`:''}`,
    page: 'projects'
  });
  for (const a of[... s.artists, ... s.trainees]) {
    events.push({
      id: 'contract-' + a.id,
      start: a.contract,
      end: a.contract,
      title: DATA.roster[a.id].name + ' 계약 만료',
      kind: 'contract',
      body: termsText(a),
      page: s.trainees.includes(a) ? 'training': 'teams'
    });
    if (a.recoveryUntil > s.day) events.push({
      id: 'rest-' + a.id,
      start: s.day,
      end: a.recoveryUntil - 1,
      title: DATA.roster[a.id].name + ' 회복',
      kind: 'rest',
      body: date(a.recoveryUntil) + '부터 새 활동 가능',
      page: 'artists'
    });
    if (s.trainees.includes(a) && a.signed + 90 >= s.day) events.push({
      id: 'debut-' + a.id,
      start: a.signed + 90,
      end: a.signed + 90,
      title: DATA.roster[a.id].name + ' 데뷔 평가 가능일',
      kind: 'debut',
      body: '입소90일과 평균 능력55를 모두 충족해야 데뷔 가능합니다.',
      page: 'training'
    });
  }
  for (const c of s.catalog) events.push({
    id: 'release-' + c.id,
    start: c.market.startDay,
    end: c.market.startDay,
    title: '발매 · ' + c.name,
    kind: 'single',
    body: c.market.artistName + ' · 완성도 ' + Math.round(c.quality) + ' · 음악 제작·홍보비 ' + money(c.market.production),
    page: 'music'
  });
  for (const[index, p] of s.performance.entries()) if (p.kind !== 'single') events.push({
    id: 'performance-' + index,
    start: p.day,
    end: p.day,
    title: kindLabel[p.kind] + ' 완료 · ' + p.ids.map(id => DATA.roster[id].name).join(' · '),
    kind: p.kind,
    body: '완성도 ' + Math.round(p.quality) + ' · 당시 활동 기록',
    page: 'projects'
  });
  const stamp = calendarBase(),
  first = Math.round((Date.UTC(Math.floor(stamp / 12), stamp % 12, 1) - Date.UTC(2027, 0, 1)) / 86400000),
  last = Math.round((Date.UTC(Math.floor(stamp / 12), stamp % 12 + 1, 0) - Date.UTC(2027, 0, 1)) / 86400000);
  for (let day = Math.max(30, Math.ceil(first / 30) * 30); day <= last; day += 30) if (!game.cashForecast().some(x => x.day === day && x.label === '월 고정비·연습생 지원비')) events.push({
    id: 'monthly-' + day,
    start: day,
    end: day,
    title: '정기 월 정산',
    kind: 'finance',
    body: '30일 주기의 급여·고정비 및 운영 정산. 구체적인 지출은 당시 인원·계약에 따라 달라집니다.',
    page: 'finance'
  });
  for (const[index, x] of game.cashForecast().entries()) events.push({
    id: 'cash-' + index,
    start: x.day,
    end: x.day,
    title: x.label,
    kind: 'finance',
    body: x.type + ' · ' + money(x.amount),
    page: 'finance'
  });
  return events;
}
function calendarBase() {
  const now = new Date(Date.UTC(2027, 0, 1 + game.s.day));
  return calendarMonth ?? now.getUTCFullYear() * 12 + now.getUTCMonth();
}
function schedule_operations() {
  const month = calendarBase(),
  year = Math.floor(month / 12),
  m = month % 12,
  start = Date.UTC(year, m, 1),
  startDay = Math.round((start - Date.UTC(2027, 0, 1)) / 86400000),
  weekday = new Date(start).getUTCDay(),
  days = new Date(Date.UTC(year, m + 1, 0)).getUTCDate(),
  count = Math.ceil((weekday + days) / 7) * 7,
  events = scheduleEvents(),
  selected = calendarDay ?? game.s.day,
  chosen = events.filter(x => x.start <= selected && x.end >= selected);
  return heading('통합 일정', '날짜를 선택하고 일정 항목을 누르면 상세정보가 열립니다.') + `<div class="row between wrap calendar-controls"><h2>${year}년 ${m+1}월</h2><div class="row">${btn('이전 달','m-calendar-month','data-shift="-1"')}${btn('오늘','m-calendar-today')}${btn('다음 달','m-calendar-month','data-shift="1"')}</div></div><div class="month-calendar">${['일','월','화','수','목','금','토'].map(x=>`<div class="weekday">${x}</div>`).join('')}${Array.from({length:count},(_,i)=>{const day=startDay-weekday+i,inside=i>=weekday&&i<weekday+days,items=events.filter(x=>x.start<=day&&x.end>=day),label=new Date(Date.UTC(2027,0,1+day)).getUTCDate();return `<button type="button" class="month-day ${inside?'':'outside'} ${day===game.s.day?'today':''} ${day===selected?'selected':''}" data-action="m-calendar-day" data-day="${day}" aria-label="${date(day,true)} 일정 ${items.length}건" aria-pressed="${day===selected}"><strong>${label}</strong>${items.slice(0,2).map(x=>`<span class="calendar-event event-${x.kind}">${esc(x.title)}</span>`).join('')}${items.length>2?`<small>+${items.length-2}건</small>`:''}</button>`;}).join('')}</div><section class="panel section"><h2>${date(selected,true)} · ${chosen.length}건</h2>${chosen.map(x=>btn(`<span class="pill event-${x.kind}">${kindLabel[x.kind]||{contract:'계약',rest:'회복',debut:'데뷔',finance:'정산'}[x.kind]}</span> ${esc(x.title)} · 상세 보기`,'m-calendar-event',`data-event="${x.id}"`,'calendar-detail')).join('')||'<p>등록된 주요 일정이 없습니다. 훈련과 음원 집계는 매일 자동 진행됩니다.</p>'}</section>`;
};
const operationsFinance = finance_progression;
function finance_operations() {
  return operationsFinance() + panel('예정 입금·지출', `<p>공연은 종료7일 후, 광고 잔금은 촬영14일 후 입금됩니다. 음원은 주간 정산입니다. 입금은 약정 배분 후 회사 몫이며 음원 추정은 현재 누적분만 포함합니다.</p>${game.cashForecast().map(x=>`<div class="contract-row"><strong>${date(x.day)} · ${esc(x.label)}</strong><p>${x.type} · ${money(x.amount)}</p></div>`).join('')}<small>미래 일 훈련비, 신규 제작·계약, 판매량 증가분은 포함하지 않습니다.</small>`);
};
const operationsProjectModal = projectModal_market, operationsTalentModal = talentModal_management;
function projectModal_operations(key) {
  operationsProjectModal(key);
  $('#release-options').insertAdjacentHTML('beforeend', `<label for="promotion">사전 홍보</label><select id="promotion" name="promotion">${Object.entries(DATA.promotionPlans).map(([key,p])=>`<option value="${key}">${p.name} · ${money(p.cost)} · 준비 +${p.days}일</option>`).join('')}</select><small>초기 관심을 높이지만 흥행을 보장하지 않습니다.</small>`);
  budgetPreview();
};
;
function talentModal_operations(id) {
  const d = DATA.roster[id];
  if (!d.career) return operationsTalentModal(id);
  modal(d.name + ' · 경력 아티스트', `<div class="detail-grid"><img class="detail-photo" src="${d.image}" alt="${d.name}"><div><span class="pill">${d.career} · ${d.position}</span><p>${d.age}세 · ${d.story}</p><p>현재 충성 팬 ${d.priorFans}명 · 인지도 ${d.priorFame}</p>${statsHTML(d.stats,true)}</div></div>${personalityCard(id)}<p>육성 대기 없이 계약 후 바로 활동 가능. 음반 제작 기간과 회복 일정은 필요합니다. 과거 작품 권리와 매출은 이전 소속사에 남습니다.</p><form id="m-contract"><input type="hidden" name="id" value="${id}"><label for="offer">계약 제안</label><select name="offer" id="offer">${Object.entries(DATA.terms).filter(([key])=>key!=='company').map(([key,t])=>`<option value="${key}">${t.name} · 계약금 ${money(t.fee+250+d.priorFame*12)} · 회사 ${Math.round(t.share*100)}% · ${t.days}일</option>`).join('')}</select><button class="primary section">전속계약 승인</button></form>`, true);
};
const operationsManagementClick = managementClick_personality;
function managementClick_operations(action, d) {
  switch (action) {
    case 'm-staff-detail': return staffDetail(d.id);
    case 'm-recruit-filter': recruitFilter = d.filter;
    render();
    return;
    case 'm-trainee-detail': traineeGraphDays = 30;
    traineeGraphMetric = - 1;
    return traineeDetail(d.id);
    case 'm-growth-range': traineeGraphDays = Number(d.days) === 90 ? 90: 30;
    return traineeDetail(d.id);
    case 'm-calendar-month': calendarMonth = calendarBase() +(Number(d.shift) < 0 ? - 1: 1);
    calendarDay = Math.round((Date.UTC(Math.floor(calendarMonth / 12), calendarMonth % 12, 1) - Date.UTC(2027, 0, 1)) / 86400000);
    render();
    return;
    case 'm-calendar-today': calendarMonth = null;
    calendarDay = game.s.day;
    render();
    return;
    case 'm-calendar-day': calendarDay = Number(d.day);
    render();
    return;
    case 'm-calendar-event': {
      const item = scheduleEvents().find(x => x.id === d.event);
      if (!item) throw Error('일정이 변경되었습니다. 달력을 다시 확인하세요.');
      return modal('일정 상세', `<h3>${esc(item.title)}</h3><p>${esc(item.body)}</p><p>${date(item.start,true)} → ${date(item.end,true)} · ${Math.max(0,item.end-game.s.day)}일 남음</p>${btn('관련 관리 화면','nav',`data-page="${item.page}"`,'primary')}`);
    }
    default: throw Error("처리할 수 없는 동작입니다.");
  }
};
UIEvents.onChange('operations', ev => {
  const target = ev.target;
  try {
    if (target.dataset.controlId !== undefined) {
      const a = game.talent(Number(target.dataset.controlId));
      game.setTrainingControl(a.id, target.value, a.trainingGoal);
      save();
      traineeDetail(a.id);
    } else if (target.dataset.goalId !== undefined) {
      const a = game.talent(Number(target.dataset.goalId));
      game.setTrainingControl(a.id, a.trainingMode, target.value);
      save();
      traineeDetail(a.id);
    } else if (target.dataset.growthId !== undefined) {
      traineeGraphMetric = Number(target.value);
      traineeDetail(target.dataset.growthId);
    } else if (target.dataset.trainingId !== undefined) {
      game.transaction(() => game.setTraining(Number(target.dataset.trainingId), target.value));
      save();
      render();
      traineeDetail(target.dataset.trainingId);
      toast('훈련 계획을 변경했습니다.');
    };
    if (target.id === 'promotion') budgetPreview();
  } catch (e) {
    toast(e.message);
  }
});


;
/* FILE src/activity-results-ui.js */
'use strict';
// View-only adapters. No new financial rules or duplicated saved transaction history.
function festivalStatement(record) {
  const offer = game.s.festivalOffers.find(o => o.status === 'accepted' && o.entity === record.entity && o.day === record.day && o.approval?.name === record.name);
  const gross = offer?.approval?.pay ?? null, cost = offer?.approval?.cost ?? null;
  return {name:record.name, day:record.day, kind:'festival', scope:'행사 출연', gross,
    payout:gross===null||cost===null?null:Math.round((gross-cost-record.net)*100)/100,
    cost, production:0, net:record.net, paymentDay:record.day};
}
function activityStatement(entry) {
  return {name:entry.name, day:entry.day, kind:entry.kind,
    scope:entry.kind==='ad'?'광고 잔금 구간':'공연 정산', gross:entry.gross, payout:entry.payout,
    cost:entry.variable, production:entry.budget, net:entry.net,
    paymentDay:entry.day+(entry.kind==='ad'?DATA.rules.advertisement.balanceDays:7)};
}
function activityStatementHTML(row) {
  const known = row.gross!==null && row.payout!==null && row.cost!==null;
  return `<section class="tip activity-statement"><strong>${esc(row.scope)}</strong>${known?`<p>이 정산 총액 ${money(row.gross, 2)} · 아티스트 배분 ${money(row.payout, 2)}</p><p>활동비 ${money(row.cost, 2)} · 선집행 제작비 ${money(row.production, 2)}</p>`:'<p>이전 상세 정산 자료가 없어 총액·배분·활동비는 표시하지 않습니다.</p>'}<p><strong>회사 손익 ${money(row.net, 2)}</strong> · 일 훈련·월 고정비 별도</p><p>입금 기준일 ${date(row.paymentDay,true)}${row.paymentDay>game.s.day?' · 입금 예정':''}</p>${row.kind==='ad'?'<small>잔금 구간만 표시합니다. 선금40%와 해당 배분은 계약 당시 거래 내역에서 확인하세요.</small>':row.kind==='live'?'<small>입금은 아티스트 배분 차감 후 이루어집니다. 활동비·제작비는 이미 집행한 지출입니다.</small>':''}</section>`;
}
function outcomeSettlementHTML(outcome) {
  if (!['live','ad'].includes(outcome.kind)) return '';
  const entry = game.s.settlements.find(e => e.day===outcome.day && e.kind===outcome.kind && e.name===outcome.title);
  return entry?`<details><summary>정산 금액·입금일</summary>${activityStatementHTML(activityStatement(entry))}</details>`:'';
}
function activityFinanceHTML() {
  const rows = game.s.settlements.map(activityStatement).concat(game.s.festivalHistory.map(festivalStatement)).sort((a,b)=>b.day-a.day).slice(0,15);
  return panel('활동별 회사 손익', '<p>공연·광고·행사의 실제 기록입니다. 광고는 잔금 구간만 표시하며, 손익과 입금 시점은 다릅니다.</p>'+ (rows.map(row=>`<article class="contract-row"><h3>${esc(row.name)} · ${date(row.day)}</h3>${activityStatementHTML(row)}</article>`).join('')||'<p>완료된 활동 내역 없음</p>'));
}
function festivalsOnDay(summary) {
  return game.s.festivalHistory.filter(e=>e.day===summary.day);
}
function festivalCount(summary) {
  return Math.max(festivalsOnDay(summary).length, Number.isSafeInteger(summary.festivals)?Math.max(0,summary.festivals):0);
}
function dayFestivalHTML(summary) {
  const records=festivalsOnDay(summary),count=festivalCount(summary);
  return records.map(e=>`<p>행사 완료: ${esc(e.name)} · ${esc(e.artist)} · 회사 실수령 ${money(e.net)} · 팬 +${e.fans}명</p>`).join('')+(count>records.length?`<p>행사 ${count-records.length}건 완료 · 상세 결과 보관 기간 종료</p>`:'');
}
function recentWeekHTML() {
  const s=game.s,from=Math.max(0,s.day-6),accounts=s.accounts.filter(a=>a.day>=from&&a.day<=s.day),days=s.daySummaries.filter(d=>d.day>=from&&d.day<=s.day);
  const income=accounts.reduce((n,a)=>n+a.revenue,0),expense=accounts.reduce((n,a)=>n+a.expense,0),fans=days.reduce((n,d)=>n+d.fansChange,0),teamFans=days.reduce((n,d)=>n+d.teamFansChange,0);
  return panel('최근 7일 운영 요약', `<p>${date(from)}~${date(s.day)} · 기록된 운영 수입 <strong>${money(income, 2)}</strong> · 지출 <strong>${money(expense, 2)}</strong></p><p>운영 차액 ${money(income-expense, 2)} · 개인 팬 ${fans>=0?'+':''}${fans.toLocaleString()}명 · 팀 팬 ${teamFans>=0?'+':''}${teamFans.toLocaleString()}명</p><small>대출 원금·회생·목표 지원금 제외, 이자 포함. 팬 변화는 하루 진행 기록 기준이며 계약 종료도 반영합니다.</small>`);
}


;
/* FILE src/evolution-ui.js */
'use strict';
let momentAudio = null, goalView = 'all';
function portraitsStrip(ids, cls = '') {
  return `<div class="ensemble ${cls}">${ids.map(id=>`<img src="${DATA.roster[id].image}" alt="${esc(DATA.roster[id].name)}" loading="lazy">`).join('')}</div>`;
}
function spotlightEntity() {
  return game.entity(game.s.pinnedEntity) || game.entities.find(e => game.s.jobs.some(j => j.entity === e.key)) || game.entities.find(e => e.key.startsWith('u')) || game.entities[0] || null;
}
function spotlight() {
  const e = spotlightEntity(),
  job = e && game.s.jobs.find(j => j.snapshot?.ids.some(id => e.members.some(a => a.id === id))),
  latest = e && game.s.outcomes.filter(o => o.ids.some(id => e.members.some(a => a.id === id))).at(- 1);
  return `<section class="spotlight ${e?'':'empty-spotlight'}" aria-label="오늘의 아티스트"><div class="spotlight-copy"><span class="eyebrow">OUR NEXT STAGE</span><h1>${e?esc(e.name):'아직 만나지 못한 가능성'}</h1><p>${job?esc(job.name)+' · '+Math.max(0,job.due-game.s.day)+'일 후 완료':latest?'최근 활동 · '+esc(latest.title):e?'오늘의 연습이 내일의 무대가 됩니다.':'첫 인재를 만나 우리만의 음악을 시작하세요.'}</p>${e?`<p class="spotlight-line">“${esc(game.trainingReaction(e.members[0].id))}”</p><div class="row wrap">${btn('함께한 기록','m-memory',`data-id="${e.members[0].id}"`,'primary')}${btn('활동 준비','project-modal',`data-entity="${e.key}"`,'soft')}</div><label for="spotlight-select">홈에서 볼 아티스트</label><select id="spotlight-select"><option value="">활동 중인 대상 자동 선택</option>${game.entities.map(x=>`<option value="${x.key}" ${game.s.pinnedEntity===x.key?'selected':''}>${esc(x.name)}${x.key.startsWith('u')?' · 팀':' · 개인'}</option>`).join('')}</select>`:btn('인재 모집 시작','casting-modal','','primary')}</div>${e?portraitsStrip(e.members.map(a=>a.id),'spotlight-portraits'):'<img class="office-scene" src="assets/office.webp" alt="햇빛이 드는 첫 기획사 사무실">'}</section>`;
}
const evolutionTasks = todayTasks_market;
function todayTasks_evolution() {
  let tasks = evolutionTasks();
  if (game.s.jobs.some(j => j.kind === 'casting')) tasks = tasks.filter(t => t.label !== '첫 인재 모집 시작');
  else if (game.s.candidates.length) tasks = tasks.map(t => t.label === '첫 인재 모집 시작' ? {
    priority: 2,
    label: '도착한 영입 후보 비교',
    action: 'nav',
    args: 'data-page="casting"'
  }
  : t);
  for (const st of game.s.stories) if (st.status === 'open') tasks.push({
    priority: 1,
    label: DATA.roster[st.talentId].name + '의 이야기 · ' + Math.max(0, st.expires - game.s.day) + '일 남음',
    action: 'm-story',
    args: `data-id="${st.id}"`
  });
  for (const r of game.s.reports) if (r.kind === 'ad' && game.reportState(r).needsDecision) tasks.push({
    priority: 2,
    label: r.title + ' · ' +(r.expires - game.s.day) + '일 남음',
    action: 'report',
    args: `data-id="${r.id}"`
  });
  return tasks.sort((a, b) => a.priority - b.priority);
};
function home_evolution() {
  const s = game.s,
  tasks = todayTasks(),
  forecast = game.cashForecast(),
  incoming = forecast.find(x => x.amount > 0),
  outgoing = forecast.find(x => x.amount < 0),
  moments = s.moments.slice(- 2).reverse();
  return spotlight() + guideCard() + panel('오늘 결정할 일', tasks.length ? `<div class="task-list">${tasks.slice(0,3).map(t=>btn(`<span class="pill ${t.priority===0?'coral':''}">${t.priority===0?'긴급':'확인'}</span> ${esc(t.label)}`,t.action,t.args,'task-button')).join('')}</div>${tasks.length>3?btn('전체 할 일 '+tasks.length+'건','m-all-tasks','','link'):''}`: '<p>급한 결정이 없습니다. 다음 무대를 준비하거나 날짜를 진행하세요.</p>') + `<section class="cash-ribbon panel section" aria-label="가까운 자금 흐름"><div><small>현재 운영 자금</small><h2>${money(s.cash)}</h2><p>평판 ${s.reputation.toFixed(1)} · ${DATA.stageNames[game.stage]}</p></div><div><small>가까운 지출</small><strong>${outgoing?date(outgoing.day)+' · '+money(-outgoing.amount):'확정 지출 없음'}</strong><p>${outgoing?esc(outgoing.label):''}</p></div><div><small>다음 입금</small><strong>${incoming?date(incoming.day)+' · '+money(incoming.amount):'집계 중'}</strong><p>${incoming?esc(incoming.type+' · '+incoming.label):'새 활동이나 작품의 정산이 필요합니다.'}</p></div><div class="row wrap">${btn('재정','nav','data-page="finance"','soft')}${btn('운영자금 대출','loan-modal','','link')}</div><small class="cash-note">예정 금액은 현재 기록 기준. 미래 훈련비·신규 제작비·판매 증가분은 별도입니다.</small></section>` + recentWeekHTML() + panel('다가오는 일주일', `<div class="next-week">${scheduleEvents().filter(x=>x.end>=s.day&&x.start<=s.day+7).slice(0,5).map(x=>`<div><span>${date(Math.max(s.day,x.start))}</span><strong>${esc(x.title)}</strong>${btn('보기','nav',`data-page="${x.page}"`,'link small')}</div>`).join('')||'<p>등록된 주요 일정이 없습니다. 훈련과 음원 집계는 매일 진행됩니다.</p>'}</div>${btn('전체 일정','nav','data-page="schedule"','soft')}`) + panel('우리의 최근 순간', moments.map(m => `<div class="contract-row"><small>${date(m.day)} · ${m.seen?'함께한 기록':'새로운 순간'}</small><h3>${esc(m.title)}</h3>${btn('다시 보기','m-moment',`data-id="${m.id}"`,'link')}</div>`).join('') || '<p>첫 계약부터 우리의 기록이 쌓입니다.</p>') + panel('최근 발매', s.catalog.slice(- 3).reverse().map(c => releaseRow({ release: c, company: s.company, own: true })).join('') || '<p>아직 발매작이 없습니다.</p>');
};
function memoriesHTML(id) {
  const a = game.talent(Number(id)) || game.s.departed.find(x => x.id === Number(id));
  return a ? `<section class="memories"><h3>함께한 기록</h3>${a.memories.slice(-8).reverse().map(m=>`<div><small>${date(m.day)}</small><p>${esc(m.text)}</p></div>`).join('')||'<p>첫 순간을 기다리고 있습니다.</p>'}${a.memories.length>8?btn('전체 기록 ('+a.memories.length+')','m-memory',`data-id="${id}"`,'link'):''}</section>`: '';
}
const evolutionArtistModal = artistModal_market, evolutionTraineeDetail = traineeDetail_operations;
function artistModal_evolution(id, candidate = false) {
  evolutionArtistModal(id, candidate);
  if (!candidate) $('#modal-error').insertAdjacentHTML('beforebegin', memoriesHTML(id));
};
function traineeDetail_evolution(id) {
  evolutionTraineeDetail(id);
  $('#modal-error').insertAdjacentHTML('beforebegin', memoriesHTML(id));
};
function storyModal(id) {
  const st = game.s.stories.find(x => x.id === Number(id));
  if (!st) throw Error('이야기 기록이 없습니다.');
  const d = DATA.personalStories[st.kind],
  a = game.talent(st.talentId),
  p = game.personality(st.talentId),
  open = st.status === 'open' && a && st.expires >= game.s.day;
  modal(DATA.roster[st.talentId].name + ' · ' + d.title, portraitsStrip([st.talentId], 'story-portrait') + `<span class="pill">${esc(p.name)} · ${esc(DATA.roster[st.talentId].career||'우리의 아티스트')}</span><p class="story-quote">“${esc(d.body)}”</p><p>${esc(p.intro)}</p>${open?`<p>대화 기한 ${date(st.expires)} · 선호와 맞는 선택은 신뢰 +5, 다른 선택 +3 (상한100)</p><div class="story-options">${btn(d.support,'m-story-choice',`data-id="${st.id}" data-choice="support"`,'primary',game.s.cash<100)}<small>스트레스 -6 · 창작/무대 상담 선호 시 신뢰 +5</small>${btn(d.space,'m-story-choice',`data-id="${st.id}" data-choice="space"`,'soft')}<small>체력 +5 · 스트레스 -10 · 휴식 상담 선호 시 신뢰 +5</small></div><p>기존 확정 일정은 유지됩니다. 기한이 지나도 별도 페널티는 없습니다.</p>`:`<p>${st.status==='resolved'?'대화를 마쳤습니다. 함께한 기록에 선택과 답장이 남습니다.':'대화 기한이 지났거나 계약이 종료됐습니다.'}</p>`}${btn('함께한 기록','m-memory',`data-id="${st.talentId}"`,'link')}`);
}
function momentTone() {
  if (!game.s.soundEnabled) return;
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    momentAudio = momentAudio || new AC();
    momentAudio.resume().catch (() => {
    });
    [523.25, 659.25, 783.99].forEach((hz, i) => {
      const oscillator = momentAudio.createOscillator(),
      gain = momentAudio.createGain(),
      t = momentAudio.currentTime + i * .12;
      oscillator.frequency.value = hz;
      gain.gain.setValueAtTime(0, t);
      gain.gain.linearRampToValueAtTime(.035, t + .015);
      gain.gain.exponentialRampToValueAtTime(.001, t + .28);
      oscillator.connect(gain);
      gain.connect(momentAudio.destination);
      oscillator.start(t);
      oscillator.stop(t + .3);
    });
  } catch {
  }
}
function momentModal(id) {
  const m = game.s.moments.find(x => x.id === Number(id));
  if (!m) throw Error('기념 기록이 없습니다.');
  m.seen = true;
  save();
  modal('함께 만든 순간', `<section class="milestone-scene">${portraitsStrip(m.ids)}<span class="eyebrow">A MOMENT TO REMEMBER</span><h2>${esc(m.title)}</h2><p>${esc(m.body).replace(/\n/g,'<br>')}</p><small>${date(m.day,true)} · ${esc(game.s.company)}</small></section><div class="modal-actions">${btn('다음 순간 / 계속','m-next-moment','','primary')}${btn('목표와 보상','nav','data-page="goals"','soft')}${btn('모두 건너뛰기','m-skip-moments','','link')}</div><small>건너뛴 순간도 홈·목표 화면에서 다시 볼 수 있습니다.</small>`);
  momentTone();
}
function nextMoment() {
  const m = game.s.moments.find(x => !x.seen);
  if (m) return momentModal(m.id);
  close();
  render();
}
function outcomeHTML(o) {
  const settlement = outcomeSettlementHTML(o);
  if (o.kind === 'ad') return settlement + `<section class="activity-scene">${portraitsStrip(o.ids)}<span class="eyebrow">CAMPAIGN COMPLETE</span><h2>${esc(o.title)}</h2></section><p>촬영을 완료했습니다. 잔금은 ${date(o.day+DATA.rules.advertisement.balanceDays)} 입금 예정이며, 아티스트 약정 배분을 차감합니다.</p><p>중단된 음반 제작은 오늘부터 재개합니다. 활동 화면에서 남은 제작일과 변경된 완료일을 확인하세요.</p>`;
  const commentary = o.kind === 'live' ?(o.attendance === o.capacity ? '관객으로 가득 찬 객석이 마지막 곡까지 함께했습니다.': o.attendance > 0 ? '작은 객석에서도 우리의 음악을 듣는 사람들이 있었습니다.': '관객 확보에 어려움을 겪었습니다. 팬층에 맞는 규모부터 다시 준비해 보세요.'): o.quality >= 75 ? '준비한 음악과 표현이 좋은 반응으로 이어졌습니다.': '이번 활동의 경험을 다음 무대에 이어 가세요.';
  return settlement + `<section class="activity-scene">${portraitsStrip(o.ids)}<span class="eyebrow">${o.kind==='live'?'ON STAGE':o.kind==='single'?'NEW RELEASE':'OUR MUSIC'}</span><h2>${esc(o.title)}</h2><p>“${o.quality>=75?'오늘의 무대를 오래 기억할 것 같아요.':'다음에는 조금 더 잘 전하고 싶어요.'}”</p></section><p>${commentary}</p>${o.factors?.length?`<section class="tip"><strong>실제 결과에 반영된 요인</strong>${o.factors.map(x=>`<p>${esc(x)}</p>`).join('')}</section>`:''}<div class="result-metrics"><div><small>완성도</small><strong>${Math.round(o.quality)}</strong></div><div><small>새로운 팬</small><strong>+${o.fans.toLocaleString()}명</strong></div>${o.kind==='live'?`<div><small>유료 관객</small><strong>${o.attendance} / ${o.capacity}</strong></div><div><small>회사 손익</small><strong class="${o.net>=0?'positive':'negative'}">${money(o.net)}</strong></div>`:''}</div><p>${o.kind==='live'?'공연 손익은 제작비·현장비·아티스트 배분 포함. 훈련·고정비 별도. 실제 정산은 종료7일 후 입금됩니다.':o.kind==='single'?'발매 시점의 반응입니다. 실제 흥행은 판매·재생으로 판정하고 매주 정산합니다.':'활동 완료 기록입니다. 실제 입출금은 재정에서 확인하세요.'}</p>`;
}
const evolutionReportDetail = reportDetail_app;
function reportDetail_evolution(r) {
  if (r.storyId) {
    const st = game.s.stories.find(x => x.id === r.storyId);
    return `<h2>${esc(r.title)}</h2><p class="report-content">${esc(r.body)}</p>${st?btn(st.status==='open'?'이야기 듣기':'대화 기록','m-story',`data-id="${st.id}"`,'primary'):''}`;
  }
  let html = evolutionReportDetail(r);
  if (r.outcomeId) {
    const o = game.s.outcomes.find(x => x.id === r.outcomeId);
    if (o) html = outcomeHTML(o) + `<details><summary>상세 정산 보고</summary>${html}</details>`;
  }
  if (r.talentId !== undefined) html += btn('인물·함께한 기록', 'm-memory', `data-id="${r.talentId}"`, 'soft');
  if (r.goalRewardIds) html += btn('목표와 지급 보상', 'nav', 'data-page="goals"', 'primary');
  if (r.weeklySummary || r.title === '육성 담당 주간 보고') html += `<div class="row wrap">${btn('연습생 관리','nav','data-page="training"','soft')}${btn('재정','nav','data-page="finance"','soft')}</div>`;
  return html;
};
function goals_evolution() {
  const allRows = game.goalList(),
  rows = allRows.filter(g => goalView === 'all' ||(goalView === 'done' ? g.done: !g.done)),
  offers = game.s.specialOffers;
  return heading('성장 목표와 보상', '날짜 진행 시 달성을 확인하고 1회 자동 지급합니다. 지원금은 영업이익에 포함하지 않습니다.') + `<div class="reward-wallet panel"><h2>사용 가능한 지원</h2><p>싱글 제작비5% 할인권 ${game.s.perks.productionVoucher}장 (최대200만 원) · 싱글 홍보 ${game.s.perks.debutPromo}회 · 공연 홍보 ${game.s.perks.livePromo}회</p><small>해당 활동의 다음 승인에 자동 적용. 할인은 기본 제작비만 적용하며 홍보·제조비는 별도. 홍보 지원은 관심/관객 수요 +8%, 흥행 보장 없음.</small></div><div class="tabs section">${[['all','전체'],['progress','진행 중'],['done','달성 완료']].map(([key,label])=>btn(label,'m-goal-filter',`data-filter="${key}"`,goalView===key?'active':'')).join('')}</div><div class="two-col section">${rows.map(g=>`<article class="panel goal-card ${g.done?'goal-done':''}"><span class="pill">${g.done?'달성 완료':'진행 중'}</span><h2>${esc(g.title)}</h2><p>${esc(g.reward.description)}</p><div class="bar" role="progressbar" aria-label="${esc(g.title)}" aria-valuemin="0" aria-valuemax="${g.target}" aria-valuenow="${Math.floor(Math.min(g.value,g.target))}"><span style="width:${g.done?100:Math.max(0,Math.min(100,g.value/g.target*100))}%"></span></div><p>${g.done?'회사 연혁에 기록됨':Math.floor(Math.min(g.value,g.target)).toLocaleString()+' / '+g.target.toLocaleString()}</p><strong>${esc(g.reward.text)}</strong><small>${g.paid?'자동 지급 완료':g.done?'다음 날짜 진행 시 보상 반영':'날짜 진행 시 달성 확인·자동 지급'}</small>${g.done&&game.s.moments.some(m=>m.title===g.title)?btn('기념 장면','m-moment',`data-id="${game.s.moments.find(m=>m.title===g.title).id}"`,'link'):''}</article>`).join('')}</div>` + panel('특별 활동 제안', offers.map(o => `<div class="contract-row"><h3>${esc(DATA.specialOffers[o.kind].title)}</h3><p>${esc(DATA.specialOffers[o.kind].note)}</p><p>${o.used?'승인 완료':o.expires<game.s.day?'기한 종료':'제안 기한 '+date(o.expires)}</p>${btn('대상과 비용 검토','m-offer',`data-id="${o.id}"`,'soft',o.used||o.expires<game.s.day)}</div>`).join('') || '<p>팬·스타·업계 목표를 달성하면 제안이 도착합니다.</p>');
};
function offerModal(id) {
  const o = game.s.specialOffers.find(x => x.id === Number(id));
  if (!o) throw Error('제안이 없습니다.');
  const d = DATA.specialOffers[o.kind],
  eligible = game.entities.filter(e => game.offerEligible(o, e.key));
  modal(d.title, `<p>${esc(d.note)}</p><p>특별 캠페인: 싱글 초기 관심 +4% / 공연 홍보 수요 +8%. 일반 배분·회복·일정 규칙이 적용됩니다.</p>${eligible.map(e=>{const q=game.projectQuote(e.key,d.kind,d.budget);return `<article class="contract-row"><h3>${esc(e.name)}</h3><p>실제 승인비 ${money(q.total)}${q.discount?' · 할인 '+money(q.discount):''} / 승인 후 ${money(game.s.cash-q.total)}</p>${btn('이 대상으로 활동 승인','m-offer-accept',`data-id="${o.id}" data-key="${e.key}"`,'primary',game.busy(e.key)||e.members.some(a=>a.recoveryUntil>game.s.day||a.energy<25)||game.s.cash<q.total)}</article>`;}).join('')||'<p>현재 조건을 충족하는 대상이 없습니다. 팬·현재 스타 등급·영업이익·회사 단계를 확인하세요.</p>'}<p>추가 실물 제조 없이 진행합니다. 지원 할인권은 해당되는 경우 자동 적용합니다. 제안 기한 ${date(o.expires,true)}</p>`);
}
const evolutionProjectModal = projectModal_operations;
function projectModal_evolution(key) {
  evolutionProjectModal(key);
  budgetPreview();
};
function budgetPreview_evolution() {
  const kind = $('#project-kind')?.value || 'single',
  key = $('#entity')?.value || game.entities[0]?.key,
  b = Number($('#budget')?.value || 2000),
  e = game.entity(key),
  options = { format: $('#release-format')?.value || 'digital', quantity: Number($('#release-quantity')?.value || 1000), promotion: $('#promotion')?.value || 'none' },
  q = game.projectQuote(key, kind, b, options),
  box = $('#release-options');
  if (box) box.hidden = kind !== 'single';
  let caution = '완성도와 흥행은 다릅니다. 제작비는 즉시 집행하며 회수는 보장되지 않습니다.';
  if (kind === 'single') caution = b === 1000 ? '신인 제작: 적은 초기 투자로 시작합니다. 투자 규모에 따른 완성도 기여는 작으며 판매·재생은 발매 후 집계합니다.': '작품은 발매 이후 장기 정산됩니다. 팬층과 후속 활동이 수요에 영향을 줍니다.';
  if (kind === 'cover') caution = '직접 수익보다 노출을 위한 활동입니다. 최근 커버의 관심은 다음 싱글에 최대16% 반영되며60일 동안 감소합니다. 반복 효과는 줄어듭니다.';
  if (kind === 'live' && e) {
    const team = e.members.length > 1,
    cap = b <= 300 ?(team ? 500: 200): b <= 800 ?(team ? 1400: 700):(team ? 3200: 1800),
    fans = e.members.reduce((n, a) => n + a.fans, 0),
    recent = game.s.performance.filter(p => p.kind === 'live' && p.day > game.s.day - 30 && p.ids.some(id => e.members.some(a => a.id === id))).length;
    caution = `수용 ${cap}명 · ${fans<cap?'현재 팬층에 비해 공연장이 큽니다. 신규 관객 확보가 필요합니다.':'팬층에 맞는 규모와 관객 반응을 함께 확인하세요.'} ${recent?'최근30일 공연 '+recent+'회 · 반복 수요 둔화가 적용됩니다.':''} 신곡 발매 후45일은 관심에 도움이 됩니다.`;
  }
  const due = game.s.day +(DATA.rules.activity[kind]?.days || 0) +(kind === 'single' ? DATA.promotionPlans[options.promotion].days: 0),
  forecast = game.cashForecast().find(x => x.amount < 0),
  p = kind === 'single' && game.s.perks.debutPromo ? '싱글 홍보 지원 자동 사용 · 초기 관심 +8%': kind === 'live' && game.s.perks.livePromo ? '공연 홍보 지원 자동 사용 · 관객 수요 +8%': '';
  $('#budget-preview').innerHTML = `<strong>총 집행 ${money(q.total)}</strong><br>기본 제작 ${money(q.base)}${q.discount?' − 할인 '+money(q.discount):''} + 제조 ${money(q.manufacturing)} + 홍보 ${money(q.promo)}<br>승인 후 잔액 <strong class="${game.s.cash<q.total?'negative':''}">${money(game.s.cash-q.total)}</strong><br>${forecast?'가까운 지출 '+date(forecast.day)+' · '+money(-forecast.amount)+' ('+esc(forecast.label)+')<br>':''}활동 완료 ${date(due)} · ${kind==='live'?'종료7일 후 정산':kind==='single'?'발매일부터7일 단위 정산':'직접 정산 없음'}${p?'<br>'+p:''}<p>${caution}</p><small>미래 일 훈련비·신규 지출 별도. 정확한 관객·수익·성공 확률은 미리 확정되지 않습니다.</small>`;
};
function teamSummary(e) {
  const p = game.teamProfile(e);
  return `<p><strong>${DATA.specs[p.strength]} 강점 · ${DATA.specs[p.weak]} 보완</strong></p><p>협업 호흡 ${p.cohesion.toFixed(1)} / 100 · 역할 ${p.roles}종</p><small>각 분야의 강점이 팀 평균을 보완합니다. 함께한 활동과 안정적인 연습으로 호흡이 성장하며 멤버 변경 시 일부 조정됩니다.</small>`;
}
const evolutionTeams = teams_management, evolutionUnitModal = unitModal_app;
function teams_evolution() {
  return evolutionTeams() + panel('팀 프로필과 개인 활동', game.s.units.map(u => {
    const e = game.entity(u.key);
    return `<article class="contract-row">${portraitsStrip(u.ids,'team-lineup')}<h3>${esc(u.name)}</h3>${teamSummary(e)}${btn('팀 활동 준비','project-modal',`data-entity="${u.key}"`,'primary',u.status!=='active'||u.ids.length<2)}<div class="row wrap">${u.ids.map(id=>btn(DATA.roster[id].name+' 개인 활동','project-modal',`data-entity="${id}"`,'soft small')).join('')}</div><small>개인 활동도 가능하지만 같은 멤버의 팀·개인 일정은 겹칠 수 없습니다.</small></article>`;
  }).join('') || '<p>팀을 결성하면 단체 프로필과 협업 상태를 볼 수 있습니다.</p>');
};
function unitModal_evolution() {
  evolutionUnitModal();
  $('#modal-error').insertAdjacentHTML('beforebegin', '<div id="team-composition" aria-live="polite"><p>멤버를 선택하면 조합의 강점과 보완점을 표시합니다.</p></div>');
};
const evolutionStaffDetail = staffDetail_operations;
function staffDetail_evolution(id) {
  evolutionStaffDetail(id);
  const p = DATA.staff.find(x => x.id === id),
  current = game.s.staff.map(x => DATA.staff.find(y => y.id === x)).filter(x => x.kind === p.kind),
  best = Math.max(0, ... current.map(x => x.coaching));
  let message = p.kind === 'trainer' ? '육성은 훈련 분야별 최적 직원1명을 적용합니다. 기존 직원보다 적합한 전문 분야가 있을 때 효과가 바뀌며 성장·절감률은 중복 합산하지 않습니다.': current.length ?(p.coaching > best ? '현재 직무 최고 능력을 갱신합니다.': '현재 최고 직무 능력보다 낮거나 같아 직무 보너스가 늘지 않습니다.'): '해당 직무의 첫 전문 직원입니다.';
  $('#modal-error').insertAdjacentHTML('beforebegin', `<section class="tip"><strong>추가 채용 효과</strong><p>${message}</p><small>관리 정원 증가는 해당 직무 보유 여부로 적용하며 같은 직무 추가 인원만큼 늘지 않습니다.</small></section>`);
};
const evolutionStaffScreen = staffScreen_operations;
function staffScreen_evolution() {
  const x = game.s.staffImpact;
  return evolutionStaffScreen() + panel('직원의 실제 기여', `<p>기록 시작 ${date(x.since)} 이후 연습생 훈련비 <strong>${money(x.saved)}</strong> 절감</p><p>직원 지도 훈련 ${x.trainingDays}인일 · 자동 회복 조정 ${x.recoveryDays}인일</p><small>실제로 실행한 연습생 훈련·회복만 집계합니다. 능력 성장의 차이를 가정해서 소급 계산하지 않습니다.</small>`);
};
const evolutionReleaseModal = releaseModal_market;
function releaseModal_evolution(uid) {
  evolutionReleaseModal(uid);
  const c = game.allReleases().find(x => x.release.market.uid === uid)?.release;
  if (c?.market.resurfaceUntil > game.s.day) $('#modal-error').insertAdjacentHTML('beforebegin', `<p class="pill">다시 듣는 음악 · ${esc(c.market.resurfaceReason)} · ${date(c.market.resurfaceUntil-1)}까지 관심 보강</p>`);
};
const evolutionSettings = settings_app;
function settings_evolution() {
  evolutionSettings();
  if (game.s) $('#modal-error').insertAdjacentHTML('beforebegin', `<div class="row wrap section">${btn('기념 순간 효과음: '+(game.s.soundEnabled?'켜짐':'꺼짐'),'m-sound','','soft')}${btn('기념 순간 모아 보기','m-moments','','soft')}</div><small>효과음은 짧은 합성음이며 기본은 꺼짐입니다.</small>`);
};
const evolutionMutate = mutate_app;
function mutate_evolution(fn, message) {
  evolutionMutate(fn, message);
  if (saveOK && game.s?.moments.some(m => !m.seen)) nextMoment();
};
function showAdvanceNotice_evolution() {
  if (!game.s || !lastAdvanceNotice) return;
  if (!saveOK) {
    modal('저장 확인 필요', progressSummaryContent() + btn('설정·백업', 'settings', '', 'primary'));
    return;
  }
  if (game.s.moments.some(m => !m.seen)) return nextMoment();
  const result = game.s.outcomes.filter(o => o.day > lastAdvanceNotice.from && o.day <= lastAdvanceNotice.to).at(- 1);
  if (result) return modal('활동을 마쳤습니다', outcomeHTML(result) + btn('계속', 'close', '', 'primary'));
  if (game.pending.length) return modal('확인할 소식이 있습니다', progressSummaryContent() + btn('수신함 확인', 'nav', 'data-page="inbox"', 'primary'));
  toast((lastAdvanceNotice.to - lastAdvanceNotice.from) + '일 진행 완료 · 활동 결과와 수신함을 확인하세요.');
};
const evolutionManagementClick = managementClick_operations;
function managementClick_evolution(action, d) {
  switch (action) {
    case 'm-goal-filter': goalView = ['all', 'progress', 'done'].includes(d.filter) ? d.filter: 'all';
    render();
    return;
    case 'm-skip-moments': game.s.moments.forEach(m => m.seen = true);
    save();
    close();
    render();
    return;
    case 'm-memory': {
      const a = game.talent(Number(d.id)) || game.s.departed.find(x => x.id === Number(d.id));
      if (!a) throw Error('인물 기록이 없습니다.');
      return modal(DATA.roster[a.id].name + ' · 함께한 기록', portraitsStrip([a.id], 'story-portrait') + a.memories.slice().reverse().map(m => `<article class="contract-row"><small>${date(m.day,true)}</small><p>${esc(m.text)}</p></article>`).join(''));
    }
    case 'm-story': return storyModal(d.id);
    case 'm-story-choice': return mutate(() => game.resolveStory(d.id, d.choice), '대화를 기록했습니다.');
    case 'm-moment': return momentModal(d.id);
    case 'm-next-moment': return nextMoment();
    case 'm-moments': return modal('함께 만든 순간', game.s.moments.slice().reverse().map(m => `<article class="contract-row"><h3>${esc(m.title)}</h3><small>${date(m.day,true)}</small>${btn('다시 보기','m-moment',`data-id="${m.id}"`,'soft')}</article>`).join('') || '<p>첫 순간을 기다리고 있습니다.</p>');
    case 'm-offer': return offerModal(d.id);
    case 'm-offer-accept': return mutate(() => game.acceptOffer(d.id, d.key), '특별 활동을 승인했습니다.');
    case 'm-all-tasks': return modal('오늘의 전체 할 일', todayTasks().map(t => btn(esc(t.label), t.action, t.args, 'task-button')).join(''));
    case 'm-sound': game.s.soundEnabled = !game.s.soundEnabled;
    save();
    settings();
    if (game.s.soundEnabled) momentTone();
    return;
    default: throw Error("처리할 수 없는 동작입니다.");
  }
};
UIEvents.onChange('evolution', ev => {
  try {
    const t = ev.target;
    if (t.id === 'spotlight-select') {
      game.s.pinnedEntity = t.value || null;
      save();
      render();
    }
    if (t.closest?.('#unit-form') && t.name === 'members') {
      const ids = [...(document.querySelectorAll?.('#unit-form input[name="members"]:checked') ||[])].map(x => Number(x.value)),
      e = { key: 'preview', type: DATA.roster[ids[0]]?.type || 'idol', members: ids.map(id => game.artist(id)) };
      $('#team-composition').innerHTML = ids.length >= 2 ? teamSummary(e): '<p>멤버2명 이상을 선택하세요.</p>';
    }
  } catch (e) {
    toast(e.message);
  }
});


;
/* FILE src/campaign-ui.js */
'use strict';
let inboxView = 'all', inboxCategory = 'all';
function reportBadge(r) {
  const state = game.reportState(r);
  return `<span class="pill report-${state.status}">${esc(state.status==='info'?'일반 보고':state.label)}</span> <span class="read-label">${r.read?'읽음':'● 안 읽음'}</span>${state.expires!==undefined?` <small>기한 ${date(state.expires)}</small>`:''}`;
}
function inbox_campaign() {
  const counts = game.inboxCounts(),
  selected = game.s.reports.find(r => r.id === selectedReport);
  const rows = game.s.reports.filter(r =>(inboxView === 'all' || inboxView === 'unread' && !r.read || inboxView === 'decision' && game.reportState(r).needsDecision) &&(inboxCategory === 'all' || game.reportCategory(r) === inboxCategory)).sort((a, b) => Number(game.reportState(b).needsDecision) - Number(game.reportState(a).needsDecision) || b.day - a.day || b.id - a.id);
  const row = r => btn(`<small>${date(r.day)} · ${reportBadge(r)}</small><strong>${esc(r.title)}</strong>`, 'open-report', `data-id="${r.id}"`, `${r.id===selectedReport?'selected ':''}${!r.read?'unread ':''}${game.reportState(r).needsDecision?'decision-row':''}`);
  const groups = new Map();
  for (const r of rows) {
    const key = game.reportState(r).status === 'info' && !r.important ? r.day: 'r' + r.id;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(r);
  }
  return heading('수신함', `안 읽음 ${counts.unread}건 · 결정 필요 ${counts.decision}건. 읽음 여부와 처리 상태를 별도로 표시합니다.`, btn('일반 보고 모두 읽음', 'read-info', '', 'soft')) + `<div class="tabs">${[['all','전체'],['unread','안 읽음'],['decision','결정 필요']].map(([v,t])=>btn(t,'m-inbox-filter',`data-value="${v}"`,inboxView===v?'active':'')).join('')}</div><div class="tabs section">${[['all','모든 분야'],['training','육성'],['activity','활동'],['finance','재정'],['general','운영']].map(([v,t])=>btn(t,'m-inbox-category',`data-value="${v}"`,inboxCategory===v?'active':'')).join('')}</div><div class="inbox"><section class="panel inbox-list" style="padding:0">${[...groups.values()].map(rs=>rs.length>=3?`<details ${rs.some(r=>r.id===selectedReport)?'open':''}><summary>${date(rs[0].day)} 일반 보고 ${rs.length}건 · 안 읽음 ${rs.filter(r=>!r.read).length}건</summary>${rs.map(row).join('')}</details>`:rs.map(row).join('')).join('')||'<p>조건에 맞는 보고가 없습니다.</p>'}</section><section class="panel inbox-detail">${selected?reportDetail(selected):'<p>보고를 선택하세요.</p>'}</section></div>`;
}
function reportDetail_campaign(r) {
  let body;
  if (r.kind === 'ad') {
    const p = game.adPlan(r.id),
    active = game.reportState(r).needsDecision;
    body = `<h2>${esc(r.title)}</h2><p class="report-content">${esc(r.body)}</p>${active?`<section class="tip"><h3>광고 수락 시 변경</h3><p>촬영 ${p.days}일 · 완료 ${date(p.shootingDay)} · 잔금 입금 ${date(p.paymentDay)}</p><p>계약 총액 ${money(p.pay)} · 선금 40% ${money(p.advance)} · 잔금 60% ${money(p.balance)}. 아티스트 약정 배분을 차감합니다.</p>${p.productions.map(j=>`<p><strong>${esc(j.title)}</strong><br>완료 ${date(j.oldDue)} → ${date(j.newDue)} (+${j.newDue-j.oldDue}일) · 예약 행사 반영<br>제작 잔여 ${j.remaining}일 보존 · 촬영 후 재개</p>`).join('')||'<p>변경되는 제작 일정 없음</p>'}${p.reasons.map(x=>`<p class="negative">${esc(x)}</p>`).join('')}</section><div class="row wrap">${btn('광고 수락','resolve',`data-id="${r.id}" data-choice="accept"`,'primary',!p.allowed)}${btn('제안 거절','resolve',`data-id="${r.id}" data-choice="decline"`)}</div>`:''}`;
  } else body = reportDetail_evolution(['done', 'expired'].includes(game.reportState(r).status) ? { ... r, resolved: true }: r);
  return `<div class="row between">${reportBadge(r)}${btn(r.read?'안 읽음으로 표시':'읽음으로 표시','m-report-unread',`data-id="${r.id}" data-read="${r.read?'false':'true'}"`,'soft small')}</div>` + body;
}
function projects_campaign() {
  return projects_app().replace('동일 아티스트는 한 번에 하나의 프로젝트·광고를 진행할 수 있습니다.', '제작 중 광고를 수락하면 해당 제작을 촬영 기간만큼 중단하고 완료일을 늦춥니다.') + panel('제작 일정 상세', game.s.jobs.filter(j => j.kind === 'single').map(j => {
    const p = game.productionState(j);
    return `<p><strong>${esc(j.name)}</strong> · ${p.paused?game.productionState(j).reason+'으로 중단 · '+date(p.resume)+' 재개':'제작 진행 중'}<br>실제 제작 잔여 ${p.remaining}일 · 누적 연장 ${p.delay}일 · 완료 ${date(j.due)}</p>`;
  }).join('') || '<p>진행 중인 제작 없음</p>');
}
function finance_campaign() {
  const p = game.cashPlan();
  return finance_operations() + panel('향후 30일 자금 계획', `<p>현재 잔액 ${money(game.s.cash)} + 확정 입금 ${money(p.confirmed)} − 예정 지출 ${money(p.scheduled)} − 유지 훈련비 추정 ${money(p.maintenance)}</p><p><strong>보수적 예상 잔액 ${money(p.balance)}</strong></p><p>별도 조건부·예상 입금 ${money(p.conditional)} (예상 잔액에서 제외)</p><small>현재 훈련 방침을 30일 유지하는 추정입니다. 회복·일정·직원·인원 변경에 따라 달라집니다. 신규 승인·확률 사건은 포함하지 않습니다.</small>`);
}
function budgetPreview_campaign() {
  budgetPreview_evolution();
  const key = $('#entity')?.value || game.entities[0]?.key;
  if (!key) return;
  const a = game.activityAvailability(key);
  $('#budget-preview').innerHTML += `<p class="${a.allowed?'positive':'negative'}">${a.allowed?'일정 승인 가능':a.reasons.map(esc).join(' · ')}</p>`;
  const submit = $('#project-form button[type="submit"]');
  if (submit) submit.disabled = !a.allowed;
}
function staffDetail_campaign(id) {
  staffDetail_evolution(id);
  const x = game.staffComparison(id);
  $('#modal-error').insertAdjacentHTML('beforebegin', `<section class="panel"><h3>현재 직원과 비교</h3><p>후보 ${esc(x.candidate.name)} · 지도 ${x.candidate.coaching} · 월급 ${money(x.candidate.salary)}</p><p>${x.current?'현재 최고 '+esc(x.current.name)+' · 지도 '+x.current.coaching+' · 월급 '+money(x.current.salary):'같은 직무의 기존 직원 없음'}</p></section>`);
}
function managementClick_campaign(action, d) {
  if (action === 'm-inbox-filter') inboxView = d.value;
  else if (action === 'm-inbox-category') inboxCategory = d.value;
  else if (action === 'm-report-unread') {
    mutate(() => game.setReportRead(d.id, d.read === 'true'));
    return;
  }
  render();
}


;
/* FILE src/season-ui.js */
'use strict';
let chartScope = 'all', chartLimit = 20;
function charts_season() {
  const global = game.charts(chartMetric),
  ranks = new Map(global.map((r, i) => [r.release.market.uid, i + 1])),
  rows = chartScope === 'all' ? global: global.filter(r => !r.external),
  own = global.map((r, i) =>({ ... r, rank: i + 1 })).filter(r => r.own);
  return heading('전체 음악 시장 차트', '최근 7일 집계 · 지난 확정 주 대비 등락 · 매주 최고 순위 기록 · 외부 아티스트를 포함한 가상 음악 시장입니다.', btn('연말 시상식', 'm-awards', '', 'soft')) + `<div class="tabs">${btn('주간 스트리밍','m-chart','data-metric="streams"',chartMetric==='streams'?'active':'')}${btn('주간 음반 판매','m-chart','data-metric="sales"',chartMetric==='sales'?'active':'')}</div><div class="tabs section">${[['all','전체 시장'],['labels','우리·라이벌']].map(([k,n])=>btn(n,'m-chart-scope',`data-scope="${k}"`,chartScope===k?'active':'')).join('')}</div>` + panel('우리 작품의 전체 시장 순위', own.map(r => `<p><strong>${r.rank}위${r.rank>100?' · TOP 100 밖':''}</strong> · ${esc(r.release.name)} · ${r.week[chartMetric].toLocaleString()}${chartMetric==='streams'?'회':'장'}</p>`).join('') || '<p>최근 7일 집계된 우리 작품이 없습니다.</p>') + panel('TOP 100 · ' +(chartScope === 'all' ? '전체 시장': '참여 레이블'), rows.slice(0, Math.min(100, chartLimit)).map((r, index) => {
    const h = game.chartPosition(r.release.market.uid, chartMetric, ranks),
    change = h.previous === null ? '신규': h.previous === h.rank ? '유지': h.previous > h.rank ? '▲ ' +(h.previous - h.rank): '▼ ' +(h.rank - h.previous);
    return `<article class="chart-row"><strong class="rank">${index+1}</strong><div class="spacer"><h3>${esc(r.release.name)} ${r.own?'<span class="pill">우리</span>':''}</h3><small>${esc(r.release.market.artistName)} · ${esc(r.company)}</small><p>${r.week[chartMetric].toLocaleString()}${chartMetric==='streams'?'회':'장'} · ${change}${h.best?' · 확정 주간 최고 '+h.best+'위':''}${chartScope==='labels'&&h.rank?' · 전체 '+h.rank+'위':''}</p>${btn('성과 보기','m-release',`data-uid="${r.release.market.uid}"`,'link small')}</div></article>`;
  }).join('') || '<p>최근 집계 없음</p>') +(chartLimit < 100 && rows.length > chartLimit ? btn('20위 더 보기', 'm-chart-more', '', 'soft'): '');
}
function reportDetail_season(r) {
  if (r.festivalOfferId) {
    const o = game.s.festivalOffers.find(o => o.id === r.festivalOfferId),
    p = game.festivalPlan(r.festivalOfferId),
    state = game.reportState(r);
    return `<div class="row between">${reportBadge(r)}${btn(r.read?'안 읽음으로 표시':'읽음으로 표시','m-report-unread',`data-id="${r.id}" data-read="${!r.read}"`,'soft small')}</div><h2>${esc(r.title)}</h2><p>${esc(r.body)}</p>${o?`<section class="tip"><p><strong>행사 ${date(o.day,true)}</strong> · 준비·출연 ${p.duration}일</p><p>준비 시작 ${date(p.start)} · 행사 완료일 지급<br>출연료 ${money(p.pay)} − 약정 배분·출연비 → <strong>회사 실수령 ${money(p.net)}</strong></p><p>출연비는 ${money(p.cost)}이며 행사 완료일에 차감합니다.</p>${p.productions.map(j=>`<p>${esc(j.title)} · 완료 ${date(j.oldDue)} → ${date(j.newDue)} (+${j.newDue-j.oldDue}일) · 예약 행사 반영</p>`).join('')}<small>수락일부터 준비 시작 전까지 제작은 계속됩니다. 준비·출연 구간에만 제작을 중단합니다. 출연 후 2일간 새 활동을 잡지 않습니다.</small></section>`:''}${state.needsDecision?`<p>${p.reasons.map(esc).join(' · ')}</p><div class="row wrap">${btn('출연 수락','m-festival',`data-id="${r.festivalOfferId}" data-choice="accept"`,'primary',!p.allowed)}${btn('섭외 거절','m-festival',`data-id="${r.festivalOfferId}" data-choice="decline"`)}</div>`:''}`;
  }
  if (r.festivalResultId) {
    const record = game.s.festivalHistory.find(e => e.id === r.festivalResultId);
    return reportDetail_campaign(r) + (record ? activityStatementHTML(festivalStatement(record)): '');
  }
  if (r.awardYear) return awardHTML(r.awardYear);
  return reportDetail_campaign(r);
}
function awardHTML(year) {
  const a = game.s.awardHistory.find(a => a.year === Number(year));
  if (!a) return '<p>아직 후보 발표 전입니다. 12월 1일 후보를 확정하고, 선정된 후보의 12월 28일까지 기록으로 수상자를 평가합니다.</p>';
  return `<section class="award-hero"><span class="eyebrow">NEXT MUSIC AWARDS</span><h2>${a.year}년 ${a.resultDay===null?'후보 발표':'시상 결과'}</h2><p>올해의 음악과 무대를 함께 돌아봅니다. 12월 초 후보 발표 · 12월 28일 시상.</p></section><details class="tip"><summary>집계 기간·후보 선정 기준</summary><p>후보는 ${date(a.nominationDay,true)}까지 집계한 기록으로 확정합니다. 발표 뒤 새 작품·인물은 후보에 추가하지 않습니다.</p><p>수상 평가는 확정 후보의 기록을 ${a.resultDay===null?a.year+'년 12월 28일':date(a.resultDay,true)}까지 반영합니다. 신인상은 기록된 데뷔 연도가 시상 연도인 대상입니다.</p></details>${a.categories.map(c=>`<section class="panel section"><h3>${SEASON_DATA.awards[c.key]}</h3>${c.winner?`<p class="award-winner">🏆 ${esc(c.winner.name)}${c.key==='song'?' · '+esc(c.winner.artist):''}${c.winner.own?' · 우리 회사':''}</p>${c.winner.own?'<p>인지도·회사 평판 및 수상 이력 반영. “함께해 주신 분들 덕분이에요.”</p>':''}`:'<p>'+(a.resultDay===null?'12월 28일 수상 발표':'해당 후보 없음')+'</p>'}<details ${a.resultDay===null?'open':''}><summary>후보 ${c.nominees.length}명·작품</summary>${c.nominees.map(n=>`<p>${esc(n.name)}${c.key==='song'?' · '+esc(n.artist):''}${n.own?' · 우리 회사':''}</p>`).join('')||'<p>조건을 충족한 기록 없음</p>'}<small>${c.key==='live'?'실제 관객·무대 반응':c.key==='rookie'?'데뷔 첫해 판매·재생·무대 성과':'해당 연도 판매·재생과 활동 성과'}로 후보에 선정됐습니다.</small></details></section>`).join('')}${a.summary?`<p>시상일까지 우리 회사 기록: 재생 ${a.summary.streams.toLocaleString()}회 · 음반 ${a.summary.sales.toLocaleString()}장 · 무대 ${a.summary.live}회</p>`:''}<small>집계 시작 ${date(Math.max(game.s.seasonSince,Math.round((Date.UTC(a.year,0,1)-Date.UTC(2027,0,1))/86400000)),true)}. 과거 누락 기록은 소급 생성하지 않습니다. 상금·별도 준비 과제 없음.</small>`;
}
function releaseModal_season(uid) {
  if (!uid.startsWith('x-')) {
    releaseModal_evolution(uid);
    const c = game.s.catalog.find(c => c.market.uid === uid);
    if (c) {
      const m = c.market,
      invest = m.production + m.manufacturing,
      paid = m.paid - m.payout;
      $('#modal-error').insertAdjacentHTML('beforebegin', `<section class="tip"><strong>총투자금 ${money(invest)} · 회사 누적 회수 ${money(paid)}</strong><p>${m.legacy?'이전 작품 · 과거 전체 투자금 회수 여부는 판정하지 않습니다.':paid>=invest?'투자금 회수 완료':'투자금 회수 중'}</p><small>제작·홍보·제조비 포함. 일 훈련·고정비는 별도.</small></section>`);
    }
    return;
  }
  const r = game.globalReleases().find(r => r.release.market.uid === uid);
  if (!r) throw Error('현재 집계 중인 외부 작품이 아닙니다.');
  const w = r.release.market.days.filter(d => d.day > game.s.day - 7).reduce((n, d) =>({ streams: n.streams + d.streams, sales: n.sales + d.sales }), { streams: 0, sales: 0 });
  modal(r.release.name, `<p>${esc(r.release.market.artistName)} · ${esc(r.company)}</p><p>발매 ${date(r.release.market.startDay,true)}</p><p>최근 7일 스트리밍 ${w.streams.toLocaleString()}회 · 음반 ${w.sales.toLocaleString()}장</p><small>외부 시장 아티스트입니다. 내부 원가·계약·수입은 공개하지 않습니다.</small>`);
}
function projects_season() {
  return projects_campaign() + panel('확정 행사', game.s.engagements.map(e => `<article class="contract-row"><span class="pill">${game.s.day>=e.start?'준비·출연 중':'출연 예약'}</span><h3>${esc(e.name)}</h3><p>${esc(e.snapshot.name)} · 행사 ${date(e.due)} · 준비 ${date(e.start)} 시작</p><small>준비·출연 ${e.due-e.start}일 · 확정 멤버·배분 유지</small></article>`).join('') || '<p>확정된 행사 없음 · 섭외는 수신함으로 도착합니다.</p>') + panel('최근 행사 결과', game.s.festivalHistory.slice(- 3).reverse().map(e => `<details><summary>${esc(e.artist)} · ${esc(e.name)} · 회사 ${money(e.net)}</summary><p>새로운 팬 +${e.fans}명</p>${activityStatementHTML(festivalStatement(e))}</details>`).join('') || '<p>아직 출연 기록이 없습니다.</p>');
}
function scheduleEvents_season() {
  const rows = scheduleEvents_operations();
  for (const e of game.s.engagements) rows.push({
    id: 'festival-' + e.id,
    start: e.start,
    end: e.due,
    title: e.name + ' · ' + e.snapshot.name,
    kind: 'live',
    body: `준비 ${date(e.start)}~출연 ${date(e.due)} · 출연료 ${money(e.pay)} (약정 배분·출연비 차감) · 준비 구간에만 제작 중단`,
    page: 'projects'
  });
  const year = game.s.seasonYear;
  for (const[month, day, name] of[[11, 1, '연말 시상식 후보 발표'], [11, 28, 'NEXT MUSIC AWARDS']]) {
    const dateDay = Math.round((Date.UTC(year, month, day) - Date.UTC(2027, 0, 1)) / 86400000);
    rows.push({
      id: 'awards-' + year + '-' + day,
      start: dateDay,
      end: dateDay,
      title: name,
      kind: 'award',
      body: '평소 활동 기록으로 자동 평가합니다. 별도 준비 일정은 없습니다.',
      page: 'charts'
    });
  }
  return rows;
}
function todayTasks_season() {
  return todayTasks_evolution().concat(game.s.reports.filter(r => r.festivalOfferId && game.reportState(r).needsDecision || r.awardYear && !r.read || r.festivalResultId && !r.read).map(r =>({
    priority: 2,
    label: r.title,
    action: 'report',
    args: `data-id="${r.id}"`
  }))).sort((a, b) => a.priority - b.priority);
}
function budgetPreview_season() {
  budgetPreview_campaign();
  const key = $('#entity')?.value || game.entities[0]?.key,
  e = game.entity(key);
  if (e) {
    const planned = game.s.engagements.filter(x => x.snapshot.ids.some(id => e.members.some(a => a.id === id)));
    const kind = $('#project-kind')?.value || 'single',
    availability = game.projectAvailability(key, kind),
    submit = $('#project-form button[type="submit"]');
    if (submit) submit.disabled = !availability.allowed;
    if (!availability.allowed) $('#budget-preview').innerHTML += `<p class="negative">${availability.reasons.map(esc).join(' · ')}</p>`;
    if (kind === 'single' && planned.length) {
      const due = game.productionPreview(key, $('#promotion')?.value || 'none').due;
      $('#budget-preview').innerHTML += `<p><strong>행사 반영 예상 완료 ${date(due)}</strong></p>`;
    }
    if (planned.length) $('#budget-preview').innerHTML += `<p>확정 행사: ${planned.map(x=>esc(x.name)+' '+date(x.start)+'~'+date(x.due)).join(' · ')}. 싱글은 겹치는 준비 기간만큼 완료일이 연장됩니다.</p>`;
  }
}
function managementClick_season(action, d) {
  if (action === 'm-festival') return mutate(() => game.resolveFestival(d.id, d.choice), '행사 섭외를 처리했습니다.');
  if (action === 'm-chart-scope') {
    chartScope = d.scope;
    chartLimit = 20;
  } else if (action === 'm-chart-more') chartLimit = Math.min(100, chartLimit + 20);
  else if (action === 'm-awards') {
    const years = game.s.awardHistory.slice().reverse();
    modal('연말 음악 시상식', `<div class="row wrap">${years.map(a=>btn(a.year+'년','m-award-year',`data-year="${a.year}"`,'soft')).join('')}</div>` + awardHTML(years[0]?.year));
    return;
  } else if (action === 'm-award-year') {
    modal('연말 음악 시상식', awardHTML(Number(d.year)));
    return;
  }
  render();
}


;
/* FILE src/concept-ui.js */
'use strict';
let developmentId = null, developmentTab = 'training';
const developmentLabels = {balanced:'균형',vocal:'보컬',performance:'무대',creative:'창작',rest:'휴식'};
function openDevelopment(id) {
  game.ownedTalent(id); developmentId=Number(id);developmentTab='training';navigate('development');
}
function artistModal_concept(id,candidate=false) { return candidate?talentModal(id):openDevelopment(id); }
function traineeDetail_concept(id) { openDevelopment(id); }
function countdownHTML(a) {
  const mark=game.developmentCountdown(a);
  if(!mark)return `<span class="countdown-label">목표 일정을 지정해 보세요</span>`;
  const label={debut:'데뷔',live:'공연',single:'발매'}[mark.kind],left=mark.day-game.s.day;
  return `<span class="countdown-label">${label}${mark.completedDay!==null?' 완료':mark.confirmed?' · 확정 일정':' · 목표일'}</span><strong>${mark.completedDay!==null?'달성':left>0?left+'일':left===0?'오늘':Math.abs(left)+'일 지남'}</strong><small>${date(mark.completedDay??mark.day)}${!mark.confirmed&&mark.completedDay===null?' · 일정 예약 아님':''}</small>`;
}
function forecastModal() {
  const f=game.monthlyOperatingForecast();
  modal('월 예상 영업손익',`<p>${date(f.from)} ~ ${date(f.to)} · 향후 30일</p><div class="forecast-breakdown"><p>예상 영업 수입 <strong>${money(f.revenue)}</strong></p><p>예상 영업 지출 <strong>${money(f.expense)}</strong></p><p>예상 영업손익 <strong class="${f.profit<0?'negative':'positive'}">${f.profit>0?'+':''}${money(f.profit)}</strong></p><p>참고 · 예상 현금 증감 <strong>${money(f.cashChange)}</strong></p></div><p>현재 소속 인물·훈련 계획·확정 활동을 유지한 별도 30일 시뮬레이션입니다. 실제 진행과 난수 상태는 바꾸지 않습니다.</p><p>대출 실행·원금 상환·이자·회생 지원은 영업손익에서 제외합니다. 게임 거래 기준으로 이미 지출한 제작비는 재차 차감하지 않습니다. 신규 계약·신규 활동·앞으로의 선택은 반영하지 않으므로 실제 결과와 달라질 수 있습니다.</p>`,true);
}
function home_concept() {
  const s=game.s,tasks=todayTasks(),people=[...s.artists,...s.trainees];
  const events=scheduleEvents().filter(e=>e.end>=s.day&&e.start<=s.day+7).sort((a,b)=>Math.max(a.start,s.day)-Math.max(b.start,s.day));
  const forecast=running&&game._developmentForecast?game._developmentForecast.value:game.monthlyOperatingForecast();
  return `<div class="concept-home"><div class="concept-page-title"><h1>기획사 경영</h1><p>좋은 오늘이, 더 멋진 내일의 무대를 만듭니다.</p></div>
  <section class="concept-agency-scene" aria-label="기획사 사무실"><img src="assets/agency-manager-v1.webp" alt="따뜻한 기획사 사무실에서 태블릿을 들고 있는 운영 매니저"><div><small>${date(s.day,true)}</small><h2>오늘도, 다음 무대를 향해.</h2><p>좋은 음악, 좋은 사람이 모여<br>특별한 이야기가 시작되는 곳.</p><span>${esc(s.company)} · ${esc(DATA.stageNames[game.stage])}</span></div></section>
  <section class="concept-summary" aria-label="핵심 경영 지표">
  ${btn(`${ico('wallet')}<span><small>보유 자금</small><strong>${money(s.cash)}</strong></span>${ico('arrow')}`,'nav','data-page="finance"','concept-summary-card')}
  ${btn(`${ico('chart')}<span><small>월 예상 영업손익 · ${running?'진행 후 갱신':'향후 30일'}</small><strong class="${forecast.profit<0?'negative':'positive'}">${forecast.profit>0?'+':''}${money(forecast.profit)}</strong></span>${ico('arrow')}`,'m-month-forecast','','concept-summary-card')}
  ${btn(`${ico('people')}<span><small>소속 아티스트</small><strong>${s.artists.length}명 <em>· 연습생 ${s.trainees.length}명</em></strong></span>${ico('arrow')}`,'nav','data-page="artists"','concept-summary-card')}
  </section><div class="concept-desk">
  <section class="panel concept-task-panel"><div class="concept-section-heading"><h2>오늘의 주요 업무</h2><small>${tasks.length}건 확인 필요</small></div><div>${tasks.slice(0,5).map(t=>btn(`<span class="concept-check">${t.priority===0?'!':'↗'}</span><strong>${esc(t.label)}</strong><span class="concept-status ${t.priority===0?'urgent':''}">${t.priority===0?'우선 확인':'확인'}</span>`,t.action,t.args,'concept-task')).join('')||'<div class="concept-calm">급한 업무를 모두 확인했어요.<br>다음 무대를 준비해 보세요.</div>'}</div>${tasks.length>5?btn('전체 업무 보기','m-all-tasks','','link small'):''}</section>
  <section class="panel concept-agenda"><div class="concept-section-heading"><h2>다가오는 일정</h2>${btn('전체 일정','nav','data-page="schedule"','link small')}</div>${events.slice(0,5).map(e=>btn(`<time>${e.start<=s.day?'진행 중':'D-'+(e.start-s.day)}</time><strong>${esc(e.title)}</strong><small>${date(Math.max(s.day,e.start))}</small>`,'nav',`data-page="${e.page}"`,'concept-event')).join('')||'<div class="concept-calm">등록된 주요 일정이 없습니다.<br>날짜별 일정은 전체 일정에서 확인하세요.</div>'}</section>
  </div><section class="panel concept-roster"><div class="concept-section-heading"><h2>소속 아티스트</h2>${btn('전체 보기','nav',`data-page="${s.artists.length?'artists':'training'}"`,'link small')}</div><div class="concept-roster-bottom"><div class="concept-roster-cards">${people.slice(0,3).map(a=>{const d=DATA.roster[a.id],trainee=s.trainees.includes(a);return btn(`<div class="concept-thumb"><img src="${d.image}" alt="" loading="lazy"></div><span><strong>${esc(d.name)}</strong><small>${trainee?'연습생':DATA.labels[d.type]} · ${d.position}</small><span class="concept-energy ${a.energy<40?'low':''}">컨디션 ${a.energy<40?'회복 필요':a.energy<70?'보통':'좋음'}</span><span class="bar"><span style="width:${Math.max(0,Math.min(100,a.energy))}%"></span></span></span>`,'m-development',`data-id="${a.id}"`,'concept-person');}).join('')||`<div class="concept-calm">우리의 첫 인재를 기다리고 있어요.${btn('인재 모집 시작','casting-modal','','soft')}</div>`}</div></div></section>
  <details class="concept-more studio-archive" ${studioArchiveOpen?'open':''}><summary>가이드·경영 계획·함께한 기록</summary>${!s.guideHidden?guideCard():''}<div class="row wrap section">${btn('캐스팅','nav','data-page="casting"','soft')}${btn('활동 준비','project-modal','','soft',!s.artists.length)}${btn('개인 육성','nav','data-page="development"','soft',!people.length)}${btn('영업손익 산출 기준','m-month-forecast','','soft')}</div>${spotlight()}${recentWeekHTML()}${panel('우리의 최근 순간',s.moments.slice(-3).reverse().map(m=>`<p>${esc(m.title)} ${btn('다시 보기','m-moment',`data-id="${m.id}"`,'link small')}</p>`).join('')||'<p>첫 계약부터 우리의 기록이 쌓입니다.</p>')}${panel('최근 발매',s.catalog.slice(-3).reverse().map(c=>releaseRow({release:c,company:s.company,own:true})).join('')||'<p>첫 음악을 기다리고 있습니다.</p>')}</details></div>`;
}
function developmentScreen() {
  const people=[...game.s.artists,...game.s.trainees];
  const a=people.find(p=>p.id===developmentId)||people[0];
  if(!a)return heading('아티스트 육성','함께 성장할 인재를 먼저 만나보세요.',btn('인재 모집','casting-modal','','primary'))+'<div class="empty">영입한 아티스트와 연습생을 이곳에서 육성할 수 있습니다.</div>';
  developmentId=a.id;
  const d=DATA.roster[a.id],trainee=game.s.trainees.includes(a),target=a.growthTarget;
  const selected=a.weeklyPlan||Array(7).fill(trainee?a.trainingPlan:{balanced:'balanced',creative:'creative',stage:'performance',rest:'rest'}[a.focus]);
  const weekStart=game.s.day-DevelopmentWeekday(game.s.day),current=DevelopmentWeekday(game.s.day);
  const weekDate=day=>new Date(Date.UTC(2027,0,1+day));
  const dateInput=day=>weekDate(day).toISOString().slice(0,10);
  const defaultMark=a.milestone||{kind:trainee?'debut':'live',day:Math.max(game.s.day+14,trainee?a.signed+90:0)};
  return `<div class="development-page"><div class="concept-page-title"><h1>아티스트 육성</h1><p>지금의 노력이, 언젠가 가장 빛나는 무대가 됩니다.</p>${btn('아티스트 목록으로','nav',`data-page="${trainee?'training':'artists'}"`,'link small')}</div>
  <div class="development-picker"><label for="development-person">다른 아티스트 보기</label><select id="development-person">${people.map(p=>`<option value="${p.id}" ${p.id===a.id?'selected':''}>${esc(DATA.roster[p.id].name)} · ${game.s.trainees.includes(p)?'연습생':'아티스트'}</option>`).join('')}</select></div>
  <section class="development-overview"><div class="development-portrait"><img src="${d.image}" alt="${esc(d.name)}의 전체 초상화"></div><div class="development-info"><h2>${esc(d.name)} <small>· ${trainee?'데뷔를 준비하는 '+d.position:d.position+' 아티스트'}</small></h2><p class="development-quote">“${esc(game.trainingReaction(a.id))}”</p><nav class="development-tabs" aria-label="아티스트 정보">${[['profile','프로필'],['training','육성'],['story','스토리']].map(([key,label])=>btn(label,'m-development-tab',`data-tab="${key}"`,developmentTab===key?'active':'')).join('')}</nav>
  ${developmentTab==='story'?`<div class="panel development-story">${personalityCard(a.id)}${memoriesHTML(a.id)}</div>`:`<div class="panel development-stats"><div class="concept-section-heading"><h3>성장 능력치</h3><small>현재 실력</small></div>${statsHTML(a.stats)}<div class="development-state"><div><span>컨디션</span><strong>${a.energy<40?'회복 필요':a.energy<70?'보통':'좋음'}</strong><small>체력 ${Math.round(a.energy)} · 스트레스 ${Math.round(a.stress)}</small></div><div><span>회사 신뢰</span><strong>${Math.round(a.trust)}</strong><small>함께 쌓아가는 관계</small></div><div><span>개인 팬</span><strong>${a.fans.toLocaleString()}명</strong><small>팀 팬과 별도 집계</small></div><div><span>대중 인지도</span><strong>${Math.round(a.fame)} / 100</strong><small>음악과 활동으로 성장</small></div></div></div>`}
  ${developmentTab==='profile'?`<div class="development-profile"><p>${esc(d.story)}</p><p>${d.age}세 · ${esc(d.traits)} · ${DATA.labels[d.type]}</p><p>계약 만료 ${date(a.contract,true)}</p>${btn(trainee?'데뷔 계약 검토':'활동 준비',trainee?'m-debut':'project-modal',trainee?`data-id="${a.id}"`:`data-entity="${game.entities.find(e=>e.members.some(p=>p.id===a.id))?.key||a.id}"`,'primary')}</div>`:''}
  </div></section>
  ${developmentTab==='training'?`<div class="development-training"><section class="panel weekly-training"><div class="concept-section-heading"><h2>주간 훈련 계획</h2><span>${date(weekStart)} ~ ${date(weekStart+6)}</span></div><p class="development-note">월~일 반복 계획 · 오늘은 ${['월','화','수','목','금','토','일'][current]}요일입니다. 적용 후 다음 날짜 진행부터 반영됩니다.</p><form id="weekly-plan-form" data-person="${a.id}"><div class="weekly-scroll"><table class="weekly-grid"><thead><tr><th scope="col">훈련</th>${['월','화','수','목','금','토','일'].map((day,i)=>`<th scope="col" class="${i===current?'today':''}">${day}<small>${date(weekStart+i)}</small></th>`).join('')}</tr></thead><tbody>${Object.entries(developmentLabels).map(([key,label])=>`<tr><th scope="row">${label}</th>${selected.map((value,i)=>`<td class="${i===current?'today':''}"><label class="weekly-choice"><input type="radio" name="plan-${i}" value="${key}" ${value===key?'checked':''} aria-label="${['월','화','수','목','금','토','일'][i]}요일 ${label}" required><span aria-hidden="true">✓</span></label></td>`).join('')}</tr>`).join('')}</tbody></table></div><p class="weekly-scroll-hint">표를 좌우로 움직여 월~일 계획을 확인하세요.</p><div class="weekly-actions"><span>${a.weeklyPlan?'주간 계획 적용 중':'기존 훈련 방식으로 진행 중'}</span>${btn('반복 계획 해제','m-weekly-clear',`data-id="${a.id}"`,'link small',!a.weeklyPlan)}<button type="submit" class="primary">훈련 계획 적용 ${ico('arrow')}</button></div></form><details class="training-explainer"><summary>훈련별 효과와 비용</summary>${Object.entries(Game.trainingPlans).map(([key,plan])=>`<p><strong>${developmentLabels[key]}</strong> · ${plan.indexes.length?plan.indexes.map(i=>DATA.specs[i]).join('·'):'컨디션 회복'} · ${trainee?'훈련일 ' + money(plan.cost*(game.coach(key).staff ? 0.8 : 1)):key==='rest'?'훈련비 없음':'훈련일 ' + money(game.has('trainer')?7:10)}</p>`).join('')}<p>연습생은 지정 능력을 훈련하며, 아티스트는 해당 능력 중 하나가 성장합니다. 휴식일에도 월 지원비·고정비는 유지됩니다.</p></details><p class="development-note">체력 부족·과도한 스트레스·훈련비 부족 시 기존 보호 규칙이 우선합니다. 아티스트는 확정 활동을 유지하며, 휴식일에도 이미 확정한 활동이 취소되지는 않습니다.</p></section>
  <aside class="development-goals"><section class="panel personal-goal"><h3>개인 육성 목표</h3>${target?`<strong>${DATA.specs[target.metric]} ${target.target} ${target.achievedDay!==null?'달성':'목표'}</strong><p>현재 ${a.stats[target.metric].toFixed(1)}${target.achievedDay!==null?' · '+date(target.achievedDay)+' 달성':''}</p><div class="bar"><span style="width:${Math.min(100,a.stats[target.metric]/target.target*100)}%"></span></div>`:'<p>이번 성장 목표를 정해 보세요.</p>'}<details class="target-editor"><summary>목표 설정·변경</summary><form id="personal-goal-form" data-person="${a.id}"><label for="goal-metric">목표 능력</label><select id="goal-metric" name="metric">${DATA.specs.map((name,i)=>`<option value="${i}" ${target?.metric===i?'selected':''}>${name}</option>`).join('')}</select><label for="goal-target">목표값</label><input id="goal-target" name="target" type="number" min="1" max="99" value="${target?.target||Math.min(99,Math.ceil(a.stats[0])+5)}" required><button type="submit" class="soft">목표 저장</button></form></details><small>훈련 계획은 별도로 적용하세요. 목표 도달 시 달성일·보고를 남기며 추가 보상은 없습니다.</small></section>
  <section class="panel personal-countdown">${countdownHTML(a)}<details class="target-editor"><summary>목표일 설정·변경</summary><form id="milestone-form" data-person="${a.id}"><label for="milestone-kind">목표 일정</label><select id="milestone-kind" name="kind">${(trainee?[['debut','데뷔']]:[['live','공연'],['single','발매']]).map(([key,label])=>`<option value="${key}" ${defaultMark.kind===key?'selected':''}>${label}</option>`).join('')}</select><label for="milestone-date">목표 날짜</label><input id="milestone-date" name="date" type="date" min="${dateInput(trainee?Math.max(game.s.day,a.signed+90):game.s.day)}" max="${dateInput(game.s.day+365)}" value="${dateInput(Math.max(defaultMark.day,game.s.day))}" required><button type="submit" class="soft">목표일 저장</button></form></details><small>목표일은 활동을 자동 예약하지 않습니다. 확정한 제작·공연 일정이 있으면 그 완료일을 우선 표시합니다.${trainee?' 데뷔는 입소 90일과 평균 능력 55 등 기존 조건을 충족해야 합니다.':''}</small></section></aside></div>
  <details class="development-legacy"><summary>기존 훈련 방식과 상세 성장 기록</summary>${trainee?`<label for="training-mode-${a.id}">기존 관리 방식 · 변경 시 주간 계획 해제</label><select id="training-mode-${a.id}" data-control-id="${a.id}"><option value="auto" ${a.trainingMode==='auto'?'selected':''}>직원 자동 관리</option><option value="manual" ${a.trainingMode==='manual'?'selected':''}>직접 훈련</option></select><label for="training-${a.id}">기본 훈련 계획</label><select id="training-${a.id}" data-training-id="${a.id}">${Object.entries(Game.trainingPlans).map(([key,p])=>`<option value="${key}" ${a.trainingPlan===key?'selected':''}>${p.name}</option>`).join('')}</select>${growthGraph(a)}${btn('데뷔 계약 검토','m-debut',`data-id="${a.id}"`,'primary')}`:`<label for="focus">기존 육성 방향 · 변경 시 주간 계획 해제</label><select id="focus" data-focus="${a.id}">${Object.entries(focusLabel).map(([key,label])=>`<option value="${key}" ${a.focus===key?'selected':''}>${label}</option>`).join('')}</select>${btn('다음 활동 준비','project-modal',`data-entity="${game.entities.find(e=>e.members.some(p=>p.id===a.id))?.key||a.id}"`,'primary')}`}</details>`:''}</div>`;
}
function managementClick_concept(action,data) {
  if(action==='m-development')return openDevelopment(data.id);
  if(action==='m-development-tab'){developmentTab=['profile','training','story'].includes(data.tab)?data.tab:'training';return render();}
  if(action==='m-month-forecast')return forecastModal();
  if(action==='m-weekly-clear'){checkSaveSession();game.transaction(()=>game.clearWeeklyPlan(data.id));const saved=save();render();toast(saved?'주간 계획을 해제하고 이전 훈련 방식으로 돌아갑니다.':'저장에 실패했습니다. 설정에서 JSON 백업을 내보내 주세요.');return;}
}
UIEvents.onChange('development',event=>{if(event.target.id==='development-person')openDevelopment(event.target.value);});
document.addEventListener('submit',event=>{
  const form=event.target;
  if(!['weekly-plan-form','personal-goal-form','milestone-form'].includes(form.id))return;
  event.preventDefault();const data=new FormData(form),id=Number(form.dataset.person);
  try{
    checkSaveSession();
    if(form.id==='weekly-plan-form')game.setWeeklyPlan(id,Array.from({length:7},(_,i)=>data.get('plan-'+i)));
    if(form.id==='personal-goal-form')game.setGrowthTarget(id,data.get('metric'),data.get('target'));
    if(form.id==='milestone-form'){const day=(Date.parse(data.get('date')+'T00:00:00Z')-Date.UTC(2027,0,1))/86400000;game.setMilestone(id,data.get('kind'),day);}
    const saved=save();render();toast(saved?'변경 내용을 저장했습니다.':'저장에 실패했습니다. 설정에서 JSON 백업을 내보내 주세요.');
  }catch(error){toast(error.message);}
});

;
/* Activity screens share jobs, outcomes, reports and the existing calendar. */
'use strict';
function activityHeading(title,desc){return heading(title,desc,btn('통합 일정','nav','data-page="schedule"','soft'));}
function activityTypeLabel(x){return x.albumType?ActivityData.albums[x.albumType].label+' · '+x.trackCount+'곡':x.venue?ActivityData.venues[x.venue].label:x.contentType?ActivityData.content[x.contentType].label:kindLabel[x.kind]||'활동';}
function activityChoiceCards(kind,items){return `<div class="activity-choice-grid">${Object.entries(items).map(([key,v])=>`<article class="panel activity-choice"><span class="eyebrow">${kind==='single'?'ALBUM':kind==='live'?'LIVE STAGE':'ARTIST CONTENT'}</span><h2>${v.label}</h2><p>${kind==='single'?v.tracks+'곡 · 기본 제작 '+v.days+'일':kind==='live'?v.capacity.toLocaleString()+'석 · 준비 '+v.days+'일':v.desc}</p><small>${kind==='single'?'제작비 '+money(1000*v.factor)+'~'+money(7000*v.factor)+' · 제조·홍보 별도':kind==='live'?'선집행 '+money(v.cost)+' · 티켓 '+money(v.ticket)+' · 관객당 현장비 '+money(v.variable,2):'제작 '+v.days+'일 · 예산 100~600만 원'}</small>${btn('준비하기','m-activity-new',`data-kind="${kind}" data-subtype="${key}"`,'primary',!game.s.artists.length)}</article>`).join('')}</div>`;}
function albums_activity(){
  return activityHeading('앨범 준비','아티스트와 음반 종류, 방향, 예산을 정하면 제작은 자동으로 진행됩니다.')+activityChoiceCards('single',{album:ActivityData.albums.album,mini:ActivityData.albums.mini,digital:ActivityData.albums.digital})+`<div class="tip section">곡마다 따로 조작하지 않습니다. 미니앨범·정규앨범은 제작 기간과 투자비가 늘고, 발매 후 관심이 더 오래 이어집니다. 곡 수만큼 수익이 배수로 늘지는 않습니다.</div>`+panel('최근 발매한 음반',game.s.catalog.slice(-6).reverse().map(c=>releaseRow({release:c,company:game.s.company,own:true})).join('')||'<p>첫 음악을 기다리고 있습니다.</p>');
}
function concerts_activity(){return activityHeading('공연','규모보다 현재 팬층과 수익을 먼저 확인하세요. 큰 공연장은 빈 좌석과 적자의 위험도 커집니다.')+activityChoiceCards('live',ActivityData.venues)+`<div class="tip section">승인 전에 예상 관객 범위·전체 비용·손익분기 관객·예상 회사 손익을 확인할 수 있습니다. 최근 공연 반복, 신곡 발매, 팀 팬과 직원 역량이 수요에 반영됩니다. 공연 대금은 완료 후 7일 뒤 입금됩니다.</div>`;}
function content_activity(){return activityHeading('콘텐츠','작은 활동으로 팬을 만나고 다음 발매를 준비하세요.')+activityChoiceCards('cover',ActivityData.content)+`<div class="tip section">콘텐츠 자체의 직접 수입은 없습니다. 개인·팀 팬과 인지도, 다음 발매 관심을 쌓습니다. 같은 콘텐츠를 최근 30일 동안 반복하면 팬과 발매 관심의 추가 효과가 줄어듭니다. 일상·소통 콘텐츠는 신뢰와 스트레스 회복도 돕습니다.</div>`;}
function offers_activity(){
  const offers=game.s.reports.filter(r=>r.kind==='ad'||r.festivalOfferId),pending=offers.filter(r=>game.reportState(r).needsDecision),closed=offers.filter(r=>!game.reportState(r).needsDecision).slice(0,10);
  return activityHeading('외부 제안','광고와 축제·행사 섭외를 검토하세요. 수신함과 같은 제안이며 한 번만 처리됩니다.')+panel('결정할 제안 · '+pending.length,reportRows(pending))+panel('최근 처리·종료된 제안',reportRows(closed));
}
function progress_activity(){
  const jobs=game.s.jobs.filter(j=>j.kind!=='casting');
  return activityHeading('진행 중','확정한 제작·공연·촬영과 행사 일정을 함께 확인하세요.')+panel('진행 중인 활동 · '+jobs.length,jobs.map(j=>{const state=j.kind==='single'?game.productionState(j):null,progress=state?1-state.remaining/((j.baselineDue??j.due)-j.start):(game.s.day-j.start)/(j.due-j.start);return `<article class="contract-row"><div class="row between wrap"><span class="pill">${activityTypeLabel(j)}</span><strong>D-${j.due-game.s.day}</strong></div><h3>${esc(j.name)}</h3><p>${esc(j.snapshot?.name||game.entity(j.entity)?.name||'확정 아티스트')} · 완료 예정 ${date(j.due,true)}</p><div class="bar"><span style="width:${Math.max(0,Math.min(100,progress*100))}%"></span></div><p>${j.kind==='ad'?'촬영 후 잔금 '+money(j.pay):'총 승인 비용 '+money(DATA.rules.jobCost(j))}</p>${state?.paused?'<small>행사·촬영으로 제작 일시 중단 · '+date(state.resume)+' 재개</small>':''}</article>`;}).join('')||'<p>진행 중인 제작·공연·촬영이 없습니다.</p>')+panel('확정 행사',game.s.engagements.map(e=>`<article class="contract-row"><h3>${esc(e.name)}</h3><p>${esc(e.snapshot.name)} · 준비 ${date(e.start)} → 행사 ${date(e.due)}</p></article>`).join('')||'<p>예약된 행사가 없습니다. 외부 제안을 확인해 보세요.</p>');
}
function results_activity(){
  return activityHeading('활동 결과','완료한 활동의 반응과 비용, 실제 정산을 확인하세요.')+panel('최근 활동',game.s.outcomes.slice(-20).reverse().map(o=>`<details class="contract-row"><summary>${esc(o.title)} · ${activityTypeLabel(o)} · ${date(o.day)}</summary><p>완성도 ${Math.round(o.quality)} · 개인 팬 ${o.fans>=0?'+':''}${o.fans.toLocaleString()}명</p><p>선집행 제작비 ${money(o.production)}${o.capacity?' · 유료 관객 '+o.attendance.toLocaleString()+'/'+o.capacity.toLocaleString()+'명':''}</p>${o.net!==null?'<p>회사 손익 '+money(o.net)+'</p>':'<p>'+ (o.kind==='single'?'음원·음반 매출과 투자금 회수는 발매 성과에서 확인하세요.':'콘텐츠 직접 수입 없음 · 팬과 발매 관심 중심의 활동입니다.')+'</p>'}${(o.factors||[]).map(f=>'<p>'+esc(f)+'</p>').join('')}${outcomeSettlementHTML(o)}</details>`).join('')||'<p>아직 완료한 활동이 없습니다.</p>')+panel('최근 행사 결과',game.s.festivalHistory.slice(-10).reverse().map(e=>`<details class="contract-row"><summary>${esc(e.artist)} · ${esc(e.name)} · ${date(e.day)}</summary><p>신규 팬 +${e.fans.toLocaleString()}명</p>${activityStatementHTML(festivalStatement(e))}</details>`).join('')||'<p>행사 출연 기록이 없습니다.</p>');
}
function projectModal_activity(key,kind='single',subtype=''){
  const entities=game.entities;if(!entities.length)throw Error('먼저 아티스트와 계약하세요.');
  modal('새 활동 준비',`<form id="activity-form"><div class="form-grid"><div class="field"><label for="activity-entity">아티스트·팀</label><select name="entity" id="activity-entity">${entities.map(e=>`<option value="${e.key}" ${key===e.key?'selected':''}>${esc(e.name)}</option>`).join('')}</select></div><div class="field"><label for="activity-kind">활동</label><select id="activity-kind" name="kind">${[['single','앨범 준비'],['live','공연'],['cover','콘텐츠']].map(([k,n])=>`<option value="${k}" ${kind===k?'selected':''}>${n}</option>`).join('')}</select></div></div><div class="field" data-activity-field="single"><label for="activity-album">음반 종류</label><select id="activity-album" name="albumType">${Object.entries(ActivityData.albums).map(([k,v])=>`<option value="${k}" ${subtype===k?'selected':''}>${v.label} · ${v.tracks}곡 · ${v.days}일</option>`).join('')}</select></div><div class="field" data-activity-field="live"><label for="activity-venue">공연장</label><select id="activity-venue" name="venue">${Object.entries(ActivityData.venues).map(([k,v])=>`<option value="${k}" ${subtype===k?'selected':''}>${v.label} · ${v.capacity.toLocaleString()}석 · ${money(v.cost)}</option>`).join('')}</select></div><div class="field" data-activity-field="cover"><label for="activity-content">콘텐츠 종류</label><select id="activity-content" name="contentType">${Object.entries(ActivityData.content).map(([k,v])=>`<option value="${k}" ${subtype===k?'selected':''}>${v.label} · ${v.days}일</option>`).join('')}</select></div><div class="field"><label for="activity-name">작품·활동 이름</label><input id="activity-name" name="title" maxlength="30" required placeholder="우리의 다음 무대"></div><div class="form-grid"><div class="field"><label for="activity-concept">활동 방향</label><select id="activity-concept" name="concept"><option value="balanced">균형 중심</option><option value="public">대중성 중심</option><option value="creative">창작 중심</option></select></div><div class="field" id="activity-budget-field"><label for="activity-budget">제작 투자</label><select id="activity-budget" name="budget"></select><small id="activity-budget-note"></small></div></div><div data-activity-field="single" class="form-grid"><div class="field"><label for="activity-format">발매 형태</label><select id="activity-format" name="format"><option value="digital">음원 전용</option><option value="physical">실물 음반 + 음원</option></select></div><div class="field"><label for="activity-quantity">실물 초도 수량</label><select id="activity-quantity" name="quantity">${[1000,3000,10000].map(n=>`<option value="${n}">${n.toLocaleString()}장 · 제조비 ${money(n*.6)}</option>`).join('')}</select></div><div class="field"><label for="activity-promotion">사전 홍보</label><select id="activity-promotion" name="promotion">${Object.entries(DATA.promotionPlans).map(([k,v])=>`<option value="${k}">${v.name} · ${money(v.cost)} · +${v.days}일</option>`).join('')}</select></div></div><div class="tip" id="activity-preview" aria-live="polite"></div><div class="modal-actions"><button type="submit" class="primary">활동 승인</button></div></form>`,true);
  activityBudgetOptions();activityPreview();
}
function activityBudgetOptions(){
  const kind=$('#activity-kind').value,rule=DATA.rules.activity[kind],select=$('#activity-budget');select.innerHTML=rule.budgets.map(([n,l])=>`<option value="${n}">${l}</option>`).join('');
}
function activityFormValues(){
  const f=$('#activity-form'),d=new FormData(f),kind=d.get('kind'),options=kind==='single'?{albumType:d.get('albumType'),format:d.get('format'),quantity:Number(d.get('quantity')),promotion:d.get('promotion')}:kind==='live'?{venue:d.get('venue')}:{contentType:d.get('contentType')};
  return{key:d.get('entity'),kind,title:d.get('title'),budget:Number(d.get('budget')),concept:d.get('concept'),options};
}
function activityPreview(){
  const f=$('#activity-form');if(!f)return;
  const kind=$('#activity-kind').value;f.querySelectorAll('[data-activity-field]').forEach(el=>el.hidden=el.dataset.activityField!==kind);$('#activity-budget-field').hidden=kind==='live';
  const digital=$('#activity-album').value==='digital';if(digital)$('#activity-format').value='digital';$('#activity-format').disabled=digital;$('#activity-quantity').disabled=digital||$('#activity-format').value!=='physical';
  const v=activityFormValues();if(digital&&kind==='single')v.options.format='digital';
  const target=$('#activity-preview'),submit=f.querySelector('[type="submit"]');
  try{
    const p=game.activityPlan(v.key,v.kind,v.budget,v.options),q=p.quote;
    $('#activity-budget').querySelectorAll('option').forEach(o=>{const factor=kind==='single'?ActivityData.albums[v.options.albumType].factor:1;o.textContent=money(Number(o.value)*factor);});
    $('#activity-budget-note').textContent=kind==='single'?'선택한 음반 종류에 따른 제작비입니다. 제조·홍보비 별도.':'직접 수입 없이 팬·관심을 위한 투자입니다.';
    target.innerHTML=`<p>완료 예정 <strong>${date(p.due,true)}</strong> · 기본 ${p.duration}일${p.due-game.s.day>p.duration?' · 홍보·확정 행사 연장 포함':''}</p><p>제작비 ${money(q.production)}${q.discount?' (지원 할인 '+money(q.discount)+')':''} · 제조 ${money(q.manufacturing)} · 홍보 ${money(q.promo)}</p><p><strong>지금 승인할 총액 ${money(q.total)}</strong></p>`;
    if(kind==='live'){
      const c=game.concertPreview(v.key,v.options.venue),lo=c.low,hi=c.high;
      target.innerHTML+=`<p>예상 관객 <strong>${lo.attendance.toLocaleString()}~${hi.attendance.toLocaleString()} / ${c.capacity.toLocaleString()}명</strong></p><p>예상 총비용 ${money(lo.totalCost)}~${money(hi.totalCost)} · 제작·현장·아티스트 배분 포함</p><p>손익분기 관객 <strong>${c.breakEven===null?'달성 불가':c.breakEven.toLocaleString()+'명'}${c.breakEven>c.capacity?' · 수용 좌석 초과':''}</strong></p><p>예상 회사 손익 <strong>${money(lo.net)}~${money(hi.net)}</strong></p><small>현재 팬·팀·직원 기준, 완성도 40~85 가정입니다. 완료일까지의 변화로 실제 관객은 달라집니다. 일 훈련·월 고정비 별도, 입금은 완료 후 7일 뒤입니다.</small>`;
    }
    if(kind==='cover'){const e=game.contentEffect(game.entity(v.key),v.options.contentType);target.innerHTML+=`<p>직접 수입 없음 · 최근 30일 같은 콘텐츠 ${e.repeats}회 · 팬·발매 관심 추가 효과 ${Math.round(e.multiplier*100)}%</p>`;}
    if(kind==='single'&&v.options.format==='physical')target.innerHTML+='<p>음반 판매가 '+money(v.options.albumType==='album'?3.5:3,2)+' · 장당 제조비 '+money(.6,2)+'</p>';
    if(kind==='single')target.innerHTML+='<small>실물 미판매 재고의 위험이 있습니다. 제작비는 선집행되며 발매 후 매출은 매주 정산됩니다.</small>';
    if(!p.allowed)target.innerHTML+='<p class="negative">'+p.reasons.map(esc).join(' · ')+'</p>';
    if(game.s.cash<q.total)target.innerHTML+='<p class="negative">승인 자금이 부족합니다.</p>';
    submit.disabled=!p.allowed||game.s.cash<q.total;
  }catch(e){target.textContent=e.message;submit.disabled=true;}
}
function managementClick_activity(action,d){if(action==='m-activity-new')projectModal_activity(d.entity,d.kind,d.subtype);}
UIEvents.onChange('activities',ev=>{if(!ev.target.closest('#activity-form'))return;if(ev.target.id==='activity-kind')activityBudgetOptions();activityPreview();});
$('#modal-root').addEventListener('submit',ev=>{
  if(ev.target.id!=='activity-form')return;ev.preventDefault();
  try{const v=activityFormValues();if(v.kind==='single'&&v.options.albumType==='digital')v.options.format='digital';mutate(()=>game.startProject(v.key,v.kind,v.title,v.budget,v.concept,v.options),'활동을 승인했습니다.');}catch(e){$('#modal-error').textContent=e.message;}
});

;
/* FILE src/ui-actions.js */
'use strict';
// Unique action IDs. Add new actions here; feature handlers never chain by script order.
const UI_ACTIONS = Object.freeze({
  "m-activity-new": managementClick_activity,
  "m-development": managementClick_concept,
  "m-development-tab": managementClick_concept,
  "m-weekly-clear": managementClick_concept,
  "m-month-forecast": managementClick_concept,
  "m-festival": managementClick_season,
  "m-chart-scope": managementClick_season,
  "m-chart-more": managementClick_season,
  "m-awards": managementClick_season,
  "m-award-year": managementClick_season,
  "m-inbox-filter": managementClick_campaign,
  "m-inbox-category": managementClick_campaign,
  "m-report-unread": managementClick_campaign,
  "m-renew": managementClick_management,
  "m-debut": managementClick_management,
  "m-release-trainee": managementClick_management,
  "m-leave-confirm": managementClick_management,
  "m-trainee-release": managementClick_management,
  "m-leave": managementClick_management,
  "m-team-confirm": managementClick_management,
  "m-team-apply": managementClick_management,
  "m-team": managementClick_management,
  "m-transfer": managementClick_management,
  "m-transfer-confirm": managementClick_management,
  "m-transfer-apply": managementClick_management,
  "m-saves": managementClick_progression,
  "m-slot-save-confirm": managementClick_progression,
  "m-slot-save": managementClick_progression,
  "m-slot-load": managementClick_progression,
  "m-point-load": managementClick_progression,
  "m-restore-apply": managementClick_progression,
  "m-incident-open": managementClick_progression,
  "m-incident-respond": managementClick_progression,
  "m-slot-delete-confirm": managementClick_market,
  "m-slot-delete": managementClick_market,
  "m-points-clear-confirm": managementClick_market,
  "m-points-clear": managementClick_market,
  "m-release": managementClick_market,
  "m-release-scope": managementClick_market,
  "m-chart": managementClick_market,
  "m-compare-select": managementClick_market,
  "m-compare": managementClick_market,
  "m-reprint": managementClick_market,
  "m-reprint-apply": managementClick_market,
  "m-trainee-filter": managementClick_market,
  "m-personal": managementClick_personality,
  "m-staff-detail": managementClick_operations,
  "m-recruit-filter": managementClick_operations,
  "m-trainee-detail": managementClick_operations,
  "m-growth-range": managementClick_operations,
  "m-calendar-month": managementClick_operations,
  "m-calendar-today": managementClick_operations,
  "m-calendar-day": managementClick_operations,
  "m-calendar-event": managementClick_operations,
  "m-goal-filter": managementClick_evolution,
  "m-skip-moments": managementClick_evolution,
  "m-memory": managementClick_evolution,
  "m-story": managementClick_evolution,
  "m-story-choice": managementClick_evolution,
  "m-moment": managementClick_evolution,
  "m-next-moment": managementClick_evolution,
  "m-moments": managementClick_evolution,
  "m-offer": managementClick_evolution,
  "m-offer-accept": managementClick_evolution,
  "m-all-tasks": managementClick_evolution,
  "m-sound": managementClick_evolution
});
function dispatchManagementAction(action, data) {
  const handler = UI_ACTIONS[action];
  if (!handler) throw Error('지원하지 않는 동작입니다: ' + action);
  return handler(action, data);
}


;
/* FILE src/studio-ui.js */
'use strict';
// Presentation only: every action delegates to the existing game handlers.
let studioArchiveOpen = false;
function home_studio() {
  const s = game.s, tasks = todayTasks(), events = scheduleEvents()
    .filter(x => x.end >= s.day && x.start <= s.day + 7)
    .sort((a, b) => Math.max(s.day, a.start) - Math.max(s.day, b.start));
  const people = [...s.artists, ...s.trainees], focus = spotlightEntity();
  const forecast = game.cashForecast(), outgoing = forecast.find(x => x.amount < 0), incoming = forecast.find(x => x.amount > 0);
  const profit = s.monthIn - s.monthOut, urgent = tasks.filter(t => t.priority === 0).length;
  const sectionHead = (title, note, action = '') => `<div class="studio-section-head"><div><h2>${title}</h2><p>${note}</p></div>${action}</div>`;
  return `<div class="studio-dashboard">
    <section class="studio-hero" aria-label="기획사 운영 현황">
      <div class="studio-hero-copy"><span class="eyebrow">YOUR AGENCY, YOUR NEXT STAGE</span><h1>오늘도, 다음 무대를 향해.</h1><p>${esc(s.company)}의 이야기는 오늘도 이어집니다.<br>${focus?`${esc(focus.name)}의 다음 활동을 함께 준비해 보세요.`:'첫 인재를 만나 우리만의 음악을 시작하세요.'}</p><div class="row wrap">${focus?btn('다음 활동 준비 '+ico('arrow'),'project-modal',`data-entity="${focus.key}"`,'primary'):btn('첫 인재 만나기 '+ico('arrow'),'casting-modal','','primary')}${btn('회사 운영 살펴보기','nav','data-page="company"','hero-secondary')}</div><span class="studio-hero-caption">${esc(DATA.stageNames[game.stage])} · ${s.artists.length}명의 아티스트 · ${s.trainees.length}명의 연습생</span></div><div class="studio-hero-art"><img src="${focus?DATA.roster[focus.members[0].id].image:'assets/office.webp'}" alt="${focus?esc(focus.name)+' · 오늘의 아티스트':'햇빛이 드는 기획사 사무실'}"><span>${focus?'ARTIST SPOTLIGHT':'OUR FIRST CHAPTER'}</span></div>
    </section>
    <section class="studio-metrics" aria-label="핵심 경영 지표">
      <article class="studio-metric"><span class="studio-metric-icon">${ico('wallet')}</span><div><small>보유 자금</small><strong class="${s.cash<0?'negative':''}">${money(s.cash)}</strong><span>현재 사용할 수 있는 운영 자금</span></div></article>
      <article class="studio-metric"><span class="studio-metric-icon">${ico('chart')}</span><div><small>이번 달 현금 수지</small><strong class="${profit<0?'negative':'positive'}">${profit>0?'+':''}${money(profit)}</strong><span>기록된 입금 − 지출 · 대출 포함</span></div></article>
      <article class="studio-metric"><span class="studio-metric-icon">${ico('people')}</span><div><small>함께하는 인재</small><strong>${people.length}<em>명</em></strong><span>아티스트 ${s.artists.length} · 연습생 ${s.trainees.length}</span></div></article>
      <article class="studio-metric"><span class="studio-metric-icon">${ico('calendar')}</span><div><small>진행 중인 일정</small><strong>${s.jobs.length+(s.engagements?.length||0)}<em>건</em></strong><span>확인이 필요한 업무 ${tasks.length}건</span></div></article>
    </section>
    <div class="studio-workspace"><div class="studio-primary">
      <section class="panel studio-tasks">${sectionHead('오늘 결정할 일',urgent?`기한이 가까운 업무 ${urgent}건을 먼저 확인하세요.`:'중요한 결정은 대표에게, 실무는 직원에게.',tasks.length?`<span class="studio-count">${tasks.length}</span>`:'')}${tasks.length?`<div class="studio-task-list">${tasks.slice(0,5).map((t,i)=>btn(`<span class="studio-task-mark ${t.priority===0?'urgent':''}">${t.priority===0?ico('mail'):String(i+1).padStart(2,'0')}</span><span class="studio-task-copy"><strong>${esc(t.label)}</strong><small>${t.priority===0?'우선 확인이 필요한 업무':'다음 성장을 위한 선택'}</small></span>${ico('arrow')}`,t.action,t.args,'studio-task')).join('')}</div>${tasks.length>5?btn('전체 업무 '+tasks.length+'건 보기','m-all-tasks','','link section'):''}`:`<div class="studio-empty">${ico('check')}<h3>급한 업무를 모두 확인했어요.</h3><p>다음 활동을 준비하거나 하루를 진행해 보세요.</p></div>`}</section>
      ${!s.guideHidden?`<details class="studio-guide" ${s.day===0?'open':''}><summary>첫 운영 가이드 <span>시작부터 첫 정산까지</span></summary>${guideCard()}</details>`:''}
      <section class="panel studio-roster">${sectionHead('함께 성장하는 아티스트','작은 연습이 쌓여, 다음 무대가 됩니다.',btn('전체 보기','nav',`data-page="${s.artists.length?'artists':'training'}"`,'link small'))}${people.length?`<div class="studio-people">${people.slice(0,6).map(a=>{const d=DATA.roster[a.id],trainee=s.trainees.some(t=>t.id===a.id);return btn(`<img src="${d.image}" alt="" loading="lazy"><span><strong>${esc(d.name)}</strong><small>${trainee?'연습생':DATA.labels[d.type]+' 아티스트'}</small><span class="studio-condition ${a.energy<40?'tired':''}">컨디션 ${a.energy<40?'회복 필요':a.energy<70?'보통':'좋음'}</span><span class="bar"><span style="width:${Math.max(0,Math.min(100,a.energy))}%"></span></span></span>`,trainee?'m-trainee-detail':'artist',`data-id="${a.id}"`,'studio-person');}).join('')}</div>`:`<div class="studio-empty"><h3>우리의 첫 아티스트를 기다리고 있어요.</h3><p>공개 오디션과 인재 발굴에서 새로운 가능성을 만나보세요.</p>${btn('캐스팅 살펴보기','nav','data-page="casting"','soft')}</div>`}</section>
    </div><aside class="studio-secondary" aria-label="일정과 자금 계획">
      <section class="panel studio-agenda">${sectionHead('다가오는 일정','오늘부터 일주일',btn('전체 일정','nav','data-page="schedule"','link small'))}<div class="studio-event-list">${events.slice(0,5).map(x=>btn(`<span class="studio-event-date">${Math.max(s.day,x.start)===s.day?'오늘':'D-'+(x.start-s.day)}</span><span><strong>${esc(x.title)}</strong><small>${date(Math.max(s.day,x.start))}${x.end>x.start?' ~ '+date(x.end):''}</small></span>`, 'nav',`data-page="${x.page}"`,'studio-event')).join('')||'<div class="studio-empty"><p>예정된 주요 일정이 없습니다.<br>새 활동을 준비해 보세요.</p></div>'}</div></section>
      <section class="panel studio-cash">${sectionHead('앞으로의 자금 흐름','예정과 실제 지출을 구분해 확인하세요.')}<div class="studio-cash-item"><span class="pill">가까운 지출</span><strong>${outgoing?money(-outgoing.amount):'확정 지출 없음'}</strong><small>${outgoing?date(outgoing.day)+' · '+esc(outgoing.label):'등록된 지출이 없습니다.'}</small></div><div class="studio-cash-item"><span class="pill green">다음 입금</span><strong>${incoming?money(incoming.amount):'새로운 수익을 준비해요'}</strong><small>${incoming?date(incoming.day)+' · '+esc(incoming.type)+' · '+esc(incoming.label):'활동과 작품 정산이 여기에 표시됩니다.'}</small></div><p class="studio-note">현재 기록에 따른 예정 금액입니다. 추가 훈련·제작비와 향후 판매 변화는 포함하지 않습니다.</p>${btn('재정 자세히 보기','nav','data-page="finance"','soft')}</section>
    </aside></div>
    <details class="studio-archive" ${studioArchiveOpen?'open':''}><summary>함께한 기록과 최근 성과 <span>진행 기록 · 기념 순간 · 발매작</span></summary><div class="studio-archive-body">${spotlight()}${recentWeekHTML()}${panel('우리의 최근 순간',s.moments.slice(-3).reverse().map(m=>`<div class="contract-row"><small>${date(m.day)}</small><h3>${esc(m.title)}</h3>${btn('다시 보기','m-moment',`data-id="${m.id}"`,'link')}</div>`).join('')||'<p>첫 계약부터 우리의 기록이 쌓입니다.</p>')}${panel('최근 발매',s.catalog.slice(-3).reverse().map(c=>releaseRow({release:c,company:s.company,own:true})).join('')||'<p>첫 음악을 기다리고 있습니다.</p>')}</div></details>
  </div>`;
}

;
/* FILE src/ui-bindings.js */
'use strict';
// Final screen ownership. Feature helpers have unique names; no global overwrites.
const UI_IMPLEMENTATIONS = Object.freeze({
  home: home_concept,
  artistModal: artistModal_concept,
  inbox: inbox_campaign,
  charts: charts_season,
  scheduleEvents: scheduleEvents_season,
  projects: albums_activity,
  reportDetail: reportDetail_season,
  finance: finance_campaign,
  projectModal: projectModal_activity,
  budgetPreview: budgetPreview_season,
  settings: settings_evolution,
  unitModal: unitModal_evolution,
  mutate: mutate_evolution,
  talentModal: talentModal_operations,
  staffScreen: staffScreen_evolution,
  training: training_operations,
  teams: teams_evolution,
  company: company_market,
  industry: industry_progression,
  goals: goals_evolution,
  managementClick: dispatchManagementAction,
  schedule: schedule_operations,
  applyRestore: applyRestore_dayfeedback,
  todayTasks: todayTasks_season,
  releaseModal: releaseModal_season,
  showAdvanceNotice: showAdvanceNotice_evolution,
  staffDetail: staffDetail_campaign,
  traineeDetail: traineeDetail_concept
});
function home(... args) {
  return UI_IMPLEMENTATIONS.home(... args);
}
function artistModal(... args) {
  return UI_IMPLEMENTATIONS.artistModal(... args);
}
function reportDetail(... args) {
  return UI_IMPLEMENTATIONS.reportDetail(... args);
}
function finance(... args) {
  return UI_IMPLEMENTATIONS.finance(... args);
}
function projectModal(... args) {
  return UI_IMPLEMENTATIONS.projectModal(... args);
}
function budgetPreview(... args) {
  return UI_IMPLEMENTATIONS.budgetPreview(... args);
}
function settings(... args) {
  return UI_IMPLEMENTATIONS.settings(... args);
}
function unitModal(... args) {
  return UI_IMPLEMENTATIONS.unitModal(... args);
}
function mutate(... args) {
  return UI_IMPLEMENTATIONS.mutate(... args);
}
function talentModal(... args) {
  return UI_IMPLEMENTATIONS.talentModal(... args);
}
function staffScreen(... args) {
  return UI_IMPLEMENTATIONS.staffScreen(... args);
}
function training(... args) {
  return UI_IMPLEMENTATIONS.training(... args);
}
function teams(... args) {
  return UI_IMPLEMENTATIONS.teams(... args);
}
function company(... args) {
  return UI_IMPLEMENTATIONS.company(... args);
}
function industry(... args) {
  return UI_IMPLEMENTATIONS.industry(... args);
}
function goals(... args) {
  return UI_IMPLEMENTATIONS.goals(... args);
}
function managementClick(... args) {
  return UI_IMPLEMENTATIONS.managementClick(... args);
}
function schedule(... args) {
  return UI_IMPLEMENTATIONS.schedule(... args);
}
function applyRestore(... args) {
  return UI_IMPLEMENTATIONS.applyRestore(... args);
}
function todayTasks(... args) {
  return UI_IMPLEMENTATIONS.todayTasks(... args);
}
function releaseModal(... args) {
  return UI_IMPLEMENTATIONS.releaseModal(... args);
}
function showAdvanceNotice(... args) {
  return UI_IMPLEMENTATIONS.showAdvanceNotice(... args);
}
function staffDetail(... args) {
  return UI_IMPLEMENTATIONS.staffDetail(... args);
}
function traineeDetail(... args) {
  return UI_IMPLEMENTATIONS.traineeDetail(... args);
}
function inbox(... args) {
  return UI_IMPLEMENTATIONS.inbox(... args);
}
function projects(... args) {
  return UI_IMPLEMENTATIONS.projects(... args);
}
function charts(... args) {
  return UI_IMPLEMENTATIONS.charts(... args);
}
function scheduleEvents(... args) {
  return UI_IMPLEMENTATIONS.scheduleEvents(... args);
}


;
/* FILE src/app-bootstrap.js */
'use strict';
// app-bootstrap: see docs/MAINTENANCE.md for ownership and loading order.
title();

